//
//  DisplayViewController.h
//  TASKTOCHECKINPUT
//
//  Created by BL@CK on 4/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisplayViewController : UIViewController <UITextFieldDelegate>
{
    IBOutlet UITextField *number;
    IBOutlet UITextField *character;
    IBOutlet UITextField *symbol;
}
-(IBAction)btnTouched:(id)sender;

@end
