//
//  AppDelegate.h
//  TASKTOCHECKINPUT
//
//  Created by BL@CK on 4/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
