<p><a href="#" target="_blank" style="display: flex; justify-content: center; align-items: center;">
    <img alt="" title="" height="38px" src="{{env('AWS_S3_PATH')}}logo11.png" width="138px">
  </a></p>

<p>Hi!  We received a request to reset the password for the Fisio account associated with this email address.</p>

<p>To reset your password, <a href="{{$link}}">click here</a>.</p>

<p>If you didn't make this request, or no longer need to reset your password, you can ignore this email.</p>

<p>The Fisio Team</p>