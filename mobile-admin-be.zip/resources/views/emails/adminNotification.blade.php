<!DOCTYPE html>
<html>
<head>
    <title>New User Signup Notification</title>
</head>
<body>
    <p>Hi Kurt,</p>
    <p>A new user has signed up:</p>
    <ul>
        <li><strong>Name:</strong> {{ $name }}</li>
        <li><strong>Email:</strong> {{ $email }}</li>
    </ul>
    <p>Best regards,<br>Team Fisio</p>
</body>
</html>
