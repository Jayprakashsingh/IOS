<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
  </head>
    <style>
      body {
        text-align: center;
        padding: 40px 0;
        background: #EBF0F5;
        width: 100vw;
        min-height: 100dvh;
      }
        h1 {
          color: #f58124;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-weight: 900;
          font-size: 40px;
          margin-bottom: 10px;
        }
        p {
          color: #404F5E;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-size:20px;
          margin: 0;
        }
      i {
        color: #f58124;
        font-size: 100px;
        line-height: 170px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }
    </style>
    <body>
      <div class="card">
        <a href="#" target="_blank" style="display: flex; justify-content: center; align-items: center;">
          <img alt="" title="" height="38px" src="{{env('AWS_S3_PATH')}}logo11.png" width="138px">
        </a>
      
        <div style="border-radius:170px; height:170px; width:170px; background: #F8FAF5; margin:0 auto;margin-top: 30px;">
          <i class="checkmark">✓</i>
        </div>
        <h1>Success</h1> 
        <p>Email Confirmation Success:<br/> Go back to the app to login.</p>
        {{-- <p>Your email is verified;<br/> Now you can login and enjoy Fisio™</p> --}}
      </div>
    </body>
</html>