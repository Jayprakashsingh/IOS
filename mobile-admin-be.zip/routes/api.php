<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\AdminController;
use App\Http\Controllers\AppleAuthController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CountryInfoController;
use App\Http\Controllers\RevenueCatWebhookController;
use App\Http\Controllers\StripeWebhookController;

// use App\Http\Controllers\StripeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('/contact-us-support', [AuthController::class, 'contactUs']);
Route::get('/delete-users/{id}', [AuthController::class, 'deleteUser']);
Route::get('/faq', [AuthController::class, 'getFaq']);
Route::get('/terms-service', [AuthController::class, 'getTermServcie']);
Route::get('/privacy-policy', [AuthController::class, 'getPrivacyPolicy']);
Route::get('/information-center', [AuthController::class, 'getInformationCenter']);
Route::post('/stripe/webhook', [StripeWebhookController::class, 'handleWebhook']);
Route::post('/webhooks/revenuecat', [RevenueCatWebhookController::class, 'handleWebhook']);
Route::group([
    'middleware' => 'api',
    'prefix' => 'auth'
], function($router){
    //Auth related routes
    Route::get('/countries', [CountryInfoController::class, 'index']);
    Route::get('/timezone', [AuthController::class, 'getTimezone']);
    Route::get('/country-timezone', [AuthController::class, 'getCountryTimezone']);
    Route::get('/search-category', [UserController::class, 'getSearchCategory']);
    Route::get('/search', [UserController::class, 'getSearch']);
    Route::post('/login',[AuthController::class,'login']);
    // Route::post('/apple/verify', [AppleAuthController::class, 'verifyAppleToken']);
    Route::post('/social-login',[AuthController::class,'social_login']);
    
    Route::post('/logout',[AuthController::class,'logout']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/re-send-email', [AuthController::class, 'resendEmail']);
    
    //general setting api
    Route::get('/general-setting', [UserController::class, 'getGeneralSetting']);
    Route::post('/general-setting', [UserController::class, 'updateGeneralSetting']);

    Route::post('/payment', [UserController::class, 'updatePayment']);
    Route::post('/coachreview-payment', [UserController::class, 'updateCoachReviewPayment']);
    Route::post('/payment-free', [AdminController::class, 'updatePaymentFreeToUser']);
    Route::get('/payment-method/{user_id}', [AdminController::class, 'getPaymentMethodOfUser']);
    Route::get('/payment-history/{user_id}', [AdminController::class, 'getPaymentHistoryOfUser']);
    Route::get('/payment-history-all', [AdminController::class, 'getPaymentHistoryAll']);
    Route::get('/payment-plan', [UserController::class, 'getPaymentPlan']);
    Route::get('/plans', [AdminController::class, 'getPlan']);
    Route::post('/cancel-plan', [UserController::class, 'postCancelPlan']);
    Route::get('/purchase-history', [UserController::class, 'getPurchaseHistory']);
    Route::get('/get-customer-card-user/{user_id}', [AdminController::class, 'getCustomerCardByUser']);

    // Route::post('/create-session',  [StripeController::class, 'createSession']);
    Route::post('/stripe/create-customer', [UserController::class, 'createCustomer']);
    Route::get('/stripe/list-card', [UserController::class, 'getCustomerCard']);
    Route::delete('/stripe/delete-card/{cardId}', [UserController::class, 'deleteCustomerCard']);
    Route::post('/stripe/default-card/{cardId}', [UserController::class, 'makeDefaultCard']);
    Route::post('/stripe/switch-plan', [UserController::class, 'switchPlanPayment']);
    Route::post('/stripe/cancel-plan', [UserController::class, 'cancelSubscription']);
    Route::post('/stripe/update-payment', [UserController::class, 'updateSubscription']);
    // Route::get('/user-purchase-history/{user_id}', [AdminController::class, 'getPurchaseHistory']);



      //Admin-user crud
    Route::get('/get-admin-list', [AdminController::class, 'getAdminList']);
    Route::get('/get-coach-list', [AdminController::class, 'getCoachList']);
    Route::post('/users/{id}', [AdminController::class, 'updateUser']);
    Route::delete('/users/{id}', [AdminController::class, 'deleteUser']);

    //basic welcome pages routes
    Route::get('/getwelcomeimages', [UserController::class, 'getImages']); 
    Route::post('/display-images', [UserController::class, 'postImages']);
    Route::delete('/display-images/{id}', [UserController::class, 'deleteImages']);
    Route::post('/confirmcheck', [UserController::class, 'confirmcheck']);
    Route::post('/confirm_process', [UserController::class, 'confirmProcess']);
    Route::post('/verify-password-link', [UserController::class, 'verifyPasswordLink']);
    Route::post('/registrationProcessCheck', [UserController::class, 'registrationProcessCheck']);

    Route::post('/send-push-notification', [AdminController::class, 'sendPushNotificationToUsers']);
    Route::post('/recall-card-setting-update', [AdminController::class, 'recallCardSettingUpdate']);
    //Admin recall card crud
    Route::post('/recall-cards', [AdminController::class, 'storeRecallCards']);
    Route::delete('/recall-cards/{id}', [AdminController::class, 'deleteRecallCards']);
    Route::post('/user-recall-updates', [UserController::class, 'storeUserRecallCardUpdate']);
    Route::get('/recall-cards', [AdminController::class, 'getRecallCards']);
    Route::get('/user-recall-cards/{session_id?}', [UserController::class, 'getRecallCardsByUser']);
    Route::get('/user-recall-cards-graph', [UserController::class, 'getUserRecallCardGraph']);
    
    //Streak history for app user 
    Route::get('/user-streaks', [UserController::class, 'getStreakHistoryByUser']);


    //Affiliate Deeplinks
    Route::get('/get-affiliate-deeplinks', [AdminController::class, 'getUserAffiliateDeeplinks']);

    //Admin question crud
    Route::post('/questions', [AdminController::class, 'storeQuestion']);
    Route::post('/drag-questions', [AdminController::class, 'dragQuestion']);
    Route::get('/questions', [AdminController::class, 'getQuestion']);
    Route::put('/questions', [AdminController::class, 'updateQuestion']);
    Route::delete('/questions/{id}', [AdminController::class, 'deleteQuestion']);

    //Software Update
    Route::post('/update-app', [AdminController::class, 'storeForceUpdate']);
    Route::delete('/update-app/{id}', [AdminController::class, 'deleteForceUpdate']);
    Route::get('/update-app', [AdminController::class, 'getForceUpdate']);

    Route::get('/force-update-app/{device_type}', [UserController::class, 'getForceUpdateApp']);
    Route::post('/force-update-app', [UserController::class, 'storeForceUpdateApp']);

    //App side self report on object api
    Route::post('/user-self-report', [UserController::class, 'storeUserSelfReport']);


    Route::post('/user-self-check-audit', [UserController::class, 'storeUserSCA']);
    Route::get('/user-self-check-audit', [UserController::class, 'getUserSCAByFundamental']);
    Route::get('/user-self-check-audit-history/{fundamental_id}', [UserController::class, 'getUserSCAHistoryByFundamental']);

    //App side self check check on object api
    Route::post('/user-self-check-check', [UserController::class, 'storeUserSelfCheckCheck']);
    Route::get('/user-self-check-check-history', [UserController::class, 'getUserSelfCheckCheckHistory']);

    //App side weekly report by user api
    Route::post('/user-weekly-report', [UserController::class, 'storeUserWeeklyReport']);

    //App side shot-check api's crud
    Route::post('/user-shot-check', [UserController::class, 'postUserShotCheck']);
    Route::get('/user-shot-check', [UserController::class, 'getUserShotCheck']);
    Route::get('/shot-check', [AdminController::class, 'getShotCheck']);
    Route::get('/user-shot-check-history', [UserController::class, 'getUserShotCheckHistory']);
    Route::get('/user-shot-check-graph/{type?}', [UserController::class, 'getUserShotCheckGraph']);
    Route::post('/user-shot-check-erase', [UserController::class, 'eraseUserShotCheck']);

    //App side trust-hole api's crud
    Route::post('/user-trust-hole', [UserController::class, 'postUserTrustHole']);
    Route::post('/user-trust-hole-erase', [UserController::class, 'eraseUserTrustHole']);
    Route::get('/user-trust-hole', [UserController::class, 'getUserTrustHole']);
    Route::get('/trust-hole', [AdminController::class, 'getTrustHole']);
    Route::get('/user-trust-hole-graph/{type?}', [UserController::class, 'getUserTrustHoleGraph']);
    Route::get('/user-trust-hole-history/{type?}', [UserController::class, 'getUserTrustHoleHistory']);
    Route::get('/user-trust-reps-summary', [UserController::class, 'getUserTrustRepsSummary']);
    Route::get('/user-reps-summary', [UserController::class, 'getUserRepsSummary']);
    Route::post('/user-manual-reps', [UserController::class, 'postManualUserReps']);

    Route::get('/fundamentals', [AdminController::class, 'getFundamentals']);
    Route::post('/fundamental', [AdminController::class, 'updateFundamental']);

    //Admin guide api
    Route::get('/guide', [AdminController::class, 'getGuide']);
    Route::post('/guide', [AdminController::class, 'postGuide']);
    Route::post('/guide_fundamentals', [AdminController::class, 'postGuideFundamentals']);
    Route::delete('/guide_fundamentals/{id}/{guide_id}', [AdminController::class, 'deleteGuideFundamentals']);
    //App side  guide api
    Route::get('/user-guide-fundamentals/{id}/{guide_id}', [UserController::class, 'getUserGuideFundamental']);
    Route::get('/user-guide', [UserController::class, 'getUserGuide']);


    //App side folder api's crud
    Route::post('/folder', [UserController::class, 'updateFolder']);
    Route::get('/folder', [UserController::class, 'getFolder']);
    Route::get('/deleted-folder', [UserController::class, 'getDeletedFolder']);
    Route::delete('/folder/{id}', [UserController::class, 'deleteFolder']);

    //App side notes api's crud
    Route::post('/notes', [UserController::class, 'updateNote']);
    Route::get('/notes/{folder_id?}', [UserController::class, 'getNote']);
    Route::delete('/notes/{id}', [UserController::class, 'deleteNote']);
    Route::post('/pin-note/{note_id}', [UserController::class, 'pinNotes']);
    Route::post('/allow-notification/{type}', [UserController::class, 'allowNotification']);

    //App side reports api's crud
    Route::get('/reports', [AdminController::class, 'getReport']);
    Route::post('/weekly-rating-switch/{user_id}', [AdminController::class, 'weeklyRatingSwitchForUser']);
    // App side forgot and confirm password routes
    Route::post('/remind-later/{type}', [UserController::class, 'remindLater']);
    Route::post('/forgotpassword', [UserController::class, 'forgotpassword']);
    Route::post('/send-resetpasswordLink', [AdminController::class, 'sendresetpasswordLink']);
    Route::post('/confirm-password', [UserController::class, 'confirmPassword']);
    Route::post('/confirm-password-app', [UserController::class, 'confirmPasswordApp']);
    Route::post('/verify-password-app', [UserController::class, 'verifyPasswordApp']);
    //App side user on board routes 
    Route::post('/user-questions-answer', [UserController::class, 'storeUserQuestionAnswer']);
    Route::post('/user-training-plan', [UserController::class, 'storeUserTrainPlan']);
    Route::post('/user-contact-person', [UserController::class, 'storeUserContactPerson']);
   
    
    // App side user profile routes
    Route::get('/profile', [UserController::class, 'getProfile']);
    Route::get('/profile-detail/{id}', [UserController::class, 'getProfileById']);
    Route::post('/profile', [UserController::class, 'updateProfile']);
    Route::post('/profile-picture', [UserController::class, 'updateProfilePicture']);
    
    // Training intention crud routes
    Route::get('/training-intention', [AdminController::class, 'getTrainigIntention']);
    Route::post('/training-intention', [AdminController::class, 'updateTrainigIntention']);
    Route::delete('/training-intention/{id}', [AdminController::class, 'deleteTrainigIntention']);

    // Users friends updaye and delete crud routes
    Route::post('/contact-support', [UserController::class, 'updateFriendSupport']);
    Route::delete('/contact-support/{id}', [UserController::class, 'deleteFriendSupport']);

    // FAQ Crud routes
    Route::post('/faq', [AdminController::class, 'updateFaq']);
    Route::get('/faq', [AdminController::class, 'getFaq']);
    Route::delete('/faq/{id}', [AdminController::class, 'deleteFaq']);

    Route::post('/trustKey', [AdminController::class, 'updateTrustKey']);
    Route::get('/trustKey', [AdminController::class, 'getTrustKey']);
    Route::delete('/trustKey/{id}', [AdminController::class, 'deleteTrustKey']);

    // App side basic routes
    Route::get('/terms-service', [UserController::class, 'getTermServcie']);
    Route::get('/about', [UserController::class, 'getAboutScreen']);
    Route::post('/user-reminder', [UserController::class, 'updateUserReminder']);
    Route::post('/timezone', [UserController::class, 'postTimezone']);
    Route::post('/user-daily-reminder', [UserController::class, 'userDailyReminder']);
    Route::get('/user-daily-reminder', [UserController::class, 'getUserDailyReminder']);
    //Admin About fisio 
    Route::post('/about_fisio', [AdminController::class, 'postAboutFisio']);
    Route::get('/about_fisio', [AdminController::class, 'getAboutFisio']);
    Route::delete('/about_fisio/{id}', [AdminController::class, 'deleteAboutFisio']);
    Route::post('/order_about_fisio', [AdminController::class, 'updateOrderAboutFisio']);
    Route::post('/order_faq', [AdminController::class, 'updateOrderFAQ']);
    Route::get('/information-center', [UserController::class, 'getInformationCenter']);
    Route::get('/homepage', [UserController::class, 'homepage']);
    Route::post('/contact-us', [AdminController::class, 'updateContactUs']);
    

    // Tag Crud routes
    Route::post('/tags', [AdminController::class, 'updateTags']);
    Route::delete('/tags/{id}', [AdminController::class, 'deleteTags']);
    Route::get('/tags', [AdminController::class, 'getTags']);

    // App side basic dropdown like 1)object type 2) category type 3) session type
    Route::get('/object-type', [UserController::class, 'getObjectType']);
    Route::get('/category-type', [UserController::class, 'getCategoryType']);
    Route::get('/session-type', [UserController::class, 'getSessionType']);

    // Admin side user object crud routes
    Route::get('/get-user-objects', [AdminController::class, 'getUserObjects']);
    Route::post('/user-object-type', [AdminController::class, 'updateUserObjectType']);
    Route::get('/user-object-type-session/{session_id}', [AdminController::class, 'getUserObjectTypeBySessionID']);
    Route::get('/user-object-type', [AdminController::class, 'getUserObjectType']);
    Route::get('/drills', [AdminController::class, 'getUserObjectTypeDrillsOnly']);
    Route::delete('/user-object-type/{id}', [AdminController::class, 'deleteUserObjectType']);

    //  Admin side user session crud routes
    Route::post('/session', [AdminController::class, 'updateSession']);
    Route::get('/session', [AdminController::class, 'getSession']);
    Route::delete('/session/{id}', [AdminController::class, 'deleteSession']);

    //  Admin side user session crud routes
    Route::post('/unit', [AdminController::class, 'updateUnit']);
    Route::get('/unit', [AdminController::class, 'getUnit']);
    Route::delete('/unit/{id}', [AdminController::class, 'deleteUnit']);

    //  Admin side user session crud routes
    Route::post('/group', [AdminController::class, 'updateGroup']);
    Route::post('/freeUser', [AdminController::class, 'updateFreeUser']);
    Route::post('/skipReminder', [AdminController::class, 'updateSkipReminder']);
    Route::get('/freeUser', [AdminController::class, 'getFreeUser']);
    Route::post('/assign-group-user', [AdminController::class, 'assignGroupUser']);
    Route::get('/group', [AdminController::class, 'getGroup']);
    Route::delete('/group/{id}', [AdminController::class, 'deleteGroup']);

    // Api for app for unit and session
    Route::get('/unit-program/{slug}', [UserController::class, 'getUnitProgram']);
    Route::get('/session-overview/{id}/{unit_id?}', [UserController::class, 'getSessionOverview']);
    Route::get('/session-detail/{id}/{unit_id?}', [UserController::class, 'getSessionDetail']);
    Route::get('/complete-mark/{id}/{session_id}/{unit_id?}', [UserController::class, 'getCompleteMark']);
    Route::get('/session-closing/{session_id}/{unit_id?}', [UserController::class, 'getSessionClosingDetails']);
    Route::post('/object-bookmark/{object_id}', [UserController::class, 'updateUserBookmark']);

    Route::post('/coach_review', [AdminController::class, 'uploadCoachReview']);
    Route::get('/coach_review/{swing_id}', [AdminController::class, 'getCoachReview']);

    Route::post('/swing', [AdminController::class, 'uploadSwing']);
    Route::post('/upload-reps', [UserController::class, 'uploadReps']);
    Route::post('/rename-swing', [UserController::class, 'uploadRenameSwing']);
    Route::get('/swing', [AdminController::class, 'getSwing']);
    Route::get('/rep-video', [UserController::class, 'getRepVideos']);
    Route::post('/rep-submit-to-coach/{id}', [UserController::class, 'SubmitToCoachRep']);
    Route::post('/swing-submit-to-coach/{id}', [UserController::class, 'SubmitToCoachSwing']);
    Route::delete('/swing/{id}', [AdminController::class, 'deleteSwing']);
    Route::delete('/rep_video/{id}', [UserController::class, 'deleteRepVideo']);
    Route::post('/admin_coach_review', [AdminController::class, 'updateCoachReview']);
    Route::post('/admin_coach_rep_review', [AdminController::class, 'updateCoachRepReview']);
    Route::delete('/admin_coach_review/{id}', [AdminController::class, 'deleteCoachReview']);
    Route::get('/admin_coach_review', [AdminController::class, 'getCoachReviewList']);
    Route::get('/coach_review_detail/{id}', [AdminController::class, 'getCoachReviewDetail']);
    Route::get('/coach_review_detail_by_rep_video/{swing_id}', [UserController::class, 'getCoachReviewDetailByREpVideoId']);
    Route::get('/coach_review_detail_by_swing/{swing_id}', [UserController::class, 'getCoachReviewDetailBySwingId']);
    Route::get('/dashboard', [AdminController::class, 'dashboard']);

    //saved sessions crud
    Route::post('/save-object/{id}/{session_id}/{unit_id?}', [UserController::class, 'storeSavedObject']);
    Route::post('/session-autoplay/{id}/{unit_id?}', [UserController::class, 'postSessionAutoplay']);
    Route::post('/save-item/{id}/{unit_id?}', [UserController::class, 'storeSavedItem']);
    Route::post('/save-trust-or-shot-check', [UserController::class, 'storeSavedTrustOrShotCheck']);
    Route::get('/locker/{slug}', [UserController::class, 'getLockerDetail']);

    //trophies crud 
    Route::get('/trophies', [UserController::class, 'getTrophies']);
    Route::get('/trophies-list', [UserController::class, 'getTrophiesAdmin']);
    Route::post('/trophies', [AdminController::class, 'updateTrophies']);
    Route::delete('/trophies/{id}', [AdminController::class, 'deleteTrophies']);

    //ads crud  
    Route::get('/ads/{page?}', [UserController::class, 'getAds']);
    Route::post('/ads', [AdminController::class, 'updateAds']);
    Route::delete('/ads/{id}', [AdminController::class, 'deleteAds']);
    Route::get('/trust-quote', [UserController::class, 'getTrustQuote']);
    Route::post('/verify-promo-code/{id}', [UserController::class, 'verifyPromo']);
    Route::post('/verify-promo-code-100/{id}', [UserController::class, 'verifyPromo100']);
    Route::post('/verify-coach-promo-code/{id}', [UserController::class, 'verifyCoachPromo']);

    Route::post('/promo-code', [AdminController::class, 'updatePromo']);
    Route::get('/promo-code', [AdminController::class, 'getPromo']);
    Route::delete('/promo-code/{id}', [AdminController::class, 'deletePromo']);

    Route::post('/assign-tag', [AdminController::class, 'assignTag']);
    //trust_quote crud for admin
    Route::get('/quote', [AdminController::class, 'getQuote']);
    Route::post('/quote', [AdminController::class, 'updateQuote']);
    Route::delete('/quote/{id}', [AdminController::class, 'deleteQuote']);

    Route::get('/notification', [UserController::class, 'getNotification']);
    Route::get('/notification-history/{user_id}', [AdminController::class, 'getNotificationByUser']);
    Route::get('/unread-notification', [UserController::class, 'getUnreadNotification']);
    Route::post('/notification', [UserController::class, 'updateNotification']);

    Route::post('/payment-setting/{free_app}', [AdminController::class, 'updatePaymentSetting']);
    Route::post('/flow-setting/{new_flow}', [AdminController::class, 'updateFlowSetting']);

    //overview api
    Route::get('/overview/{type}', [UserController::class, 'getOverview']);
    Route::post('/overview', [AdminController::class, 'updateOverview']);

    //User Dashboard api``
    Route::get('/user-progress-tracking-app', [UserController::class, 'getUserProgressTrackingApp']);
    Route::get('/user-progress-tracking/{user_id}', [AdminController::class, 'getUserProgressTracking']);
    Route::get('/all-user-progress-tracking', [AdminController::class, 'getAllUserProgressTracking']);
    Route::post('/remind_later-reminder/{remindLater}', [UserController::class, 'updateRemindLaterReminder']);
    Route::get('/user-dashboard', [AdminController::class, 'getUserDashboardData']);
    Route::get('/user-rating', [AdminController::class, 'getUserRatingList']);
    Route::get('/user-activity', [AdminController::class, 'getUserActivityList']);
    Route::get('/user-feedbacks', [AdminController::class, 'getUserFeedbackList']);
    Route::get('/user-profile/{user_id}', [AdminController::class, 'getUserProfileData']);
});



// Route::post('/login', [UserController::class, 'login']);

// Route::middleware('apiauth')->group(function () {
//     Route::get('/get-intro-images', [UserController::class, 'getImages']);
// });

// Route::get('get-intro-images', 'API\UserController@getImages');

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
