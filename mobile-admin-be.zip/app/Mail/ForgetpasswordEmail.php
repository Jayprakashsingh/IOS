<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ForgetpasswordEmail extends Mailable
{
    use Queueable, SerializesModels;
    public $userId;
    public $link; // Add this line
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($userId,$link)
    {
        $this->userId = $userId;
        $this->link = $link; // Set the link
    }

    /**
     * Get the message envelope.
     *
     * @return \Illuminate\Mail\Mailables\Envelope
     */
    public function envelope()
    {
        return new Envelope(
            subject: 'Please reset your Fisio password',
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function content()
    {
        return new Content(
            view: 'emails.forgetpassword',
        );
    }

    public function build()
    {
        // return $this->subject('Welcome to My App')
        //     ->view('emails.confirmation');

            //return $this->view('emails.forgetpassword')->with('userId', $this->userId);
            return $this->view('emails.forgetpassword') // Assuming you have a view for this
                    ->with([
                        'userId' => $this->userId,
                        'link' => $this->link, // Pass the link to the view
                    ]);
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [];
    }
}
