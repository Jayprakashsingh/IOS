<?php

namespace App\Mail;

use App\Models\Swing;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class CoachReminderEmail extends Mailable
{
    use Queueable, SerializesModels;
    public $userId;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($swingId, $coach_name, $user_name)
    {
        $this->swingId = $swingId;
        $this->coach_name = $coach_name;
        $this->user_name = $user_name;
    }

    /**
     * Get the message envelope.
     *
     * @return \Illuminate\Mail\Mailables\Envelope
     */
    public function envelope()
    {
        return new Envelope(
            subject: 'New Swing Video to Review',
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function content()
    {
        return new Content(
            view: 'emails.coach_reminder_email',
        );
    }

    public function build()
    {
        return $this->view('emails.coach_reminder_email')->with([
            'swing' => Swing::find($this->swingId),
            'coach_name' => $this->coach_name,
            'user_name' => $this->user_name,
        ]);
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [];
    }
}
