<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class FreeUser extends Model
{
    protected $collection = 'free_users';
    protected $fillable = [
        'email',
        'admin_id'
    ];
}
