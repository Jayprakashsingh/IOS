<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class InformationCenterImages extends Model
{
    protected $collection = 'information_center_images';
    protected $fillable = [
        'images',
        'title',
    ];
}