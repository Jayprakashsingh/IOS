<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UserCoachReview extends Model
{
    protected $collection = 'user_coach_reviews';
    protected $fillable = [
        'user_id',
        'coach_review',
        'used_coach_review',
        'expiration_date',
        'status'
    ];
}
