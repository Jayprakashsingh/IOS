<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class TermService extends Model
{
    protected $collection = 'terms_service';
    protected $fillable = [
        'content',
    ];
}