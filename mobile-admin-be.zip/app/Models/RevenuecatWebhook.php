<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class RevenuecatWebhook extends Model
{
    protected $collection = 'revenuecat_webhooks';
    protected $fillable = [
        'event',
        'event_type'
    ];
}
