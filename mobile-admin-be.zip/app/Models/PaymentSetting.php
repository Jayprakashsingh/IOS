<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class PaymentSetting extends Model
{
    protected $collection = 'payment_setting';
    protected $fillable = [
        'free_app'
    ];
}