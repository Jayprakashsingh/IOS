<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserSessionProgress extends Model
{
    protected $collection = 'user_session_progress';
    protected $fillable = [
        'user_id','unit_id',
        'session_id',
        'object_id',
    ];
}