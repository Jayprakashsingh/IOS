<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class About extends Model
{
    protected $collection = 'about_us';
    protected $fillable = [
        'headline',
        'subtitle',
        'text',
        'image',
        'vimeo_link'
    ];
}