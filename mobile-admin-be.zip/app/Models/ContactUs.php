<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class ContactUs extends Model
{
    protected $collection = 'contact_us';
    protected $fillable = [
        'subject',
        'message',
        'user_id',
        'email',
    ];
}