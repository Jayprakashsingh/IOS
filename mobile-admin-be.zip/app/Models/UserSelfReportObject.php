<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserSelfReportObject  extends Model
{
    protected $collection = 'user_self_report_objects';
    protected $fillable = [
        'object_id',
        'session_id',
        'unit_id',
        'user_id',
        'rating',
        'text'
    ];
}