<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class SavedItems extends Model
{
    protected $collection = 'saved_items';
    protected $fillable = [
        'type',
        'saved_item_id',
        'unit_id',
        'session_id',
        'user_id'
    ];
}
