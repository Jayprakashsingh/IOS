<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class ForceUpdateSetting extends Model
{
    protected $collection = 'force_update_setting';
    protected $fillable = [
        'device_type',
        'version',
        'force_update',
        'description'
    ];
}
