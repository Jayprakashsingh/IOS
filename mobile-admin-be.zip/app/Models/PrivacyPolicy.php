<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class PrivacyPolicy extends Model
{
    protected $collection = 'privacy_policy';
    protected $fillable = [
        'content',
    ];
}