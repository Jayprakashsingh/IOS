<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class ObjectType extends Model
{
    protected $collection = 'object_type';
    protected $fillable = [
        'name',
    ];
}