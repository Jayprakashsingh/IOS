<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserObjectType extends Model
{
    protected $collection = 'user_object_type';
    protected $fillable = [
        'object_type_id',
        'category_type_id',
        'object_name',
        'headline',
        'subtitle',
        'textarea',
        'equipment',
        'object_time',
        'tag',
        'link_items'
    ];
}