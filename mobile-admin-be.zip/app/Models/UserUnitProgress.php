<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserUnitProgress extends Model
{
    protected $collection = 'user_running_unit_progress';
    protected $fillable = [
        'user_id',
        'unit_id',
        'unit_no',
        'completed_percentage',
    ];
}