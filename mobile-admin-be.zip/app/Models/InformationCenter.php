<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class InformationCenter extends Model
{
    protected $collection = 'information_center';
    protected $fillable = [
        'question',
        'answer',
    ];
}