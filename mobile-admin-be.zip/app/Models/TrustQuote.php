<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class TrustQuote extends Model
{
    protected $collection = 'trust_quotes';
    protected $fillable = [
        'title',
        'quote',
        'quote_by',
        'shown',
        'shown_date'
    ];
}