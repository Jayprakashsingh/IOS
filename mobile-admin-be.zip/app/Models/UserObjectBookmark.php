<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserObjectBookmark extends Model
{
    protected $collection = 'user_object_bookmark';
    protected $fillable = [
        'user_id',
        'object_id',
    ];
}