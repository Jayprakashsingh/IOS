<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class GuideFundamental extends Model
{
    protected $collection = 'guide_fundamentals';
    protected $fillable = [
        'guide_id',
        'name',
        'description',
        'main_image',
        'secondary_image',
        'micro_move_steps'
    ];
}