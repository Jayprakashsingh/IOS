<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserManualReps extends Model
{
    protected $collection = 'user_manual_reps';
    protected $fillable = [
        'user_id',
        'tag_id',
        'reps',
        'reps_type'
    ];
}