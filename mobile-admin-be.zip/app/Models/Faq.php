<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Faq extends Model
{
    protected $collection = 'faq';
    protected $fillable = [
        'question',
        'answer',
    ];
}