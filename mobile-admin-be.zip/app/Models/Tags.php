<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Tags extends Model
{
    protected $collection = 'tags';
    protected $fillable = [
        'user_id',
        'name',
        'type'
    ];
}