<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Session extends Model
{
    protected $collection = 'session';
    protected $fillable = [
        'session_type_id',
        'category_type_id',
        'session_name',
        'internal_session_name',
        'session_object',
    ];
}