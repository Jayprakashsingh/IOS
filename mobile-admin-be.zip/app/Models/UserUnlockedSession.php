<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserUnlockedSession extends Model
{
    protected $collection = 'user_unlocked_session';
    protected $fillable = [
        'user_id',
        'unit_id',
        'session_id',
        'date',
    ];
}