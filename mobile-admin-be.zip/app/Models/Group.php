<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Group extends Model
{
    protected $collection = 'groups';
    protected $fillable = [
        'group_name',
        'group_object',
        'order'
    ];
}