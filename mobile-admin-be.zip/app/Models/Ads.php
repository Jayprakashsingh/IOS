<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Ads extends Model
{
    protected $collection = 'ads';
    protected $fillable = [
        'page',
        'title',
        'ads_type',
        'ads_url'
    ];
}
