<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class FlowSetting extends Model
{
    protected $collection = 'flow_setting';
    protected $fillable = [
        'new_flow'
    ];
}