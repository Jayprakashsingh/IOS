<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class DisplayImages extends Model
{
    protected $collection = 'display_images';
}
