<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class TrustKey extends Model
{
    protected $collection = 'trust_keys';
    protected $fillable = [
        'trust_key',
        'date',
        'created_by'
    ];
}