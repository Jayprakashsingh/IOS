<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Question extends Model
{
    protected $collection = 'questions';
    protected $fillable = [
        'text',
        'answers'
    ];
}