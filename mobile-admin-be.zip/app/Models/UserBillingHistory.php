<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserBillingHistory extends Model
{
    protected $collection = 'user_billing_history';
    protected $fillable = [
        'transaction_no',
        'user_id',
        'plan_id',
        'amount',
        'status',
        'payment_status',
        'expiry_date',
        'payment_method'
    ];
}