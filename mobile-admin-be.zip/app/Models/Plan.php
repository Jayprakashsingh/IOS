<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Plan extends Model
{
    protected $collection = 'plan';
    protected $fillable = [
        'name',
        'amount',
        'validity',
        'validity_type',
    ];
}