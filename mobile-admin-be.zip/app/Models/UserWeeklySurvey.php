<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserWeeklySurvey  extends Model
{
    protected $collection = 'user_weekly_survey';
    protected $fillable = [
        'user_id',
        'rating',
        'text',
        'date'
    ];
}