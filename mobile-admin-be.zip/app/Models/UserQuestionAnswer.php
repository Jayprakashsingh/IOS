<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserQuestionAnswer extends Model
{
    protected $collection = 'user_question_answer';
    protected $fillable = [
        'user_id',
        'question_id',
        'answer',
    ];
}