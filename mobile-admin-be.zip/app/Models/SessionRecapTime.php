<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class SessionRecapTime extends Model
{
    protected $collection = 'session_recap_times';
    protected $fillable = [
        'session_id',
        'unit_id',
        'user_id',
        'recap_reps'
    ];
}