<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Guide extends Model
{
    protected $collection = 'guides';
    protected $fillable = [
        'title',
        'description'
    ];
}