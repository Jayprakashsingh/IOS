<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class SessionType extends Model
{
    protected $collection = 'session_type';
    protected $fillable = [
        'name',
    ];
}