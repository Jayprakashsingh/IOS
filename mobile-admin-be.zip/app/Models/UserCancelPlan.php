<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UserCancelPlan extends Model
{
    protected $collection = 'user_cancel_plan';
    protected $fillable = [
        'user_id',
        'plan_id',
        'description',
        'file',
        'file_type'
    ];
}
