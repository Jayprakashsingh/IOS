<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Notification extends Model
{
    protected $collection = 'notifications';
    protected $fillable = [
        'user_id',
        'notification_reminder_category_id',
        'title',
        'description',
        'is_read',
        'type','fcm_token'
    ];
}
