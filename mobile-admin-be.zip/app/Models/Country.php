<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Country extends Model
{
    protected $collection = 'country';
    protected $fillable = [
        'code',
        'name',
        'flag_url',
        'timezone',
        'gmt_offset'
    ];
}