<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class AdminCoachReview extends Model
{
    protected $collection = 'coach_review';
    protected $fillable = [
        'coach_id',
        'swing_id',
        'status',
        'title',
        'comment',
        'rating',
        'file',
    ];
}
