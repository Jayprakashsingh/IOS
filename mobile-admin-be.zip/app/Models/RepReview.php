<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class RepReview extends Model
{
    protected $collection = 'rep_reviews';
    protected $fillable = [
        'user_id',
        'duration',
        'status',
        'rep_video',
        'file_size',
        'submit_to_coach'
    ];
}