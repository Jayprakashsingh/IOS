<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class LogEntry extends Model
{
    protected $collection = 'log_entries';
    protected $fillable = [
        'cron_name',
        'type',
        'message'
    ];
}

