<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class CoachReview extends Model
{
    protected $collection = 'coach_reviews';
    protected $fillable = [
        'user_id',
        'file',
    ];
}
