<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class GeneralSetting extends Model
{
    protected $collection = 'general_setting';
    protected $fillable = [
        'user_id',
        'type',
        'field',
        'setting'
    ];
}
