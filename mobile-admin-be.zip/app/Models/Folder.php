<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Folder extends Model
{
    protected $collection = 'folders';
    protected $fillable = [
        'name',
        'user_id'
    ];
}