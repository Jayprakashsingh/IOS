<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserContactPerson extends Model
{
    protected $collection = 'user_contact_person';
    protected $fillable = [
        'user_id',
        'person_name',
        'phone',
    ];
}