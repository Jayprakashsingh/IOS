<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class RecentSearch extends Model
{
    protected $collection = 'recent_search';
    protected $fillable = [
        'user_id',
        'search',
        'category',
        'date'
    ];
}