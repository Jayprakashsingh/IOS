<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class CategoryType extends Model
{
    protected $collection = 'category_type';
    protected $fillable = [
        'name',
    ];
}