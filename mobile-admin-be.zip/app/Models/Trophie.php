<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Trophie extends Model
{
    protected $collection = 'trophies';
    protected $fillable = [
        'trophie_front',
    ];
}