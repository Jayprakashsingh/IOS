<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class PromoCode extends Model
{
    protected $collection = 'promo_codes';
    protected $fillable = [
        'code',
        'plan_id',
        'discount',
        'status'
    ];
}