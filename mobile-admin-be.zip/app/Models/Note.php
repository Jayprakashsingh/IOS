<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Note extends Model
{
    protected $collection = 'notes';
    protected $fillable = [
        'title',
        'type',
        'description',
        'file',
        'file_type',
        'user_id',
        'folder_id'
    ];
}
