<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class TrustOverview extends Model
{
    protected $collection = 'trust_overview';
    protected $fillable = [
        'headline',
        'text',
        'time',
        'type',
        'description'
    ];
}
