<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UserShotCheck extends Model
{
    protected $collection = 'user_shot_checks';
    protected $fillable = [
        'user_id',
        'shot_no',
        'direction',
        'curve',
        'contact',
        'face',
        'distance',
        'date',
        'location'
    ];
}
