<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Autoplay extends Model
{
    protected $collection = 'autoplay';
    protected $fillable = [
        'session_id',
        'unit_id',
        'user_id'
    ];
}
