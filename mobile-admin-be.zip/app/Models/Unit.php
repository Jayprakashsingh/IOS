<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Unit extends Model
{
    protected $collection = 'unit';
    protected $fillable = [
        'category_type_id',
        'unit_name',
        'internal_unit_name',
        'unit_object',
    ];
}