<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UserRecallCards extends Model
{
    protected $collection = 'user_recall_cards';
    protected $fillable = [
        'user_id',
        'recall_card_id',
        'session_id',
        'interval',
        'due_date',
        'show'
    ];
}
