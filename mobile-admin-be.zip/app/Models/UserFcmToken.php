<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UserFcmToken extends Model
{
    protected $collection = 'user_fcm_tokens';
    protected $fillable = [
        'user_id',
        'fcm_token',
        'device_type',
        'latest'
    ];
}
