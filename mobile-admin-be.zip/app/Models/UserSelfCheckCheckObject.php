<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserSelfCheckCheckObject  extends Model
{
    protected $collection = 'user_self_check_check_objects';
    protected $fillable = [
        'tag_id',
        'object_id',
        'session_id',
        'unit_id',
        'user_id',
        'answer_1',
        'answer_2',
        'answer_3',
        'answer_4',
        'fundamental_id',
    ];
}