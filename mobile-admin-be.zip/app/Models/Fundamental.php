<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Fundamental extends Model
{
    protected $collection = 'fundamentals';
    protected $fillable = [
        'name',
        'headline',
        'text',
        'vimeo_link'
    ];
}