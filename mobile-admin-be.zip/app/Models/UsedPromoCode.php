<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UsedPromoCode extends Model
{
    protected $collection = 'used_promo_codes';
    protected $fillable = [
        'user_id',
        'promo_code',
        'payment_id'
    ];
}
