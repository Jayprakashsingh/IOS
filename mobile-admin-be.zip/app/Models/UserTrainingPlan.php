<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserTrainingPlan extends Model
{
    protected $collection = 'user_training_plan';
    protected $fillable = [
        'user_id',
        'day',
        'time',
        'location',
    ];
}