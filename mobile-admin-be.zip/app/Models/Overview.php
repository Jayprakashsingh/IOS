<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Overview extends Model
{
    protected $collection = 'overviews';
    protected $fillable = [
        'session_id',
        'headline',
        'text',
        'time',
        'is_equipments_needed',
        'equipments',
        'list_items',
        'move_drills_count',
        'recall_cards_count'
    ];
}
