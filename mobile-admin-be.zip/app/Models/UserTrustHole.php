<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class UserTrustHole extends Model
{
    protected $collection = 'user_trust_holes';
    protected $fillable = [
        'user_id',
        'trust_hole_no',
        'hole_type',
        'date',
        'location',
        'temperature',
        'wind',
        'warm_up_time',
        'direction',
        'curve',
        'contact',
        'face',
        'alignment',
        'distance',
        'trust_key_percent',
        'pre_shot_percent',
        'post_shot_percent'
    ];
}
