<?php

namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class Swing extends Model
{
    protected $collection = 'swings';
    protected $fillable = [
        'user_id',
        'down_the_line',
        'face_on',
        'face_on_duration',
        'status',
        'down_the_line_duration',
        'title',
        'submit_to_coach',
        'direction',
        'curve',
        'contact',
        'face',
        'description'
    ];
}