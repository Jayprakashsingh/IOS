<?php
namespace App\Models;
use Jenssegers\Mongodb\Eloquent\Model;

class RecallCard extends Model
{
    protected $collection = 'recall_cards';
    protected $fillable = [
        'question_text',
        'question_img',
        'answer_text',
        'answer_img',
        'learn_more_video',
        'title',
        'level',
        'tag',
        'link_items'
    ];
}
