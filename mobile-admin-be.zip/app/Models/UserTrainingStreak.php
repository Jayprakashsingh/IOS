<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserTrainingStreak extends Model
{
    protected $collection = 'user_training_streaks';
    protected $fillable = [
        'user_id',
        'date',
        'current_streak',
        'mulligan'
    ];
}