<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class UserRecallCardUpdate extends Model
{
    protected $collection = 'user_recall_card_updates';
    protected $fillable = [
        'user_id',
        'recall_card_id',
        'answer',
        'user_level'
    ];
}