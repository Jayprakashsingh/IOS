<?php

namespace App\Helpers;

use App\Models\AdminCoachReview;
use App\Models\CategoryType;
use App\Models\CoachReview;
use App\Models\ObjectType;
use App\Models\SavedItems;
use App\Models\Session;
use App\Models\SessionType;
use App\Models\Swing;
use App\Models\User;
use App\Models\UserCoachReview;
use App\Models\UserObjectBookmark;
use App\Models\UserObjectType;
use App\Models\UserSessionProgress;
use App\Models\Unit;
use App\Models\Group;
use App\Models\UserUnlockedSession;
use DateTime;
use Illuminate\Support\Collection;

class Functions
{
    public static function sortArray($data, $sortColumn)
    {
        if (substr($sortColumn, 0, 1) === "-") {
            // Sort is in descending order
            $columnName = substr($sortColumn, 1);
            $typeOfSort ="desc";
        } else {
            // Sort is in ascending order
            $columnName = $sortColumn;
            $typeOfSort = "asc";
        }
        if($sortColumn != ""){
            $tagsCollection = Collection::make($data);
            if($typeOfSort == "desc"){
                $sortedData = $tagsCollection->sortByDesc($columnName)->values()->all();
            }else{
                $sortedData = $tagsCollection->sortBy($columnName)->values()->all();
            }
        }else{
            $sortedData = $data;
        }

        return $sortedData;
    }

    public static function filterArrayByField($array, $searchTerm, $field="")
    {
        if($searchTerm == ""){
            return $array;
        }else{
            if($field != ""){
                $result = collect($array)
                    ->filter(function ($item) use ($field, $searchTerm) {
                        if (is_array($item[$field])) {
                            return in_array($searchTerm, $item[$field]);
                        }
                        return stripos($item[$field], $searchTerm) !== false;
                    })
                    ->values();

                return $result;
            }else{
                $fieldArray = $array[0];
                $keyArray = [];
                
                foreach ($fieldArray as $key => $value) {
                    $field = $key;
                    $valueArray = collect($array)->filter(function ($item) use ($field, $searchTerm) {
                        if(!is_array($item[$field])){
                            return stripos($item[$field], $searchTerm) !== false;
                        }
                    })->values();
                    if(sizeof($valueArray) > 0){
                        $keyArray[] = $valueArray;
                    }
                }
                
                if(sizeof($keyArray) > 0 ){
                    return $keyArray[0];
                }else{
                    return $keyArray;
                }
            }
        }
    }

    public static function filterArrayByFieldArray($array, $searchTerm, $field = "")
    {
        if ($searchTerm == "" && $field == "") {
            return $array;
        } else {
           
            if ($field != "") {
                $result = collect($array)
                    ->filter(function ($item) use ($field, $searchTerm) {
                        if (is_array($item[$field])) {
                            return in_array($searchTerm, $item[$field]);
                        }
                        return stripos($item[$field], $searchTerm) !== false;
                    })
                    ->values();

                return $result;
            } else {
                $fieldArray = $array[0];
                $keyArray = [];
                foreach ($fieldArray->toArray() as $key => $value) {
                    if($key != "link_items"){
                        $field = $key;
                        $valueArray = collect($array)->filter(function ($item) use ($field, $searchTerm) {
                            if(is_array($item[$field])){
                                foreach($item[$field] as $innerField => $valueOfField){
                                    return stripos($valueOfField, $searchTerm) !== false;
                                }
                                // return stripos($item[$field], $searchTerm) !== false;
                            }else{
                                return stripos($item[$field], $searchTerm) !== false;
                            }
                            // return stripos($item[$field], $searchTerm) !== false;
                        })->values();
                        if (count($valueArray) > 0) {
                            $keyArray[] = $valueArray;
                        }
                    }
                    
                }
            
                if (!empty($keyArray)) {
                    return $keyArray[0];
                } else {
                    return $keyArray;
                }
            }
        }
    }
    public static function filterArrayByFieldArrayMultiPle($array, $searchTerm, $fields = [])
    {
        if ($searchTerm == "" || empty($fields)) {
            return $array;
        } else {
            $result = collect($array)
                ->filter(function ($item) use ($fields, $searchTerm) {
                    foreach ($fields as $field) {
                        if (isset($item[$field])) {
                            if (is_array($item[$field])) {
                                if (in_array($searchTerm, $item[$field])) {
                                    return true;
                                }
                            } else {
                                if (stripos($item[$field], $searchTerm) !== false) {
                                    return true;
                                }
                            }
                        }
                    }
                    return false;
                })
                ->values();

            return $result;
        }
    }

    public static function filterArrayByFieldProgram($array, $searchTerm, $field="")
    {
        if($searchTerm == ""){
            return $array;
        }else{
            if($field != ""){
                $result = collect($array)
                    ->filter(function ($item) use ($field, $searchTerm) {
                        if (is_array($item[$field])) {
                            return in_array($searchTerm, $item[$field]);
                        }
                        return stripos($item[$field], $searchTerm) !== false;
                    })
                    ->values();

                return $result;
            }else{
                $fieldArray = $array[0];
                $keyArray = [];
                
                foreach ($fieldArray->toArray() as $key => $value) {
                    $field = $key;
                    $valueArray = collect($array)->filter(function ($item) use ($field, $searchTerm) {
                        if(!is_array($item[$field])){
                            return stripos($item[$field], $searchTerm) !== false;
                        }
                    })->values();
                    if(sizeof($valueArray) > 0){
                        $keyArray[] = $valueArray;
                    }
                }
                
                if(sizeof($keyArray) > 0 ){
                    return $keyArray[0];
                }else{
                    return $keyArray;
                }
            }
        }
    }

    public static function lockerDetailHistoryOld($user,$search = ""){
        $sessionCollection = [];
        $appUrl = env('AWS_S3_PATH');
        $session = [];
        $sessionIds = Session::pluck("_id")->toArray();
        $savedSessionIdsQ = UserSessionProgress::where('user_id',$user['_id'])->where('unit_id','!=',NULL);
        if(!empty($sessionIds)){
            $savedSessionIdsQ = $savedSessionIdsQ->whereIn('session_id',$sessionIds);
        }
        $savedSessionIds = $savedSessionIdsQ->pluck('unit_id','session_id')->toArray();
        $userSessionProgress = UserSessionProgress::where('user_id', $user["_id"])->orderBy('created_at','desc')->get();
        if(!empty($savedSessionIds)){
            $userObject = UserObjectType::pluck('object_time','_id');
            $key = 0;
            foreach ($savedSessionIds as $keyy => $value) {
                $sessionId = $keyy;
                $unitId = $value;
                $sessionSingleRecord = Session::find($sessionId);
                $percentage = 0; 
                $objectIds = [];
                $totalTime = 0;
                if (!empty($sessionSingleRecord["session_object"])) {
                    foreach ($sessionSingleRecord["session_object"] as $keyz => $unitObject) {
                        if (!empty($userObject)) {
                            $totalTime += floatval( $userObject[$unitObject["object_id"]]);
                            array_push($objectIds, $unitObject["object_id"]);
                        }
                    }
                }
                $userUnitProgressQ =  $userSessionProgress->where('session_id',$sessionSingleRecord['_id']);
                if($unitId != null && $unitId != ""){
                    $userUnitProgressQ = $userUnitProgressQ->where('unit_id',$unitId);
                }
                $userUnitProgress = $userUnitProgressQ->whereIn('object_id',$objectIds)->pluck('object_id')->unique()->count();
                $countSessionUnitObjects = count($sessionSingleRecord["session_object"]);
                if($userUnitProgress > 0 && $countSessionUnitObjects > 0){
                    $percentage = ($userUnitProgress/$countSessionUnitObjects) * 100;
                }  
                $seen =  $percentage >= 100 ? true : false;
                if($seen == true){
                    $sessionCollection[$key]['seen'] = $seen;
                    $sessionCollection[$key]['id'] = $sessionSingleRecord["_id"];
                    $sessionCollection[$key]['unit_id'] = $unitId != null ? $unitId : "";
                    $sessionCollection[$key]['title'] = $sessionSingleRecord["session_name"] ?? "N/A";
                    $sessionCollection[$key]['internal_session_name'] = $sessionSingleRecord["internal_session_name"] ?? "N/A";
                    $sessionCollection[$key]['duration'] = $totalTime;
                    $sessionCollection[$key]['percentage'] = $percentage;
                    $sessionCollection[$key]['thumbnail'] =  $appUrl.'thumbnail.png';
                    $key++;
                }
            }
        }
        $sessionCollection = array_values($sessionCollection);
        return $sessionCollection;  
    }

    public static function lockerDetailHistory($user, $search = "")
    {
        $sessionCollection = [];
        $appUrl = env('AWS_S3_PATH');
        
        $defaultProgram = env('DEFAULT_PROGRAM');

        $groupUnitIds = array_column(Group::where('group_name', $defaultProgram)->first()["group_object"], "object_id");

        if (!empty($user->group_id) && $group = Group::find($user->group_id)) {
            $groupUnitIds = array_column($group["group_object"], "object_id");
        }
        
        // $categoryType = CategoryType::where('name', 'LIKE', 'Train')->first();
        $unitCollectionData = Unit::whereIn('_id', $groupUnitIds)
                                    // ->where('category_type_id', $categoryType["_id"])
                                    ->get()
                                    ->sortBy(function ($item) use ($groupUnitIds) {
                                        return array_search($item['_id'], $groupUnitIds);
                                    });
        
        $unitData = [];
        $userSessionProgress = UserSessionProgress::where('user_id', $user["_id"])->orderBy('created_at', 'desc')->get();
        $userObjectTypeDurations = UserObjectType::pluck('object_time', '_id')->toArray();
        
        // $userUnlockedSessionsMap = UserUnlockedSession::where('user_id', $user["_id"])
        //     ->get()
        //     ->keyBy(function ($item) {
        //         return $item->unit_id . '_' . $item->session_id;
        //     })->toArray();
        
        foreach ($unitCollectionData as $unit) {
            $unitId = $unit["_id"];
            
            $unitData[$unitId] = [
                'id' => $unitId,
                'program_name' => "",
                'unit_name' => $unit["unit_name"],
                'order' => (int)$unit["order"],
                'unit_percentage' => '0%', 
                'session' => []
            ];
            
            $totalSessions = 0;
            $seenSessions = 0;
            
            foreach ($unit["unit_object"] as $unitObject) {
                $session = Session::find($unitObject["object_id"]);
                if (!$session) continue;
                
                $sessionTotalObjects = count($session["session_object"]);
                $sessionSeenObjects = $userSessionProgress
                    ->where('session_id', $session["_id"])
                    ->where('unit_id', $unitId)
                    ->pluck('object_id')
                    ->unique()
                    ->count();
                
                $totalSessions++;
                $seen = $sessionSeenObjects >= $sessionTotalObjects;
                // if ($sessionSeenObjects >= $sessionTotalObjects) { // for all sessions 
                if ($seen) {
                    $seenSessions++;
                }
                
                $totalSessionDuration = collect($session["session_object"])
                    ->reduce(function ($carry, $obj) use ($userObjectTypeDurations) {
                        return $carry + ($userObjectTypeDurations[$obj["object_id"]] ?? 0);
                    }, 0);
                
                // $sessionPercentage = ($sessionSeenObjects / max($sessionTotalObjects, 1)) * 100;
                $sessionPercentage = min(($sessionSeenObjects / max($sessionTotalObjects, 1)) * 100, 100);
                // $isLocked = !isset($userUnlockedSessionsMap[$unitId . '_' . $session["_id"]]);
                
                if ($seen) {
                    $unitData[$unitId]['session'][] = [
                        'seen' => $seen,
                        'id' => $session["_id"],
                        'unit_id' => $unitId,
                        'title' => $session["session_name"] ?? "N/A",
                        'internal_session_name' => $session["internal_session_name"] ?? "N/A",
                        'duration' => number_format($totalSessionDuration, 2),
                        'percentage' => round($sessionPercentage) . "%",
                        'thumbnail' => $appUrl . 'thumbnail.png'
                        // 'is_locked' => (int)$isLocked
                    ];
                }
            }
            
            // $unitPercentage = ($seenSessions / max($totalSessions, 1)) * 100;
            $unitPercentage = min(($seenSessions / max($totalSessions, 1)) * 100, 100);
            $unitData[$unitId]['unit_percentage'] = round($unitPercentage) . '%';
        }
        
        // $sessionCollection = array_values($unitData);
        foreach ($unitData as $unitId => $unit) {
            if (!empty($unit['session'])) {
                $sessionCollection[] = $unit;
            }
        }
        
        return $sessionCollection;
    }
    public static function mySaved($user,$search = ""){
        $savedCollection = [];
        $appUrl = env('AWS_S3_PATH');
        $savedItems = SavedItems::where('user_id', $user["userid"])->where('unit_id','!=',null)->orderBy('created_at','desc')->get();
        if(!empty($savedItems)){
            $userSessionProgress = UserSessionProgress::where('user_id',$user['_id'])->get();
            $key = 0;
            $userObjectBookmarks = UserObjectBookmark::where('user_id', $user['_id'])->get()->keyBy('object_id');
            $objectTypes = ObjectType::get()->keyBy('_id');
            $userObject = UserObjectType::pluck('object_time','_id');
            $sessionTypes = SessionType::pluck('name', '_id');
            foreach($savedItems as $savedItem){
                if($savedItem->type == "session"){
                    $sessionSingleRecord = Session::find($savedItem->saved_item_id);
                    $percentage = 0;
                    $objectIds = [];
                    $totalTime = 0;
                    if (!empty($sessionSingleRecord["session_object"])) {
                        foreach ($sessionSingleRecord["session_object"] as $keyz => $unitObject) {
                            if (!empty($userObject)) {
                                $totalTime += floatval( $userObject[$unitObject["object_id"]]);
                                array_push($objectIds, $unitObject["object_id"]);
                            }
                        }
                    }
                    $userUnitProgressQ =  $userSessionProgress->where('session_id',$sessionSingleRecord['_id']);
                    if($savedItem->unit_id != null && $savedItem->unit_id != ""){
                        $userUnitProgressQ = $userUnitProgressQ->where('unit_id',$savedItem->unit_id);
                    }
                    //->whereIn('object_id',$objectIds)
                    $userUnitProgress = $userUnitProgressQ->pluck('object_id')->unique()->count();
                    $countSessionUnitObjects = count($sessionSingleRecord["session_object"]);
                    if($userUnitProgress > 0 && $countSessionUnitObjects > 0){
                        $percentage = ($userUnitProgress/$countSessionUnitObjects) * 100;
                    }
                    $savedCollection[$key]['saved_type'] = 'session';
                    $savedCollection[$key]['seen'] =  $percentage >= 100? true : false;
                    $savedCollection[$key]['id'] = $sessionSingleRecord["_id"];
                    $savedCollection[$key]['unit_id'] = $savedItem->unit_id ?? "";
                    $sessionTypeID = $sessionSingleRecord["session_type_id"];
                    $savedCollection[$key]['session_type'] = $sessionTypes[$sessionTypeID] ?? "N/A";
                    $savedCollection[$key]['session_id'] = $savedItem->session_id ?? "";
                    $savedCollection[$key]['title'] =  $sessionSingleRecord["session_name"] ?? "N/A";
                    $savedCollection[$key]['internal_session_name'] = $sessionSingleRecord["internal_session_name"] ?? "N/A";
                    $savedCollection[$key]['duration'] = $totalTime;
                    $savedCollection[$key]['percentage'] = $percentage;
                    $savedCollection[$key]['thumbnail'] = $appUrl.'thumbnail.png';
                   
                }else{
                    $userObjectData = UserObjectType::find($savedItem->saved_item_id);
                    $bookmark = false;
                    $totalTime = 0;
                    if (!empty($userObjectData)) {
                        $objectPath = env('AWS_OBJECT_IMAGES_PATH');
                        $userObjectType = $userObjectBookmarks->get($savedItem->saved_item_id);
                        if(!empty($userObjectType)){
                            $bookmark = true;
                        }
                        $objectType = $objectTypes->get($userObjectData->object_type_id);
                        $userSessionProgress = UserSessionProgress::where('object_id',$savedItem->saved_item_id)
                                                ->where('session_id',$savedItem->session_id)
                                                ->where('unit_id',$savedItem->unit_id)
                                                ->where('user_id',$user['_id'])
                                                ->first();
                        if($userSessionProgress){
                            $percentage = 100;
                        }else{
                            $percentage = 0;
                        }
                        $savedCollection[$key] = [
                            'saved_type' => 'object',
                            'object_id' => $userObjectData["_id"],
                            'object_name' => $userObjectData["object_name"],
                            'object_time' => $userObjectData["object_time"],
                            'headline' => $userObjectData["headline"],
                            'subtitle' => $userObjectData["subtitle"],
                            'description' => $userObjectData["textarea"],
                            'file' => $appUrl.''.$objectPath.''.$userObjectData["file"] ?? '',
                            'obj_thumbnail' => $userObjectData["thumbnail"] != "" ? $appUrl.''.$objectPath.''.$userObjectData["thumbnail"] : '',
                            'type' => $objectType["name"] ?? '',
                            'bookmark' => $bookmark,
                            'video_id' => $userObjectData["video_id"] ?? "",
                            'saved'  => true,
                            'seen' =>  $percentage == 100 ? true : false,
                            'session_id' => $savedItem->session_id ?? "",
                            'unit_id' => $savedItem->unit_id ?? "",
                            'thumbnail' =>  $appUrl.'savedObj.jpg'
                        ];
                    }
                }
                $key++;
            }
        }
        $savedCollection = array_values($savedCollection);
        return $savedCollection;
    }

    public static function coachReviewOld($user,$search = ""){
        $appUrl = env('AWS_S3_PATH');
        $coachReviewPath = env('AWS_COACH_REVIEW_PATH');
        $swingPath = env('AWS_SWING_PATH');
        $swingIds = Swing::where('user_id',$user["_id"])->pluck('_id')->toArray();
        $coachReviewsData = [];
        if(!empty($swingIds)){
            $today = now()->format("Y-m-d");
            $user_active_coach_review = UserCoachReview::where('user_id',$user["userid"])->where('expiration_date','>=',$today)->where('status','active')->orderBy('created_at')->first();
            $total_review = $reviewRemain = 0;
            $expiration_date = "";
            if($user_active_coach_review){
                $total_review = $user_active_coach_review->coach_review;
                $reviewRemain = $user_active_coach_review->coach_review - $user_active_coach_review->used_coach_review;
                $expiration_date = $user_active_coach_review->expiration_date;
            }
            $coachReviews = AdminCoachReview::whereIn('swing_id',$swingIds)->orderBy('created_at','desc')->get();
            $swings = Swing::where('user_id',$user["_id"])->get();
            foreach ($coachReviews as $key => $coachReview) {
                $coach = User::find( $coachReview["coach_id"]);
                $coachReviewsData[$key]['id'] =  $coachReview["_id"];
                $coachReviewsData[$key]['swing_id'] =  $coachReview["swing_id"];
                $swing = $swings->where('_id', $coachReview["swing_id"])->first();
                // $coachReviewsData[$key]['swing_video'] = $swing->file != "" ? $appUrl ."".$swingPath."".$swing->file : "";
                // $coachReviewsData[$key]['swing_video_duration'] = $swing->duration ?? "";
                $coachReviewsData[$key]['down_the_line'] = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                $coachReviewsData[$key]['face_on'] = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                $coachReviewsData[$key]['face_on_duration'] = $swing->face_on_duration ?? "";
                $coachReviewsData[$key]['down_the_line_duration'] = $swing->down_the_line_duration ?? "";
                $coachReviewsData[$key]['title'] =  $coachReview["title"] ?? "Feedback name";
                $coachReviewsData[$key]['status'] =  $coachReview['status'] ?? "";
                $coachReviewsData[$key]['comment'] = $coachReview["comment"] ?? "";
                $coachReviewsData[$key]['rating'] = $coachReview["rating"] ?? 0;
                $coachReviewsData[$key]['user_id'] =  $user["_id"];
                $coachReviewsData[$key]['coach_id'] =  $coachReview["coach_id"];
                $coachReviewsData[$key]['coach_name'] = $coach->full_name ?? "" ;
                $coachReviewsData[$key]['file'] =  $coachReview["file"] != "" ? $appUrl.''.$coachReviewPath.''.$coachReview["file"] :"";
                $coachReviewsData[$key]['created_at'] =  $coachReview["created_at"];
                $coachReviewsData[$key]['last_update'] =  $coachReview["updated_at"];
            }
        }

        $newRoot = [
            'coach_reviews' => $coachReviewsData,
            'total_review' => $total_review,
            'review_remain' => $reviewRemain,
            'expiration_date' => $expiration_date
        ];

        return $newRoot;  
    }
    public static function coachReview($user,$search = ""){
        $appUrl = env('AWS_S3_PATH');
        $coachReviewPath = env('AWS_COACH_REVIEW_PATH');
        $swingPath = env('AWS_SWING_PATH');
        $swingIds = Swing::where('user_id',$user["_id"])->pluck('_id')->toArray();
        $coachReviewsData = [];
        $total_review = $reviewRemain = 0;
        $usedReview = 0;
        $expiration_date = null;
        $expiration_dates = [];
        
        if(!empty($swingIds)){
            
            $today = now()->format("Y-m-d");
            $user_active_coach_reviews = UserCoachReview::where('user_id', $user["userid"])->where('expiration_date', '>=', $today)->where('status', 'active')->orderBy('created_at')->get();
            
            if(!empty($user_active_coach_reviews)){
                foreach ($user_active_coach_reviews as $user_active_coach_review) {
                    $rowReview = $user_active_coach_review->coach_review;
                    $rowUsedReview = $user_active_coach_review->used_coach_review;
                    $rowExpirationDate = $user_active_coach_review->expiration_date;
                
                    $total_review += $rowReview;
                    $usedReview += $rowUsedReview;
                    $expiration_dates[] = $rowExpirationDate;
                }
                
                $reviewRemain = $total_review - $usedReview;
                $expiration_date = end($expiration_dates);
            }

            $coachReviews = AdminCoachReview::whereIn('swing_id',$swingIds)->orderBy('created_at','desc')->get();
            $swings = Swing::where('user_id',$user["_id"])->get();
            foreach ($coachReviews as $key => $coachReview) {
                $coach = User::find( $coachReview["coach_id"]);
                $coachReviewsData[$key]['id'] =  $coachReview["_id"];
                $coachReviewsData[$key]['swing_id'] =  $coachReview["swing_id"];
                $swing = $swings->where('_id', $coachReview["swing_id"])->first();
                // $coachReviewsData[$key]['swing_video'] = $swing->file != "" ? $appUrl ."".$swingPath."".$swing->file : "";
                // $coachReviewsData[$key]['swing_video_duration'] = $swing->duration ?? "";
                $coachReviewsData[$key]['down_the_line'] = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                $coachReviewsData[$key]['face_on'] = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                $coachReviewsData[$key]['face_on_duration'] = $swing->face_on_duration ?? "";
                $coachReviewsData[$key]['down_the_line_duration'] = $swing->down_the_line_duration ?? "";
                $coachReviewsData[$key]['down_the_line_filesize'] = $swing->down_the_line_filesize ?? "";
                $coachReviewsData[$key]['face_on_filesize'] = $swing->face_on_filesize ?? "";
                $coachReviewsData[$key]['title'] =  $coachReview["title"] ?? "Feedback name";
                $coachReviewsData[$key]['status'] =  $coachReview['status'] ?? "";
                $coachReviewsData[$key]['comment'] = $coachReview["comment"] ?? "";
                $coachReviewsData[$key]['rating'] = $coachReview["rating"] ?? 0;
                $coachReviewsData[$key]['user_id'] =  $user["_id"];
                $coachReviewsData[$key]['coach_id'] =  $coachReview["coach_id"];
                $coachReviewsData[$key]['coach_name'] = $coach->full_name ?? "" ;
                $coachReviewsData[$key]['file'] =  $coachReview["file"] != "" ? $appUrl.''.$coachReviewPath.''.$coachReview["file"] :"";
                $coachReviewsData[$key]['created_at'] =  $coachReview["created_at"];
                $coachReviewsData[$key]['last_update'] =  $coachReview["updated_at"];
            }
        }

        $newRoot = [
            'coach_reviews' => $coachReviewsData,
            'total_review' => $total_review,
            'review_remain' => $reviewRemain,
            'expiration_date' => $expiration_date
        ];

        return $newRoot;  
    }
    public static function generateUniqueNumber() {
        $generatedNumbers = [];
    
        while (true) {
            $num = str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT); // Ensure 6 digits
            
            if (!in_array($num, $generatedNumbers)) {
                $generatedNumbers[] = $num;
                return $num;
            }
        }
    }
    
    public static function swingOld($user,$search = ""){
        $appUrl = env('AWS_S3_PATH');
        $swingPath = env('AWS_SWING_PATH');
        $swings = Swing::where('user_id', $user["_id"])->orderBy('created_at','desc')->get();
        $today = now()->format("Y-m-d");
        $user_active_coach_review = UserCoachReview::where('user_id',$user["userid"])->where('expiration_date','>=',$today)->where('status','active')->orderBy('created_at')->first();
        $total_review = 0;
        $reviewRemain = 0;
        $expiration_date = "";
      
        if($user_active_coach_review){
            $total_review = $user_active_coach_review->coach_review;    
            $reviewRemain = $user_active_coach_review->coach_review - $user_active_coach_review->used_coach_review;
            $expiration_date = $user_active_coach_review->expiration_date;
        }
        $swingData = [];
        $i = $swings->count();
        foreach ($swings as $key => $swing) {
            $date = new DateTime($swing["updated_at"]);
            $formattedDate = $date->format('d F, Y');
            $swingData[$key]['id'] =  $swing["_id"];
            $swingData[$key]['title'] =  "Player Packet #".$i;
            $swingData[$key]['user_id'] =  $swing["user_id"];
            $swingData[$key]['down_the_line'] = $swing['down_the_line'] != '' ? $appUrl.''.$swingPath.''.$swing['down_the_line'] : '';
            $swingData[$key]['face_on'] = $swing['face_on'] != '' ? $appUrl.''.$swingPath.''.$swing['face_on'] : '';
            $swingData[$key]['face_on_duration'] = $swing["face_on_duration"]?? "";
            $swingData[$key]['down_the_line_duration'] = $swing["down_the_line_duration"]?? "";
            $swingData[$key]['submit_to_coach'] = $swing["submit_to_coach"]?? false;
            $admin_coach_review = AdminCoachReview::where('swing_id', $swing["_id"])->first();
            if($admin_coach_review){
                $swingData[$key]['coach_review'] = true;
                
            }else{
                $swingData[$key]['coach_review'] = false;
            }
            $swingData[$key]['direction'] =  $swing["direction"] ?? "";
            $swingData[$key]['curve'] =  $swing["curve"] ?? "";
            $swingData[$key]['contact'] =  $swing["contact"] ?? "";
            $swingData[$key]['face'] =  $swing["face"] ?? "";
            $swingData[$key]['status'] =  $swing["status"] ?? "Pending";
            $swingData[$key]['description'] =  $swing["description"] ?? "";
            $swingData[$key]['last_update'] = $formattedDate;
            $i--;
        }
        $newRoot = [
            'swings' => $swingData,
            'total_review' => $total_review,
            'review_remain' => $reviewRemain,
            'expiration_date' => $expiration_date
        ];
        return $newRoot;          
    }
    public static function swing($user,$search = ""){
        $appUrl = env('AWS_S3_PATH');
        $swingPath = env('AWS_SWING_PATH');
        $swings = Swing::where('user_id', $user["_id"])->orderBy('created_at','desc')->get();
        $today = now()->format("Y-m-d");

        $total_review = $reviewRemain = 0;
        $usedReview = 0;
        $expiration_date = null;
        $expiration_dates = [];

        $user_active_coach_reviews = UserCoachReview::where('user_id', $user["userid"])->where('expiration_date', '>=', $today)->where('status', 'active')->orderBy('created_at')->get();
            
        if(!empty($user_active_coach_reviews)){
            foreach ($user_active_coach_reviews as $user_active_coach_review) {
                $rowReview = $user_active_coach_review->coach_review;
                $rowUsedReview = $user_active_coach_review->used_coach_review;
                $rowExpirationDate = $user_active_coach_review->expiration_date;
            
                $total_review += $rowReview;
                $usedReview += $rowUsedReview;
                $expiration_dates[] = $rowExpirationDate;
            }
            
            $reviewRemain = $total_review - $usedReview;
            $expiration_date = end($expiration_dates);
        }

        $swingData = [];
        $i = $swings->count();
        foreach ($swings as $key => $swing) {
            $date = new DateTime($swing["updated_at"]);
            $formattedDate = $date->format('d F, Y');
            $swingData[$key]['id'] =  $swing["_id"];
            $swingData[$key]['title'] =  "Player Packet #".$i;
            $swingData[$key]['user_id'] =  $swing["user_id"];
            $swingData[$key]['down_the_line'] = $swing['down_the_line'] != '' ? $appUrl.''.$swingPath.''.$swing['down_the_line'] : '';
            $swingData[$key]['face_on'] = $swing['face_on'] != '' ? $appUrl.''.$swingPath.''.$swing['face_on'] : '';
            $swingData[$key]['face_on_duration'] = $swing["face_on_duration"]?? "";
            $swingData[$key]['down_the_line_duration'] = $swing["down_the_line_duration"]?? "";
            $swingData[$key]['down_the_line_filesize'] = $swing["down_the_line_filesize"]?? "";
            $swingData[$key]['face_on_filesize'] = $swing["face_on_filesize"]?? "";
            $swingData[$key]['submit_to_coach'] = $swing["submit_to_coach"]?? false;
            $admin_coach_review = AdminCoachReview::where('swing_id', $swing["_id"])->first();
            if($admin_coach_review){
                $swingData[$key]['coach_review'] = true;
                
            }else{
                $swingData[$key]['coach_review'] = false;
            }
            $swingData[$key]['direction'] =  $swing["direction"] ?? "";
            $swingData[$key]['curve'] =  $swing["curve"] ?? "";
            $swingData[$key]['contact'] =  $swing["contact"] ?? "";
            $swingData[$key]['face'] =  $swing["face"] ?? "";
            $swingData[$key]['status'] =  $swing["status"] ?? "Pending";
            $swingData[$key]['description'] =  $swing["description"] ?? "";
            $swingData[$key]['last_update'] = $formattedDate;
            $i--;
        }
        $newRoot = [
            'swings' => $swingData,
            'total_review' => $total_review,
            'review_remain' => $reviewRemain,
            'expiration_date' => $expiration_date
        ];
        return $newRoot;          
    }
}

?>