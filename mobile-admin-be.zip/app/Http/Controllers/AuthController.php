<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\DisplayImages;
use App\Helpers\ApiResponse;
use App\Helpers\Functions;
use App\Mail\AdminNotificationEmail;
use App\Mail\ContactUsEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Mail\WelcomeEmail;
use App\Models\ContactUs;
use App\Models\Country;
use App\Models\Faq;
use App\Models\Group;
use App\Models\InformationCenter;
use App\Models\InformationCenterImages;
use App\Models\PaymentSetting;
use App\Models\PrivacyPolicy;
use App\Models\PromoCode;
use App\Models\TermService;
use App\Models\Unit;
use App\Models\UserBillingHistory;
use App\Models\UserCoachReview;
use App\Models\UserFcmToken;
use App\Models\UserQuestionAnswer;
use App\Models\UserUnlockedSession;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use DateTime;
use DateTimeZone;

class AuthController extends Controller
{
    public function __construct()
    {
            $this->middleware('auth:api',['except' => ['getFaq','deleteUser','getPrivacyPolicy','getTermServcie','getInformationCenter','login','social_login','contactUs','register','resendEmail','getTimezone','getCountryTimezone']]);
    }

    /**
    * Developer: Apptodate 0
    * Comment: App login
    */
    public function getInformationCenter()
    {
        try{
            // Initialize the root data structure
            $newRoot = [
                'information_center_images' => [],
                'information_center_question' => [],
            ];
            // Initialize arrays to store information center images and questions
            $infoImage = [];
            $infoQuestion = [];
            $infoImages = InformationCenterImages::all();// Retrieve all information center images from the database
            $infoQuestions = InformationCenter::all();// Retrieve all information center questions from the database
            // Process information center images
            foreach ($infoImages as $key => $value) {
                // Set image and title for each information center image
                $infoImage[$key]["image"] = $value["image"];
                $infoImage[$key]["title"] = $value["title"];
            }
            // Process information center questions
            foreach ($infoQuestions as $key => $value) {
                // Set question and answer for each information center question
                // Set question and answer for each information center question
                $infoQuestion[$key]["question"] = $value["question"];
                $infoQuestion[$key]["answer"] = $value["answer"];
            }
            
           $newRoot['information_center_images'] = $infoImage;
           $newRoot['information_center_question'] = $infoQuestion;

            return ApiResponse::success($newRoot,'Information center data fetch successfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getTermServcie()
    {
        try{
            $faqs = TermService::first();
            return ApiResponse::success($faqs,'Terms &service fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getPrivacyPolicy()
    {
        try{
            $faqs = PrivacyPolicy::first();
            return ApiResponse::success($faqs,'Privacy Policy fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getFaq()
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_FAQ_PATH');
            $faqs = Faq::orderBy('order', 'asc')->get();
            foreach ($faqs as $faq) {
                $faq->image = $faq->image ?? "";
                $faq->vimeo_link = $faq->vimeo_link ?? "";
                $faq->image_url = $faq->image != "" ? $appUrl."".$path."".$faq->image :"";
                $faq->order  = intval($faq->order) ?? 0;
            }
            return ApiResponse::success($faqs,'Faq fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    public function contactUs(Request $request)
    {
        try{
            $request->validate([
                'subject' => 'required',
                'message' => 'required',
                'email' => 'required',
            ]);
            // Get token from header and authenticate user
           
            $contactUs = new ContactUs();
            $contactUs->subject = $request->subject;
            $contactUs->message = $request->message;
            $contactUs->email = $request->email;
            $contactUs->user_id = "";
            $contactUs->save();
            Mail::to('kurt@fisiotraining.com')->send(new ContactUsEmail($contactUs));
            return ApiResponse::successOnly('Contact us added successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function loginOld(Request $request){
        // Validate request parameters
        $validator = Validator::make($request->all(), [
            'email' => 'string|required|email',
            'password' => 'string|required',
            'user_type' => 'required',
            'fcm_token' => 'nullable',
            'device_type' => 'nullable'
        ]);
    
        if ($validator->fails()) {
            return response()->json(['message' => 'The provided credentials are invalid'], 200);
        }
        
        $credentials = $request->only('email', 'password');
        $userType = $request->input('user_type');
        // Find the user with the provided email and check if they are confirmed
        $check_email_exist = User::where('email', $credentials['email'])->first();
        if(!$check_email_exist){
            return response()->json([
                'success' => false,
                'message' => 'This email does not exist in our records. Please check the email and try again.',
            ], 400);
        }else{
            if($check_email_exist->is_confirm != 1){
                return response()->json([
                    'success' => false,
                    'message' => "You haven't completed the verification process. We've sent you an email - please check your email inbox.",
                ], 400);
            }
        }
        $user = User::where('email', $credentials['email'])->where('is_confirm', 1)->first();
        $user->last_login_at = now();
        if(!empty($request->device_type)){
            $user->device_type = $request->device_type;
            $user->save();
        }
        if(!empty($request->fcm_token) ){
            $user->fcm_token = $request->fcm_token;
            $user->save();
        }
        if($request->fcm_token == "" || $request->fcm_token == null){
            $user->fcm_token = "";
            $user->save();
        }
        if(empty($user) || !Hash::check($credentials['password'], $user->password)) {
            // Invalid credentials or unconfirmed user
            return response()->json([
                'success' => false,
                'message' => 'Invalid Password',
            ], 400);
        }
        
        if ($userType === 'admin' && $user->user_type !== 'admin') {
            // User is not an admin
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: User is not an admin',
            ], 400);
        }
        
        if ($userType === 'user' && $user->user_type !== 'user') {
            // User is not a regular user
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: User is not a regular user',
            ], 400);
        }
        // Generate token for the authenticated user
        $token = \JWTAuth::fromUser($user);
        $user->last_login_at = now()->format('Y-m-d H:i');
        $user->save();
        return response()->json([
            'success' => true,
            'message' => 'User login successfully',
            'user' => $user,
            'token' => $token,
            'type' => 'bearer',
        ]);

    }

    public function social_login(Request $request){
        try{
            // Validate request parameters
            $validator = Validator::make($request->all(), [
                'providerId' => 'string|required',
                'provider' => 'required',
                'fcm_token' => 'nullable',
                'device_type' => 'nullable'
            ]);
        
            if ($validator->fails()) {
                return response()->json(['message' => 'The provided credentials are invalid'], 200);
            }
           
            if($request->provider == "apple"){
                $user = User::where('providerId', $request->providerId)->first();
            }else{
                $user = User::where('email', $request->email)->first();
            }
            // Find the user with the provided email and check if they are confirmed
         
            if(!$user){
                $user = new User();
                $user->is_confirm = 1;
                $user->user_type = 'user';
                $name = $request->name ?? "";
                $user->email = $request->email != null ? $request->email : "";
             
                $user->password = "";
                $user->registered_at = Carbon::now(); 
                // Set additional optional fields
                $fullName = $request->full_name ?? "";
             
                if($fullName != ""){
                    $nameParts = explode(' ', trim($fullName));
                    $firstName = $nameParts[0] ?? '';
                    $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';
                    $name = $fullName;
                }else{
                    $firstName =  $request->first_name ?? "";
                    $lastName =  $request->last_name ?? "";
                    $name = "";
                }
               
                if($name == "" && $firstName != ""){
                    $user->first_name = $firstName;
                    $user->last_name = $lastName;
                    $name = $firstName." ".$lastName;
                }else{
                    $user->first_name = "";
                    $user->last_name = "";
                }
                $user->full_name = $name;
                $user->gender = "";
                $user->birthday = "";
                $user->height = "";
                $user->weight = "";
                $user->address = "";
                $user->country = "";
                $user->postal_code = "";
                $user->time_zone = "";
                $user->last_login_at = now()->format('Y-m-d H:i');
                $user->training_streak = 0;
                $user->mulligan = 0;
                $user->affiliate_deeplink = $request->input('affiliate_deeplink') ?? "";
                //$user->last_updated_training_streak = now()->format('Y-m-d'); 
                $currentDate = now()->format('Y-m-d');
                $previousDay = date('Y-m-d', strtotime($currentDate . ' -1 day'));
                // Now you can update $user->last_updated_training_streak
                $user->last_updated_training_streak = $previousDay;
                // Generate a unique userid for the user
                $userid = User::max('userid');
                if($userid) {
                    $userid = $userid + 1;
                }else{
                    $userid = 1;
                }
                $defaultProgram = env('DEFAULT_PROGRAM');
                $user->userid = $userid;
                $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                    
                $defaultGroupId = $defaultGroup->_id ?? 0;
                $user->group_id = $defaultGroupId;
                $user->save();
            }else{
             
                $fullName = $request->full_name ?? "";
             
                if($fullName != ""){
                    $nameParts = explode(' ', trim($fullName));
                    $firstName = $nameParts[0] ?? '';
                    $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';
                    $name = $fullName;
                }else{
                    $firstName =  $request->first_name ?? "";
                    $lastName =  $request->last_name ?? "";
                    $name = "";
                }
              
                if($name != ""){
                    $user->first_name = $name;
                }
                if($firstName != ""){
                    $user->first_name = $firstName;
                }
                if($lastName != ""){
                    $user->last_name = $lastName;
                }
                $user->save();
            }
            
            $user->is_confirm = 1;
            $user->provider = $request->provider;
            $user->providerId = $request->providerId;
            $user->last_login_at = now();
            if(!empty($request->device_type)){
                $user->device_type = $request->device_type;
                $user->save();
            }
            if(!empty($request->fcm_token)){
                $sameFCMTokenUsers =  User::where('fcm_token',$request->fcm_token)->get();
                if($sameFCMTokenUsers->count() > 0){
                    foreach ($sameFCMTokenUsers as $sameFCMTokenUser) {
                        $sameFCMTokenUser->fcm_token = "";
                        $sameFCMTokenUser->save();
                    }
                }
                $user->fcm_token = $request->fcm_token;
                $user->save();

                $userFCMTokensMatchs = UserFcmToken::where('fcm_token',$request->fcm_token)->get();
                if($userFCMTokensMatchs->count() > 0){
                    foreach ($userFCMTokensMatchs as $userFCMTokensMatch) {
                        $userFCMTokensMatch->delete();
                    }
                }
                $userFCMToken = new UserFcmToken();
                $userFCMToken->user_id = $user->_id;
                $userFCMToken->fcm_token = $request->fcm_token;
                $userFCMToken->latest = 1;
                $userFCMToken->device_type = $request->device_type ?? "";
                $userFCMToken->save();
                $userFcmTokens = UserFcmToken::where('fcm_token','!=',$request->fcm_token)->where('user_id',$user->_id)->get();
                if($userFcmTokens->count() > 0){
                    foreach ($userFcmTokens as $userFcmToken) {
                        $userFcmToken->latest = 0;
                        $userFCMToken->save();
                    }
                }
            }
           
            // Generate token for the authenticated user
            $token = \JWTAuth::fromUser($user);
            $user->last_login_at = now()->format('Y-m-d H:i');+
            $user->save();
            return response()->json([
                'success' => true,
                'message' => 'User login successfully',
                'user' => $user,
                'token' => $token,
                'type' => 'bearer',
            ]);
        } catch (\Exception $e) {
            return ApiResponse::error('Please login to your account.');
        }
    }

    public function login(Request $request){

        try{
            // Validate request parameters
            $validator = Validator::make($request->all(), [
                'email' => 'string|required|email',
                'password' => 'string|required',
                'user_type' => 'required',
                'fcm_token' => 'nullable',
                'device_type' => 'nullable'
            ]);
        
            if ($validator->fails()) {
                return response()->json(['message' => 'The provided credentials are invalid'], 200);
            }
            
            $credentials = $request->only('email', 'password');
            $userType = $request->input('user_type');
            // Find the user with the provided email and check if they are confirmed
            $check_email_exist = User::where('email', $credentials['email'])->first();
            if(!$check_email_exist){
                return response()->json([
                    'success' => false,
                    'message' => 'This email does not exist in our records. Please check the email and try again.',
                ], 400);
            }else{
                if($check_email_exist->is_confirm != 1){
                    return response()->json([
                        'success' => false,
                        'message' => "You haven't completed the verification process. We've sent you an email - please check your email inbox.",
                    ], 400);
                }
            }
            $user = User::where('email', $credentials['email'])->where('is_confirm', 1)->first();
            $user->last_login_at = now();
            if(!empty($request->device_type)){
                $user->device_type = $request->device_type;
                $user->save();
            }
            if(!empty($request->fcm_token)){
                $sameFCMTokenUsers =  User::where('fcm_token',$request->fcm_token)->get();
                if($sameFCMTokenUsers->count() > 0){
                    foreach ($sameFCMTokenUsers as $sameFCMTokenUser) {
                        $sameFCMTokenUser->fcm_token = "";
                        $sameFCMTokenUser->save();
                    }
                }
                $user->fcm_token = $request->fcm_token;
                $user->save();

                $userFCMTokensMatchs = UserFcmToken::where('fcm_token',$request->fcm_token)->get();
                if($userFCMTokensMatchs->count() > 0){
                    foreach ($userFCMTokensMatchs as $userFCMTokensMatch) {
                        $userFCMTokensMatch->delete();
                    }
                }
                $userFCMToken = new UserFcmToken();
                $userFCMToken->user_id = $user->_id;
                $userFCMToken->fcm_token = $request->fcm_token;
                $userFCMToken->latest = 1;
                $userFCMToken->device_type = $request->device_type ?? "";
                $userFCMToken->save();
                $userFcmTokens = UserFcmToken::where('fcm_token','!=',$request->fcm_token)->where('user_id',$user->_id)->get();
                if($userFcmTokens->count() > 0){
                    foreach ($userFcmTokens as $userFcmToken) {
                        $userFcmToken->latest = 0;
                        $userFCMToken->save();
                    }
                }
            }
            if(empty($user) || !Hash::check($credentials['password'], $user->password)) {
                // Invalid credentials or unconfirmed user
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid Password',
                ], 400);
            }
            
            if ($userType === 'admin' && $user->user_type !== 'admin') {
                // User is not an admin
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: User is not an admin',
                ], 400);
            }

            if ($userType === 'coach' && $user->user_type !== 'coach') {
                // User is not an admin
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: User is not an admin',
                ], 400);
            }
            
            if ($userType === 'user' && $user->user_type !== 'user') {
                // User is not a regular user
                return response()->json([
                    'success' => false,
                    'message' => 'Please login to your account.',
                ], 400);
            }
            // Generate token for the authenticated user
            $token = \JWTAuth::fromUser($user);
            $user->last_login_at = now()->format('Y-m-d H:i');
            $user->save();
            return response()->json([
                'success' => true,
                'message' => 'User login successfully',
                'user' => $user,
                'token' => $token,
                'type' => 'bearer',
            ]);
            
        } catch (\Exception $e) {
            return ApiResponse::error('Please login to your account.');
        }
        

    }

    /**
    * Developer: Apptodate 
    * Comment: User registration 
    */
    public function deleteUser($id)
    {
        try {
            $user = User::find($id);
            if (!$user) {
                return ApiResponse::error('User not found');
            }
            UserQuestionAnswer::where('user_id',$user->userid)->delete();
            $user->delete();
            return ApiResponse::successOnly('User deleted successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function register(Request $request)
    {
        try{
            // Validate request parameters
            $request->validate([
                'first_name' => 'required',
                'last_name' => 'nullable',
                'name' => 'nullable',
                'email' => 'required|email|unique:users',
                'password' => 'required|min:6',
                'device_type' => 'nullable',
                'fcm_token' => 'nullable',
                'affiliate_deeplink' => 'nullable|string' 
            ], [
                'email.unique' => 'That email is already registered. To Sign Up, please use a different email. Or, go to Sign In, enter that email, and click “Forgot Password” to recover.', // Custom message for unique rule
            ]);
    
            // Create a new User instance and set the input values
            $user = new User();
            $first_name = $request->input('first_name') ?? "";
            $last_name = $request->input('last_name') ?? "";
            $fullName = $request->input('name') ?? "";
            if($fullName == ""){
                $fullName = $first_name. " ".$last_name;
            }
            
            $user->first_name = $first_name ?? "";
            $user->last_name = $last_name ?? "";
            $user->full_name = $fullName ?? "";
            $user->email = $request->input('email');
            $user->password = bcrypt($request->input('password'));
            $user->user_type = $request->input('user_type');
            $user->registered_at = Carbon::now(); 
            // Set additional optional fields
            $user->status = true;
            // $user->first_name = "";
            // $user->last_name = "";
            $user->gender = "";
            $user->birthday = "";
            $user->height = "";
            $user->weight = "";
            $user->address = "";
            $user->country = "";
            $user->postal_code = "";
            $user->time_zone = "";
            $user->last_login_at = now()->format('Y-m-d H:i');
            $user->training_streak = 0;
            $user->mulligan = 0;
            $user->affiliate_deeplink = $request->input('affiliate_deeplink');
            //$user->last_updated_training_streak = now()->format('Y-m-d'); 
            $currentDate = now()->format('Y-m-d');
            $previousDay = date('Y-m-d', strtotime($currentDate . ' -1 day'));
            // Now you can update $user->last_updated_training_streak
            $user->last_updated_training_streak = $previousDay;
            // Generate a unique userid for the user
            $userid = User::max('userid');
            if($userid) {
                $userid = $userid + 1;
            }else{
                 $userid = 1;
            }
            $defaultProgram = env('DEFAULT_PROGRAM');
            $user->userid = $userid;
            $user->is_confirm = 0;
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                    
            $defaultGroupId = $defaultGroup->_id ?? 0;
            $user->group_id = $request->group_id ?? $defaultGroupId;
            if(!empty($request->device_type)){
                $user->device_type = $request->device_type;
            }
            if(!empty($request->fcm_token)){
                $user->fcm_token = $request->fcm_token;
                
            }
            if($request->fcm_token == "" || $request->fcm_token == null){
                $user->fcm_token = "";
            }
            $user->save();
            if(!empty($request->fcm_token)){
               $userFCMToken = new UserFcmToken();
               $userFCMToken->user_id = $user->_id;
               $userFCMToken->fcm_token = $request->fcm_token;
               $userFCMToken->latest = 1;
               $userFCMToken->device_type = $request->device_type ?? "";
               $userFCMToken->save();
            }
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            if(!empty($user->group_id)){
                $group = Group::find($user->group_id);
                if($group){
                    $unitIds = array_column($group["group_object"], "object_id");
                    $unit = Unit::whereIn('_id', $unitIds )->where('category_type_id','64870ab2514154525c6bdb29')->get();
                }else{
                    $unit = Unit::whereIn('_id', $default_unitIds )->where('category_type_id','64870ab2514154525c6bdb29')->get();
                }
            }else{
                $unit = Unit::whereIn('_id', $default_unitIds )->where('category_type_id','64870ab2514154525c6bdb29')->get();
            }
            $userUnlockedSession = new UserUnlockedSession();
            $userUnlockedSession->user_id = $user["_id"];
            $userUnlockedSession->unit_id = $unit[0]->_id;
            $userUnlockedSession->session_id = $unit[0]->unit_object[0]['object_id'];
            $userUnlockedSession->date = now()->format('Y-m-d');
            $userUnlockedSession->save();

            $paymentSetting = PaymentSetting::first();
            
            if($paymentSetting->free_app == true){
                $userBillingHistory = new UserBillingHistory();
                $userBillingHistory->transaction_no = Functions::generateUniqueNumber();
                $userBillingHistory->user_id = $user["_id"];
                $userBillingHistory->plan_id = "65e12c65bff8603059751932"; // need to do dynamic later
                $userBillingHistory->amount = 0;
                $userBillingHistory->status = "active";
                $userBillingHistory->payment_status = "Paid";
                $userBillingHistory->payment_method = "";
                $userBillingHistory->expiry_date = Carbon::now()->addMonth(3)->format('Y-m-d H:i:s');
                $userBillingHistory->save();
                $userCoachReview = new UserCoachReview();
                $userCoachReview->user_id = $user["userid"];
                $userCoachReview->coach_review = 6;
                $userCoachReview->used_coach_review = 0;
                $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                $userCoachReview->status = 'active';
                $userCoachReview->save();
            }
            // else{
            //     $userBillingHistory = new UserBillingHistory();
            //     $userBillingHistory->transaction_no = Functions::generateUniqueNumber();
            //     $userBillingHistory->user_id = $user["_id"];
            //     $userBillingHistory->plan_id = "65e12b53bff860305975192f"; // need to do dynamic later
            //     $userBillingHistory->amount = 0;
            //     $userBillingHistory->status = "active";
            //     $userBillingHistory->payment_status = "Paid";
            //     $userBillingHistory->payment_method = "";
            //     $userBillingHistory->expiry_date = now()->addDays(7)->format('Y-m-d H:i:s');
            //     $userBillingHistory->save();
            // }
            
            // Send a welcome email to the registered user
            Mail::to($request->input('email'))->send(new WelcomeEmail($user->userid));
            $adminEmail = env('KURT_EMAIL');
            Mail::to($adminEmail)->send(new AdminNotificationEmail($user));
            return ApiResponse::success($user,'User register successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    
    }

    public function getCountryTimezone(){
        $country = Country::get();
        // foreach ($country as $key => $c) {
        //     $c->field = $c->utc_offset.": ".$c->standard_time;
        // }
        //foreach ($country as $key => $c) {
            // $gmtOffSet = $c->gmt_offset;
            // $parts = explode(" ", $gmtOffSet);
            // $hours = explode(":", $parts[1])[0];
            // $hoursInt = (int)$hours;
            // $convertedOffset = "(GMT" . sprintf("%+d", $hoursInt) . ")";

            // $newOffset = $convertedOffset;
            // $c->hoursInt = $hoursInt;
           
            // if (Str::contains("Eastern (GMT-4)", $newOffset)) {
            //     $c->field = "Eastern (GMT-4)";
            // } 
            // if (Str::contains("Central (GMT-5)", $newOffset)) {
            //     $c->field = "Central (GMT-5)";
            // }   
            // if (Str::contains("Mountain (GMT-6)", $newOffset)) {
            //     $c->field = "Mountain (GMT-6)";
            // } 
            // if (Str::contains("Pacific (GMT-7)", $newOffset)) {
            //     $c->field = "Pacific (GMT-7)";
            // } 
            // if (Str::contains("Alaska (GMT-8)", $newOffset)) {
            //     $c->field = "Alaska (GMT-8)";
            // } 
            // if (Str::contains("Hawaii (GMT-10)", $newOffset)) {
            //     $c->field = "Hawaii (GMT-10)";
            // } 
        //}

        // $sortColumn = "";
        // $sortedData = Functions::sortArray($country,$sortColumn);
        return ApiResponse::success($country,'country with timezone successfully');
    }
    
    public function getTimezone()
    {
        try{
            $jsonData = '[
                {
                    "id": "AD",
                    "name": "Andorra",
                    "timezones": [
                        "Europe/Andorra"
                    ]
                },
                {
                    "id": "AE",
                    "name": "United Arab Emirates",
                    "timezones": [
                        "Asia/Dubai"
                    ]
                },
                {
                    "id": "AF",
                    "name": "Afghanistan",
                    "timezones": [
                        "Asia/Kabul"
                    ]
                },
                {
                    "id": "AG",
                    "name": "Antigua and Barbuda",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "AI",
                    "name": "Anguilla",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "AL",
                    "name": "Albania",
                    "timezones": [
                        "Europe/Tirane"
                    ]
                },
                {
                    "id": "AM",
                    "name": "Armenia",
                    "timezones": [
                        "Asia/Yerevan"
                    ]
                },
                {
                    "id": "AO",
                    "name": "Angola",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "AQ",
                    "name": "Antarctica",
                    "timezones": [
                        "Antarctica/Casey",
                        "Antarctica/Davis",
                        "Antarctica/Mawson",
                        "Antarctica/Palmer",
                        "Antarctica/Rothera",
                        "Antarctica/Troll",
                        "Asia/Riyadh",
                        "Asia/Urumqi",
                        "Pacific/Auckland",
                        "Pacific/Port_Moresby"
                    ]
                },
                {
                    "id": "AR",
                    "name": "Argentina",
                    "timezones": [
                        "America/Argentina/Buenos_Aires",
                        "America/Argentina/Catamarca",
                        "America/Argentina/Cordoba",
                        "America/Argentina/Jujuy",
                        "America/Argentina/La_Rioja",
                        "America/Argentina/Mendoza",
                        "America/Argentina/Rio_Gallegos",
                        "America/Argentina/Salta",
                        "America/Argentina/San_Juan",
                        "America/Argentina/San_Luis",
                        "America/Argentina/Tucuman",
                        "America/Argentina/Ushuaia"
                    ]
                },
                {
                    "id": "AS",
                    "name": "American Samoa",
                    "timezones": [
                        "Pacific/Pago_Pago"
                    ]
                },
                {
                    "id": "AT",
                    "name": "Austria",
                    "timezones": [
                        "Europe/Vienna"
                    ]
                },
                {
                    "id": "AU",
                    "name": "Australia",
                    "timezones": [
                        "Antarctica/Macquarie",
                        "Australia/Adelaide",
                        "Australia/Brisbane",
                        "Australia/Broken_Hill",
                        "Australia/Darwin",
                        "Australia/Eucla",
                        "Australia/Hobart",
                        "Australia/Lindeman",
                        "Australia/Lord_Howe",
                        "Australia/Melbourne",
                        "Australia/Perth",
                        "Australia/Sydney"
                    ]
                },
                {
                    "id": "AW",
                    "name": "Aruba",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "AX",
                    "name": "Åland Islands",
                    "timezones": [
                        "Europe/Helsinki"
                    ]
                },
                {
                    "id": "AZ",
                    "name": "Azerbaijan",
                    "timezones": [
                        "Asia/Baku"
                    ]
                },
                {
                    "id": "BA",
                    "name": "Bosnia and Herzegovina",
                    "timezones": [
                        "Europe/Belgrade"
                    ]
                },
                {
                    "id": "BB",
                    "name": "Barbados",
                    "timezones": [
                        "America/Barbados"
                    ]
                },
                {
                    "id": "BD",
                    "name": "Bangladesh",
                    "timezones": [
                        "Asia/Dhaka"
                    ]
                },
                {
                    "id": "BE",
                    "name": "Belgium",
                    "timezones": [
                        "Europe/Brussels"
                    ]
                },
                {
                    "id": "BF",
                    "name": "Burkina Faso",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "BG",
                    "name": "Bulgaria",
                    "timezones": [
                        "Europe/Sofia"
                    ]
                },
                {
                    "id": "BH",
                    "name": "Bahrain",
                    "timezones": [
                        "Asia/Qatar"
                    ]
                },
                {
                    "id": "BI",
                    "name": "Burundi",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "BJ",
                    "name": "Benin",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "BL",
                    "name": "Saint Barthélemy",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "BM",
                    "name": "Bermuda",
                    "timezones": [
                        "Atlantic/Bermuda"
                    ]
                },
                {
                    "id": "BN",
                    "name": "Brunei",
                    "timezones": [
                        "Asia/Kuching"
                    ]
                },
                {
                    "id": "BO",
                    "name": "Bolivia",
                    "timezones": [
                        "America/La_Paz"
                    ]
                },
                {
                    "id": "BQ",
                    "name": "Caribbean Netherlands",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "BR",
                    "name": "Brazil",
                    "timezones": [
                        "America/Araguaina",
                        "America/Bahia",
                        "America/Belem",
                        "America/Boa_Vista",
                        "America/Campo_Grande",
                        "America/Cuiaba",
                        "America/Eirunepe",
                        "America/Fortaleza",
                        "America/Maceio",
                        "America/Manaus",
                        "America/Noronha",
                        "America/Porto_Velho",
                        "America/Recife",
                        "America/Rio_Branco",
                        "America/Santarem",
                        "America/Sao_Paulo"
                    ]
                },
                {
                    "id": "BS",
                    "name": "Bahamas",
                    "timezones": [
                        "America/Toronto"
                    ]
                },
                {
                    "id": "BT",
                    "name": "Bhutan",
                    "timezones": [
                        "Asia/Thimphu"
                    ]
                },
                {
                    "id": "BV",
                    "name": "Bouvet Island",
                    "timezones": []
                },
                {
                    "id": "BW",
                    "name": "Botswana",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "BY",
                    "name": "Belarus",
                    "timezones": [
                        "Europe/Minsk"
                    ]
                },
                {
                    "id": "BZ",
                    "name": "Belize",
                    "timezones": [
                        "America/Belize"
                    ]
                },
                {
                    "id": "CA",
                    "name": "Canada",
                    "timezones": [
                        "America/Cambridge_Bay",
                        "America/Dawson",
                        "America/Dawson_Creek",
                        "America/Edmonton",
                        "America/Fort_Nelson",
                        "America/Glace_Bay",
                        "America/Goose_Bay",
                        "America/Halifax",
                        "America/Inuvik",
                        "America/Iqaluit",
                        "America/Moncton",
                        "America/Panama",
                        "America/Phoenix",
                        "America/Puerto_Rico",
                        "America/Rankin_Inlet",
                        "America/Regina",
                        "America/Resolute",
                        "America/St_Johns",
                        "America/Swift_Current",
                        "America/Toronto",
                        "America/Vancouver",
                        "America/Whitehorse",
                        "America/Winnipeg",
                        "America/Yellowknife"
                    ]
                },
                {
                    "id": "CC",
                    "name": "Cocos Islands",
                    "timezones": [
                        "Asia/Yangon"
                    ]
                },
                {
                    "id": "CD",
                    "name": "Democratic Republic of the Congo",
                    "timezones": [
                        "Africa/Lagos",
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "CF",
                    "name": "Central African Republic",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "CG",
                    "name": "Republic of the Congo",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "CH",
                    "name": "Switzerland",
                    "timezones": [
                        "Europe/Zurich"
                    ]
                },
                {
                    "id": "CI",
                    "name": "Ivory Coast",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "CK",
                    "name": "Cook Islands",
                    "timezones": [
                        "Pacific/Rarotonga"
                    ]
                },
                {
                    "id": "CL",
                    "name": "Chile",
                    "timezones": [
                        "America/Punta_Arenas",
                        "America/Santiago",
                        "Pacific/Easter"
                    ]
                },
                {
                    "id": "CM",
                    "name": "Cameroon",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "CN",
                    "name": "China",
                    "timezones": [
                        "Asia/Shanghai",
                        "Asia/Urumqi"
                    ]
                },
                {
                    "id": "CO",
                    "name": "Colombia",
                    "timezones": [
                        "America/Bogota"
                    ]
                },
                {
                    "id": "CR",
                    "name": "Costa Rica",
                    "timezones": [
                        "America/Costa_Rica"
                    ]
                },
                {
                    "id": "CU",
                    "name": "Cuba",
                    "timezones": [
                        "America/Havana"
                    ]
                },
                {
                    "id": "CV",
                    "name": "Cabo Verde",
                    "timezones": [
                        "Atlantic/Cape_Verde"
                    ]
                },
                {
                    "id": "CW",
                    "name": "Curaçao",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "CX",
                    "name": "Christmas Island",
                    "timezones": [
                        "Asia/Bangkok"
                    ]
                },
                {
                    "id": "CY",
                    "name": "Cyprus",
                    "timezones": [
                        "Asia/Famagusta",
                        "Asia/Nicosia"
                    ]
                },
                {
                    "id": "CZ",
                    "name": "Czechia",
                    "timezones": [
                        "Europe/Prague"
                    ]
                },
                {
                    "id": "DE",
                    "name": "Germany",
                    "timezones": [
                        "Europe/Berlin",
                        "Europe/Zurich"
                    ]
                },
                {
                    "id": "DJ",
                    "name": "Djibouti",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "DK",
                    "name": "Denmark",
                    "timezones": [
                        "Europe/Berlin"
                    ]
                },
                {
                    "id": "DM",
                    "name": "Dominica",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "DO",
                    "name": "Dominican Republic",
                    "timezones": [
                        "America/Santo_Domingo"
                    ]
                },
                {
                    "id": "DZ",
                    "name": "Algeria",
                    "timezones": [
                        "Africa/Algiers"
                    ]
                },
                {
                    "id": "EC",
                    "name": "Ecuador",
                    "timezones": [
                        "America/Guayaquil",
                        "Pacific/Galapagos"
                    ]
                },
                {
                    "id": "EE",
                    "name": "Estonia",
                    "timezones": [
                        "Europe/Tallinn"
                    ]
                },
                {
                    "id": "EG",
                    "name": "Egypt",
                    "timezones": [
                        "Africa/Cairo"
                    ]
                },
                {
                    "id": "EH",
                    "name": "Western Sahara",
                    "timezones": [
                        "Africa/El_Aaiun"
                    ]
                },
                {
                    "id": "ER",
                    "name": "Eritrea",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "ES",
                    "name": "Spain",
                    "timezones": [
                        "Africa/Ceuta",
                        "Atlantic/Canary",
                        "Europe/Madrid"
                    ]
                },
                {
                    "id": "ET",
                    "name": "Ethiopia",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "FI",
                    "name": "Finland",
                    "timezones": [
                        "Europe/Helsinki"
                    ]
                },
                {
                    "id": "FJ",
                    "name": "Fiji",
                    "timezones": [
                        "Pacific/Fiji"
                    ]
                },
                {
                    "id": "FK",
                    "name": "Falkland Islands",
                    "timezones": [
                        "Atlantic/Stanley"
                    ]
                },
                {
                    "id": "FM",
                    "name": "Micronesia",
                    "timezones": [
                        "Pacific/Guadalcanal",
                        "Pacific/Kosrae",
                        "Pacific/Port_Moresby"
                    ]
                },
                {
                    "id": "FO",
                    "name": "Faroe Islands",
                    "timezones": [
                        "Atlantic/Faroe"
                    ]
                },
                {
                    "id": "FR",
                    "name": "France",
                    "timezones": [
                        "Europe/Paris"
                    ]
                },
                {
                    "id": "GA",
                    "name": "Gabon",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "GB",
                    "name": "United Kingdom",
                    "timezones": [
                        "Europe/London"
                    ]
                },
                {
                    "id": "GD",
                    "name": "Grenada",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "GE",
                    "name": "Georgia",
                    "timezones": [
                        "Asia/Tbilisi"
                    ]
                },
                {
                    "id": "GF",
                    "name": "French Guiana",
                    "timezones": [
                        "America/Cayenne"
                    ]
                },
                {
                    "id": "GG",
                    "name": "Guernsey",
                    "timezones": [
                        "Europe/London"
                    ]
                },
                {
                    "id": "GH",
                    "name": "Ghana",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "GI",
                    "name": "Gibraltar",
                    "timezones": [
                        "Europe/Gibraltar"
                    ]
                },
                {
                    "id": "GL",
                    "name": "Greenland",
                    "timezones": [
                        "America/Danmarkshavn",
                        "America/Nuuk",
                        "America/Scoresbysund",
                        "America/Thule"
                    ]
                },
                {
                    "id": "GM",
                    "name": "Gambia",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "GN",
                    "name": "Guinea",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "GP",
                    "name": "Guadeloupe",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "GQ",
                    "name": "Equatorial Guinea",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "GR",
                    "name": "Greece",
                    "timezones": [
                        "Europe/Athens"
                    ]
                },
                {
                    "id": "GS",
                    "name": "South Georgia and the South Sandwich Islands",
                    "timezones": [
                        "Atlantic/South_Georgia"
                    ]
                },
                {
                    "id": "GT",
                    "name": "Guatemala",
                    "timezones": [
                        "America/Guatemala"
                    ]
                },
                {
                    "id": "GU",
                    "name": "Guam",
                    "timezones": [
                        "Pacific/Guam"
                    ]
                },
                {
                    "id": "GW",
                    "name": "Guinea-Bissau",
                    "timezones": [
                        "Africa/Bissau"
                    ]
                },
                {
                    "id": "GY",
                    "name": "Guyana",
                    "timezones": [
                        "America/Guyana"
                    ]
                },
                {
                    "id": "HK",
                    "name": "Hong Kong",
                    "timezones": [
                        "Asia/Hong_Kong"
                    ]
                },
                {
                    "id": "HM",
                    "name": "Heard Island and McDonald Islands",
                    "timezones": []
                },
                {
                    "id": "HN",
                    "name": "Honduras",
                    "timezones": [
                        "America/Tegucigalpa"
                    ]
                },
                {
                    "id": "HR",
                    "name": "Croatia",
                    "timezones": [
                        "Europe/Belgrade"
                    ]
                },
                {
                    "id": "HT",
                    "name": "Haiti",
                    "timezones": [
                        "America/Port-au-Prince"
                    ]
                },
                {
                    "id": "HU",
                    "name": "Hungary",
                    "timezones": [
                        "Europe/Budapest"
                    ]
                },
                {
                    "id": "ID",
                    "name": "Indonesia",
                    "timezones": [
                        "Asia/Jakarta",
                        "Asia/Jayapura",
                        "Asia/Makassar",
                        "Asia/Pontianak"
                    ]
                },
                {
                    "id": "IE",
                    "name": "Ireland",
                    "timezones": [
                        "Europe/Dublin"
                    ]
                },
                {
                    "id": "IL",
                    "name": "Israel",
                    "timezones": [
                        "Asia/Jerusalem"
                    ]
                },
                {
                    "id": "IM",
                    "name": "Isle of Man",
                    "timezones": [
                        "Europe/London"
                    ]
                },
                {
                    "id": "IN",
                    "name": "India",
                    "timezones": [
                        "Asia/Kolkata"
                    ]
                },
                {
                    "id": "IO",
                    "name": "British Indian Ocean Territory",
                    "timezones": [
                        "Indian/Chagos"
                    ]
                },
                {
                    "id": "IQ",
                    "name": "Iraq",
                    "timezones": [
                        "Asia/Baghdad"
                    ]
                },
                {
                    "id": "IR",
                    "name": "Iran",
                    "timezones": [
                        "Asia/Tehran"
                    ]
                },
                {
                    "id": "IS",
                    "name": "Iceland",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "IT",
                    "name": "Italy",
                    "timezones": [
                        "Europe/Rome"
                    ]
                },
                {
                    "id": "JE",
                    "name": "Jersey",
                    "timezones": [
                        "Europe/London"
                    ]
                },
                {
                    "id": "JM",
                    "name": "Jamaica",
                    "timezones": [
                        "America/Jamaica"
                    ]
                },
                {
                    "id": "JO",
                    "name": "Jordan",
                    "timezones": [
                        "Asia/Amman"
                    ]
                },
                {
                    "id": "JP",
                    "name": "Japan",
                    "timezones": [
                        "Asia/Tokyo"
                    ]
                },
                {
                    "id": "KE",
                    "name": "Kenya",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "KG",
                    "name": "Kyrgyzstan",
                    "timezones": [
                        "Asia/Bishkek"
                    ]
                },
                {
                    "id": "KH",
                    "name": "Cambodia",
                    "timezones": [
                        "Asia/Bangkok"
                    ]
                },
                {
                    "id": "KI",
                    "name": "Kiribati",
                    "timezones": [
                        "Pacific/Kanton",
                        "Pacific/Kiritimati",
                        "Pacific/Tarawa"
                    ]
                },
                {
                    "id": "KM",
                    "name": "Comoros",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "KN",
                    "name": "Saint Kitts and Nevis",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "KP",
                    "name": "North Korea",
                    "timezones": [
                        "Asia/Pyongyang"
                    ]
                },
                {
                    "id": "KR",
                    "name": "South Korea",
                    "timezones": [
                        "Asia/Seoul"
                    ]
                },
                {
                    "id": "KW",
                    "name": "Kuwait",
                    "timezones": [
                        "Asia/Riyadh"
                    ]
                },
                {
                    "id": "KY",
                    "name": "Cayman Islands",
                    "timezones": [
                        "America/Panama"
                    ]
                },
                {
                    "id": "KZ",
                    "name": "Kazakhstan",
                    "timezones": [
                        "Asia/Almaty",
                        "Asia/Aqtau",
                        "Asia/Aqtobe",
                        "Asia/Atyrau",
                        "Asia/Oral",
                        "Asia/Qostanay",
                        "Asia/Qyzylorda"
                    ]
                },
                {
                    "id": "LA",
                    "name": "Laos",
                    "timezones": [
                        "Asia/Bangkok"
                    ]
                },
                {
                    "id": "LB",
                    "name": "Lebanon",
                    "timezones": [
                        "Asia/Beirut"
                    ]
                },
                {
                    "id": "LC",
                    "name": "Saint Lucia",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "LI",
                    "name": "Liechtenstein",
                    "timezones": [
                        "Europe/Zurich"
                    ]
                },
                {
                    "id": "LK",
                    "name": "Sri Lanka",
                    "timezones": [
                        "Asia/Colombo"
                    ]
                },
                {
                    "id": "LR",
                    "name": "Liberia",
                    "timezones": [
                        "Africa/Monrovia"
                    ]
                },
                {
                    "id": "LS",
                    "name": "Lesotho",
                    "timezones": [
                        "Africa/Johannesburg"
                    ]
                },
                {
                    "id": "LT",
                    "name": "Lithuania",
                    "timezones": [
                        "Europe/Vilnius"
                    ]
                },
                {
                    "id": "LU",
                    "name": "Luxembourg",
                    "timezones": [
                        "Europe/Brussels"
                    ]
                },
                {
                    "id": "LV",
                    "name": "Latvia",
                    "timezones": [
                        "Europe/Riga"
                    ]
                },
                {
                    "id": "LY",
                    "name": "Libya",
                    "timezones": [
                        "Africa/Tripoli"
                    ]
                },
                {
                    "id": "MA",
                    "name": "Morocco",
                    "timezones": [
                        "Africa/Casablanca"
                    ]
                },
                {
                    "id": "MC",
                    "name": "Monaco",
                    "timezones": [
                        "Europe/Paris"
                    ]
                },
                {
                    "id": "MD",
                    "name": "Moldova",
                    "timezones": [
                        "Europe/Chisinau"
                    ]
                },
                {
                    "id": "ME",
                    "name": "Montenegro",
                    "timezones": [
                        "Europe/Belgrade"
                    ]
                },
                {
                    "id": "MF",
                    "name": "Saint Martin",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "MG",
                    "name": "Madagascar",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "MH",
                    "name": "Marshall Islands",
                    "timezones": [
                        "Pacific/Kwajalein",
                        "Pacific/Tarawa"
                    ]
                },
                {
                    "id": "MK",
                    "name": "North Macedonia",
                    "timezones": [
                        "Europe/Belgrade"
                    ]
                },
                {
                    "id": "ML",
                    "name": "Mali",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "MM",
                    "name": "Myanmar",
                    "timezones": [
                        "Asia/Yangon"
                    ]
                },
                {
                    "id": "MN",
                    "name": "Mongolia",
                    "timezones": [
                        "Asia/Choibalsan",
                        "Asia/Hovd",
                        "Asia/Ulaanbaatar"
                    ]
                },
                {
                    "id": "MO",
                    "name": "Macao",
                    "timezones": [
                        "Asia/Macau"
                    ]
                },
                {
                    "id": "MP",
                    "name": "Northern Mariana Islands",
                    "timezones": [
                        "Pacific/Guam"
                    ]
                },
                {
                    "id": "MQ",
                    "name": "Martinique",
                    "timezones": [
                        "America/Martinique"
                    ]
                },
                {
                    "id": "MR",
                    "name": "Mauritania",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "MS",
                    "name": "Montserrat",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "MT",
                    "name": "Malta",
                    "timezones": [
                        "Europe/Malta"
                    ]
                },
                {
                    "id": "MU",
                    "name": "Mauritius",
                    "timezones": [
                        "Indian/Mauritius"
                    ]
                },
                {
                    "id": "MV",
                    "name": "Maldives",
                    "timezones": [
                        "Indian/Maldives"
                    ]
                },
                {
                    "id": "MW",
                    "name": "Malawi",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "MX",
                    "name": "Mexico",
                    "timezones": [
                        "America/Bahia_Banderas",
                        "America/Cancun",
                        "America/Chihuahua",
                        "America/Ciudad_Juarez",
                        "America/Hermosillo",
                        "America/Matamoros",
                        "America/Mazatlan",
                        "America/Merida",
                        "America/Mexico_City",
                        "America/Monterrey",
                        "America/Ojinaga",
                        "America/Tijuana"
                    ]
                },
                {
                    "id": "MY",
                    "name": "Malaysia",
                    "timezones": [
                        "Asia/Kuching",
                        "Asia/Singapore"
                    ]
                },
                {
                    "id": "MZ",
                    "name": "Mozambique",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "NA",
                    "name": "Namibia",
                    "timezones": [
                        "Africa/Windhoek"
                    ]
                },
                {
                    "id": "NC",
                    "name": "New Caledonia",
                    "timezones": [
                        "Pacific/Noumea"
                    ]
                },
                {
                    "id": "NE",
                    "name": "Niger",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "NF",
                    "name": "Norfolk Island",
                    "timezones": [
                        "Pacific/Norfolk"
                    ]
                },
                {
                    "id": "NG",
                    "name": "Nigeria",
                    "timezones": [
                        "Africa/Lagos"
                    ]
                },
                {
                    "id": "NI",
                    "name": "Nicaragua",
                    "timezones": [
                        "America/Managua"
                    ]
                },
                {
                    "id": "NL",
                    "name": "Netherlands",
                    "timezones": [
                        "Europe/Brussels"
                    ]
                },
                {
                    "id": "NO",
                    "name": "Norway",
                    "timezones": [
                        "Europe/Berlin"
                    ]
                },
                {
                    "id": "NP",
                    "name": "Nepal",
                    "timezones": [
                        "Asia/Kathmandu"
                    ]
                },
                {
                    "id": "NR",
                    "name": "Nauru",
                    "timezones": [
                        "Pacific/Nauru"
                    ]
                },
                {
                    "id": "NU",
                    "name": "Niue",
                    "timezones": [
                        "Pacific/Niue"
                    ]
                },
                {
                    "id": "NZ",
                    "name": "New Zealand",
                    "timezones": [
                        "Pacific/Auckland",
                        "Pacific/Chatham"
                    ]
                },
                {
                    "id": "OM",
                    "name": "Oman",
                    "timezones": [
                        "Asia/Dubai"
                    ]
                },
                {
                    "id": "PA",
                    "name": "Panama",
                    "timezones": [
                        "America/Panama"
                    ]
                },
                {
                    "id": "PE",
                    "name": "Peru",
                    "timezones": [
                        "America/Lima"
                    ]
                },
                {
                    "id": "PF",
                    "name": "French Polynesia",
                    "timezones": [
                        "Pacific/Gambier",
                        "Pacific/Marquesas",
                        "Pacific/Tahiti"
                    ]
                },
                {
                    "id": "PG",
                    "name": "Papua New Guinea",
                    "timezones": [
                        "Pacific/Bougainville",
                        "Pacific/Port_Moresby"
                    ]
                },
                {
                    "id": "PH",
                    "name": "Philippines",
                    "timezones": [
                        "Asia/Manila"
                    ]
                },
                {
                    "id": "PK",
                    "name": "Pakistan",
                    "timezones": [
                        "Asia/Karachi"
                    ]
                },
                {
                    "id": "PL",
                    "name": "Poland",
                    "timezones": [
                        "Europe/Warsaw"
                    ]
                },
                {
                    "id": "PM",
                    "name": "Saint Pierre and Miquelon",
                    "timezones": [
                        "America/Miquelon"
                    ]
                },
                {
                    "id": "PN",
                    "name": "Pitcairn",
                    "timezones": [
                        "Pacific/Pitcairn"
                    ]
                },
                {
                    "id": "PR",
                    "name": "Puerto Rico",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "PS",
                    "name": "Palestine",
                    "timezones": [
                        "Asia/Gaza",
                        "Asia/Hebron"
                    ]
                },
                {
                    "id": "PT",
                    "name": "Portugal",
                    "timezones": [
                        "Atlantic/Azores",
                        "Atlantic/Madeira",
                        "Europe/Lisbon"
                    ]
                },
                {
                    "id": "PW",
                    "name": "Palau",
                    "timezones": [
                        "Pacific/Palau"
                    ]
                },
                {
                    "id": "PY",
                    "name": "Paraguay",
                    "timezones": [
                        "America/Asuncion"
                    ]
                },
                {
                    "id": "QA",
                    "name": "Qatar",
                    "timezones": [
                        "Asia/Qatar"
                    ]
                },
                {
                    "id": "RE",
                    "name": "Réunion",
                    "timezones": [
                        "Asia/Dubai"
                    ]
                },
                {
                    "id": "RO",
                    "name": "Romania",
                    "timezones": [
                        "Europe/Bucharest"
                    ]
                },
                {
                    "id": "RS",
                    "name": "Serbia",
                    "timezones": [
                        "Europe/Belgrade"
                    ]
                },
                {
                    "id": "RU",
                    "name": "Russia",
                    "timezones": [
                        "Asia/Anadyr",
                        "Asia/Barnaul",
                        "Asia/Chita",
                        "Asia/Irkutsk",
                        "Asia/Kamchatka",
                        "Asia/Khandyga",
                        "Asia/Krasnoyarsk",
                        "Asia/Magadan",
                        "Asia/Novokuznetsk",
                        "Asia/Novosibirsk",
                        "Asia/Omsk",
                        "Asia/Sakhalin",
                        "Asia/Srednekolymsk",
                        "Asia/Tomsk",
                        "Asia/Ust-Nera",
                        "Asia/Vladivostok",
                        "Asia/Yakutsk",
                        "Asia/Yekaterinburg",
                        "Europe/Astrakhan",
                        "Europe/Kaliningrad",
                        "Europe/Kirov",
                        "Europe/Moscow",
                        "Europe/Samara",
                        "Europe/Saratov",
                        "Europe/Simferopol",
                        "Europe/Ulyanovsk",
                        "Europe/Volgograd"
                    ]
                },
                {
                    "id": "RW",
                    "name": "Rwanda",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "SA",
                    "name": "Saudi Arabia",
                    "timezones": [
                        "Asia/Riyadh"
                    ]
                },
                {
                    "id": "SB",
                    "name": "Solomon Islands",
                    "timezones": [
                        "Pacific/Guadalcanal"
                    ]
                },
                {
                    "id": "SC",
                    "name": "Seychelles",
                    "timezones": [
                        "Asia/Dubai"
                    ]
                },
                {
                    "id": "SD",
                    "name": "Sudan",
                    "timezones": [
                        "Africa/Khartoum"
                    ]
                },
                {
                    "id": "SE",
                    "name": "Sweden",
                    "timezones": [
                        "Europe/Berlin"
                    ]
                },
                {
                    "id": "SG",
                    "name": "Singapore",
                    "timezones": [
                        "Asia/Singapore"
                    ]
                },
                {
                    "id": "SH",
                    "name": "Saint Helena, Ascension and Tristan da Cunha",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "SI",
                    "name": "Slovenia",
                    "timezones": [
                        "Europe/Belgrade"
                    ]
                },
                {
                    "id": "SJ",
                    "name": "Svalbard and Jan Mayen",
                    "timezones": [
                        "Europe/Berlin"
                    ]
                },
                {
                    "id": "SK",
                    "name": "Slovakia",
                    "timezones": [
                        "Europe/Prague"
                    ]
                },
                {
                    "id": "SL",
                    "name": "Sierra Leone",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "SM",
                    "name": "San Marino",
                    "timezones": [
                        "Europe/Rome"
                    ]
                },
                {
                    "id": "SN",
                    "name": "Senegal",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "SO",
                    "name": "Somalia",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "SR",
                    "name": "Suriname",
                    "timezones": [
                        "America/Paramaribo"
                    ]
                },
                {
                    "id": "SS",
                    "name": "South Sudan",
                    "timezones": [
                        "Africa/Juba"
                    ]
                },
                {
                    "id": "ST",
                    "name": "Sao Tome and Principe",
                    "timezones": [
                        "Africa/Sao_Tome"
                    ]
                },
                {
                    "id": "SV",
                    "name": "El Salvador",
                    "timezones": [
                        "America/El_Salvador"
                    ]
                },
                {
                    "id": "SX",
                    "name": "Sint Maarten",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "SY",
                    "name": "Syria",
                    "timezones": [
                        "Asia/Damascus"
                    ]
                },
                {
                    "id": "SZ",
                    "name": "Eswatini",
                    "timezones": [
                        "Africa/Johannesburg"
                    ]
                },
                {
                    "id": "TC",
                    "name": "Turks and Caicos Islands",
                    "timezones": [
                        "America/Grand_Turk"
                    ]
                },
                {
                    "id": "TD",
                    "name": "Chad",
                    "timezones": [
                        "Africa/Ndjamena"
                    ]
                },
                {
                    "id": "TF",
                    "name": "French Southern Territories",
                    "timezones": [
                        "Asia/Dubai",
                        "Indian/Maldives"
                    ]
                },
                {
                    "id": "TG",
                    "name": "Togo",
                    "timezones": [
                        "Africa/Abidjan"
                    ]
                },
                {
                    "id": "TH",
                    "name": "Thailand",
                    "timezones": [
                        "Asia/Bangkok"
                    ]
                },
                {
                    "id": "TJ",
                    "name": "Tajikistan",
                    "timezones": [
                        "Asia/Dushanbe"
                    ]
                },
                {
                    "id": "TK",
                    "name": "Tokelau",
                    "timezones": [
                        "Pacific/Fakaofo"
                    ]
                },
                {
                    "id": "TL",
                    "name": "Timor-Leste",
                    "timezones": [
                        "Asia/Dili"
                    ]
                },
                {
                    "id": "TM",
                    "name": "Turkmenistan",
                    "timezones": [
                        "Asia/Ashgabat"
                    ]
                },
                {
                    "id": "TN",
                    "name": "Tunisia",
                    "timezones": [
                        "Africa/Tunis"
                    ]
                },
                {
                    "id": "TO",
                    "name": "Tonga",
                    "timezones": [
                        "Pacific/Tongatapu"
                    ]
                },
                {
                    "id": "TR",
                    "name": "Türkiye",
                    "timezones": [
                        "Europe/Istanbul"
                    ]
                },
                {
                    "id": "TT",
                    "name": "Trinidad and Tobago",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "TV",
                    "name": "Tuvalu",
                    "timezones": [
                        "Pacific/Tarawa"
                    ]
                },
                {
                    "id": "TW",
                    "name": "Taiwan",
                    "timezones": [
                        "Asia/Taipei"
                    ]
                },
                {
                    "id": "TZ",
                    "name": "Tanzania",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "UA",
                    "name": "Ukraine",
                    "timezones": [
                        "Europe/Kyiv",
                        "Europe/Simferopol"
                    ]
                },
                {
                    "id": "UG",
                    "name": "Uganda",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "UM",
                    "name": "United States Minor Outlying Islands",
                    "timezones": [
                        "Pacific/Honolulu",
                        "Pacific/Pago_Pago",
                        "Pacific/Tarawa"
                    ]
                },
                {
                    "id": "US",
                    "name": "United States of America",
                    "timezones": [
                        "America/Adak",
                        "America/Anchorage",
                        "America/Boise",
                        "America/Chicago",
                        "America/Denver",
                        "America/Detroit",
                        "America/Indiana/Indianapolis",
                        "America/Indiana/Knox",
                        "America/Indiana/Marengo",
                        "America/Indiana/Petersburg",
                        "America/Indiana/Tell_City",
                        "America/Indiana/Vevay",
                        "America/Indiana/Vincennes",
                        "America/Indiana/Winamac",
                        "America/Juneau",
                        "America/Kentucky/Louisville",
                        "America/Kentucky/Monticello",
                        "America/Los_Angeles",
                        "America/Menominee",
                        "America/Metlakatla",
                        "America/New_York",
                        "America/Nome",
                        "America/North_Dakota/Beulah",
                        "America/North_Dakota/Center",
                        "America/North_Dakota/New_Salem",
                        "America/Phoenix",
                        "America/Sitka",
                        "America/Yakutat",
                        "Pacific/Honolulu"
                    ]
                },
                {
                    "id": "UY",
                    "name": "Uruguay",
                    "timezones": [
                        "America/Montevideo"
                    ]
                },
                {
                    "id": "UZ",
                    "name": "Uzbekistan",
                    "timezones": [
                        "Asia/Samarkand",
                        "Asia/Tashkent"
                    ]
                },
                {
                    "id": "VA",
                    "name": "Holy See",
                    "timezones": [
                        "Europe/Rome"
                    ]
                },
                {
                    "id": "VC",
                    "name": "Saint Vincent and the Grenadines",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "VE",
                    "name": "Venezuela",
                    "timezones": [
                        "America/Caracas"
                    ]
                },
                {
                    "id": "VG",
                    "name": "Virgin Islands (UK)",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "VI",
                    "name": "Virgin Islands (US)",
                    "timezones": [
                        "America/Puerto_Rico"
                    ]
                },
                {
                    "id": "VN",
                    "name": "Vietnam",
                    "timezones": [
                        "Asia/Bangkok",
                        "Asia/Ho_Chi_Minh"
                    ]
                },
                {
                    "id": "VU",
                    "name": "Vanuatu",
                    "timezones": [
                        "Pacific/Efate"
                    ]
                },
                {
                    "id": "WF",
                    "name": "Wallis and Futuna",
                    "timezones": [
                        "Pacific/Tarawa"
                    ]
                },
                {
                    "id": "WS",
                    "name": "Samoa",
                    "timezones": [
                        "Pacific/Apia"
                    ]
                },
                {
                    "id": "YE",
                    "name": "Yemen",
                    "timezones": [
                        "Asia/Riyadh"
                    ]
                },
                {
                    "id": "YT",
                    "name": "Mayotte",
                    "timezones": [
                        "Africa/Nairobi"
                    ]
                },
                {
                    "id": "ZA",
                    "name": "South Africa",
                    "timezones": [
                        "Africa/Johannesburg"
                    ]
                },
                {
                    "id": "ZM",
                    "name": "Zambia",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                },
                {
                    "id": "ZW",
                    "name": "Zimbabwe",
                    "timezones": [
                        "Africa/Maputo"
                    ]
                }
            ]';
           
            $countryList = json_decode($jsonData, true);
            foreach($countryList as $countryData){
                $timezones = $countryData['timezones'];
                foreach ($timezones as $key => $timezone) {
                    $countryCode = $countryData['id'];
                    $name = $countryData['name'];
                    $country = new Country();
                    $country->code = $countryCode;
                    $country->name = $name;
                    $country->timezone = $timezone;
                    $country->flag_url = "";
                    $country->gmt_offset = "";
                    $country->save();
                }
            }
            $country = Country::all();
            return ApiResponse::success($country,'Terms &service fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side user can have provision to resent email on resend email button
    */
    public function resendEmail(Request $request){
        try{
            // Validate request parameters
            $request->validate([
                'email' => 'required|email',
            ]);
            // Find the user with the provided email
            $user = User::where('email', $request->email)->first();
            
            if($user){
                // Send a welcome email to the user
                Mail::to($request->input('email'))->send(new WelcomeEmail($user["userid"]));

                return ApiResponse::successOnly('Mail sent successfully.');
            }else{
                return ApiResponse::error('User not found');
            }

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App can logout using below function
    */
    public function logout()
    {
        $user = auth()->user();
        // $user->update(['fcm_token' => null]);
        auth()->logout();
        return response()->json(['message' => 'User successfully signout']);
    }

    /**
    * Developer: Apptodate 
    * Comment: get all display images
    */
    public function getImages()
    {
        try {
            // Retrieve images from the "DisplayImages" table and select the required columns
            $images = DisplayImages::select('image', 'type', 'text', 'subtext')->get();

            // Group the images by their "type" column
            $images = $images->groupBy('type');

            return ApiResponse::success($images);

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    /**
    * Developer: Apptodate 
    * Comment: 
    */
    protected function createNewToken($token){
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => strtotime(date('Y-m-d H:i:s',strtotime("+60 min"))),
            'user' => auth()->user()
        ]);
    }




}
