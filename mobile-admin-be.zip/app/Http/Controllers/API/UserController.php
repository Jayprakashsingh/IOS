<?php

namespace App\Http\Controllers\API;
use App\Helpers\ApiResponse;
use App\Helpers\Functions;
use App\Http\Controllers\Controller;
use App\Mail\CoachReminderEmail;
use App\Models\DisplayImages;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\ContactUs;
use App\Models\TermService;
use App\Models\Question;
use App\Models\Faq;
use App\Models\Tags;
use App\Models\ObjectType;
use App\Models\CategoryType;
use App\Models\InformationCenter;
use App\Models\InformationCenterImages;
use App\Models\UserQuestionAnswer;
use App\Models\UserUnitProgress;
use App\Models\UserTrainingPlan;
use App\Models\UserContactPerson;
use Firebase\JWT\JWT;
use App\Mail\ForgetpasswordEmail;
use App\Mail\ReportToClientEmail;
use App\Models\AdminCoachReview;
use App\Models\Ads;
use App\Models\Autoplay;
use App\Models\Country;
use App\Models\FlowSetting;
use App\Models\Folder;
use App\Models\ForceUpdateSetting;
use App\Models\FreeUser;
use App\Models\Fundamental;
use App\Models\GeneralSetting;
use App\Models\Group;
use App\Models\Guide;
use App\Models\GuideFundamental;
use App\Models\Note;
use App\Models\Notification;
use App\Models\Overview;
use App\Models\PaymentSetting;
use App\Models\Plan;
use App\Models\PromoCode;
use App\Models\RecallCard;
use App\Models\RecentSearch;
use App\Models\RepReview;
use App\Models\SavedItems;
use App\Models\Session;
use App\Models\SessionRecapTime;
use App\Models\UserObjectBookmark;
use App\Models\SessionType;
use App\Models\Swing;
use App\Models\Unit;
use App\Models\Trophie;
use App\Models\TrustKey;
use App\Models\TrustOverview;
use App\Models\TrustQuote;
use App\Models\UsedPromoCode;
use App\Models\UserBillingHistory;
use App\Models\UserCancelPlan;
use App\Models\UserCoachReview;
use App\Models\UserManualReps;
use App\Models\UserMovementDrill;
use App\Models\UserObjectType;
use App\Models\UserRecallCards;
use App\Models\UserRecallCardUpdate;
use App\Models\UserSelfCheckCheckObject;
use App\Models\UserSelfReportObject;
use App\Models\UserSessionProgress;
use App\Models\UserShotCheck;
use App\Models\UserTrainingStreak;
use App\Models\UserTrustHole;
use App\Models\UserUnlockedSession;
use App\Models\UserWeeklySurvey;
use Carbon\Carbon;
use Illuminate\Support\Str;
use DateTime;
use DateTimeZone;
use Generator;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use stdClass;
use Stripe\Coupon;
use Stripe\Customer;
use Stripe\Stripe;
use Stripe\Subscription;
use Stripe\PaymentMethod;
use Stripe\Price;
use Twilio\Rest\Client;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api',['except' => ['getForceUpdateApp','verifyPasswordLink','storeForceUpdateApp','confirmcheck','getImages','forgotpassword','confirmPassword','registrationProcessCheck']]);
    }
    
    /**
    * Developer: Apptodate 
    * Comment: Below function for while forget-password recovery mail need to sent on users email address
    */

    public function storeForceUpdateApp(Request $request)
    {
        try {
            // Validate request parameters
            $validatedData = $request->validate([
                'version' => 'required|string',
                'version_code' => 'required|integer',
                'device_type' => 'required|string',
                'description' => 'required|string',
                'force_update' => 'required|boolean'
            ]);
         
            if(!empty($request->id)){
                $forceUpdateSetting = ForceUpdateSetting::find($request->id);
            }else{
                $forceUpdateSetting = new ForceUpdateSetting();
            }
            $forceUpdateSetting->version = $request->version;
            $forceUpdateSetting->version_code = $request->version_code;
            $forceUpdateSetting->device_type = $request->device_type;
            $forceUpdateSetting->description = $request->description ?? "";
            $forceUpdateSetting->force_update = $request->force_update ?? false;
            $forceUpdateSetting->save();
    
            return ApiResponse::success($forceUpdateSetting,'Force update set successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function verifyPasswordLinkOld(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'token' => 'required',
            ]);

            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return ApiResponse::error('User not found');
            }

            $tokenData = DB::table('password_resets')
                            ->where('token', $request->token)
                            ->where('email', $request->email)
                            ->first();

            if (!$tokenData) {
                return ApiResponse::error('Invalid token');
            }

            $tokenAgeHours = Carbon::parse($tokenData['created_at'])->diffInHours();
            if ($tokenAgeHours > 24) {
                return ApiResponse::error('Reset password link has expired');
            }

            return ApiResponse::successOnly('Password link is valid.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function verifyPasswordLink(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'token' => 'required',
            ]);

            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return ApiResponse::error('User not found');
            }

            $tokenExists = Password::broker()->tokenExists($user,$request->token);
            if (!$tokenExists) {
                return ApiResponse::error('Invalid token');
            }

            return ApiResponse::successOnly('Password link is valid.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function forgotpassword(Request $request)
    {
        try {
            //validate req parameter
            $request->validate([
                'email' => 'required'
            ]);
            //retrieve user data
            $user = User::where('email', $request->email)->first();
            
            if($user){
                //send forgot password email
                $token = Password::broker()->createToken($user);

                if($user->country_id != ""){
                    $country = Country::find($user->country_id);
                    $userTimezone = $country->timezone ?? "";
                }else{
                    $userTimezone = "";
                }
                $tokenInstance = DB::table('password_resets')
                                ->where('email', $user->email)
                                ->first();

                if ($tokenInstance) {
                    if($userTimezone != ""){
                        $created_at = Carbon::now($userTimezone)->format('Y-m-d H:i:s');
                    }else{
                        $created_at = Carbon::now()->format('Y-m-d H:i:s');
                    }
                    DB::table('password_resets')
                    ->where('_id', $tokenInstance['_id'])
                    ->update([
                        'created_at' => $created_at
                    ]);
                }

                $link = env('ADMIN_URL') . "forgetpassword/" . $token."/".$user->email;
                
                Mail::to($user["email"])->send(new ForgetpasswordEmail($user["id"],$link));
                return ApiResponse::successOnly('Mail sent successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function forgotpasswordOld(Request $request)
    {
        try {
            //validate req parameter
            $request->validate([
                'email' => 'required'
            ]);
            //retrieve user data
            $user = User::where('email', $request->email)->first();
            
            if($user){
                //send forgot password email
                $token = Password::broker()->createToken($user);
                
                $link = env('ADMIN_URL') . "forgetpassword/" . $token."/".$user->email;
                
                Mail::to($user["email"])->send(new ForgetpasswordEmail($user["id"],$link));
                return ApiResponse::successOnly('Mail sent successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 
    public function forgotpasswordLast(Request $request)
    {
        try {
            //validate req parameter
            $request->validate([
                'email' => 'required'
            ]);
            //retrieve user data
            $user = User::where('email', $request->email)->first();
            
            if($user){
                //send forgot password email
                $token = Password::broker()->createToken($user);
    
                $tokenData = [
                    'email' => $request->email,
                    'token' => $token,
                    'created_at' => Carbon::now()->format('Y-m-d H:i:s'), 
                ];
                DB::table('password_resets')->insert($tokenData);

                $link = env('ADMIN_URL') . "forgetpassword/" . $token."/".$user->email;
                
                Mail::to($user["email"])->send(new ForgetpasswordEmail($user["id"],$link));
                return ApiResponse::successOnly('Mail sent successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function remindLater($type = "day")
    {
        try {
            //retrieve user data
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {
                $countries = Country::pluck('timezone','_id')->toArray();
                $userTimezone = $countries[$user->country_id] ?? "UTC";
                if($type == "day"){
                    $user->remind_later = 1;
                    $user->remind_later_date = Carbon::now($userTimezone)->addDay(2)->format('Y-m-d H:i:s');
                }
                if($type == "hour"){
                    $user->remind_later_24_hour = 1;
                    $user->remind_later_date = Carbon::now($userTimezone)->addDay(1)->format('Y-m-d H:i:s');
                }
                $user->save();
                return ApiResponse::successOnly('Remind later setting saved successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 

    public function updateRemindLaterReminder($remindLater){
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user->is_reminder_later_reminder_once = $remindLater == "true" && $remindLater == true ? true : false;
          
            $user->save();
            return ApiResponse::success($user,'User Reminder remind later setting updated.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function updatePayment(Request $request)
    {
        try {
            $request->validate([
                'payment_type' => 'required',
                'plan_id' => 'required',
                'switch_plan' => 'required'
            ]);
            //retrieve user data
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {
                if($request->switch_plan == "false"){
                    $switch_plan = false;
                }else{
                    $switch_plan = true;
                }
                if(isset($request->app_user_id)){
                    $user->app_user_id = $request->app_user_id;
                }else{
                    $user->app_user_id = "";
                }
                $plan = Plan::find($request->plan_id);
                $userBillingHistory = new UserBillingHistory();
                if($switch_plan == true){
                    $oldBillingHistoryPlan = UserBillingHistory::where('user_id',$user['_id'])->where('status','active')->where('payment_status','Paid')->first();
             
                    if($oldBillingHistoryPlan){
                        $oldBillingHistoryPlan->status = 'expired';
                        $oldBillingHistoryPlan->expiry_date = now()->format('Y-m-d H:i:s');
                        $oldBillingHistoryPlan->save();
                    }
                }
                $userBillingHistory->user_id = $user["_id"];
                $userBillingHistory->amount = $request->amount ??  $plan->amount;
                $userBillingHistory->app_user_id = $request->app_user_id ?? "";
                $promo_code = $request->promo_code ?? "";
                $userBillingHistory->promo_code = $promo_code;
                if($promo_code != ""){
                    $promo_code = PromoCode::where('code',$promo_code)->first();
        
                    if($promo_code){
                        $plan = Plan::find($promo_code->plan_id);
                        $userBillingHistory->amount = $promo_code->amount;
                    }else{
                        $userBillingHistory->amount = $request->amount ??  $plan->amount;
                    }
                }else{
                    $userBillingHistory->amount = $request->amount ??  $plan->amount;
                }
                $userBillingHistory->transaction_no = Functions::generateUniqueNumber();
                $userBillingHistory->tras_id = $request->transaction_id ?? "";

                $user->active_subscription_id = "";
                $user->active_trans_id = $request->transaction_id ?? "";
                $userBillingHistory->user_id = $user->_id;
                $userBillingHistory->status = 'active';
                $userBillingHistory->payment_status = 'Paid';
                if($plan->validity_type == "day"){
                    $userBillingHistory->expiry_date = now()->addDays(7)->format('Y-m-d H:i:s');
                }else{
                    
                    if($promo_code != "" && $plan->_id == env('GUIDE_PLAN')){
                        if (stripos($promo_code, 'GREATSWING') !== false) {
                            $userBillingHistory->expiry_date = Carbon::now()->addMonths(1)->format('Y-m-d H:i:s');
                        } else {
                            $userBillingHistory->expiry_date = Carbon::now()->addMonths(12)->format('Y-m-d H:i:s');
                        }
                    }else{
                        $userBillingHistory->expiry_date = Carbon::now()->addMonths(3)->format('Y-m-d H:i:s');
                    }
                }
                $userBillingHistory->payment_method =  $request->payment_type ?? "";
                $userBillingHistory->plan_id = $plan->_id;
               
                $userBillingHistory->save();
                if($userBillingHistory->promo_code != ""){
                    // $usedPromoCodes = UsedPromoCode::where('promo_code',$user)->where('user_id',$user["_id"])->first();
                    // if($usedPromoCodes){
                    //     return ApiResponse::error('It seems already been used by user before.');
                    // }
                    $usedPromoCodes = new UsedPromoCode();
                    $usedPromoCodes->user_id = $user["_id"];
                    $usedPromoCodes->promo_code = $userBillingHistory->promo_code ;
                    $usedPromoCodes->payment_id = $request->transaction_id ?? "";
                    $usedPromoCodes->save();
                }
                $user->payment_method =  $request->payment_type ?? "";
                $user->save();
                if($plan->amount == 199){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 3;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                if($plan->amount == 299){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 6;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                return ApiResponse::successOnly('Payment details saved successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 
    public function updateCoachReviewPayment(Request $request)
    {
        try {
            
            //validate req parameter
            $request->validate([
                'payment_type' => 'required',
                'amount' => 'required'
            ]);
            //retrieve user data
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {
               
                $userBillingHistory = new UserBillingHistory();
                
                $userBillingHistory->user_id = $user["_id"];
                $userBillingHistory->amount = $request->amount ??  0;
                $userBillingHistory->app_user_id = $request->app_user_id ?? "";
                $promo_code = $request->promo_code ?? "";
                if($promo_code != ""){
                    $usedPromoCodes = new UsedPromoCode();
                    $usedPromoCodes->user_id = $user->_id;
                    $usedPromoCodes->promo_code = $promo_code;
                    $usedPromoCodes->payment_id = "";
                    $usedPromoCodes->save();
                }
                $userBillingHistory->promo_code = $promo_code;
                $userBillingHistory->user_id = $user->_id;
                $userBillingHistory->status = 'active';
                $userBillingHistory->payment_status = 'Paid';
                $userBillingHistory->expiry_date = Carbon::now()->addMonths(3)->format('Y-m-d H:i:s');
                $userBillingHistory->payment_method =  $request->payment_type ?? "";
                $userBillingHistory->plan_id = "";
                $userBillingHistory->save();
                if($userBillingHistory->amount == 99){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 4;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                if($userBillingHistory->amount == 29){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 1;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                return ApiResponse::successOnly('Coach Review payment implemented successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function updateSubscriptionold(Request $request)
    {
        try {
            Stripe::setApiKey(config('services.stripe.secret'));
            //validate req parameter
            $request->validate([
                'promo_code' => 'required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) { 
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {
                $coupons = Coupon::all();
                $coupon_id = "";
                foreach ($coupons as $key => $coupon) {
                    if($coupon["name"] == $request->promo_code){
                        $coupon_id = $coupon->id;
                        break;
                    }
                }
                if($coupon_id != ""){
                    $customerId = $user->stripe_customer_id ?? ""; 
                    if($customerId == ""){
                        return ApiResponse::error('Please subscribe to any plan from the subscription before using the promo code.');
                    }
                    $existingSubscriptions = Subscription::all(['customer' => $customerId, 'status' => 'active']);
                    if (count($existingSubscriptions->data) > 0) {
                        $subscriptionId = $existingSubscriptions->data[0]->id;
                        if ($coupon) {
                            if($request->promo_code == "STAY15"){
                                $usedPromoCodes = UsedPromoCode::where('promo_code','STAY15')->where('user_id',$user["_id"])->first();
                                if($usedPromoCodes){
                                    return ApiResponse::error('It seems already been used by user before.');
                                }
                            }
                            
                            $subscription = Subscription::update($subscriptionId, [
                                'coupon' => $coupon_id,
                            ]);
                            $user->active_subscription_id = $subscription->id ?? "";
                            $user->save();
                            $usedPromoCodes = new UsedPromoCode();
                            $usedPromoCodes->user_id = $user["_id"];
                            $usedPromoCodes->promo_code = $request->promo_code;
                            $usedPromoCodes->payment_id = $subscription->id ?? "";
                            $usedPromoCodes->save();
                            return ApiResponse::success($subscription,'Promo code applied successfully!');
                        } else {
                            return ApiResponse::error('Invalid promo code');
                        }
                    }
                }else{
                    return ApiResponse::error('Invalid promo code!');
                }
            }   
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 
    // public function updateSubscription(Request $request)
    // {
    //     try {
    //         Stripe::setApiKey(config('services.stripe.secret'));
    //         //validate req parameter
    //         $request->validate([
    //             'promo_code' => 'required'
    //         ]);
    //         $token = $this->getTokenFromHeader();
    //         $user = \JWTAuth::setToken($token)->authenticate();
    //         if(!$user) { 
    //             return ApiResponse::error('Getting trouble to fetch user information');
    //         }else {
    //             $coupons = Coupon::all();
    //             $coupon_id = "";
    //             foreach ($coupons as $key => $coupon) {
    //                 if($coupon["name"] == $request->promo_code){
    //                     $coupon_id = $coupon->id;
    //                     break;
    //                 }
    //             }
    //             if($coupon_id != ""){
    //                 $customerId = $user->stripe_customer_id ?? ""; 
    //                 if($customerId == ""){
    //                     return ApiResponse::error('Please subscribe to any plan from the subscription before using the promo code.');
    //                 }
    //                 $existingSubscriptions = Subscription::all(['customer' => $customerId, 'status' => 'active']);
    //                 if (count($existingSubscriptions->data) > 0) {
    //                     $subscriptionId = $existingSubscriptions->data[0]->id;
    //                     if ($coupon) {
    //                         if($request->promo_code == "STAY15"){
    //                             $usedPromoCodes = UsedPromoCode::where('promo_code','STAY15')->where('user_id',$user["_id"])->first();
    //                             if($usedPromoCodes){
    //                                 return ApiResponse::error('It seems already been used by user before.');
    //                             }
    //                         }
                            
    //                         $subscription = Subscription::update($subscriptionId, [
    //                             'coupon' => $coupon_id,
    //                         ]);
    //                         $user->active_subscription_id = $subscription->id ?? "";
    //                         $user->save();
    //                         $usedPromoCodes = new UsedPromoCode();
    //                         $usedPromoCodes->user_id = $user["_id"];
    //                         $usedPromoCodes->promo_code = $request->promo_code;
    //                         $usedPromoCodes->payment_id = $subscription->id ?? "";
    //                         $usedPromoCodes->save();
    //                         return ApiResponse::success($subscription,'Promo code applied successfully!');
    //                     } else {
    //                         return ApiResponse::error('Invalid promo code');
    //                     }
    //                 }
    //             }else{
    //                 return ApiResponse::error('Invalid promo code!');
    //             }
    //         }   
    //     } catch (\Exception $e) {
    //         return ApiResponse::error($e->getMessage());
    //     }
    // } 
    public function updateSubscription(Request $request)
    {
        try {
            Stripe::setApiKey(config('services.stripe.secret'));
            //validate req parameter
            $request->validate([
                'promo_code' => 'required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) { 
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {
                // $coupons = Coupon::all();
                // Fetch all coupons from Stripe
                $allCoupons = [];
                try {
                    $coupons = null;
                    do {
                        $coupons = Coupon::all([
                            'limit' => 100, 
                            'starting_after' => $coupons ? end($coupons->data)->id : null
                        ]);
                        $allCoupons = array_merge($allCoupons, $coupons->data);
                    } while ($coupons->has_more);
                } catch (\Exception $e) {
                    return ApiResponse::error('Error fetching coupons: ' . $e->getMessage());
                }

                $coupon_id = "";
                foreach ($allCoupons as  $coupon) {
                    if($coupon["name"] == $request->promo_code){
                        $coupon_id = $coupon->id;
                        break;
                    }
                }

                if (!$coupon_id) {
                    return ApiResponse::error('Invalid promo code!');
                }
               
                $checkOldPaymentType = UserBillingHistory::where('user_id',$user->_id)->where('status','active')->where('payment_status','Paid')->first();
                if ($checkOldPaymentType && !empty($checkOldPaymentType->payment_method) && $checkOldPaymentType->payment_method != 'Stripe') {
                    return ApiResponse::error('Plan subscribed using a mobile device so, the promo code is applicable on web payment.');
                }
                
                $customerId = $user->stripe_customer_id ?? ""; 
                if (empty($customerId)) {
                    return ApiResponse::error('Please subscribe to any plan from the subscription before using the promo code.');
                }
                $existingSubscriptions = Subscription::all(['customer' => $customerId, 'status' => 'active']);
                if (count($existingSubscriptions->data) > 0) {
                    $subscriptionId = $existingSubscriptions->data[0]->id;
                    if ($coupon) {
                        // if($request->promo_code == "STAY15"){
                            $usedPromoCodes = UsedPromoCode::where('promo_code',$coupon['name'])->where('user_id',$user["_id"])->first();
                            if($usedPromoCodes){
                                return ApiResponse::error('It seems already been used by user before.');
                            }
                        // }
                        
                        $subscription = Subscription::update($subscriptionId, [
                            'coupon' => $coupon_id,
                        ]);
                        $user->active_subscription_id = $subscription->id ?? "";
                        $user->save();
                        $usedPromoCodes = new UsedPromoCode();
                        $usedPromoCodes->user_id = $user["_id"];
                        $usedPromoCodes->promo_code = $request->promo_code;
                        $usedPromoCodes->payment_id = $subscription->id ?? "";
                        $usedPromoCodes->save();
                        return ApiResponse::success($subscription,'Promo code applied successfully!');
                    } else {
                        return ApiResponse::error('Invalid promo code');
                    }
                }
                
            }   
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function switchPlanPayment(Request $request)
    {
        try {
            Stripe::setApiKey(config('services.stripe.secret'));
            //validate req parameter
            $request->validate([
                'plan_id' => 'required'
                // 'switch_plan' => 'required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) { 
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {
                // if($request->switch_plan == "false"){
                //     $switch_plan = false;
                // }else{
                //     $switch_plan = true;
                // }
                $plan = Plan::find($request->plan_id);
                $userBillingHistory = new UserBillingHistory();
                if($plan->validity_type == "day"){
                    $userBillingHistory->expiry_date = now()->addDays(7)->format('Y-m-d H:i:s');
                }else{
                    $customerId = $user->stripe_customer_id ?? "";
                    if($customerId == ""){
                        $token = $request->token_id ?? "";
                        if (!$token) {
                            return ApiResponse::error('Need Customer card information for further payment.');
                        }
                        $customer = Customer::create(['email' => $user->email,'name' => $user->full_name]);

                        // Convert the token to a Payment Method and attach it to the customer
                        $paymentMethod = PaymentMethod::create([
                            'type' => 'card',
                            'card' => ['token' => $token],
                        ]);
                        $paymentMethod->attach(['customer' => $customer->id]);
            
                        // Optionally, set the Payment Method as default for the customer
                        $customer->invoice_settings = ['default_payment_method' => $paymentMethod->id];
                        $customer->save();
                        $user->stripe_customer_id = $customer->id;
                        $user->save();
                    }
                    $priceId = $this->getPriceIdForProduct($plan->product_id);
                    if (!$priceId) {
                        return ApiResponse::error('No active price found for the specified product.');
                    }
                    $customerId = $user->stripe_customer_id;
                    $existingSubscriptions = Subscription::all(['customer' => $customerId, 'status' => 'active']);
                    if (count($existingSubscriptions->data) > 0) {
                        $subscriptionId = $existingSubscriptions->data[0]->id;
                        // $updatedSubscription = Subscription::update($subscriptionId, [
                        //     'items' => [['price' => $priceId]],
                        //     'proration_behavior' => 'create_prorations', // Adjust proration settings as needed
                        // ]);
                        $subscription = Subscription::retrieve($subscriptionId);
                        $subscription->cancel();
                       
                    }
                    $newSubscription = Subscription::create([
                        'customer' => $customerId,
                        'items' => [['price' => $priceId]],
                    ]);
                    $subscription_id = $newSubscription->id;
                    $userBillingHistory->subscription_id = $subscription_id ?? "";
                    $userBillingHistory->invoice_id = $invoice_id ?? "";
                    $userBillingHistory->expiry_date = Carbon::now()->addMonths(3)->format('Y-m-d H:i:s');
                }
                // if($switch_plan == true){
                $oldBillingHistoryPlan = UserBillingHistory::where('user_id',$user['_id'])->where('status','active')->where('payment_status','Paid')->first();
                if($oldBillingHistoryPlan){
                    $oldBillingHistoryPlan->status = 'expired';
                    $oldBillingHistoryPlan->expiry_date = now()->format('Y-m-d H:i:s');
                    $oldBillingHistoryPlan->save();
                }
                // }
               
                $userBillingHistory->user_id = $user["_id"];
                $userBillingHistory->transaction_no = Functions::generateUniqueNumber();
                $userBillingHistory->tras_id = $request->transaction_id ?? "";
                $userBillingHistory->user_id = $user->_id;
                $userBillingHistory->status = 'active';
                
                $userBillingHistory->payment_status = 'Paid';
                $userBillingHistory->payment_method = "Stripe";
                $userBillingHistory->plan_id = $plan->_id;
                $userBillingHistory->amount = $plan->amount;
                $userBillingHistory->save();
                $user->active_subscription_id = $subscription_id ?? "";
                $user->payment_method = "Stripe";
                $user->active_trans_id = "";
                $user->save();
                if($plan->amount == 199){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 3;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                if($plan->amount == 299){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 6;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                return ApiResponse::successOnly('Plan switched successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 
    private function getPriceIdForProduct($productId)
    {
        try {
            $prices = Price::all([
                'product' => $productId,
                'active' => true,
                'limit' => 1, // Adjust as needed
            ]);

            if (!empty($prices->data)) {
                return $prices->data[0]->id; // Return the first active price ID found
            }
        } catch (Exception $e) {
            // Log error or handle accordingly
        }

        return null;
    }

    public function postCancelPlanOld(Request $request)
    {
        try {
            //validate req parameter
            $request->validate([
                'description'=> 'nullable',
                'plan_id' => 'required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                $planData = Plan::find($request->plan_id);
                if(!$planData) {
                    return ApiResponse::error('Getting trouble to fetch plan information');
                }
                $plan = new UserCancelPlan();
                $plan->user_id = $user["_id"];
                $plan->plan_id = $request->plan_id;
                $plan->description = $request->description ?? "";
                if($request->hasFile('file')){
                    $file = $request->file('file');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    $path = env('AWS_CANCEL_PLAN_IMAGE_PATH');
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $plan->file = $filename;
                    if(!empty($request->file_type)){
                        $plan->file_type = $request->file_type;
                    }
                    $appUrl = env('AWS_S3_PATH');
                    $notesPath = $appUrl.''.$path;
                    $plan->file = $notesPath.''.$filename;
                }
                $plan->save();
                $user->active_trans_id = "";
                $user->save();
                
                return ApiResponse::successOnly('Subscription canceled successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 
    public function postCancelPlan(Request $request)
    {
        try {
            //validate req parameter
            $request->validate([
                'description'=> 'nullable',
                'plan_id' => 'required'
            ]);

            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                $appUserIdArray = explode('$RCAnonymousID:',$user->app_user_id);
                $transactionId = $user->active_trans_id ?? "";
              
                $revenueCatApiKey = env('REVENUECAT_API_KEY');
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => "https://api.revenuecat.com/v1/subscribers/{$user->app_user_id}/subscriptions/{$transactionId}/cancel",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer $revenueCatApiKey",
                        "Content-Type: application/json"
                    ),
                ));

                $response = curl_exec($ch);
                if (curl_errno($ch)) {
                    return ApiResponse::error('Error:' . curl_error($ch));
                }
                
                curl_close($ch);
                if($response){
                    $planData = Plan::find($request->plan_id);
                    if(!$planData) {
                        return ApiResponse::error('Getting trouble to fetch plan information');
                    }
                    $billing_history = UserBillingHistory::where('user_id',$user["_id"])->where('plan_id',$request->plan_id)->where('status','active')->where('payment_status','Paid')->first();
                    $billing_history->status = 'expired';
                    $billing_history->expiry_date = now()->format('Y-m-d');
                    $billing_history->save();
                    $plan = new UserCancelPlan();
                    $plan->user_id = $user["_id"];
                    $plan->plan_id = $request->plan_id;
                    $plan->description = $request->description ?? "";
                    if($request->hasFile('file')){
                        $file = $request->file('file');
                        $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                        $path = env('AWS_CANCEL_PLAN_IMAGE_PATH');
                        Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                        $plan->file = $filename;
                        if(!empty($request->file_type)){
                            $plan->file_type = $request->file_type;
                        }
                        $appUrl = env('AWS_S3_PATH');
                        $notesPath = $appUrl.''.$path;
                        $plan->file = $notesPath.''.$filename;
                    }
                    $plan->save();
                    $user->active_trans_id = "";
                    $user->save();
                    
                    return ApiResponse::successOnly('Subscription canceled successfully.'); 
                } else {
                    return ApiResponse::error('Failed to cancel subscription');
                }
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 

    public function cancelSubscription(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                $request->validate([
                    'description'=> 'nullable',
                    'plan_id' => 'required',
                    'subscription_id' => 'required'
                ]);
                $planData = Plan::find($request->plan_id);
                if(!$planData) {
                    return ApiResponse::error('Getting trouble to fetch plan information');
                }
                //$userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->where('status','active')->first();
                if($user->active_subscription_id != $request->subscription_id){
                    return ApiResponse::error("Invalid subscription detail!");
                }
                Stripe::setApiKey(config('services.stripe.secret'));
                $subscription = Subscription::retrieve($request->subscription_id);
                $subscription->cancel();
                $user->active_subscription_id = "";
                $user->save();
                
                $plan = new UserCancelPlan();
                $plan->user_id = $user["_id"];
                $plan->plan_id = $request->plan_id ;
                $plan->description = $request->description ?? "";
                if($request->hasFile('file')){
                    $file = $request->file('file');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    $path = env('AWS_CANCEL_PLAN_IMAGE_PATH');
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $plan->file = $filename;
                    if(!empty($request->file_type)){
                        $plan->file_type = $request->file_type;
                    }
                    $appUrl = env('AWS_S3_PATH');
                    $notesPath = $appUrl.''.$path;
                    $plan->file = $notesPath.''.$filename;
                }
                $plan->save();
                return ApiResponse::successOnly('Subscription plan canceled successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 

    public function getPaymentPlanOld()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $guide_plan = env('GUIDE_PLAN');
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $plans = Plan::where('_id', '!=',$guide_plan)->get();
                $customerId = $user->stripe_customer_id ?? "";
                $custome_stripe_id_exist = $customerId != "" ? true : false;
                $expiry_date = "";
                foreach ($plans as $key => $plan) {
                    $billing_history = UserBillingHistory::where('user_id',$user["_id"])->where('status','active')->where('payment_status','Paid')->first();
                    if($billing_history->plan_id == $plan->_id){
                        $plan->active_plan = true;
                        $plan->subscription_id = $user->active_subscription_id ?? "";
                        $userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->where('plan_id',$plan->_id)->where('status','active')->first();
                        if($userBillingHistory){
                            $expiry_date = $userBillingHistory->expiry_date;
                        }
                    }else{
                        $plan->active_plan = false;
                        $plan->subscription_id =  "";
                    }
                    $plan->expiry_date = $expiry_date;
                    $plan->custome_stripe_id_exist = $custome_stripe_id_exist ?? false;
                }
                return ApiResponse::success($plans,'Payment plan detail fetched successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 

    public function getPaymentPlan()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $new_flow_setting = FlowSetting::first();
                $new_flow = $new_flow_setting->new_flow ;
                $guide_plan_id = env('GUIDE_PLAN');
                if($new_flow){
                    $plans = Plan::where('_id', $guide_plan_id)->get();
                }else{
                    $plans = Plan::where('_id','!=', $guide_plan_id)->get();
                }
               
                $customerId = $user->stripe_customer_id ?? "";
                $custome_stripe_id_exist = $customerId != "" ? true : false;
                $expiry_date = "";
                foreach ($plans as $key => $plan) {
                    $billing_history = UserBillingHistory::where('user_id',$user["_id"])->where('status','active')->where('payment_status','Paid')->first();
                    
                    if($billing_history ){//&& $billing_history->plan_id == $plan->_id
                        $plan->active_plan = true;
                        $plan->active_trans_id = $user->active_trans_id ?? "";
                        $plan->subscription_id = $user->active_subscription_id ?? "";
                        $userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->where('plan_id',$plan->_id)->where('status','active')->first();
                        if($userBillingHistory){
                            $expiry_date = $userBillingHistory->expiry_date;
                        }
                        if($new_flow){
                            $plan->promo_code = $userBillingHistory->promo_code ?? "";
                            $plan->billed_amount = $userBillingHistory->amount ??  49;
                        }else{
                            $plan->promo_code = "";
                            $plan->billed_amount = "";
                        }
                        if( $plan->promo_code != "" && $plan->_id == env('GUIDE_PLAN')){
                            if (stripos( $plan->promo_code, 'GREATSWING') !== false) {}else{
                                $plan->validity_type = "year";
                            }
                        }
                    }else{
                        $plan->promo_code = "";
                        $plan->billed_amount = "";
                        $plan->active_plan = false;
                        $plan->subscription_id =  "";
                        $plan->active_trans_id =  "";
                    }
                    $plan->payment_method = $user->payment_method ?? "";
                    $plan->expiry_date = $expiry_date;
                    $is_free = $user->is_free ?? false;
                    $FreeUser = FreeUser::where('email', $user->email)->count();
                    if($FreeUser > 0){
                        $is_free = true;
                    }
                    $plan->is_free = $is_free;
                    
                    $plan->custome_stripe_id_exist = $custome_stripe_id_exist ?? false;
                }
                return ApiResponse::success($plans,'Payment plan detail fetched successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    

    /**
    * Developer: Apptodate 
    * Comment: For app get profile where user see users info , training intention, reps and rate related data
    */

    function calculate_final_reps($totalReps)
    {
        if ($totalReps % 1000 !== 0) {
            return ((int) ($totalReps / 1000) + 1) * 1000;
        } else {
            return $totalReps;
        }
    }

    function calculateBadge($totalReps)
    {
        if ($totalReps < 1000) {
            return "";
        } else {
            $num = floor($totalReps / 1000);
            return $num . "K";
        }
    }

    public function getCoachReviewDetailBySwingId($swing_id)
    {   
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $appUrl = env('AWS_S3_PATH');
                $path = env('AWS_PROFILE_PATH');
                $objectPath = env('AWS_OBJECT_IMAGES_PATH');
                $swing = Swing::find($swing_id);
                if(!$swing){
                    return ApiResponse::error('Unable to fetch swing video details!');
                }
                $admin_coach_review = AdminCoachReview::where('swing_id',$swing_id)->first();
                if($admin_coach_review){
                    $coach = User::find( $admin_coach_review->coach_id);
                }
                $coachReviewsData['id'] =  $admin_coach_review->id ?? "";
                $coachReviewsData['swing_id'] =  $swing_id ;
                $coachReviewsData['description'] = $admin_coach_review->description ?? "";
                $coachReviewsData['drills'] =  $admin_coach_review->drills ?? [];
                $drill_list = [];
                if($admin_coach_review){
                    foreach ($admin_coach_review->drills as $key => $drill) {
                        $userObject = UserObjectType::find($drill['object_id']);
                        $tag_name = Tags::find($userObject['tag'])->name ?? "";
                        $objectType = ObjectType::where('_id', $userObject->object_type_id)->first();
                        $drill_list[$key]= [
                                'object_id' => $userObject["_id"],
                                'tag_id' => $userObject["tag"],
                                'object_name' => $userObject["object_name"],
                                'tag_name' => $tag_name ?? "",
                                'headline' => $userObject["headline"],
                                'subtitle' => $userObject["subtitle"],
                                'description' => $userObject["textarea"],
                                'file' => $userObject["file"] != '' && !(Str::contains($userObject["file"], 'storage/storage/')) ? $appUrl.''.$objectPath.''.$userObject["file"] : '',
                                'type' => $objectType->name ?? '',
                                'video_id' => $userObject["video_id"] ?? "", //pased by rugved
                                'link_items' => $userObject["link_items"] ?? []
                        ];
                    }
                }
                $coachReviewsData['drill_list'] =  $drill_list ?? [];
                $coachReviewsData['status'] = $admin_coach_review->status ?? "Pending";
                $coachReviewsData['coach_id'] =  $admin_coach_review->coach_id ?? "";
                $coachReviewsData['coach_name'] = $coach->full_name ?? "" ;
                $coachReviewsData['coach_img'] = ($admin_coach_review) ? ($coach->profile_picture != "" ? $appUrl."".$path."".$coach->profile_picture :"") : "";
                $coachReviewsData['vimeo_link'] =  $admin_coach_review->vimeo_link ?? "";
                $coachReviewsData['created_at'] =  $admin_coach_review->created_at ?? "";
                $coachReviewsData['last_update'] =  $admin_coach_review->updated_at ?? "";
                return ApiResponse::success($coachReviewsData,'Coach reviews detail found.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCoachReviewDetailByREpVideoId($swing_id)
    {   
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $appUrl = env('AWS_S3_PATH');
                $path = env('AWS_PROFILE_PATH');
              
                $swing = RepReview::find($swing_id);
                if(!$swing){
                    return ApiResponse::error('Unable to fetch swing video details!');
                }
                $admin_coach_review = AdminCoachReview::where('swing_id',$swing_id)->first();
                if($admin_coach_review){
                    $coach = User::find( $admin_coach_review->coach_id);
                }
                $coachReviewsData['id'] =  $admin_coach_review->id ?? "";
                $coachReviewsData['swing_id'] =  $swing_id ;
                $coachReviewsData['description'] = $admin_coach_review->description ?? "";
                $coachReviewsData['drills'] =[];
                $drill_list = [];
              
                $coachReviewsData['drill_list'] =  $drill_list ?? [];
                $coachReviewsData['status'] = $admin_coach_review->status ?? "Pending";
                $coachReviewsData['coach_id'] =  $admin_coach_review->coach_id ?? "";
                $coachReviewsData['coach_name'] = $coach->full_name ?? "" ;
                $coachReviewsData['coach_img'] = ($admin_coach_review) ? ($coach->profile_picture != "" ? $appUrl."".$path."".$coach->profile_picture :"") : "";
                $coachReviewsData['vimeo_link'] =  $admin_coach_review->vimeo_link ?? "";
                $coachReviewsData['created_at'] =  $admin_coach_review->created_at ?? "";
                $coachReviewsData['last_update'] =  $admin_coach_review->updated_at ?? "";
                return ApiResponse::success($coachReviewsData,'Coach reviews detail found.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getStreakHistoryByUser(){
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else{
                $newRoot = [
                    'streak_calender' => []
                ];
                $userStreakData = UserTrainingStreak::where('user_id',$user["userid"])
                ->where(function ($query) {
                    $query->where('current_streak', '>', 0)
                          ->orWhere('mulligan', '>', 0);
                })->get();
                $newRoot['streak_calender'] = $userStreakData ?? [];
                return ApiResponse::success($newRoot,'User streak detail fetch successfully');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getProfileOld()
    {
        try{
            $newRoot = [
                'user' => [],
                'training_intention' => [],
                'reps' => [],
                'rate' => [],
            ];
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_PROFILE_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if($user){
                if($user->first_name == "" && $user->last_name == ""){
                    if($user->full_name != ""){
                       $names= explode(' ',$user->full_name,2);
                       
                        if(sizeof($names) > 1){
                            $user->first_name = $names[0];
                            $user->last_name = $names[1];
                        }else{
                            $user->first_name = $user->full_name;
                        }
                    }
                }
                $trainingPlan = UserTrainingPlan::where('user_id', $user["userid"])->get();
                $trainingIntention = [];
                if($trainingPlan){
                    foreach ($trainingPlan as $key => $value) {
                        $trainingIntention[$key]['day'] = $value["day"];
                        $trainingIntention[$key]['time'] = $value["time"];
                        $trainingIntention[$key]['location'] = $value["location"];
                    }
                    $collection = new Collection($trainingIntention);
                    $daysOrder  = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
                    $sortedCollection = $collection->sortBy(function ($item) use ($daysOrder) {
                        return array_search($item['day'], $daysOrder);
                    });
                    $sortedTrainingDays = $sortedCollection->values()->all();
                
                }else{
                    $sortedTrainingDays = [];
                }
              
                $reps = [];
                $manual_reps_recall_card = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Recall Cards')
                    ->get();
                $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
                $manual_reps_movement_drills = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Move Drills')
                    ->get();
                $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
                $manual_reps_swing_drills = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Swing Drills')
                    ->get();    
                $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
                $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Trust Shots')
                    ->get();
                $recap_reps_all = SessionRecapTime::where('user_id', $user['_id'])->get();
                $all_totalRecapReps = 0;
                if($recap_reps_all->count() > 0){
                    foreach ($recap_reps_all as $recap_reps_a) {
                        $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                    }
                }
                $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
                // Set initial reps values
                $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
                $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card + $all_totalRecapReps;
                $docs = UserMovementDrill::where('user_id', $user['_id'])->get();
             
                $totalReps = 0;
                foreach ($docs as $doc) {
                    $totalReps += (int) $doc['reps'];
                }
                $userMovementDrillCount = $totalReps;
                $trust_reps = 0;
                $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                    return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                })->values()->all();
                $totalDate = sizeof($sortedDates);
                if( $totalDate > 0){
                    $trust_reps = $totalDate * 40;
                }
                $reps['move_drills'] =  $userMovementDrillCount + $total_manual_reps_movement_drills ?? 0;
                $swings = Swing::where('user_id',$user["_id"])->count();
                $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills?? 0;
                $reps['trust_shots'] = $trust_reps + $total_manual_reps_trust?? 0;
                // $calculatedReps = $totalReps + $userRecallCardsCount + $total_manual_reps_recall_card + $trust_reps + $swings + $total_manual_reps_movement_drills + $total_manual_reps_recall_card + $total_manual_reps_swing_drills + $total_manual_reps_trust ?? 0;
                $calculatedReps =  $reps['trust_shots'] + $reps['swing_drills'] + $reps['move_drills'] + $reps['recall_cards'];
                $currentLevel = $this->calculateBadge($calculatedReps);
                // Update profile picture URL
                $user->profile_picture = $user->profile_picture != "" ? $appUrl."".$path."".$user->profile_picture :"";
                if($user->country_id != ""){
                    $country = Country::find($user->country_id);
                    $timezone = $country->timezone ?? "";
                    $country_name = $country->name ?? "";
                    $field =  $country->name. " - ".$country->timezone ?? "";
                }else{
                    $timezone = "";
                    $country_name = ""; $field ="";
                }
               
                $newRoot['user'] = $user;
                $newRoot['user']['timezone_name'] = $timezone;
                $newRoot['user']['country_name'] = $country_name;
                $newRoot['user']['timezone_field'] = $field;
                $newRoot['plan'] = $user->plan ?? "Good";
                $newRoot['training_intention'] = $sortedTrainingDays;
                $newRoot['reps'] = $reps;
                $newRoot['rate'] =  $currentLevel ?? "";
                // $newRoot['training_streak'] = $user->training_streak ?? 1;
                // if($user->last_updated_training_streak == now()->format('Y-m-d')){
                //     $newRoot['show_blue'] = 1;
                // }else{
                //     $newRoot['show_blue'] = 0;
                // }
                // $newRoot['max_training_streak'] = $user->max_training_streak ?? 1;
                // $today = now()->format('Y-m-d');
                // $trainingStreakData = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$today)->first();
                // $current_training_streak = $trainingStreakData->current_streak ?? 0;
                $newRoot['training_streak'] = $user->training_streak ?? 0;
                //$newRoot['training_streak'] = $current_training_streak ?? 0;
                $today = new DateTime();
                $yesterday = $today->modify('-1 day')->format('Y-m-d');
                $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
                if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                    $newRoot['show_blue'] = 1;
                    $newRoot['training_streak'] = $user->mulligan ?? 1;
                }else{
                    $newRoot['show_blue'] = 0;
                }
                $newRoot['max_training_streak'] = $user->max_training_streak ?? ($user->training_streak ?? 0);
                
                return ApiResponse::success($newRoot,'User detail fetch successfully');
            }else{
                return ApiResponse::error('User not found');
            }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }

    public function getProfile()
    {
        try{
            $newRoot = [
                'user' => [],
                'rate' => [],
            ];
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_PROFILE_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if($user){
                if($user->first_name == "" && $user->last_name == ""){
                    if($user->full_name != ""){
                       $names= explode(' ',$user->full_name,2);
                       
                        if(sizeof($names) > 1){
                            $user->first_name = $names[0];
                            $user->last_name = $names[1];
                        }else{
                            $user->first_name = $user->full_name;
                        }
                    }
                }
              
                $reps = [];
                $manual_reps_recall_card = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Recall Cards')
                    ->get();
                $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
                $manual_reps_movement_drills = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Move Drills')
                    ->get();
                $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
                $manual_reps_swing_drills = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Swing Drills')
                    ->get();    
                $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
                $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Trust Shots')
                    ->get();
                $recap_reps_all = SessionRecapTime::where('user_id', $user['_id'])->get();
                $all_totalRecapReps = 0;
                if($recap_reps_all->count() > 0){
                    foreach ($recap_reps_all as $recap_reps_a) {
                        $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                    }
                }
                $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
                // Set initial reps values
                $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
                $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card + $all_totalRecapReps;
                $docs = UserMovementDrill::where('user_id', $user['_id'])->get();
             
                $totalReps = 0;
                foreach ($docs as $doc) {
                    $totalReps += (int) $doc['reps'];
                }
                $userMovementDrillCount = $totalReps;
                $trust_reps = 0;
                $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                    return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                })->values()->all();
                $totalDate = sizeof($sortedDates);
                if( $totalDate > 0){
                    $trust_reps = $totalDate * 40;
                }
                $reps['move_drills'] =  $userMovementDrillCount + $total_manual_reps_movement_drills ?? 0;
                $swings = Swing::where('user_id',$user["_id"])->count();
                $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills?? 0;
                $reps['trust_shots'] = $trust_reps + $total_manual_reps_trust?? 0;
                // $calculatedReps = $totalReps + $userRecallCardsCount + $total_manual_reps_recall_card + $trust_reps + $swings + $total_manual_reps_movement_drills + $total_manual_reps_recall_card + $total_manual_reps_swing_drills + $total_manual_reps_trust ?? 0;
                $calculatedReps =  $reps['trust_shots'] + $reps['swing_drills'] + $reps['move_drills'] + $reps['recall_cards'];
                $currentLevel = $this->calculateBadge($calculatedReps);
                // Update profile picture URL
                $user->profile_picture = $user->profile_picture != "" ? $appUrl."".$path."".$user->profile_picture :"";
                if($user->country_id != ""){
                    $country = Country::find($user->country_id);
                    $timezone = $country->timezone ?? "";
                    $country_name = $country->name ?? "";
                    $gmtOffSet = $country->gmt_offset ?? "";
                    if($gmtOffSet == "")
                    {
                        $field = "";
                    }else{
                        // $parts = explode(" ", $gmtOffSet);
                        // $hours = explode(":", $parts[1])[0];
                        // $hoursInt = (int)$hours;
                        // $convertedOffset = "(GMT" . sprintf("%+d", $hoursInt) . ")";
                        // $field ="";
                        // $newOffset = $convertedOffset;
                        // if (Str::contains("Eastern (GMT-4)", $newOffset)) {
                        //     $field = "Eastern (GMT-4)";
                        // } 
                        // if (Str::contains("Central (GMT-5)", $newOffset)) {
                        //     $field = "Central (GMT-5)";
                        // }   
                        // if (Str::contains("Mountain (GMT-6)", $newOffset)) {
                        //     $field = "Mountain (GMT-6)";
                        // } 
                        // if (Str::contains("Pacific (GMT-7)", $newOffset)) {
                        //     $field = "Pacific (GMT-7)";
                        // } 
                        // if (Str::contains("Alaska (GMT-8)", $newOffset)) {
                        //     $field = "Alaska (GMT-8)";
                        // } 
                        // if (Str::contains("Hawaii (GMT-10)", $newOffset)) {
                        //     $field = "Hawaii (GMT-10)";
                        // } 
                        // if($field == ""){
                        //     $field =  $country->name. " - ".$country->timezone ?? "";
                        // }
                        $field = $country->utc_offset.": ".$country->standard_time ?? "";
                        //$field =  $country->name. " - ".$country->timezone ?? "";
                    }
                   
                }else{
                    $timezone = "";
                    $country_name = ""; $field ="";
                }
               
                $newRoot['user'] = $user;
                // $newRoot['user']['timezone_name'] = $timezone;
                $newRoot['user']['timezone_name'] =  $field;
                $newRoot['user']['country_name'] = $country_name;
                $newRoot['user']['timezone_field'] = $field;
                // $newRoot['plan'] = $user->plan ?? "Good";
                // $newRoot['reps'] = $reps;
                $newRoot['rate'] =  $currentLevel ?? "";
                $paymentSetting = PaymentSetting::first();
                $newRoot['free_app'] = $paymentSetting->free_app ?? false;
                $new_flow = false;
                $flowSetting = FlowSetting::first();
                $new_flow = $flowSetting->new_flow ?? false;
                $newRoot['new_flow'] = $new_flow ?? false;
                // $newRoot['free_app'] =  true;
                return ApiResponse::success($newRoot,'User detail fetch successfully');
            }else{
                return ApiResponse::error('User not found');
            }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }

    /**
    * Developer: Apptodate 
    * Comment: For app get general setting
    */
    public function getGeneralSetting()
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            // Retrieve user training plan information
            $generalSetting = GeneralSetting::where('user_id',$user['userid'])->get();
            $general_setting = [
                "sound" => 1,
                "video" => 0,
                "audio" => 0,
                "voice_instruction" => 0
            ];
            if($generalSetting->count() > 0){
                foreach ($generalSetting as $key => $setting) {
                    if($setting['field'] == 'sound'){
                        $general_setting['sound'] = $setting['setting'];
                    }
                    if($setting['field'] == 'video'){
                        $general_setting['video']  = $setting['setting'];
                    }
                    if($setting['field'] == 'audio'){
                        $general_setting['audio'] = $setting['setting'];
                    }
                    if($setting['field'] == 'voice_instruction'){
                        $general_setting['voice_instruction'] = $setting['setting'];
                    }
                }
            }
            return ApiResponse::success($general_setting,'User detail fetch successfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }

    /**
    * Developer: Apptodate 
    * Comment: For app get unread notification count
    */
    public function getUnreadNotification()
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $unread_notification = Notification::where('user_id',$user["userid"])->where('is_read',false)->count();
            $newRoot = [
                "unread_notification_count" => $unread_notification 
            ];
            return ApiResponse::success($newRoot,'Here is unread notification count.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: For app get notification 
    */
    public function getNotification()
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
         
            Notification::where('user_id',$user["userid"])->update(['is_read' => true]); // mark notification as read
            
            $notification = Notification::where('user_id',$user["userid"])->orderBy('created_at','desc')->get(); //get all notification of user
            foreach ($notification as $key => $notification_data) {
                $notification[$key]['show_weekly_form'] = $notification_data->title == "How's it Going?" ? 1: 0;
            }
            return ApiResponse::success($notification,'Here is the notification.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: For app store general setting
    */
    public function updateGeneralSetting(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $details = $request->all();
            foreach ($details as $key => $value) {
                $general_setting_save = GeneralSetting::where('user_id',$user['userid'])->where('field',$key)->firstOrCreate();
                $general_setting_save->field = $key;
                $general_setting_save->setting = $value;
                $general_setting_save->user_id = $user['userid'];
                $general_setting_save->save();
            }
            $generalSetting = GeneralSetting::where('user_id',$user['userid'])->get();
            $general_setting['sound']  = 1;
            $general_setting['video']  = 0;
            $general_setting['audio']  = 0;
            $general_setting['voice_instruction']  = 0;
            if($generalSetting->count() > 0){
                foreach ($generalSetting as $key => $setting) {
                    if($setting['field'] == 'sound'){
                        $general_setting['sound'] = $setting['setting'];
                    }
                    if($setting['field'] == 'video'){
                        $general_setting['video']  = $setting['setting'];
                    }
                    if($setting['field'] == 'audio'){
                        $general_setting['audio'] = $setting['setting'];
                    }
                    if($setting['field'] == 'voice_instruction'){
                        $general_setting['voice_instruction'] = $setting['setting'];
                    }
                }
            }
            return ApiResponse::success($general_setting,'User detail fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
    }


    /**
    * Developer: Apptodate 
    * Comment: For app store to add self report of user
    */
    public function storeUserSelfReport(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            $request->validate([
                'object_id' => 'required',
                'session_id' => 'required',
                'unit_id' => 'required',
                'rating' => 'required',
                'text' => 'nullable'
            ]);
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }

            $details = $request->all();

            $userObject = UserObjectType::find($details['object_id']);
            if(!$userObject){
                return ApiResponse::error('Object not found!');
            }
            $selfReport = new UserSelfReportObject();
            $selfReport->object_id = $details['object_id'];
            $selfReport->session_id = $details['session_id'];
            $selfReport->unit_id = $details['unit_id'];
            $selfReport->user_id = $user['_id'];
            $selfReport->rating =  $details['rating'] ?? 0;
            $selfReport->text =  $details['text'] ?? "";
            $selfReport->save();
            return ApiResponse::success($selfReport,'User Self Report added successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
    }

    /**
    * Developer: Apptodate 
    * Comment: For app store to add weekly report of user
    */
    public function storeUserWeeklyReport(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            $request->validate([
                'rating' => 'required',
                'text' => 'nullable'
            ]);
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $details = $request->all();
            $selfReport = new UserWeeklySurvey();
            $selfReport->user_id = $user['_id'];
            $selfReport->rating =  $details['rating'] ?? 0;
            $selfReport->text =  $details['text'] ?? "";
            $selfReport->date = now()->format('Y-m-d');
            $selfReport->save();
            $logInUser = User::find($user['_id']);
            
            $logInUser->weekly_rating_switch = false;
            $logInUser->save();
           
            return ApiResponse::success($selfReport,'User Weekly survey Report added successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: For app store to add self check check of user
    */
    public function storeUserSelfCheckCheck(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $request->validate([
                'tag_id' => 'required',
                'object_id' => 'required',
                'session_id' => 'required',
                'unit_id' => 'required',
                'answer_1' => 'required',
                'answer_3' => 'nullable',
                'answer_2' => 'nullable',
                'answer_4' => 'nullable'
            ]);
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $details = $request->all();
            $userObject = UserObjectType::find($details['object_id']);
            if(!$userObject){
                return ApiResponse::error('Object not found!');
            }
            $tag = Tags::find($details['tag_id']);
            if(!$tag){
                return ApiResponse::error('Tag not found!');
            }
            $selfReport = new UserSelfCheckCheckObject();
            $selfReport->tag_id = $details['tag_id'];
            $selfReport->object_id = $details['object_id'];
            $selfReport->session_id = $details['session_id'];
            $selfReport->unit_id = $details['unit_id'];
            $selfReport->user_id = $user['_id'];
            $selfReport->answer_1 =  $details['answer_1'] ?? "";
            $selfReport->answer_2 =  $details['answer_2'] ?? "";
            $selfReport->answer_3 =  $details['answer_3'] ?? "";
            $selfReport->answer_4 =  $details['answer_4'] ?? "";
            $selfReport->save();
            $userSelfCheckDataForTag = UserSelfCheckCheckObject::where('tag_id', $details['tag_id'])->where('user_id', $user["_id"])->orderBy('created_at', 'desc')->take(5)->select('answer_1')->get();
            $newRoot = [
                'self_check_check' => $selfReport,
                'conclusion' => $userSelfCheckDataForTag,
                'tag_name' => $tag->name ?? "",
                'object_name' => $userObject->object_name
            ];
            $msg = "";
            if($userSelfCheckDataForTag->count() == 1){
                $msg = "Well done! You've completed your first SCC!";
            }
            return ApiResponse::success($newRoot,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function storeUserSCA(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $request->validate([
                'fundamental_id' => 'required',
                'answer_1' => 'required',
                'answer_2' => 'nullable',
            ]);
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $details = $request->all();
            $tag = Fundamental::find($details['fundamental_id']);
            if(!$tag){
                return ApiResponse::error('Fundamental not found!');
            }
            $selfReport = new UserSelfCheckCheckObject();
            $selfReport->fundamental_id = $details['fundamental_id'];
            $selfReport->user_id = $user['_id'];
            $selfReport->answer_1 =  $details['answer_1'] ?? "";
            $selfReport->answer_2 =  $details['answer_2'] ?? "";
            $selfReport->save();
            $newRoot = [
                'SCA' => $selfReport,
                'tag_name' => $tag->name ?? ""
            ];
         
            return ApiResponse::success($newRoot,"Self check audit added successfully.");
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: For app to get self check check history of user
    */
    public function getUserSelfCheckCheckHistory(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $msg = "Here is history of user's self check check.";
            $tag = Tags::pluck('name','_id')->toArray();
            
            $userSelfCheckDataTags = UserSelfCheckCheckObject::whereNotNull('tag_id')->where('user_id', $user["_id"])->groupBy('tag_id')->pluck('tag_id')->toArray();
            if(!empty($userSelfCheckDataTags)){
                foreach ($userSelfCheckDataTags as $key => $userSelfCheckDataTag) {
                    $userSelfCheckDataForEachTag = UserSelfCheckCheckObject::where('tag_id', $userSelfCheckDataTag)->where('user_id', $user["_id"])->orderBy('created_at', 'desc')->take(5)->select('answer_1')->get();
                    $newRoot[$key]['tag_id'] = $userSelfCheckDataTag;
                    $newRoot[$key]['tag_name'] = $tag[$userSelfCheckDataTag] ?? "";
                    $newRoot[$key]['check_1'] = $userSelfCheckDataForEachTag[0]->answer_1 ?? "";
                    $newRoot[$key]['check_2'] = $userSelfCheckDataForEachTag[1]->answer_1 ?? "";
                    $newRoot[$key]['check_3'] = $userSelfCheckDataForEachTag[2]->answer_1 ?? "";
                    $newRoot[$key]['check_4'] = $userSelfCheckDataForEachTag[3]->answer_1 ?? "";
                    $newRoot[$key]['check_5'] = $userSelfCheckDataForEachTag[4]->answer_1 ?? "";
                }
            }
            return ApiResponse::success($newRoot,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function getUserSCAHistoryByFundamental($fundamental_id)
    {
        try{
         
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $msg = "Here is self check audit history by fundamentals.";
            $tag = Fundamental::find($fundamental_id);
            if(!$tag){
                return ApiResponse::error('Fundamental not found!');
            }
            $SCAList = UserSelfCheckCheckObject::where('fundamental_id',$fundamental_id)->where('user_id',$user["_id"])->orderBy('created_at','desc')->get();
           
            $SCACount = $SCAList->count();
            foreach ($SCAList as $key => $sca) {
                $newRoot[$key]['fundamental_id'] = $fundamental_id;
                $newRoot[$key]['fundamental_name'] = $tag->name;
                $newRoot[$key]['title'] = "Audit ". $SCACount;
                $newRoot[$key]['answer_1'] = $sca->answer_1 ?? "";
                $newRoot[$key]['answer_2'] = $sca->answer_2 ?? "";
                $newRoot[$key]['audit_date'] = Carbon::parse($sca->created_at)->format('M d, Y');
                $SCACount--;
            }
            return ApiResponse::success($newRoot,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getUserSCAByFundamental()
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $msg = "Here is self check audit latest by fundamentals.";
            $tags = Fundamental::all();
            foreach ($tags as $key => $tag) {
                $last_audit = "";
                $sca_count = UserSelfCheckCheckObject::where('fundamental_id',$tag->_id)->where('user_id', $user['_id'])->count();
                $sca_latest = UserSelfCheckCheckObject::where('fundamental_id',$tag->_id)->where('user_id', $user['_id'])->orderBy('created_at','desc')->first();
                if($sca_latest){
                    $last_audit =  Carbon::parse($sca_latest->created_at)->format('M d, Y');
                }
                $newRoot[$key]['fundamental_id'] = $tag->_id;
                $newRoot[$key]['fundamental_name'] = $tag->name;
                $newRoot[$key]['SCA_count'] = $sca_count ?? 0;
                $newRoot[$key]['last_audit'] = $last_audit;
                $newRoot[$key]['last_audit_answer_1'] = $sca_latest->answer_1 ?? "";
                $newRoot[$key]['last_audit_answer_2'] = $sca_latest->answer_2 ?? "";
            }
            return ApiResponse::success($newRoot,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: For app get profile where user see users info , training intention, reps and rate related data
    */
    public function getProfileById($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('id required!!');
            }
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_PROFILE_PATH');
            $newRoot = [
                'user' => [],
                'training_intention' => [],
                'reps' => [],
                'rate' => [],
            ];

            $user = User::find($id);
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if($user){
                // Retrieve user training plan information
                $userQuestion = UserTrainingPlan::where('user_id', $user["userid"])->get();
                $trainingIntention = [];
                if($userQuestion){
                    foreach ($userQuestion as $key => $value) {
                        $trainingIntention[$key]['day'] = $value["day"];
                        $trainingIntention[$key]['time'] = $value["time"];
                        $trainingIntention[$key]['location'] = $value["location"];
                    }
                    $collection = new Collection($trainingIntention);
                    $daysOrder  = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
                    $sortedCollection = $collection->sortBy(function ($item) use ($daysOrder) {
                        return array_search($item['day'], $daysOrder);
                    });
                    $sortedTrainingDays = $sortedCollection->values()->all();
                }else{
                    $sortedTrainingDays = [];
                }
                
                $reps = [];
                // Set initial reps values
                $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
                $reps['recall_cards'] = $userRecallCardsCount;
                $docs = UserMovementDrill::where('user_id', $user['_id'])->get();
                $totalReps = 0;
                foreach ($docs as $doc) {
                    $totalReps += (int) $doc['reps'];
                }
                $userMovementDrillCount = $totalReps;
                $reps['move_drills'] =  $userMovementDrillCount;
                $swings = Swing::where('user_id',$user["_id"])->count();
                $trust_shot_data = UserTrustHole::select('trust_hole_no','date')
                                ->where('user_id', $user["userid"])
                                ->whereNotNull('trust_hole_no')
                                ->groupBy('trust_hole_no','date')
                                ->havingRaw('COUNT(DISTINCT hole_type) = 1')
                                ->whereIn('hole_type', ['Drive', 'Approach'])
                                ->get();
                if(!empty($trust_shot_data)){
                    $trust_shots = $trust_shot_data->count();
                }else{
                    $trust_shots = 0;
                }
                $reps['swing_drills'] = $swings ?? 0;
                $reps['trust_shots'] = $trust_shots ?? 0;
                
                $user->profile_picture =  $user->profile_picture != "" ? $appUrl."".$path."".$user->profile_picture :"";
                $newRoot['plan'] = $user->plan ?? "Good";
                $newRoot['user'] = $user;
                $newRoot['training_intention'] = $sortedTrainingDays;
                $newRoot['reps'] = $reps;
                $newRoot['rate'] = "10K";

                return ApiResponse::success($newRoot,'User detail fetch successfully');
            }else{
                return ApiResponse::error('User not found');
            }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }


    /**
    * Developer: Apptodate 
    * Comment: home page api for app
    */
    public function homepage(){
        try {
            // Initialize the root data structure
            $newRoot = [
                'unit' => new stdClass(),
                'user_rate' => 0,
            ];
            // Get the token from the request header
            $token = $this->getTokenFromHeader();
            $countries = Country::pluck('timezone','_id')->toArray();
            $user = \JWTAuth::setToken($token)->authenticate();// Authenticate the user using JWTAuth and the provided token
            if(!$user) {// If the user is authenticated
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $appUrl = env('AWS_S3_PATH');
            $defaultProgram = env('DEFAULT_PROGRAM');
            if($user){
                
                $countries = Country::pluck('timezone','_id')->toArray();
                $userTimezone = $countries[$user->country_id] ?? "UTC";
                $todayDate = Carbon::now($userTimezone)->format('Y-m-d H:i:s');
               
                $remindLater = false;
                $isRemindMeLaterOn = User::where('userid',$user->userid)->where('remind_later',1)->where('remind_later_date', '>=', $todayDate)->first();
                if($isRemindMeLaterOn){
                    $remindLater = true;
                }
                $remind_later_24_hour_on = User::where('userid',$user->userid)->where('remind_later_24_hour',1)->where('remind_later_date', '>=', $todayDate)->first();
                if($remind_later_24_hour_on){
                    $remind_later_24_hour = true;
                }
                $category_type_id = CategoryType::where('name','Train')->pluck('_id')->first();
                if (!$category_type_id) {
                    return ApiResponse::error('Category type not found');
                }
                $groupUnitIds = array_column(Group::where('group_name', $defaultProgram)->first()["group_object"], "object_id");
                if (!empty($user->group_id) && $group = Group::find($user->group_id)) {
                    $groupUnitIds = array_column($group["group_object"], "object_id");
                }
                $unitCollectionData = Unit::whereIn('_id', $groupUnitIds)
                                        ->where('category_type_id', $category_type_id)
                                        ->get()
                                        ->sortBy(function ($item) use ($groupUnitIds) {
                                            return array_search($item['_id'], $groupUnitIds);
                                        });
                $unitProgress = $unitCollectionData;
                $unitData = [];
                $objectIds = collect($unitProgress)->flatMap(fn($unit) => array_column($unit['unit_object'], 'object_id'))->unique();
                $sessionData = Session::whereIn('_id', $objectIds)->get();
                $userObjectTypeIds = $sessionData->pluck('session_object.*.object_id')->flatten()->unique();
                $valueObjData = UserObjectType::whereIn('_id', $userObjectTypeIds)->pluck('object_time')->toArray();
                $userSessionProgress = UserSessionProgress::where('user_id', $user->_id)->get();
                foreach ($unitProgress as $key => $value) {
                    $unitData[$key]['id'] = $value["_id"];
                    $unitData[$key]['title'] = $value["unit_name"];
                    $unitData[$key]['percentage'] = '0%';
                    $unitData[$key]['completed_session'] = 0;
                    $noOfSession = 0;
                    $unitObjectCount = count($value['unit_object']);
                    if ($unitObjectCount > 0) {
                        $session = [];
                        $pending_session_ids[$value["_id"]] = [];
                        $finished_session_ids[$value["_id"]] = [];
                        $totalSessionDuration = 0;
                        // Iterate over unit objects in the current unit
                        foreach ($value['unit_object'] as $keys => $unitObject) {
                            $percentage = 0;
                            $sessionDataItem = $sessionData->firstWhere('_id', $unitObject['object_id']);
                            $objIds = [];
                            if ($sessionDataItem) {
                                // Set session data for the current unit object
                                $session[$keys]['id'] = $sessionDataItem->_id;
                                $session[$keys]['seen'] = false;
                                $session[$keys]['title'] = $sessionDataItem->session_name;
                                $session[$keys]['internal_session_name'] = $sessionDataItem->internal_session_name ?? "";
                                $session[$keys]['headline'] = $sessionDataItem->headline;
                                $session[$keys]['text'] = $sessionDataItem->text;
                                $session[$keys]['thumbnail'] = $appUrl.'thumbnail_old.png';
                                $countSessionObject = count($sessionDataItem->session_object) ?? 0;
                                if ($countSessionObject > 0) {
                                    if (sizeof($valueObjData) > 0) {
                                        $countValObjData = array_sum($valueObjData);
                                        $totalSessionDuration += $countValObjData;
                                    }
                                    $session[$keys]['duration'] = number_format($totalSessionDuration,2);
                                    $objIds = array_column($sessionDataItem["session_object"], "object_id");
                                    $countUserUnitProgress = $userSessionProgress->where('unit_id',$value["_id"])->where('session_id', $sessionDataItem->_id)->whereIn('object_id',$objIds)->pluck('object_id')->unique()->count(); // Get unique values
                                    if ($countUserUnitProgress == $countSessionObject) {
                                        $noOfSession++;
                                        $finished_session_ids[$value["_id"]][] = $sessionDataItem->_id;
                                        $session[$keys]['seen'] = true;
                                    }else{
                                        $pending_session_ids[$value["_id"]][] = $sessionDataItem->_id;
                                    }
                                
                                    if ($countUserUnitProgress > 0 && $countSessionObject > 0) {
                                        $percentage = ($countUserUnitProgress / $countSessionObject) * 100;
                                    }
                                    
                                    $session[$keys]['percentage'] = number_format($percentage, 2) . '%';
                                }
                            }
                        }
                    }
                    if ($noOfSession > 0 && $unitObjectCount > 0) {
                        $unitData[$key]['percentage'] = $noOfSession / $unitObjectCount * 100 . '%';
                        $unitData[$key]['completed_session'] = $noOfSession;
                    }
                    $unitData[$key]['session'] = $session;
                }
                $unit = [];
                foreach ($unitData as $key => $value) {
                    // $intPercent =(int)$value['percentage'];
                    $intPercent = round((float)$value['percentage']);
                 
                    if( $intPercent < 100){
                        $unit['no_of_unit'] = $value["title"];
                        $unit['completed_percentage'] = $intPercent;
                        $unit['unit_id'] = $value['id'];
                        break;
                    }else{
                        $unit['no_of_unit'] = $value["title"];
                        $unit['completed_percentage'] = $intPercent;
                        $unit['unit_id'] = $value['id'];
                    }
                }
                $showDailyReminderPopUp = false;
                if( $user->skip_reminder === null){
                    $registerdatetime = $user->registered_at;
                    $currentDatetime = Carbon::now(); // Get current datetime

                    $diffInMinutes = Carbon::parse($registerdatetime)->diffInMinutes($currentDatetime);
                   
                    if ($diffInMinutes > 10) {
                        $showDailyReminderPopUp = true;
                    }
                }
                $newRoot['training_streak'] = $user->training_streak ?? 0;
                $newRoot['showDailyReminderPopUp'] = $showDailyReminderPopUp ?? false;
                $today = new DateTime();
                $yesterday = $today->modify('-1 day')->format('Y-m-d');
                $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
                if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                    $newRoot['show_blue'] = 1;
                    $newRoot['training_streak'] = $user->mulligan ?? 1;
                }else{
                    $newRoot['show_blue'] = 0;
                }
                //$newRoot['max_training_streak'] = $user->max_training_streak ?? ($user->training_streak ?? 0);
                $newRoot['unit'] = $unit;
                $newRoot['provider'] = $user->provider  ?? "";
                $newRoot['providerId'] = $user->providerId ?? "";
                $newRoot['email'] = $user->email ?? "";
                $newRoot['full_name'] = $user->full_name ?? "";
                $freeAppSetting = PaymentSetting::first();
                $newRoot['free_app'] = $freeAppSetting->free_app ?? false;
                
                $plans = Plan::all();
                $expiryInTwoDay = false;
                $expiryIn24Hours = false;
                $userTimezone = $countries[$user->country_id] ?? "UTC";
                
                $is_expired = false;
                $billing_history = UserBillingHistory::where('user_id',$user["_id"])->orderBy('created_at', 'desc')->first();
                if($billing_history){
                    $lastExpDate = $billing_history->expiry_date;
                    $todayDate = Carbon::now($userTimezone);
                    $expiryDate = Carbon::parse($lastExpDate, $userTimezone);

                    if ($todayDate > $expiryDate) {
                        $is_expired = true;
                    }
                }
                foreach ($plans as $key => $plan) {
                    $plan->is_expired = false;

                    if($billing_history && $billing_history->plan_id == $plan->_id){
                        if($billing_history->status == "active") {
                                $plan->active_plan = true;
                        }else{
                                $plan->active_plan = false;
                        }
                        
                        $plan->subscription_id = $user->active_subscription_id ?? "";
                        $userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->where('plan_id',$plan->_id)->where('status','active')->first();
                        if($userBillingHistory){
                            $expiry_date = $userBillingHistory->expiry_date;
                            $currentDate = Carbon::now($userTimezone);
                            $expiryDate = Carbon::parse($expiry_date, $userTimezone);

                            $daysUntilExpiry = $currentDate->diffInDays($expiryDate);
                            $hoursUntilExpiry = $currentDate->diffInHours($expiryDate);

                            if ($daysUntilExpiry <= 2) {
                                $expiryInTwoDay = true;
                            }

                            if ($hoursUntilExpiry <= 24) {
                                $expiryIn24Hours = true;
                            }
                            if ($currentDate > $expiryDate) {
                                $plan->is_expired = true;
                            }
                        }
                    }else{
                        $plan->active_plan = false;
                        $plan->subscription_id =  "";
                    }
                    $plan->expiry_in_two_day = $expiryInTwoDay;
                    $plan->expiry_in_24_hours = $expiryIn24Hours;
                }
                $newRoot['is_free'] = $user->is_free ?? false;
                $newRoot['remind_later'] = $remindLater ?? false;
                $newRoot['remind_later_24_hour'] = $remind_later_24_hour ?? false;
                $newRoot['popup_display'] = $expiryInTwoDay;
                $newRoot['popup_display_24hour'] = $expiryIn24Hours;
                $newRoot['is_expired'] = $is_expired;
                $newRoot['plans'] = $plans;

                return ApiResponse::success($newRoot,'User Unit Progress fetch successfully');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function homepageLast(){
        try {
            // Initialize the root data structure
            $newRoot = [
                'unit' => new stdClass(),
                'user_rate' => 0,
            ];
            // Get the token from the request header
            $token = $this->getTokenFromHeader();
            $countries = Country::pluck('timezone','_id')->toArray();
            $user = \JWTAuth::setToken($token)->authenticate();// Authenticate the user using JWTAuth and the provided token
            if(!$user) {// If the user is authenticated
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $appUrl = env('AWS_S3_PATH');
            $defaultProgram = env('DEFAULT_PROGRAM');
            if($user){
                 $newRoot['is_free'] = $user->is_free ?? false;
                $countries = Country::pluck('timezone','_id')->toArray();
                $userTimezone = $countries[$user->country_id] ?? "UTC";
                $todayDate = Carbon::now($userTimezone)->format('Y-m-d H:i:s');
               
                $remindLater = false;
                $isRemindMeLaterOn = User::where('userid',$user->userid)->where('remind_later',1)->where('remind_later_date', '>=', $todayDate)->first();
                if($isRemindMeLaterOn){
                    $remindLater = true;
                }
                $remind_later_24_hour_on = User::where('userid',$user->userid)->where('remind_later_24_hour',1)->where('remind_later_date', '>=', $todayDate)->first();
                if($remind_later_24_hour_on){
                    $remind_later_24_hour = true;
                }
                $category_type_id = CategoryType::where('name','Train')->pluck('_id')->first();
                if (!$category_type_id) {
                    return ApiResponse::error('Category type not found');
                }
                $groupUnitIds = array_column(Group::where('group_name', $defaultProgram)->first()["group_object"], "object_id");
                if (!empty($user->group_id) && $group = Group::find($user->group_id)) {
                    $groupUnitIds = array_column($group["group_object"], "object_id");
                }
                $unitCollectionData = Unit::whereIn('_id', $groupUnitIds)
                                        ->where('category_type_id', $category_type_id)
                                        ->get()
                                        ->sortBy(function ($item) use ($groupUnitIds) {
                                            return array_search($item['_id'], $groupUnitIds);
                                        });
                $unitProgress = $unitCollectionData;
                $unitData = [];
                $objectIds = collect($unitProgress)->flatMap(fn($unit) => array_column($unit['unit_object'], 'object_id'))->unique();
                $sessionData = Session::whereIn('_id', $objectIds)->get();
                $userObjectTypeIds = $sessionData->pluck('session_object.*.object_id')->flatten()->unique();
                $valueObjData = UserObjectType::whereIn('_id', $userObjectTypeIds)->pluck('object_time')->toArray();
                $userSessionProgress = UserSessionProgress::where('user_id', $user->_id)->get();
                foreach ($unitProgress as $key => $value) {
                    $unitData[$key]['id'] = $value["_id"];
                    $unitData[$key]['title'] = $value["unit_name"];
                    $unitData[$key]['percentage'] = '0%';
                    $unitData[$key]['completed_session'] = 0;
                    $noOfSession = 0;
                    $unitObjectCount = count($value['unit_object']);
                    if ($unitObjectCount > 0) {
                        $session = [];
                        $pending_session_ids[$value["_id"]] = [];
                        $finished_session_ids[$value["_id"]] = [];
                        $totalSessionDuration = 0;
                        // Iterate over unit objects in the current unit
                        foreach ($value['unit_object'] as $keys => $unitObject) {
                            $percentage = 0;
                            $sessionDataItem = $sessionData->firstWhere('_id', $unitObject['object_id']);
                            $objIds = [];
                            if ($sessionDataItem) {
                                // Set session data for the current unit object
                                $session[$keys]['id'] = $sessionDataItem->_id;
                                $session[$keys]['seen'] = false;
                                $session[$keys]['title'] = $sessionDataItem->session_name;
                                $session[$keys]['internal_session_name'] = $sessionDataItem->internal_session_name ?? "";
                                $session[$keys]['headline'] = $sessionDataItem->headline;
                                $session[$keys]['text'] = $sessionDataItem->text;
                                $session[$keys]['thumbnail'] = $appUrl.'thumbnail_old.png';
                                $countSessionObject = count($sessionDataItem->session_object) ?? 0;
                                if ($countSessionObject > 0) {
                                    if (sizeof($valueObjData) > 0) {
                                        $countValObjData = array_sum($valueObjData);
                                        $totalSessionDuration += $countValObjData;
                                    }
                                    $session[$keys]['duration'] = number_format($totalSessionDuration,2);
                                    $objIds = array_column($sessionDataItem["session_object"], "object_id");
                                    $countUserUnitProgress = $userSessionProgress->where('unit_id',$value["_id"])->where('session_id', $sessionDataItem->_id)->whereIn('object_id',$objIds)->pluck('object_id')->unique()->count(); // Get unique values
                                    if ($countUserUnitProgress == $countSessionObject) {
                                        $noOfSession++;
                                        $finished_session_ids[$value["_id"]][] = $sessionDataItem->_id;
                                        $session[$keys]['seen'] = true;
                                    }else{
                                        $pending_session_ids[$value["_id"]][] = $sessionDataItem->_id;
                                    }
                                
                                    if ($countUserUnitProgress > 0 && $countSessionObject > 0) {
                                        $percentage = ($countUserUnitProgress / $countSessionObject) * 100;
                                    }
                                    
                                    $session[$keys]['percentage'] = number_format($percentage, 2) . '%';
                                }
                            }
                        }
                    }
                    if ($noOfSession > 0 && $unitObjectCount > 0) {
                        $unitData[$key]['percentage'] = $noOfSession / $unitObjectCount * 100 . '%';
                        $unitData[$key]['completed_session'] = $noOfSession;
                    }
                    $unitData[$key]['session'] = $session;
                }
                $unit = [];
                foreach ($unitData as $key => $value) {
                    $intPercent =(int)$value['percentage'];
                 
                    if( $intPercent < 100){
                        $unit['no_of_unit'] = $value["title"];
                        $unit['completed_percentage'] = $intPercent;
                        $unit['unit_id'] = $value['id'];
                        break;
                    }else{
                        $unit['no_of_unit'] = $value["title"];
                        $unit['completed_percentage'] = $intPercent;
                        $unit['unit_id'] = $value['id'];
                    }
                }
                $newRoot['training_streak'] = $user->training_streak ?? 0;
                $today = new DateTime();
                $yesterday = $today->modify('-1 day')->format('Y-m-d');
                $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
                if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                    $newRoot['show_blue'] = 1;
                    $newRoot['training_streak'] = $user->mulligan ?? 1;
                }else{
                    $newRoot['show_blue'] = 0;
                }
                //$newRoot['max_training_streak'] = $user->max_training_streak ?? ($user->training_streak ?? 0);
                $newRoot['unit'] = $unit;
                
                $plans = Plan::all();
                $expiryInTwoDay = false;
                $expiryIn24Hours = false;
                $userTimezone = $countries[$user->country_id];
                
                $is_expired = false;
                $billing_history = UserBillingHistory::where('user_id',$user["_id"])->orderBy('created_at', 'desc')->first();
                if($billing_history){
                    $lastExpDate = $billing_history->expiry_date;
                    $todayDate = Carbon::now($userTimezone);
                    $expiryDate = Carbon::parse($lastExpDate, $userTimezone);

                    if ($todayDate > $expiryDate) {
                        $is_expired = true;
                    }
                }
                foreach ($plans as $key => $plan) {
                    $plan->is_expired = false;

                    if($billing_history && $billing_history->plan_id == $plan->_id){
                        if($billing_history->status == "active") {
                                $plan->active_plan = true;
                        }else{
                                $plan->active_plan = false;
                        }
                        
                        $plan->subscription_id = $user->active_subscription_id ?? "";
                        $userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->where('plan_id',$plan->_id)->where('status','active')->first();
                        if($userBillingHistory){
                            $expiry_date = $userBillingHistory->expiry_date;
                            $currentDate = Carbon::now($userTimezone);
                            $expiryDate = Carbon::parse($expiry_date, $userTimezone);

                            $daysUntilExpiry = $currentDate->diffInDays($expiryDate);
                            $hoursUntilExpiry = $currentDate->diffInHours($expiryDate);

                            if ($daysUntilExpiry <= 2) {
                                $expiryInTwoDay = true;
                            }

                            if ($hoursUntilExpiry <= 24) {
                                $expiryIn24Hours = true;
                            }
                            if ($currentDate > $expiryDate) {
                                $plan->is_expired = true;
                            }
                        }
                    }else{
                        $plan->active_plan = false;
                        $plan->subscription_id =  "";
                    }
                    $plan->expiry_in_two_day = $expiryInTwoDay;
                    $plan->expiry_in_24_hours = $expiryIn24Hours;
                }
               
                $newRoot['remind_later'] = $remindLater ?? false;
                $newRoot['remind_later_24_hour'] = $remind_later_24_hour ?? false;
                $newRoot['popup_display'] = $expiryInTwoDay;
                $newRoot['popup_display_24hour'] = $expiryIn24Hours;
                $newRoot['is_expired'] = $is_expired;
                $newRoot['plans'] = $plans;

                return ApiResponse::success($newRoot,'User Unit Progress fetch successfully');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: App side shows terms and service static content
    */

    public function getUserDailyReminder(){
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user){
                return ApiResponse::error('Getting trouble while fetching user information.');
            }
            $skip_reminder = $user->skip_reminder ?? true;
            $set_daily_reminder = ($skip_reminder == true ) ? false : true;
            $set_daily_reminder_time = "";
            $hour = $min = $timeAM = "";
            if( $set_daily_reminder == true){
                $hour = ($user->hour != '') ? (int)$user->hour : 6;
                $min = ($user->min != '') ? (int)$user->min :0;
                $timeAM = Str::upper($user->time)?? "AM";
                if($hour != "" && $min != "" && $hour > 0 ){
                    $time = $hour. ":". $min;
                    $parsedTime = Carbon::parse($time);
                    $finalTime  =  $parsedTime->format('g:i')." ".$timeAM;
                }
                $set_daily_reminder_time = $finalTime ?? "";
            }

            $response = [
                'hour' => $hour,
                'min' => $min,
                'time' => $timeAM,
                'skip_reminder' => $skip_reminder,
                'set_daily_reminder' => $set_daily_reminder,
                'set_daily_reminder_time' => $set_daily_reminder_time
            ];

            return ApiResponse::success($response,'Daily reminder detail fetched successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function getTermServcie()
    {
        try{
            $faqs = TermService::first();
            return ApiResponse::success($faqs,'Terms &service fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side about screen content
    */
    public function getAboutScreen()
    {
        try{
            $data = [
                'image' => env('AWS_S3_PATH'). "" . env('AWS_DISPLAY_IMAGE_PATH') . "Rectangle+5997.png",
                'title' => "Let’s talk about your golf game",
                'description' => "We’ll walk you through a few questions to help guide your training plan"
            ];
            return ApiResponse::success($data,'About data fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side shows information center images and relavent question for that
    */
    public function getInformationCenter()
    {
        try{
            // Initialize the root data structure
            $newRoot = [
                'information_center_images' => [],
                'information_center_question' => [],
            ];
            // Initialize arrays to store information center images and questions
            $infoImage = [];
            $infoQuestion = [];
            $infoImages = InformationCenterImages::all();// Retrieve all information center images from the database
            $infoQuestions = InformationCenter::all();// Retrieve all information center questions from the database
            // Process information center images
            foreach ($infoImages as $key => $value) {
                // Set image and title for each information center image
                $infoImage[$key]["image"] = $value["image"];
                $infoImage[$key]["title"] = $value["title"];
            }
            // Process information center questions
            foreach ($infoQuestions as $key => $value) {
                // Set question and answer for each information center question
                // Set question and answer for each information center question
                $infoQuestion[$key]["question"] = $value["question"];
                $infoQuestion[$key]["answer"] = $value["answer"];
            }
            
           $newRoot['information_center_images'] = $infoImage;
           $newRoot['information_center_question'] = $infoQuestion;

            return ApiResponse::success($newRoot,'Information center data fetch successfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side user can save/unsave the session
    */
    public function storeSavedItem($id,$unit_id = "")
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$id){
                return ApiResponse::error('Session id required!!');
            }
            $saved = [];
            $sessionSavedQ = SavedItems::where('saved_item_id',$id)->where('type','session');
            if($unit_id != ""){
                $sessionSavedQ = $sessionSavedQ->where('unit_id',$unit_id);
            }
            $sessionSaved = $sessionSavedQ->where('user_id',$user['userid'])->first();
            if(!empty($sessionSaved)){
                $savedItem['saved'] = false;
                $sessionSaved->delete();       
                $msg = 'Session unsaved successfully.';
            }else{
                $savedItem['saved'] = true;
                $sessionSavedItem = new SavedItems();
                $sessionSavedItem->user_id = $user['userid'];
                $sessionSavedItem->unit_id = $unit_id ?? "";
                $sessionSavedItem->saved_item_id = $id;
                $sessionSavedItem->session_id = $id;
                $sessionSavedItem->type = 'session';
                $sessionSavedItem->save();
                $msg = 'Session saved successfully.';
            }
            return ApiResponse::success($savedItem,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side user can save/unsave the object
    */
    public function storeSavedObject($id,$session_id,$unit_id = "")
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$id){
                return ApiResponse::error('Object id required!!');
            }
            if(!$session_id){
                return ApiResponse::error('Session id required!!');
            }
            if(!$unit_id){
                return ApiResponse::error('Unit id required!!');
            }
            $sessionSavedQ = SavedItems::where('saved_item_id',$id)->where('type','object');
            if($unit_id != ""){
                $sessionSavedQ = $sessionSavedQ->where('unit_id',$unit_id);
            }
            if($session_id != ""){
                $sessionSavedQ = $sessionSavedQ->where('session_id',$session_id);
            }
            $sessionSaved = $sessionSavedQ->where('user_id',$user['userid'])->first();
            if(!empty($sessionSaved)){
                $savedItem['saved'] = false;
                $sessionSaved->delete();       
                $msg = 'Object unsaved successfully.';
            }else{
                $savedItem['saved'] = true;
                $sessionSavedItem = new SavedItems();
                $sessionSavedItem->user_id = $user['userid'];
                $sessionSavedItem->unit_id = $unit_id;
                $sessionSavedItem->session_id = $session_id;
                $sessionSavedItem->saved_item_id = $id;
                $sessionSavedItem->type = 'object';
                $sessionSavedItem->save();
             
                $msg = 'Object saved successfully.';
            }
            return ApiResponse::success($savedItem,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }


    public function storeSavedTrustOrShotCheck(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            $date = $request->date;
            if(!$date){
                return ApiResponse::error('Date is required!!');
            }
            if($request->type == 'trust'){
                $type = "Trust";
                $savedItem_ = SavedItems::where('type','trust')->where('saved_item_id',$date)->where('user_id',$user['userid'])->first();
            
            }else{
                $type = "Shot Check";
                $savedItem_ = SavedItems::where('type','shot-check')->where('saved_item_id',$date)->where('user_id',$user['userid'])->first();
            
            }
            if(!empty($savedItem_)){
                $savedItem['saved'] = false;
                $savedItem_->delete();    
                $msg = $type.' unsaved successfully.';
            }else{
                $savedItem['saved'] = true;
                $savedItem_ = new SavedItems();
                $savedItem_->user_id = $user['userid'];
                $savedItem_->saved_item_id = $date;
                $savedItem_->trust_key = $request->trust_key ?? "";
                if($request->type == "trust"){
                    $savedItem_->type = 'trust';
                }else{
                    $savedItem_->type = 'shot-check';
                }
                $savedItem_->save();
                $msg = $type.' saved successfully.';
            }
            return ApiResponse::success($savedItem,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function deleteSavedItem($id){
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            if($user){
                $savedItem = SavedItems::where('type','session')->where('user_id',$user["userid"])->where('saved_item_id',$id)->first();
                if($savedItem){
                    $savedItem->delete();
                    return ApiResponse::successOnly('Session removed from saved list');
                }else{
                    return ApiResponse::error('This session not exist in saved list!');
                }
            }else{
                return ApiResponse::error('Getting trouble to fetch user information');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: App side update user's friend 
    */
    public function updateFriendSupport(Request $request)
    {
        try{
            
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
          
            $request->validate([
                'name' => 'required',
                'phone' => 'required',
            ]);
            if($user){
                // Add/update plan for user
                if(isset($request->plan) && $request->plan != ""){
                    $user->plan = $request->plan;
                    $user->save();
                }
            }
            if(isset($request->id)){
                $contactPerson = UserContactPerson::where('user_id', $user["userid"])->where('_id', $request->id)->first();
                if(!$contactPerson){
                    return ApiResponse::error('Contact person not found!!');
                }
                $contactPerson->person_name = $request->name;
                $contactPerson->phone = $request->phone;
                $contactPerson->save();
                $status = 'updated';
            }else{
                $contactPerson = new UserContactPerson();
                $contactPerson->person_name = $request->name;
                $contactPerson->user_id = $user["userid"];
                $contactPerson->phone = $request->phone;
                $contactPerson->save();
                $status = 'added';
            }
            $sid = env('TWILIO_SID');
            $token = env('TWILIO_AUTH_TOKEN');
            $twilioNumber = env('TWILIO_PHONE_NUMBER');
            $client = new Client($sid, $token);
              
            $recipientNumber = $request->phone;
          
            $messageBody = '     
Hello '.$request->name.',

'.$user["full_name"].' asked we share the following training schedule because research shows people stick with their training when they share it with friends. Thank you for supporting '.$user["full_name"].' on this!
    
The Fisio™ Team 
Fisio™: Personal Golf Training';
        
            
            try {
                $message = $client->messages->create(
                    $recipientNumber,
                    [
                        'from' => $twilioNumber,
                        'body' => $messageBody,
                    ]
                );
            } catch (\Exception $e) {
                error_log("Error sending SMS: " . $e->getMessage(), 0);
            }
            $newRoot = [
                'user_name' => $user->full_name,
                'friendSupport' => $contactPerson
            ];
            return ApiResponse::success($contactPerson,'Contact person '.$status.' successfully');
        
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }
    
    /**
    * Developer: Apptodate 
    * Comment: App side delete user's friend
    */
    public function deleteFriendSupport($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Contact person id required!!');
            }
            $contactPerson = UserContactPerson::find($id);
            if($contactPerson){
                $contactPerson->delete();
                return ApiResponse::successOnly('Contact person deleted successfully.');
            }else{
                return ApiResponse::error('Contact person not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side add/update folder
    */
    public function updateFolder(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'name' => 'required'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(isset($request->id)){
                $folder = Folder::where('user_id', $user["userid"])->where('_id', $request->id)->first();
                if(!$folder){
                    return ApiResponse::error('Folder not found!!');
                }
                $status = 'updated';
            }else{
                $folder = new Folder();
                $status = 'added';
            }
            $folder->user_id = $user["userid"];
            $folder->name = $request->name;
            $folder->save();
            return ApiResponse::success($folder,'Folder '.$status.' successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    /**
    * Developer: Apptodate 
    * Comment: App side delete folder
    */
    public function deleteFolder($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Folder id required!!');
            }
            $folder = Folder::find($id); //find folder by passed id
            if($folder){
                //for soft delete after confirmation
                // $folder->is_deleted = true;
                // $folder->deleted_at = now();
                // $folder->save();
            
                $folder->delete(); //delete folder
                return ApiResponse::successOnly('Folder deleted successfully.');
            }else{
                return ApiResponse::error('Folder not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side list folder
    */
    public function getFolder(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $searchTerm = $request->input('search'); //filter for name
            $query = Folder::query(); 
            if (!empty($searchTerm)) {
                $query->where('name', 'like', '%' . $searchTerm . '%');
            }
            $folders = $query->where('user_id',$user["userid"])->get(); //get folder list by logged in user
          
            $newFolder = (object) [
                "_id" => "0",
                "user_id" =>  $user["userid"],
                "name" => "General",
                "updated_at"=> "2023-08-07T08:47:17.129000Z",
                "created_at"=> "2023-08-07T08:47:17.129000Z"
                // Add other properties of the folder if needed
            ];
            $folders->push($newFolder);

            // $folder = $query->where('user_id',$user["userid"])->where('is_deleted',false)->get();
            return ApiResponse::success($folders,'Here is folders list.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getUserGuide()
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_GUIDE_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $guides = Guide::all();//get folder list by logged in user
            $guideData = [];
            $purchased = false;
            $userBillingHistory = UserBillingHistory::where('plan_id','!=','65e12b53bff860305975192f')->where('user_id',$user["_id"])->where('status','active')->first();
            if($userBillingHistory){
                $purchased = true;
            }else{
                $purchased = $user->is_free ?? false;
                $FreeUser = FreeUser::where('email', $user->email)->count();
                if($FreeUser > 0){
                    $purchased = true;
                }
            }
            $freeAppSetting = PaymentSetting::first();
            if($guides->count() > 0){
                foreach ($guides as $key => $guide) {
                    
                    $guideData[$key]['free_app'] = $freeAppSetting->free_app ?? false;
                    $guideData[$key]['purchased'] = $purchased;
                    $guideData[$key]['id'] = $guide->_id;
                    $guideData[$key]['title'] = $guide->title;
                    $guideData[$key]['description'] = $guide->description;
                    $fundamentals = GuideFundamental::where('guide_id',$guide->id)->get();
                    $fundamentalsData = [];
                    if($fundamentals->count() > 0){
                        foreach ($fundamentals as $keyy => $fundamental) {
                            $fundamentalsData[$keyy]['id'] = $fundamental->_id;
                            $fundamentalsData[$keyy]['name'] = $fundamental->title;
                            $fundamentalsData[$keyy]['description'] = $fundamental->description;
                            $fundamentalsData[$keyy]['main_image'] =  $fundamental->main_image != "" ? $appUrl."".$path."".$fundamental->main_image :"";
                            $fundamentalsData[$keyy]['secondary_vimeo_link'] =  $fundamental->secondary_vimeo_link ?? "";
                            $fundamentalsData[$keyy]['secondary_image'] =  $fundamental->secondary_image != "" ? $appUrl."".$path."".$fundamental->secondary_image :"";
                            // $fundamentalsData[$keyy]['micro_moves'] = $fundamental->micro_move_steps ?? [];
                        }
                        $guideData[$key]['fundamentals'] = $fundamentalsData;
                    }
                }
            }
            return ApiResponse::success($guideData,'Here is Guide list.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getUserGuideFundamental($id,$guide_id)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_GUIDE_PATH');
            $step_img_path = env('AWS_GUIDE_STEP_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $fundamental = GuideFundamental::where('guide_id',$guide_id)->where('_id',$id)->first();
            if($fundamental){
                $fundamentalsData = [];
                $fundamentalsData['id'] = $fundamental->_id;
                $fundamentalsData['name'] = $fundamental->title;
                $fundamentalsData['description'] = $fundamental->description;
                $fundamentalsData['main_image'] =  $fundamental->main_image != "" ? $appUrl."".$path."".$fundamental->main_image :"";
                $fundamentalsData['secondary_image'] =  $fundamental->secondary_image != "" ? $appUrl."".$path."".$fundamental->secondary_image :"";
                $fundamentalsData['secondary_vimeo_link'] =  $fundamental->secondary_vimeo_link ?? "";
                if (!empty($fundamental->micro_move_steps)) {
                    $micro_move_steps_data = $fundamental->micro_move_steps;
                    foreach ($micro_move_steps_data as $keyq => &$micro_move_steps) {
                        if (!empty($micro_move_steps['steps'])) {
                            foreach ($micro_move_steps['steps'] as $keyt => &$step) {
                                // Check if 'vimeo_link' exists and is not empty, else set to an empty string
                                $step['details'] = !empty($step['details']) ? $step['details'] : '';
                                $step['vimeo_link'] = !empty($step['vimeo_link']) ? $step['vimeo_link'] : '';
                                $step['image'] = !empty($step['image']) ? $appUrl."".$step_img_path."".$step['image'] :"";
                            }
                            unset($step); // Best practice to unset the reference to prevent potential future bugs
                        }
                    }
                    unset($micro_move_steps); // Unset the reference after the loop
                }
                
                $fundamentalsData['micro_moves'] = $micro_move_steps_data ?? [];
                return ApiResponse::success($fundamentalsData,'Here is Guide Fundamental details.');
            }else{
                return ApiResponse::error('Getting trouble to fetch Guide Fundamental');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    

    /**
    * Developer: Apptodate 
    * Comment: App side list folder
    */
    public function getDeletedFolder(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $searchTerm = $request->input('search'); //filter for name
            $query = Folder::query(); 
            if (!empty($searchTerm)) {
                $query->where('name', 'like', '%' . $searchTerm . '%');
            }
            $folders = $query->where('user_id',$user["userid"])->where('is_deleted',true)->get(); //get folder list by logged in user
            
            return ApiResponse::success($folders,'Here is recently deleted folders.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

        /**
    * Developer: Apptodate 
    * Comment: App side add/update notes
    */
    public function updateNote(Request $request)
    {
        try{
            $toEmail = env('CLIENT_EMAIL');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'title' => 'nullable',
                'is_pinned' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(isset($request->id)){
                $note = Note::where('user_id', $user["userid"])->where('_id', $request->id)->first();
                if(!$note){
                    return ApiResponse::error('Note not found!!');
                }
                $status = 'updated';
              //  $note->folder_id = !empty($request->folder_id) ?? $request->folder_id;
            }else{
                $note = new Note();
               // $note->folder_id = !empty($request->folder_id) ? $request->folder_id : null;
                $status = 'added';
            }
            if(!empty($request->folder_id)){
                $note->folder_id =  $request->folder_id;
            }else{
                $note->folder_id = 0;
            }
            $note->user_id = $user["userid"];
            $note->type = $request->type ?? "note";
            $note->title = $request->title ?? "";
            $note->description = $request->description ?? "";
            if(!empty($request->file_type)){
                $note->file_type = $request->file_type;
            }
            if($request->hasFile('file')){
                $file = $request->file('file');
                $filename = uniqid() . '.' . $file->getClientOriginalExtension();
				$path = env('AWS_NOTES_REPORTS_IMAGE_PATH');
				Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                $note->file = $filename;
                // $path = $request->file('file')->store('public/storage/notes');
                // $fileUploaded = Storage::url($path);
                
                $appUrl = env('AWS_S3_PATH');
                $notesPath = $appUrl.''.$path;
                $note->file = $notesPath.''.$filename;
            }
            $is_pinned = false;
            if(!empty($request->is_pinned)){
                if($request->is_pinned == "true"){
                    $is_pinned = true;
                }else if($request->is_pinned == "false"){
                    $is_pinned = false;
                }else{
                    $is_pinned = $request->is_pinned;
                }
            }
            $note->is_pinned = $is_pinned;
            $note->save();
            $folder = Folder::find($note->folder_id);
            $note->folder_name = $folder->name ?? "General";
            if($user->first_name != ""){
                if($user->last_name != ""){
                    $user_name = $user->first_name." ".$user->last_name ?? "";
                }else{
                    $user_name = $user->first_name ?? "";
                }
            }else{
                $user_name = $user->full_name ?? "";
            }
            
            $unit_name = "";
            $session_name = "";
            $object_name = "";
            if($note->type == "note"){
                $type = "Note";
            }else{
                $type = "Report";
                $object_id = $request->object_id ?? "";
                $session_id = $request->session_id ?? "";
                $unit_id = $request->unit_id ?? "";
               
                if($object_id != "" && $session_id != "" && $unit_id != ""){
                    $userObjectType = UserObjectType::find($object_id);
                    $session = Session::find($session_id);
                    $unit = Unit::find($unit_id);
                    $unit_name = $unit->unit_name ?? "";
                    $session_name = $session->session_name ?? "";
                    $object_name = $userObjectType->object_name ?? "";
                }
                $email = $user->email ?? "";
                Mail::to($toEmail)->send(new ReportToClientEmail($note, $email, $user_name, $unit_name, $session_name, $object_name));
            }
            return ApiResponse::success($note,$type.' '.$status.' successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updateUserReminder(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $defaultProgram = env('DEFAULT_PROGRAM');
            $request->validate([
                'skip' => 'required',
                'hour' => 'nullable',
                'min' => 'nullable',
                'time' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            $skip = true;
            if($request->skip == "true"){
                $skip = true;
            }else if($request->skip == "false"){
                $skip = false;
            }else{
                $skip = $request->skip;
            }
            $user->skip_reminder = $skip;
         
            if($skip === false){
                $user->hour = (int)$request->hour ?? "";
                $user->min = (int)$request->min ?? "";
                $user->time = $request->time ?? "";
            }else{
                $user->hour = "";
                $user->min = "";
                $user->time = "";
            }

            $user->save();
            $categoryType = CategoryType::where('name', 'LIKE', 'Train')->first();
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            if(!empty($user->group_id)){
                $group = Group::find($user->group_id);
                
                if($group){
                    $unitIds = array_column($group["group_object"], "object_id");
                    $unitCollectionData = Unit::whereIn('_id', $unitIds )->where('category_type_id', $categoryType["_id"])->get();
                    $unitCollectionData = $unitCollectionData->sortBy(function ($item) use ($unitIds) {
                        return array_search($item['_id'], $unitIds);
                    });
                }else{
                    $unitCollectionData = Unit::whereIn('_id', $default_unitIds )->where('category_type_id', $categoryType["_id"])->get();
                    $unitCollectionData = $unitCollectionData->sortBy(function ($item) use ($default_unitIds) {
                        return array_search($item['_id'], $default_unitIds);
                    });
                }
            }else{
                $unitCollectionData = Unit::whereIn('_id', $default_unitIds )->where('category_type_id', $categoryType["_id"])->get();
                $unitCollectionData = $unitCollectionData->sortBy(function ($item) use ($default_unitIds) {
                    return array_search($item['_id'], $default_unitIds);
                });
            }
            foreach ($unitCollectionData as $key => $unit) {
                $unit_id = $unit->_id; 
                $session_id = $unit->unit_object[0];
                break;
            }
            $user->unit_id = $unit_id ?? "";
            $user->session_id = $session_id['object_id'] ?? "";
 
            return ApiResponse::success($user,'Daily reminder time added successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function postTimezone(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $request->validate([
                'country_id' => 'nullable',
                'countryCode' => 'required',
                'timezone' => 'required'
            ]);
            
            $user->timezone = $request->timezone  ?? "";
            if($request->timezone != "" && $request->countryCode != ""){
                $country = Country::where('code',$request->countryCode)->where('timezone',$request->timezone)->first();
                if($country){
                    $user->country_id = $country->_id;
                }else{
                    $user->country_id = $request->country_id ?? "";
                }
            }else{
                $user->country_id = $request->country_id ?? "";
            }
            $user->save();
            return ApiResponse::success($user,'User Timezone details saved successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    

    /**
    * Developer: Apptodate 
    * Comment: App side delete notes
    */
    public function deleteNote($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Notes id required!!');
            }
            $notes = Note::find($id); //find note by passed id
            if($notes){
                $notes->delete(); //delete note
                return ApiResponse::successOnly('Note deleted successfully.');
            }else{
                return ApiResponse::error('Notes not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side list notes
    */
    public function getNote(Request $request,$folder_id = '')
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $notesPath = $appUrl.''.env('AWS_NOTES_REPORTS_IMAGE_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $searchTerm = $request->input('search'); //filter for name
            $query = Note::query(); 
            if($folder_id != "" && $folder_id != 0){ //list by folder 
                $query->where('folder_id', $folder_id);
            }
            $query->where('type', 'note');
            if (!empty($searchTerm)) { //filter in notes title and desc.
                $query->where(function ($q) use ($searchTerm) {
                    $q->where('title', 'like', '%' . $searchTerm . '%')->orWhere('description', 'like', '%' . $searchTerm . '%');
                });
            }
            $notes = $query->where('user_id',$user["userid"])->get(); //get notes list by logged in user
          
            foreach ($notes as $key => $note) {
                $note->folder_id = $note->folder_id ?? 0;
                $folder = Folder::find($note->folder_id);
                $note->folder_name = $folder->name ?? "General";
               $notes[$key]['file'] = $note->file != "" && !(Str::contains($note->file, 'storage/storage/')) ? $note->file : "";
               $notes[$key]['thumbnail'] = $appUrl.'thumbnail_old.png';
            }
            if($folder_id == 0){
                $notes = Functions::filterArrayByFieldArray($notes, 'General', 'folder_name');
            }
           
            return ApiResponse::success($notes,'Here is Notes list.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: App side after registertation process 
    */
    public function updateProfile(Request $request)
    {
        try{         
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if($user){

                $user->first_name = $request->input('first_name');
                $user->last_name =  $request->input('last_name');
                $user->full_name =  $request->input('first_name') . "" . ( $request->input('last_name')  ? " ".$request->input('last_name') :  "");

                $user->email =  $request->input('email') ?? "";
                $user->gender =     $request->input('gender');
                $user->birthday =   $request->input('birthday');
                $user->height =     $request->input('height');
                $user->weight =     $request->input('weight');
                $user->address =    $request->input('address');
                $user->country =    $request->input('country');
                $user->postal_code = $request->input('postal_code');
                $user->time_zone =  $request->input('time_zone');
                $user->timezone =  $request->input('timezone');
                if(!empty($request->input('country_id'))){
                    $user->country_id = $request->input('country_id');
                }
                $user->save();

                return ApiResponse::success($user,'User profile update successfuly');
            }else{
                return ApiResponse::error('User not found');
            }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }
    
    /**
    * Developer: Apptodate 
    * Comment: App side sotre profile picture 
    */
    public function updateProfilePicture(Request $request)
    {
        try{
            
            $request->validate([
                'picture' => 'required|image|mimes:jpeg,png,jpg,gif|max:20480',
            ]);

            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_PROFILE_PATH');
            $file = $request->file('picture');
            $filename = uniqid() . '_profile_pic.' . $file->getClientOriginalExtension();
            Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
            if($user){
                $user->profile_picture = $filename;
                $user->save();
                $imageAccessUrl =  $user->profile_picture != "" ? $appUrl."".$path."".$user->profile_picture :"";
                return ApiResponse::success($imageAccessUrl,'User profile update successfully');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }

    /**
    * Developer: Apptodate 
    * Comment: From user side getting password and confirm password and store into the DB
    */
    public function confirmPassword(Request $request)
    {
        try {

            $request->validate([
                'token' => 'required',
                'email' => 'required',
                'password' => 'required',
                'confirm_password' => 'required',
            ]);
            
            if($request->password != $request->confirm_password){
                return ApiResponse::error('Entered both password does not matched!!');
            }

            $user = User::where('email', $request->email)->first();
            if($user){
            
                $tokenData = DB::table('password_resets')
                                ->where('email', $request->email)
                                ->first();

                if (!$tokenData) {
                    return ApiResponse::error('Invalid token');
                }       
                $tokenExists = Password::broker()->tokenExists($user,$request->token);
                if(!$tokenExists){
                    return ApiResponse::error('Invalid token');
                }
                $user->password = bcrypt($request->input('password'));
                $user->save();
                

                $status = Password::broker()->reset(
                    $request->only('email', 'password', 'confirm_password', 'token'),
                    function ($user, $password) {
                        $user->forceFill([
                            'password' => Hash::make($password),
                            'remember_token' => Str::random(60),
                        ])->save();
            
                        event(new PasswordReset($user));
                    }
                );
            
                if ($status == Password::PASSWORD_RESET) {
                    return ApiResponse::successOnly('Password has been successfully reset.');
                }
                return ApiResponse::successOnly('Password changed successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }
    public function confirmPasswordApp(Request $request)
    {
        try {

            $request->validate([
                'user_id' => 'required',
                'password' => 'required',
                'confirm_password' => 'required',
            ]);
            
            if($request->password != $request->confirm_password){
                return ApiResponse::error('Entered both password does not matched!!');
            }

            $user = User::find($request->user_id);
            if($user){
            //     $tokenData = DB::table('password_resets')
            //                     ->where('token', Hash::make($request->token))
            //                     ->where('email', $request->email)
            //                     ->first();

            //     if (!$tokenData) {
            //         return ApiResponse::error('Invalid token');
            //     }

            //     // Check if token has expired
            //     $tokenAgeMinutes = Carbon::parse($tokenData->created_at)->diffInMinutes();
            //     if ($tokenAgeMinutes > 5) {
            //         return ApiResponse::error('reset password link has been expired');
            //        // return response()->json(['message' => 'Token has expired.'], 400);
            //     }

                $user->password = Hash::make($request->input('password'));
                $user->save();
                

                // $status = Password::broker()->reset(
                //     $request->only('email', 'password', 'confirm_password', 'token'),
                //     function ($user, $password) {
                //         $user->forceFill([
                //             'password' => Hash::make($password),
                //             'remember_token' => Str::random(60),
                //         ])->save();
            
                //         event(new PasswordReset($user));
                //     }
                // );
            
                // if ($status == Password::PASSWORD_RESET) {
                //     return ApiResponse::successOnly('Password has been successfully reset.');
                // }

                return ApiResponse::successOnly('Password changed successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }
    public function verifyPasswordApp(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required',
                'password' => 'required'
            ]);
            $user = User::find($request->user_id);
            if($user){
                if(Hash::check($request->password, $user->password)){
                    return ApiResponse::successOnly('Your password has been successfully verified.');
                }else{
                    return ApiResponse::error('Invalid Password!');
                }
            }else{
                return ApiResponse::error('User not found');
            }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        } 
    }

    /**
    * Developer: Apptodate 
    * Comment: From user side getting home intro screens
    */
    public function getImages()
    {
        try {
            $images = DisplayImages::select('image','type','text','subtext')->get()->groupBy('type');
            $displayImageURL = env('AWS_S3_PATH')."".env('AWS_DISPLAY_IMAGE_PATH');
            foreach ($images as $type => $group) {
                foreach ($group as $image) {
                    $image->image = $image->image != "" ? $displayImageURL . '' . $image->image : "";
                }
            }
            return ApiResponse::success($images);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function postImages(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if($user){
                if($request->id){
                    $displayImages = DisplayImages::find($request->id);
                }else{
                    $displayImages = new DisplayImages();
                    $request->validate([
                        'image' => 'required|image|mimes:jpeg,png,jpg|max:20480',
                        'type' => 'required',
                        'text' => 'required',
                        'subtext' => 'required'
                    ]);
                }
               
                if($request->hasFile('image')){
                    $file = $request->file('image');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
				    $path = env('AWS_DISPLAY_IMAGE_PATH');
				    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $displayImages->image = $filename;
                }
                if(!empty($request->type)){
                    $displayImages->type = $request->type;
                }
                if(!empty($request->text)){
                    $displayImages->text = $request->text ?? "";
                }
                if(!empty($request->subtext)){
                    $displayImages->subtext = $request->subtext ?? "";
                }
                $displayImages->save();
                return ApiResponse::success( $displayImages,'Display image uploaded successfully');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    } 

    public function updateImages(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required',
                'image' => 'required|image|mimes:jpeg,png,jpg|max:20480',
                'type' => 'required',
                'text' => 'required',
                'subtext' => 'required'
            ]);

            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);

            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if($user){
                $displayImages = DisplayImages::find($request->id);
                if($displayImages){
                    $file = $request->file('image');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->storeAs('display-images', $filename, 'public');
                    $imageAccessUrl = Storage::disk('public')->url('display-images/' . $filename);
                    $displayImages->image = $imageAccessUrl;
                    $displayImages->type = $request->type;
                    $displayImages->text = $request->text ?? "";
                    $displayImages->subtext = $request->subtext ?? "";
                    $displayImages->save();
                    return ApiResponse::success( $displayImages,'Display image uploaded successfuly');
                }else{
                    return ApiResponse::error('Disply image not found!!');
                }
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function deleteImages($id)
    {
        try {
            if(!$id){
                return ApiResponse::error('Display image id required!!');
            }
            $displayImages = DisplayImages::find($id);

            if($displayImages){
                $displayImages->delete();
                return ApiResponse::successOnly('Display image deleted successfully.');
            }else{
                return ApiResponse::error('Display image not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: App side while user after signin storing introduction question 
    */
    public function storeUserQuestionAnswer(Request $request)
    {
        try {
            // $country_id = $request->country_id ?? "";
            $collectData = $request->input('questions_data');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user = User::find($user['_id']);
            // $user->country_id = $country_id;
            // $user->save();
            foreach ($collectData as $key => $value) {
                $questionSet = Question::find($value["question_id"]);
                if (!$questionSet) {
                    return ApiResponse::error('Question not found!!');
                } 
                $userQuestion = new UserQuestionAnswer();
                $userQuestion->answer = $value["answer"];
                $userQuestion->user_id = $user["userid"];
                $userQuestion->question_id = $value["question_id"];

                $userQuestion->save();
            
            }
            return ApiResponse::successOnly('User question answer submit sucessfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getRecallCardsByUserOld($session_id="")
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_RECALL_CARD_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            //$recallCardUpdatedIds = UserRecallCardUpdate::where('user_id',$user['userid'])->pluck('recall_card_id')->toArray();
            //TODO: Add logic of showing recall after algorythm
            $userRecallCardsQ = UserRecallCards::where('user_id',$user['userid']);
            if($session_id != ""){
                $userRecallCardsQ = $userRecallCardsQ->where('session_id',$session_id);
            }
            $userRecallCards = $userRecallCardsQ->pluck('recall_card_id')->toArray();
            $tags = Tags::pluck('name','_id')->toArray();
            $recallCardsData = [];
            $userLevel =  $user->user_recall_card_level ?? 1; 
            if(!empty($userRecallCards)){
                $userRecallCardsQuery = RecallCard::whereIn('_id',$userRecallCards);
                // if(!empty($recallCardUpdatedIds)){
                //     $recallCards = $userRecallCardsQuery->whereNotIn('_id',$recallCardUpdatedIds)->get();
                // }else{
                    $recallCards = $userRecallCardsQuery->get();
                //}
                // if($session_id != ""){
                //     $recallCards = RecallCard::whereIn('_id',$userRecallCards)->get();
                // }else{
                //     $recallCards = RecallCard::get();
                // }
                foreach($recallCards as $key => $value){
                    $tagData = [];
                    if(!empty($value->tag)){
                        $recallCard_tag = explode(",",$value->tag);
                        if(!empty($recallCard_tag)){
                            foreach ($recallCard_tag as $keyy => $tag) {
                                $tagData[] = $tags[$tag] ?? "";
                            }
                        }
                    }
                    // Remove empty and null values
                    $filteredArray = array_filter($tagData, function ($value) {
                        return !empty($value);
                    });
                    $recallCardsData[$key]['_id'] = $value['_id'];
                    $recallCardsData[$key]['show'] = $value['show'] ?? true;
                    $recallCardsData[$key]['title'] = $value['title'];
                    $recallCardsData[$key]['question_text'] = $value['question_text'];
                    $recallCardsData[$key]['answer_text'] = $value['answer_text'];
                    $recallCardsData[$key]['question_img'] = $value['question_img'] != "" ? $appUrl."".$path."".$value['question_img']:"";
                    $recallCardsData[$key]['answer_img'] = $value['answer_img'] != "" ? $appUrl."".$path."".$value['answer_img']:"";
                    $recallCardsData[$key]['level'] = $value['level'];
                    $recallCardsData[$key]['updated_at'] = $value['updated_at'];
                    $recallCardsData[$key]['created_at'] = $value['created_at'];
                    $recallCardsData[$key]['tag'] =  $value['tag'] ?? null;
                    $recallCardsData[$key]['session_id'] = $session_id;  
                    $recallCardsData[$key]['tagName'] =  implode(",",$filteredArray);
                }    
            }
            $newRoot = [
                "recallCards" => $recallCardsData,
                "userLevel" => $userLevel
            ];
            return ApiResponse::success($newRoot,'Recall card list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getRecallCardsByUser($session_id="")
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_RECALL_CARD_PATH');
            $objectPath = env('AWS_OBJECT_IMAGES_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $tags = Tags::pluck('name','_id')->toArray();
        
            $recallCardsData = [];
            $userLevel =  $user->user_recall_card_level ?? 1;
            $recallCardData = RecallCard::where('show',true)->orderBy('order')->get();
            
            foreach ($recallCardData as $key => $value) {
                $tagData = [];
                if(!empty($value->tag)){
                    $recallCard_tag = explode(",",$value->tag);
                    if(!empty($recallCard_tag)){
                        foreach ($recallCard_tag as $keyy => $tag) {
                            $tagData[] = $tags[$tag] ?? "";
                        }
                    }
                }
                // Remove empty and null values
                $filteredArray = array_filter($tagData, function ($value) {
                    return !empty($value);
                });
                $recallCardsData[$key]['_id'] = $value['_id'];
                $recallCardsData[$key]['show'] = $value['show'] ?? true;
                $recallCardsData[$key]['title'] = $value['title'];
                $recallCardsData[$key]['question_text'] = $value['question_text'];
                $recallCardsData[$key]['answer_text'] = $value['answer_text'];
                $recallCardsData[$key]['learn_more_video'] = "";
                $recallCardsData[$key]['question_img'] = $value['question_img'] != "" ? $appUrl."".$path."".$value['question_img']:"";
                $recallCardsData[$key]['answer_img'] = $value['answer_img'] != "" ? $appUrl."".$path."".$value['answer_img']:"";
                $recallCardsData[$key]['level'] = $value['level'];
                $recallCardsData[$key]['updated_at'] = $value['updated_at'];
                $recallCardsData[$key]['created_at'] = $value['created_at'];
                $recallCardsData[$key]['tag'] =  $value['tag'] ?? null;
                $recallCardsData[$key]['order'] =  $value['order'] ?? 0;
                $recallCardsData[$key]['session_id'] =  "";  
                $recallCardsData[$key]['tagName'] =  implode(",",$filteredArray);
                $recallCardsData[$key]['link_items'] = $value['link_items'] ?? [];
                $recallCardsData[$key]['object_type'] =  "";
                $recallCardsData[$key]['object_name'] =  "";
                $recallCardsData[$key]['object_file'] =  "";
                $recallCardsData[$key]['object_video_id'] =  "";
                $recallCardsData[$key]['object_headline'] =  "";
                $recallCardsData[$key]['object_subtitle'] =  "";
                $recallCardsData[$key]['object_description'] =  "";
                // if($value['object_id'] != ""){
                //     $userObject = UserObjectType::find($value['object_id']);
                //     $objectType = ObjectType::find($userObject->object_type_id);
                //     $recallCardsData[$key]['object_type'] =  $objectType->name ?? "";
                //     $recallCardsData[$key]['object_name'] =  $userObject->object_name ?? "";
                //     $recallCardsData[$key]['object_file'] =  $userObject->file != '' && !(Str::contains($userObject["file"], 'storage/storage/')) ? $appUrl.''.$objectPath.''.$userObject->file : '';
                //     $recallCardsData[$key]['object_video_id'] = $userObject->video_id ?? "";
                //     $recallCardsData[$key]['object_headline'] = $userObject->headline ?? "";
                //     $recallCardsData[$key]['object_subtitle'] = $userObject->subtitle ?? "";
                //     $recallCardsData[$key]['object_description'] = $userObject->description ?? "";
                // }
            }
            $newRoot = [
                "recallCards" => $recallCardsData,
                "userLevel" => $userLevel
            ];
            return ApiResponse::success($newRoot,'Recall card list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getRecallCardsByUserOldd($session_id="")
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_RECALL_CARD_PATH');
            $objectPath = env('AWS_OBJECT_IMAGES_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $recallCardIds = RecallCard::where('show','!=',false)->pluck('_id')->toArray();
            //->where('due_date', '<=', now()->format('Y-m-d'))
            $userRecallCardsQ = UserRecallCards::whereIn('recall_card_id',$recallCardIds)->where('user_id',$user['userid']);
            if($session_id != ""){
                $userRecallCardsQ = $userRecallCardsQ->where('session_id',$session_id);
            }
            $userRecallCards = $userRecallCardsQ->get();

            $tags = Tags::pluck('name','_id')->toArray();
        
            $recallCardsData = [];
            $userLevel =  $user->user_recall_card_level ?? 1; 
            if(!empty($userRecallCards)){
                $recallCardData = RecallCard::get();
                foreach ($userRecallCards as $key => $userRecallCard) {
                    $value = $recallCardData->firstWhere('_id',$userRecallCard->recall_card_id);
                   
                    $tagData = [];
                    if(!empty($value->tag)){
                        $recallCard_tag = explode(",",$value->tag);
                        if(!empty($recallCard_tag)){
                            foreach ($recallCard_tag as $keyy => $tag) {
                                $tagData[] = $tags[$tag] ?? "";
                            }
                        }
                    }
                    // Remove empty and null values
                    $filteredArray = array_filter($tagData, function ($value) {
                        return !empty($value);
                    });

                    $recallCardsData[$key]['_id'] = $value['_id'];
                    $recallCardsData[$key]['show'] = $value['show'] ?? true;
                    $recallCardsData[$key]['title'] = $value['title'];
                    $recallCardsData[$key]['question_text'] = $value['question_text'];
                    $recallCardsData[$key]['answer_text'] = $value['answer_text'];
                    $recallCardsData[$key]['learn_more_video'] = "";
                    $recallCardsData[$key]['question_img'] = $value['question_img'] != "" ? $appUrl."".$path."".$value['question_img']:"";
                    $recallCardsData[$key]['answer_img'] = $value['answer_img'] != "" ? $appUrl."".$path."".$value['answer_img']:"";
                    $recallCardsData[$key]['level'] = $value['level'];
                    $recallCardsData[$key]['updated_at'] = $value['updated_at'];
                    $recallCardsData[$key]['created_at'] = $value['created_at'];
                    $recallCardsData[$key]['tag'] =  $value['tag'] ?? null;
                    $recallCardsData[$key]['order'] =  $value['order'] ?? 0;
                    $recallCardsData[$key]['session_id'] = $userRecallCard->session_id ?? "";  
                    $recallCardsData[$key]['tagName'] =  implode(",",$filteredArray);
                    $recallCardsData[$key]['link_items'] = $value['link_items'] ?? [];
                    $recallCardsData[$key]['object_type'] =  "";
                    $recallCardsData[$key]['object_name'] =  "";
                    $recallCardsData[$key]['object_file'] =  "";
                    $recallCardsData[$key]['object_video_id'] =  "";
                    $recallCardsData[$key]['object_headline'] =  "";
                    $recallCardsData[$key]['object_subtitle'] =  "";
                    $recallCardsData[$key]['object_description'] =  "";
                    // if($value['object_id'] != ""){
                    //     $userObject = UserObjectType::find($value['object_id']);
                    //     $objectType = ObjectType::find($userObject->object_type_id);
                    //     $recallCardsData[$key]['object_type'] =  $objectType->name ?? "";
                    //     $recallCardsData[$key]['object_name'] =  $userObject->object_name ?? "";
                    //     $recallCardsData[$key]['object_file'] =  $userObject->file != '' && !(Str::contains($userObject["file"], 'storage/storage/')) ? $appUrl.''.$objectPath.''.$userObject->file : '';
                    //     $recallCardsData[$key]['object_video_id'] = $userObject->video_id ?? "";
                    //     $recallCardsData[$key]['object_headline'] = $userObject->headline ?? "";
                    //     $recallCardsData[$key]['object_subtitle'] = $userObject->subtitle ?? "";
                    //     $recallCardsData[$key]['object_description'] = $userObject->description ?? "";
                    // }
                }
            }
            $newRoot = [
                "recallCards" => $recallCardsData,
                "userLevel" => $userLevel
            ];
            return ApiResponse::success($newRoot,'Recall card list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    
    public function storeUserRecallCardUpdate(Request $request)
    {
        try {
            $collectData = $request->all();
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            foreach ($collectData as $key => $value) {
                $recallCard = RecallCard::find($value["recall_card_id"]);
                if (!$recallCard) {
                    return ApiResponse::error('Recall Card not found!!');
                }
                $userRecallCardUpdate = UserRecallCardUpdate::where('user_id', $user["userid"])->where('recall_card_id', $value["recall_card_id"])->firstOrNew();
                $userRecallCardUpdate->answer = $value["answer"];
                $userRecallCardUpdate->user_id = $user["userid"];
                $userRecallCardUpdate->recall_card_id = $value["recall_card_id"];
                
                //recall card algorithm for answer as correct = >added interval as multiply by 2 from current interval and extended due date accordingly
                // if($value["answer"] != "false"){
                    
                // }
                $userRecallCardQ = UserRecallCards::where('user_id',$user["userid"])->where('recall_card_id', $value["recall_card_id"]);
                if(!empty($value["session_id"])){
                    $userRecallCardQ = $userRecallCardQ->where('session_id', $value["session_id"]);
                }
                $userRecallCard = $userRecallCardQ->get();
                if(!empty($userRecallCard)){
                    foreach ($userRecallCard as $card) {
                        $card->interval += 1;
                        $card->due_date = now()->addDays($card->interval)->format('Y-m-d');
                        $card->save();
                    }
                }
                // $levelNeedToAdd = $value["answer"] == "false" ? 0 : 1;
                $levelNeedToAdd = 1;
                $userCurrentLevel = $user->user_recall_card_level > 1 ? $user->user_recall_card_level : 1;
                $userRecallCardUpdate->user_level = $userCurrentLevel + $levelNeedToAdd;
                $userRecallCardUpdate->save();

                $user->user_recall_card_level = $userRecallCardUpdate->user_level;
                $user->last_recall_card_level_updated_date = date("d-m-Y H:i:s");
                $user->save();
            }
            //show weekly form code;
            $showWeeklyForm = 0;
            $countries = Country::pluck('timezone','_id')->toArray();
            $userDetail = User::find($user["_id"]);
            $userTimezone = $countries[$userDetail->country_id] ?? "";
            if($userTimezone != ""){
                if (Carbon::now($userTimezone)->isSunday()) {
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                    $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                    $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                        $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                        return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                    });
                    if($filteredWeeklyForms->count() == 0){
                        $showWeeklyForm = 1;
                    }
                }
            }
               
            $data = [
                "user_recall_card_level" =>  $user->user_recall_card_level, 
                "show_popup" => $value["answer"],
                "show_weekly_form" =>$showWeeklyForm
            ];
            return ApiResponse::success($data,'User recall card update submitted successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to add user's shot check
    */
    public function postUserShotCheck(Request $request)
    {
        try {
            $request->validate([
                'date' => 'required',
            ]);
            $collectData = $request->all();
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $shotChecks = $collectData['shot-checks'];
            
            // if($userShotChecks->count() > 0){
            //     return ApiResponse::error('You have already added shot checks for the day.');
            // }else{
                foreach ($shotChecks as $key => $value) {
                    $userShotChecks =  UserShotCheck::where('date',$collectData['date'])->where('user_id',$user['userid'])->where('shot_no',$value['shot_no'])->first();
          
                    if($userShotChecks){
                        if(!empty($collectData['location'])){
                            $userShotChecks->location = $collectData['location'] ?? "";
                        }
                        if(!empty($collectData['distance'])){
                            $userShotChecks->distance = $collectData['distance'] ?? "";
                        }
                        if(!empty($value['direction'])){
                            $userShotChecks->direction = $value['direction'] ?? "";
                        }
                        if(!empty($value['curve'])){
                            $userShotChecks->curve = $value['curve'] ?? "";
                        }
                        if(!empty($value['face'])){
                            $userShotChecks->face = $value['face'] ?? "";
                        }
                        if(!empty($value['contact'])){
                            $userShotChecks->contact = $value['contact'] ?? "";
                        }
                        $userShotChecks->save();
                    }else{
                        $shotCheck = new UserShotCheck();
                        $shotCheck->shot_no = $value['shot_no'] ?? $key;
                        $shotCheck->date = $collectData['date'] ?? "";
                        $shotCheck->location = $collectData['location'] ?? "";
                        $shotCheck->distance = $collectData['distance'] ?? "";
                        $shotCheck->user_id = $user['userid'];
                        $shotCheck->direction = $value['direction'];
                        $shotCheck->curve = $value['curve'];
                        $shotCheck->contact = $value['contact'];
                        $shotCheck->face = $value['face'];
                        $shotCheck->save();
                    }
                }
                //show weekly form code;
                $showWeeklyForm = 0;
                $countries = Country::pluck('timezone','_id')->toArray();
                $userDetail = User::find($user["_id"]);
                $userTimezone = $countries[$userDetail->country_id] ?? "";
                if($userTimezone != ""){
                    if (Carbon::now($userTimezone)->isSunday()) {
                        $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                        $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                        $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                            $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                            return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                        });
                        if($filteredWeeklyForms->count() == 0){
                            $showWeeklyForm = 1;
                        }
                    }
                }
                
                $data = [
                    'show_weekly_form' =>$showWeeklyForm
                ];
                return ApiResponse::success($data,'User shot check update submitted successfully');
            // }
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to add marked trust holes
    */
    public function postUserTrustHole(Request $request)
    {
        try {
            $request->validate([
                'date' => 'required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $collectData = $request->all();
            $collectTrustData = $request->trust_hole;
            // if(!empty($collectData['trust_hole_no']) && !empty($collectData['hole_type'])){
            if(!empty($request->trust_hole)){
                foreach ($collectTrustData as $key => $trustData) {
         
                    $shortCheck = UserTrustHole::where('trust_hole_no',$collectData['trust_hole_no'])->where('hole_type',$trustData['hole_type'])
                                    ->where('user_id',$user['userid'])->where('date',$collectData['date'])->first();
                    
                    if($shortCheck){
                        $shortCheck->direction = $trustData['direction'];
                        $shortCheck->curve = $trustData['curve'];
                        $shortCheck->contact = $trustData['contact'];
                        $shortCheck->face = $trustData['face'];
                        $shortCheck->alignment = $trustData['alignment'];
                        $shortCheck->distance = $trustData['distance'];
                        if(!empty($collectData['trust_key_percent'])){
                            $shortCheck->trust_key_percent = $collectData['trust_key_percent'];
                        }
                        if(!empty($collectData['pre_shot_percent'])){
                            $shortCheck->pre_shot_percent = $collectData['pre_shot_percent'];
                        }
                        if(!empty($collectData['post_shot_percent'])){
                            $shortCheck->post_shot_percent = $collectData['post_shot_percent'];
                        }
                        $shortCheck->save();
                       // return ApiResponse::successOnly('You have already added Trust hole '.$collectData['trust_hole_no'].' for '.$trustData['hole_type'].' for today.');
                    }else{
                        $shotCheck = new UserTrustHole();
                        $shotCheck->trust_key = "3798473284932"; //TODO: It will be dynamic later
                        $shotCheck->trust_hole_no = $collectData['trust_hole_no'] ;
                      
                        $shotCheck->hole_type = $trustData['hole_type'];
                        $shotCheck->date = $collectData['date'];
                        $shotCheck->location = $collectData['location'] ?? "";
                        $shotCheck->temperature = $collectData['temperature'] ?? "";
                        $shotCheck->warm_up_time = $collectData['warm_up_time'] ?? "";
                        $shotCheck->user_id = $user['userid']; 
                        $shotCheck->direction = $trustData['direction'] ?? "";
                        $shotCheck->curve = $trustData['curve'] ?? "";
                        $shotCheck->contact = $trustData['contact'] ?? "";
                        $shotCheck->face = $trustData['face'] ?? "";
                        $shotCheck->alignment = $trustData['alignment'] ?? "";
                        $shotCheck->distance = $trustData['distance'] ?? "";
                        if(!empty($collectData['trust_key_percent'])){
                            $shotCheck->trust_key_percent = $collectData['trust_key_percent'];
                        }
                        if(!empty($collectData['pre_shot_percent'])){
                            $shotCheck->pre_shot_percent = $collectData['pre_shot_percent'];
                        }
                        if(!empty($collectData['post_shot_percent'])){
                            $shotCheck->post_shot_percent = $collectData['post_shot_percent'];
                        }
                        $shotCheck->save();
                       
                    }
                }
            }else{
                $shortCheck = UserTrustHole::where('user_id',$user['userid'])->where('date',$collectData['date'])->whereNotNull('trust_key_percent')->first();
                    
                if($shortCheck){
                    if(!empty($collectData['trust_key_percent']) || $collectData['trust_key_percent'] >= 0){
                        $shortCheck->trust_key_percent = $collectData['trust_key_percent'];
                    }
                    if(!empty($collectData['pre_shot_percent']) || $collectData['pre_shot_percent'] >= 0){
                        $shortCheck->pre_shot_percent = $collectData['pre_shot_percent'];
                    }
                    if(!empty($collectData['post_shot_percent']) || $collectData['post_shot_percent'] >= 0){
                        $shortCheck->post_shot_percent = $collectData['post_shot_percent'];
                    }
                    $shortCheck->date = $collectData['date'];
                    $shortCheck->save();
                }else{
                    if(!empty($collectData['trust_key_percent']) || $collectData['trust_key_percent'] >= 0){  
                        $shotCheck = new UserTrustHole();
                        $shotCheck->trust_key = "3798473284932"; //TODO: It will be dynamic later
                        $shotCheck->date = $collectData['date'];
                        $shotCheck->location = $collectData['location'] ?? "";
                        $shotCheck->temperature = $collectData['temperature'] ?? "";
                        $shotCheck->warm_up_time = $collectData['warm_up_time'] ?? "";
                        $shotCheck->user_id = $user['userid'];
                        if(!empty($collectData['trust_key_percent']) || $collectData['trust_key_percent'] >= 0){
                            $shotCheck->trust_key_percent = $collectData['trust_key_percent'];
                        }
                        if(!empty($collectData['pre_shot_percent']) || $collectData['pre_shot_percent'] >= 0){
                            $shotCheck->pre_shot_percent = $collectData['pre_shot_percent'];
                        }
                        if(!empty($collectData['post_shot_percent']) || $collectData['post_shot_percent'] >= 0){
                            $shotCheck->post_shot_percent = $collectData['post_shot_percent'];
                        }
                        $shotCheck->save();
                    }else{
                        return ApiResponse::error('Please provide trust key execution data');
                    }
                }
            }
            
            //show weekly form code;
            $showWeeklyForm = 0;
            $countries = Country::pluck('timezone','_id')->toArray();
            $userDetail = User::find($user["_id"]);
             //streak code added
            $training_streak = $userDetail->training_streak ?? 0;
            $max_training_streak = $userDetail->max_training_streak ?? ($userDetail->training_streak ?? 0);
            $mulligan = $user->mulligan ?? 0;
            $today = now()->format('Y-m-d');
            if(empty($userDetail->last_updated_training_streak ) || $userDetail->last_updated_training_streak == "" || $userDetail->last_updated_training_streak == null){
                $training_streak = 1;
                $max_training_streak = 1;
            }else{
                $lastDate = $userDetail->last_updated_training_streak;
          
                if($today != $lastDate || $userDetail->training_streak == 0){
                    $last_updated_training_streak = new DateTime($lastDate);
                    $current_date = new DateTime($today);
                    $interval = $current_date->diff($last_updated_training_streak);
                    $max_training_streak = $userDetail->max_training_streak ?? 1;
                    $yesterday = $current_date->modify('-1 day')->format('Y-m-d');
                    
                    //check if last_updated date of training is not yesterday
                    if((int)$interval->format('%R%a') == 0 && $userDetail->training_streak == 0){
                        $training_streak = $training_streak + 1;
                        $mulligan = 0;
                    }else if((int)$interval->format('%R%a') < -1){
                        $findMulligan = UserTrainingStreak::where('date',$yesterday)->where('mulligan',1)->where('user_id',$user->userid)->first();
                        if($findMulligan){
                            $training_streak = $training_streak + 1;
                            $mulligan = 0;
                        }else{
                            $training_streak = 1;
                        }
                            //check if last_updated date of training is  yesterday
                    }else if((int)$interval->format('%R%a') == -1){
                        $training_streak = $training_streak + 1;
                    }else{
                        $training_streak = $user->training_streak;
                        $today = $userDetail->last_updated_training_streak;
                    }
                }else{
                    $training_streak = $user->training_streak;
                    $today = $userDetail->last_updated_training_streak;
                }
                
            }
            $userDetail->training_streak = $training_streak;
            if($training_streak > $max_training_streak){
                $userDetail->max_training_streak = $training_streak;
            }
            $userDetail->last_updated_training_streak = $today;
            $userDetail->mulligan = 0;
            $userDetail->save();
            $userTrainingStreak = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$today)->first();
            if($userTrainingStreak){
                if($userTrainingStreak->current_streak == 0){
                    $userTrainingStreak->current_streak = $userDetail->training_streak ?? 1;
                    $userTrainingStreak->mulligan = 0;
                    $userTrainingStreak->save();
                }
            }else{
                $userTrainingStreak = new UserTrainingStreak();
                $userTrainingStreak->user_id = $user['userid'];
                $userTrainingStreak->date = $today;
                $userTrainingStreak->current_streak = $userDetail->training_streak ?? 1;
                $userTrainingStreak->mulligan = 0;
                $userTrainingStreak->save();
            }
            //streak code added

            $userTimezone = $countries[$userDetail->country_id] ?? "";
            if($userTimezone != ""){
                if (Carbon::now($userTimezone)->isSunday()) {
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                    $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                    $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                        $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                        return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                    });
                    if($filteredWeeklyForms->count() == 0){
                        $showWeeklyForm = 1;
                    }
                }
            }
            
            $data = [
                'show_weekly_form' =>$showWeeklyForm
            ];
            return ApiResponse::success($data,'User trust hole detail added successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to erase marked trust holes
    */
    public function eraseUserTrustHole(Request $request)
    {
        try {
            $request->validate([
                'date' => 'required',
                'erase_all' => 'required',
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $collectData = $request->all();
            if($collectData['erase_all'] == 1){
                UserTrustHole::where('date',$collectData['date'])->where('user_id',$user['userid'])->delete();
            }else{
                if(!empty($collectData['trust_hole_no'])){
                    UserTrustHole::where('date',$collectData['date'])->where('user_id',$user['userid'])->where('trust_hole_no',$collectData['trust_hole_no'])->delete();
                }
            }
            return ApiResponse::successOnly('Trust hole erased successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to erase marked shot checks
    */
    public function eraseUserShotCheck(Request $request)
    {
        try {
            $request->validate([
                'date' => 'required|date_format:d-m-Y',
                'erase_all' => 'required',
                'trust_hole_no' => 'required_if:erase_all,0'
            ],[
                'trust_hole_no.required_if' => 'shot check number is required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $collectData = $request->all();
            
            $query = UserShotCheck::where('date', $collectData['date'])
                                  ->where('user_id', $user['userid']);

            if ($collectData['erase_all'] == 1) {
                if (!$query->exists()) {
                    return ApiResponse::error('No records found for the specified date');
                }
                $query->delete();
            } 
            else {
                $query->where('shot_no', $collectData['trust_hole_no']);
                
                if (!$query->exists()) {
                    return ApiResponse::error('No records found for the specified date and slot number');
                }
                $query->delete();
            }
            return ApiResponse::successOnly('Shot Check erased successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function eraseUserShotCheckOld(Request $request)
    {
        try {
            $request->validate([
                'date' => 'required',
                'erase_all' => 'required',
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $collectData = $request->all();
            if($collectData['erase_all'] == 1){
                UserShotCheck::where('date',$collectData['date'])->where('user_id',$user['userid'])->delete();
            }else{
                if(!empty($collectData['shot_no'])){
                    UserShotCheck::where('date',$collectData['date'])->where('user_id',$user['userid'])->delete();
                }
            }
            return ApiResponse::successOnly('Shot Check erased successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment:  get shot check list for app user
    */
    public function getUserShotCheck(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $shotChecksQ = UserShotCheck::query();
            if($request->date != ""){
                $shotChecksQ = $shotChecksQ->where('date',$request->date);
            }
            if($request->location != ""){
                $shotChecksQ = $shotChecksQ->where('location',$request->location);
            }
            $shotChecks = $shotChecksQ->where('user_id',$user['userid'])->get();
            return ApiResponse::success($shotChecks,'User shot check found successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment:  get shot check history for app user
    */
    public function getUserShotCheckHistory(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $shotCheckDates = UserShotCheck::where('user_id',$user['userid'])->groupBy('date')->orderBy('date','desc')->pluck('date')->toArray();
            //show weekly form code;
            $showWeeklyForm = 0;
            $countries = Country::pluck('timezone','_id')->toArray();
          
            $userDetail = User::find($user["_id"]);
  
            $userTimezone = $countries[$userDetail->country_id] ?? "";
            if($userTimezone != ""){
                if (Carbon::now($userTimezone)->isSunday()) {
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                    $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                    $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                        $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                        return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                    });
                    if($filteredWeeklyForms->count() == 0){
                        $showWeeklyForm = 1;
                    }
                }
            }
            
            foreach ($shotCheckDates as $currentDate) {
                $shotChecks = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->get();
                $shotCheckCount = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->count();
                $newRoot[] = [
                    'date' => $currentDate,
                    'shot_check_count' => $shotCheckCount,
                    'shot_checks' => $shotChecks,
                    'show_weekly_form' => $showWeeklyForm
                ];
            }
            
            return ApiResponse::success($newRoot,'User Shot Check history fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to find marked trust holes
    */
    public function getUserTrustHole(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($request->date != ""){
                $currentDate = $request->date;
            }else{
                $currentDate = date("d-m-Y");
            }
          
            $shotCheckDrives = UserTrustHole::where('date',$currentDate)->where('hole_type','Drive')->where('user_id',$user['userid'])->get();
            $shotCheckApproach = UserTrustHole::where('date',$currentDate)->where('hole_type','Approach')->where('user_id',$user['userid'])->get();
            $trustHoleDataArray = [];
            for ($i=1; $i <=18 ; $i++) { 
               $is_drive_data =  $shotCheckDrives->firstWhere('trust_hole_no', $i);
               $is_approach_data = $shotCheckApproach->firstWhere('trust_hole_no', $i);
               $trustHoleData['trust_hole_no'] = $i;
               $trustHoleData['drive'] = ($is_drive_data) ? true : false;
               $trustHoleData['approach'] = ($is_approach_data) ? true : false;
               array_push($trustHoleDataArray,$trustHoleData);
            }
            $trustHoleDetails = UserTrustHole::where('date',$currentDate)->where('user_id',$user['userid'])->where('trust_key_percent','!=',NULL)->first();
            $newRoot = [
                'trustHoles' => $trustHoleDataArray,
                'trust_key_percent' => $trustHoleDetails->trust_key_percent ?? 0,
                'pre_shot_percent' => $trustHoleDetails->pre_shot_percent ?? 0,
                'post_shot_percent' => $trustHoleDetails->post_shot_percent ?? 0
            ];
            return ApiResponse::success($newRoot,'User Trust holes marked detail is as given here for today.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to find marked trust holes history By date for icon and list
    */
    public function getUserTrustHoleHistory(Request $request,$type = 'icon')
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $shotCheckDatesQ= UserTrustHole::where('user_id',$user['userid'])->where('trust_hole_no','!=',NULL);
            if(!empty($request->date)){
                $shotCheckDatesQ = $shotCheckDatesQ->where('date',$request->date);
            }
            $shotCheckDates = $shotCheckDatesQ->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
            $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
            })->values()->all();
            foreach ($sortedDates as $currentDate) {
                $shotCheckDrives = UserTrustHole::where('date',$currentDate)->where('hole_type','Drive')->where('user_id',$user['userid'])->get();
                $shotCheckApproach = UserTrustHole::where('date',$currentDate)->where('hole_type','Approach')->where('user_id',$user['userid'])->get();
                
                $trustHoleDataArray = [];
                for ($i=1; $i <=18 ; $i++) { 
                    $is_drive_data =  $shotCheckDrives->firstWhere('trust_hole_no', $i);
                    $is_approach_data = $shotCheckApproach->firstWhere('trust_hole_no', $i);
                    
                    if($type == 'icon'){
                        $trustHoleData['trust_hole_no'] = $i;
                        if($is_drive_data){
                            if($is_drive_data['direction'] == "" && $is_drive_data['curve'] == "" && $is_drive_data['contact'] == "" && $is_drive_data['face'] == "" && $is_drive_data['alignment'] == "" && $is_drive_data['distance'] == ""){
                                $trustHoleData['drive'] = false;
                            }else{
                                $trustHoleData['drive'] = ($is_drive_data) ? true : false;
                            }
                        }else{
                            $trustHoleData['drive'] = false;
                        }
                        if($is_approach_data){
                            if($is_approach_data['direction'] == "" && $is_approach_data['curve'] == "" && $is_approach_data['contact'] == "" && $is_approach_data['face'] == "" && $is_approach_data['alignment'] == "" && $is_approach_data['distance'] == ""){
                                $trustHoleData['approach'] = false;
                            }else{
                                $trustHoleData['approach'] = ($is_approach_data) ? true : false;
                            }
                        }else{
                            $trustHoleData['approach'] = false;
                        }
                        array_push($trustHoleDataArray,$trustHoleData);
                    }else{
                        if(($is_drive_data) || ($is_approach_data)){
                            $trustHoleData['trust_hole_no'] = $i;
                            $trustHoleData['drive'] = [
                                'direction' => $is_drive_data->direction ?? "",
                                'curve' => $is_drive_data->curve ?? "",
                                'contact' => $is_drive_data->contact ?? "",
                                'face' => $is_drive_data->face ?? "",
                                'alignment' => $is_drive_data->alignment ?? "",
                                'distance' => $is_drive_data->distance ?? "",
                            ];
                            $trustHoleData['approach'] = [
                                'direction' => $is_approach_data->direction ?? "",
                                'curve' => $is_approach_data->curve ?? "",
                                'contact' => $is_approach_data->contact ?? "",
                                'face' => $is_approach_data->face ?? "",
                                'alignment' => $is_approach_data->alignment ?? "",
                                'distance' => $is_approach_data->distance ?? "",
                            ];
                            array_push($trustHoleDataArray,$trustHoleData);
                        }
                        
                    }
                    
                }
                $trustHoleMarkedDetails = 0;
                $trustHoleMarkedDetails = UserTrustHole::where('date', $currentDate)
                ->where('user_id', $user['userid'])
                ->whereNotNull('trust_hole_no')
                ->whereNotNull('hole_type')
                ->pluck('trust_hole_no')
                ->unique()->count();

                // ->groupBy('trust_hole_no')->count();
               
                $trustHoleDetails = UserTrustHole::where('date',$currentDate)->where('user_id',$user['userid'])->where('trust_key_percent','!=',NULL)->first();
                $newRoot[] = [
                    'date' => $currentDate,
                    'trust_hole_marked_count' => $trustHoleMarkedDetails,
                    'trustHoles' => $trustHoleDataArray,
                    'trust_key_percent' => $trustHoleDetails->trust_key_percent ?? 0,
                    'pre_shot_percent' => $trustHoleDetails->pre_shot_percent ?? 0,
                    'post_shot_percent' => $trustHoleDetails->post_shot_percent ?? 0
                ];
            }
            
            return ApiResponse::success($newRoot,'User Trust holes marked history fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to find user's total trust reps
    */
    public function getUserTrustRepsSummary()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $trust_reps = 0;
            $old_trust_reps = 0;
            $trust_shots = 0;
            // $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->where('trust_hole_no','!=',NULL)->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
            $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
            $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
            })->values()->all();
            $totalDate = sizeof($sortedDates);
            if( $totalDate > 0){
                $trust_reps = $totalDate * 40;
                $toDate = now()->format('d-m-Y');
                if (in_array($toDate, $sortedDates)) {
                    $old_trust_reps = $trust_reps - 40;
                }else{
                    $old_trust_reps = $trust_reps;
                }
            }

            $trust_shot_data = UserTrustHole::select('trust_hole_no','date')
            ->where('user_id', $user["userid"])
            ->whereNotNull('trust_hole_no')
            ->groupBy('trust_hole_no','date')
            ->havingRaw('COUNT(DISTINCT hole_type) = 1')
            ->whereIn('hole_type', ['Drive', 'Approach'])
            ->get();
            if(!empty($trust_shot_data)){
                $trust_shots = $trust_shot_data->count();
            }else{
                $trust_shots = 0;
            }
            $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Trust Shots')
                ->get();
            $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
            $reps['old_trust_reps'] = $old_trust_reps + $total_manual_reps_trust ?? 0;
            $reps['trust_reps'] = $trust_reps + $total_manual_reps_trust?? 0;
            $reps['trust_shots'] = $trust_shots ?? 0;
            //show weekly form code;
            $showWeeklyForm = 0;
            $countries = Country::pluck('timezone','_id')->toArray();
            $userDetail = User::find($user["_id"]);
            $userTimezone = $countries[$userDetail->country_id] ?? "";
            if($userTimezone  != ""){
                if (Carbon::now($userTimezone)->isSunday()) {
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                    $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                    $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                        $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                        return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                    });
                    if($filteredWeeklyForms->count() == 0){
                        $showWeeklyForm = 1;
                    }
                }
            }
            
            $newRoot = [
                'reps' => $reps,
                'show_weekly_form' => $showWeeklyForm
            ];
            return ApiResponse::success($newRoot,'User Trust holes summary fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getUserRepsSummary()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $reps = [];
            $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
            $docs = UserMovementDrill::where('user_id', $user['_id'])->get();
            $totalReps = 0;
            foreach ($docs as $doc) {
                $totalReps += (int) $doc['reps'];
            }
            $userMovementDrillCount = $totalReps;
            $trust_reps = 0;
            $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
            $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
            })->values()->all();
            $totalDate = sizeof($sortedDates);
            if( $totalDate > 0){
                $trust_reps = $totalDate * 40;
            }
            $swings = Swing::where('user_id',$user["_id"])->count();
            $manual_reps_recall_card = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Recall Cards')
                ->get();
            $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
            $manual_reps_movement_drills = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Move Drills')
                ->get();
            $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
            $manual_reps_swing_drills = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Swing Drills')
                ->get();    
            $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
            $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Trust Shots')
                ->get();
            $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
            $recap_reps_all = SessionRecapTime::where('user_id', $user['_id'])->get();
            $all_totalRecapReps = 0;
            if($recap_reps_all->count() > 0){
                foreach ($recap_reps_all as $recap_reps_a) {
                    $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                }
            }
            $reps['move_drills'] =  $userMovementDrillCount +  $total_manual_reps_movement_drills ?? 0;
            $reps['trust_reps'] = $trust_reps +  $total_manual_reps_trust ?? 0;
            $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills ?? 0;
            $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card + $all_totalRecapReps ?? 0;
            $newRoot = [
                'reps' => $reps
            ];
            return ApiResponse::success($newRoot,'User Trust holes summary fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function postManualUserReps(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $validatedData = $request->validate([
                'reps_type' => 'required',
                'reps' => 'required'
            ]);
         
            $manual_reps = new UserManualReps();
            $manual_reps->reps_type = $validatedData['reps_type'];
            $manual_reps->reps =  $validatedData['reps'];
            $manual_reps->tag_id = $request->tag_id ?? "";
            $manual_reps->user_id = $user["_id"];
            $manual_reps->save();
            return ApiResponse::successOnly('Extra Reps added successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to find marked trust holes graph By date 
    */
    public function getUserTrustHoleGraph($type ='all')
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $trustHoleDataArray = [];
            $userTrustHoles = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
            $sortedDates = collect($userTrustHoles)->sortBy(function ($date) {
                return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
            })->values()->all();
            foreach ($sortedDates as $currentDate) {
                $trustHoleDetails = UserTrustHole::where('date',$currentDate)->where('user_id',$user['userid'])->where('trust_key_percent','!=',NULL)->first();
                if($trustHoleDetails){
                    if( $trustHoleDetails->trust_key_percent != 0 ||  $trustHoleDetails->pre_shot_percent != 0 || $trustHoleDetails->post_shot_percent != 0){
                        if($type == 'trust_key'){
                            $trustHoleData['trust_key_percent'] = $trustHoleDetails->trust_key_percent ?? 0;
                            $trustHoleData['pre_shot_percent'] = 0;
                            $trustHoleData['post_shot_percent'] = 0;
                        }else if($type == 'pre_shot'){
                            $trustHoleData['trust_key_percent'] = 0;
                            $trustHoleData['pre_shot_percent'] = $trustHoleDetails->pre_shot_percent ?? 0;
                            $trustHoleData['post_shot_percent'] = 0;
                        }else if($type == 'post_shot'){
                            $trustHoleData['trust_key_percent'] = 0;
                            $trustHoleData['pre_shot_percent'] = 0;
                            $trustHoleData['post_shot_percent'] = $trustHoleDetails->post_shot_percent ?? 0;
                        }else{
                            $trustHoleData['trust_key_percent'] = $trustHoleDetails->trust_key_percent ?? 0;
                            $trustHoleData['pre_shot_percent'] = $trustHoleDetails->pre_shot_percent ?? 0;
                            $trustHoleData['post_shot_percent'] = $trustHoleDetails->post_shot_percent ?? 0;
                        }
                        $newRoot[] = [
                            'date' => $currentDate,
                            'trustHoles' => $trustHoleData
                        ];
                    }
                }
                
                
                // array_push($trustHoleDataArray,$trustHoleData);
                
            }
            
            return ApiResponse::success($newRoot,'User Trust holes graph fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to find marked trust holes graph By date 
    */
    public function getUserShotCheckGraph($type ='direction',Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            $today = now()->format('d-m-Y');
            if($type == 'direction'){
                $shotCheckDetail1 = UserShotCheck::where('date',$today)->where('user_id',$user['userid'])->where('direction','!=',NULL)->where('direction','!=',"")->get();
                $shotCheckData1['Left'] = $shotCheckDetail1->where('direction','Left')->count() ?? 0;
                $shotCheckData1['Straight'] = $shotCheckDetail1->where('direction','Straight')->count() ?? 0;
                $shotCheckData1['Right'] = $shotCheckDetail1->where('direction','Right')->count() ?? 0;
            }else if($type == 'curve'){
                $shotCheckDetail1 = UserShotCheck::where('date',$today)->where('user_id',$user['userid'])->where('curve','!=',NULL)->where('curve','!=',"")->get();
                $shotCheckData1['To Left'] = $shotCheckDetail1->where('curve','To Left')->count() ?? 0;
                $shotCheckData1['No Curve'] = $shotCheckDetail1->where('curve','No Curve')->count() ?? 0;
                $shotCheckData1['To Right'] = $shotCheckDetail1->where('curve','To Right')->count() ?? 0;
            }else if($type == 'contact'){
                $shotCheckDetail1 = UserShotCheck::where('date',$today)->where('user_id',$user['userid'])->where('contact','!=',NULL)->where('contact','!=',"")->get();
                $shotCheckData1['Fat'] = $shotCheckDetail1->where('contact','Fat')->count() ?? 0;
                $shotCheckData1['Solid'] = $shotCheckDetail1->where('contact','Solid')->count() ?? 0;
                $shotCheckData1['Thin'] = $shotCheckDetail1->where('contact','Thin')->count() ?? 0;
            }else if($type == 'face'){
                $shotCheckDetail1 = UserShotCheck::where('date',$today)->where('user_id',$user['userid'])->where('face','!=',NULL)->where('face','!=',"")->get();
                $shotCheckData1['Heel'] = $shotCheckDetail1->where('face','Heel')->count() ?? 0;
                $shotCheckData1['Center'] = $shotCheckDetail1->where('face','Center')->count() ?? 0;
                $shotCheckData1['Toe'] =  $shotCheckDetail1->where('face','Toe')->count() ?? 0;
            }else{
                $shotCheckDetail1 = UserShotCheck::where('date',$today)->where('user_id',$user['userid'])->where('distance','!=',NULL)->where('distance','!=',"")->get();
                $shotCheckData1['Shorter than expected'] = $shotCheckDetail1->where('distance','Shorter than expected')->count() ?? 0;
                $shotCheckData1['As expected'] =  $shotCheckDetail1->where('distance','As expected')->count() ?? 0;
                $shotCheckData1['Longer than expected'] =  $shotCheckDetail1->where('distance','Longer than expected')->count() ?? 0;
            }

            if($request->type == "month"){
                $graph = "month";
                $userShotChecks = UserShotCheck::where('user_id',$user['userid'])->groupBy('date')->pluck('date')->toArray();
                $uniqueMonths = array_unique(array_map(function($date) {
                    return date("m", strtotime($date));
                }, $userShotChecks));
                
                $uniqueMonths = array_values($uniqueMonths); // Re-index the array if needed
                $newRoot[] = [
                    'graph' => $graph,
                    'check' => "Today",
                    'shotCheck' => $shotCheckData1
                ];
                foreach ($uniqueMonths as $uniqueMonth) {
                    if($type == 'direction'){
                        $shotCheckDetail = UserShotCheck::where('user_id', $user['userid'])
                            ->where('direction', '!=', NULL)
                            ->where('direction', '!=', "")
                            ->get();
                        $filteredRecords = collect($shotCheckDetail)->filter(function ($record) use ($uniqueMonth) {
                            $recordMonth = date('m', strtotime($record->date));
                            return $recordMonth === $uniqueMonth;
                        });
                        $shotCheckData = [
                            'Left' => $filteredRecords->where('direction', 'Left')->count() ?? 0,
                            'Straight' => $filteredRecords->where('direction', 'Straight')->count() ?? 0,
                            'Right' => $filteredRecords->where('direction', 'Right')->count() ?? 0,
                        ];
                        
                    }else if($type == 'curve'){
                        $shotCheckDetail = UserShotCheck::where('user_id', $user['userid'])
                            ->where('curve', '!=', NULL)
                            ->where('curve', '!=', "")
                            ->get();
                        $filteredRecords = collect($shotCheckDetail)->filter(function ($record) use ($uniqueMonth) {
                            $recordMonth = date('m', strtotime($record->date));
                            return $recordMonth === $uniqueMonth;
                        });
                        $shotCheckData = [
                            'To Left' => $filteredRecords->where('curve', 'To Left')->count() ?? 0,
                            'No Curve' => $filteredRecords->where('curve', 'No Curve')->count() ?? 0,
                            'To Right' => $filteredRecords->where('curve', 'To Right')->count() ?? 0,
                        ];
                    }else if($type == 'contact'){
                        $shotCheckDetail = $shotCheckDetail = UserShotCheck::where('user_id', $user['userid'])->where('contact', '!=', NULL)->where('contact', '!=', "")->get();
                        $filteredRecords = collect($shotCheckDetail)->filter(function ($record) use ($uniqueMonth) {
                            $recordMonth = date('m', strtotime($record->date));
                            return $recordMonth === $uniqueMonth;
                        });
                        $shotCheckData['Fat'] = $filteredRecords->where('contact','Fat')->count() ?? 0;
                        $shotCheckData['Solid'] = $filteredRecords->where('contact','Solid')->count() ?? 0;
                        $shotCheckData['Thin'] = $filteredRecords->where('contact','Thin')->count() ?? 0;
                        
                    }else if($type == 'face'){
                        $shotCheckDetail = UserShotCheck::where('user_id', $user['userid'])
                            ->where('face', '!=', NULL)
                            ->where('face', '!=', "")
                            ->get();
                        $filteredRecords = collect($shotCheckDetail)->filter(function ($record) use ($uniqueMonth) {
                            $recordMonth = date('m', strtotime($record->date));
                            return $recordMonth === $uniqueMonth;
                        });
                        $shotCheckData = [
                            'Heel' => $filteredRecords->where('face', 'Heel')->count() ?? 0,
                            'Center' => $filteredRecords->where('face', 'Center')->count() ?? 0,
                            'Toe' => $filteredRecords->where('face', 'Toe')->count() ?? 0,
                        ];
                    }else{
                        $shotCheckDetail = $shotCheckDetail = UserShotCheck::where('user_id', $user['userid'])->where('distance', '!=', NULL)->where('distance', '!=', "")->get();
                        $filteredRecords = collect($shotCheckDetail)->filter(function ($record) use ($uniqueMonth) {
                            $recordMonth = date('m', strtotime($record->date));
                            return $recordMonth === $uniqueMonth;
                        });
                        $shotCheckData = [
                            'Shorter than expected' => $filteredRecords->where('distance', 'Shorter than expected')->count() ?? 0,
                            'As expected' => $filteredRecords->where('distance', 'As expected')->count() ?? 0,
                            'Longer than expected' => $filteredRecords->where('distance', 'Longer than expected')->count() ?? 0,
                        ];
                    }
                    $newRoot[] = [
                        'graph' => $graph,
                        'check' => "Month ".(int) $uniqueMonth,
                        'shotCheck' => $shotCheckData
                    ];
                }
            }else{
                $graph = "check";
                $userShotChecks = UserShotCheck::where('user_id',$user['userid'])->groupBy('shot_no')->orderBy('shot_no','desc')->pluck('shot_no')->toArray();
                $newRoot[] = [
                    'graph' => $graph,
                    'check' => "Today",
                    'shotCheck' => $shotCheckData1
                ];
                foreach ($userShotChecks as $key => $userShotCheck) {
                    if($type == 'direction'){
                        $shotCheckDetail = UserShotCheck::where('shot_no',$userShotCheck)->where('user_id',$user['userid'])->where('direction','!=',NULL)->where('direction','!=',"")->get();
                        if($shotCheckDetail->count() > 0){
                            $shotCheckData['Left'] = $shotCheckDetail->where('direction','Left')->count() ?? 0;
                            $shotCheckData['Straight'] = $shotCheckDetail->where('direction','Straight')->count() ?? 0;
                            $shotCheckData['Right'] = $shotCheckDetail->where('direction','Right')->count() ?? 0;
                            $newRoot[] = [
                                'graph' => $graph,
                                'check' => "Check ".$userShotCheck,
                                'shotCheck' => $shotCheckData
                            ];
                        }
                    }else if($type == 'curve'){
                        $shotCheckDetail = UserShotCheck::where('shot_no',$userShotCheck)->where('user_id',$user['userid'])->where('curve','!=',NULL)->where('curve','!=',"")->get();
                        
                        if($shotCheckDetail->count() > 0){
                            $shotCheckData['To Left'] = $shotCheckDetail->where('curve','To Left')->count() ?? 0;
                            $shotCheckData['No Curve'] = $shotCheckDetail->where('curve','No Curve')->count() ?? 0;
                            $shotCheckData['To Right'] = $shotCheckDetail->where('curve','To Right')->count() ?? 0;
                            $newRoot[] = [
                                'graph' => $graph,
                                'check' => "Check ".$userShotCheck,
                                'shotCheck' => $shotCheckData
                            ];
                        }
                       
                    }else if($type == 'contact'){
                        $shotCheckDetail = UserShotCheck::where('shot_no',$userShotCheck)->where('user_id',$user['userid'])->where('contact','!=',NULL)->where('contact','!=',"")->get();
                        if($shotCheckDetail->count() > 0){
                            $shotCheckData['Fat'] = $shotCheckDetail->where('contact','Fat')->count() ?? 0;
                            $shotCheckData['Solid'] = $shotCheckDetail->where('contact','Solid')->count() ?? 0;
                            $shotCheckData['Thin'] = $shotCheckDetail->where('contact','Thin')->count() ?? 0;
                            $newRoot[] = [
                                'graph' => $graph,
                                'check' => "Check ".$userShotCheck,
                                'shotCheck' => $shotCheckData
                            ];
                        }
                    }else if($type == 'face'){
                        $shotCheckDetail = UserShotCheck::where('shot_no',$userShotCheck)->where('user_id',$user['userid'])->where('face','!=',NULL)->where('face','!=',"")->get();
                        if($shotCheckDetail->count() > 0){
                            $shotCheckData['Heel'] = $shotCheckDetail->where('face','Heel')->count() ?? 0;
                            $shotCheckData['Center'] = $shotCheckDetail->where('face','Center')->count() ?? 0;
                            $shotCheckData['Toe'] =  $shotCheckDetail->where('face','Toe')->count() ?? 0;
                            $newRoot[] = [
                                'graph' => $graph,
                                'check' => "Check ".$userShotCheck,
                                'shotCheck' => $shotCheckData
                            ];
                        }
                    }else if($type == 'distance'){
                        $shotCheckDetail = UserShotCheck::where('shot_no',$userShotCheck)->where('user_id',$user['userid'])->where('distance','!=',NULL)->where('distance','!=',"")->get();
                        if($shotCheckDetail->count() > 0){
                            $shotCheckData['Shorter than expected'] = $shotCheckDetail->where('distance','Shorter than expected')->count() ?? 0;
                            $shotCheckData['As expected'] =  $shotCheckDetail->where('distance','As expected')->count() ?? 0;
                            $shotCheckData['Longer than expected'] =  $shotCheckDetail->where('distance','Longer than expected')->count() ?? 0;
                            $newRoot[] = [
                                'graph' => $graph,
                                'check' => "Check ".$userShotCheck,
                                'shotCheck' => $shotCheckData
                            ];
                        }
                    }
                }
            }
            
            
            return ApiResponse::success($newRoot,'User Shot Check graph fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Api for user in app to find recall card graph By date 
    */
    public function getUserRecallCardGraph(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            for ($i=1; $i <= 10; $i++) { 
                $newRoot[] = [
                    'level' => $i,
                    'count' => UserRecallCards::where('user_id',$user['userid'])->where('interval',$i)->groupBy('interval')->count() ?? 0
                ];
            }
            return ApiResponse::success($newRoot,'User Recall Card graph fetched successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side storing users train plan into DB
    */
    public function storeUserTrainPlan(Request $request)
    {
        try {
            
            $collectData = $request->all();
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
          
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else{
                if(isset($request->plan) && $request->plan != ""){
                    $user->plan = $request->plan;
                    $user->save();
                }
            }
            foreach ($collectData['data'] as $key => $value) {
                $userQuestion = UserTrainingPlan::where('user_id', $user["userid"])
                                    ->where('day', $value["day"])
                                    ->firstOrNew();
                $userQuestion->day = $value["day"];
                $userQuestion->user_id = $user["userid"];
                $userQuestion->time = $value["time"];
                $userQuestion->location = $value["location"];
                $userQuestion->save();
            }
            return ApiResponse::successOnly('User training intention submit successfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side storing user's contact person to DB
    */
    public function storeUserContactPerson(Request $request)
    {
        try {
            $collectData = $request->all();
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else{
                if(isset($request->plan) && $request->plan != ""){
                    $user->plan = $request->plan;
                    $user->save();
                }
            }
            $sid = env('TWILIO_SID');
            $token = env('TWILIO_AUTH_TOKEN');
            $twilioNumber = env('TWILIO_PHONE_NUMBER');
            foreach ($collectData['data'] as $key => $value) {
                $userQuestion = UserContactPerson::where('user_id', $user["userid"])
                                    ->where('person_name', $value["name"])
                                    ->firstOrNew();

                $userQuestion->person_name = $value["name"];
                $userQuestion->user_id = $user["userid"];
                $userQuestion->phone = $value["phone"];
                $userQuestion->save();
               
                $client = new Client($sid, $token);
              
                $recipientNumber = $value["phone"];
                $messageBody = '       
Hello '.$value["name"].',

'.$user["full_name"].' asked we share the following training schedule because research shows people stick with their training when they share it with friends. Thank you for supporting '.$user["full_name"].' on this!
    
The Fisio™ Team 
Fisio™: Personal Golf Training';
            try {
                $message = $client->messages->create(
                    $recipientNumber,
                    [
                        'from' => $twilioNumber,
                        'body' => $messageBody,
                    ]
                );
            } catch (\Exception $e) {
                error_log("Error sending SMS: " . $e->getMessage(), 0);
            }
                
            }
            $newRoot = [
                'user_name' => $user->full_name

            ];
            return ApiResponse::success($newRoot,'User contact person submit successfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: While any object bookmark then need to add into user's favorite list and remove as well
    */
    public function updateUserBookmark($object_id)
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$object_id){
                return ApiResponse::error('Object id required!!');
            }
            $bookmark = [];
            $sessionId = 0;
            $objectId = 0;
            $userObjectType = UserObjectBookmark::where('object_id',$object_id)->where('user_id',$user['_id'])->first();
            if(!empty($userObjectType)){
                $bookmark['bookmark'] = false;
                $userObjectType->delete();        
            }else{
                $session = Session::all();
                foreach ($session as $key => $value) {
                    foreach ($value["session_object"] as $keyy => $objectData) {
                        if($objectData["object_id"] == $object_id){
                            $sessionId = $value['_id'];
                            $objectId = $objectData["object_id"];
                        }
                    }
                }
                $bookmark['bookmark'] = true;
                $userObjectType = new UserObjectBookmark();
                $userObjectType->user_id = $user['_id'];
                $userObjectType->object_id = $objectId;
                $userObjectType->session_id = $sessionId;
                $userObjectType->save();
            }
            return ApiResponse::success($bookmark,'Object bookmark successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: Based on session id grabs the session details from the DB
    */
    public function getSessionDetail($id,$unit_id="")
    {
        try {
            $autoPlay = false;
            $appUrl = env('AWS_S3_PATH');
            $objectPath = env('AWS_OBJECT_IMAGES_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $tags = Session::where('_id', $id)->first();// Assuming you want to display 10 sessions per page
            $general_setting_video = GeneralSetting::where('field','video')->where('user_id',$user["userid"])->where('setting','1')->first();
            $general_setting_audio = GeneralSetting::where('field','audio')->where('user_id',$user["userid"])->where('setting','1')->first();
            $sessionAutoplayQ = Autoplay::where('session_id',$id);
            if($unit_id != ""){
                $sessionAutoplayQ = $sessionAutoplayQ->where('unit_id',$unit_id);
            }
            $sessionAutoplay = $sessionAutoplayQ->where('user_id',$user['userid'])->first();
            
            $session = [];
            $object = [];
                // $savedItem = SavedItems::where('type','session')->where('user_id',$user["userid"])->where('saved_item_id',$id)->first();
                $category_name = CategoryType::where('_id', $tags["category_type_id"])->pluck('name', '_id')->first();
              
                $session_name = SessionType::where('_id', $tags["session_type_id"])->pluck('name', '_id')->first();
                $userObjects = UserObjectType::whereIn('_id', array_column($tags["session_object"], 'object_id'))->get();
                $objectTypeIds = $userObjects->pluck('object_type_id')->unique();
                $objectTypes = ObjectType::whereIn('_id', $objectTypeIds)->get()->keyBy('_id');
                $userObjectIds = $userObjects->pluck('_id');
                $userObjectBookmarks = UserObjectBookmark::whereIn('object_id', $userObjectIds)->where('user_id', $user['_id'])->get()->keyBy('object_id');
                $totalTime = 0;
           
                if (!empty($tags["session_object"])) {
                    foreach ($tags["session_object"] as $keyy => $unitObject) {
                        $saved_obj = false;
                        $savedItem = SavedItems::where('type','object')->where('user_id', $user['userid'])->where('unit_id',$unit_id)->where('session_id',$id)->where('saved_item_id',$unitObject["object_id"])->first();
                       
                        if($savedItem){
                            $saved_obj = true;
                        }
                        $userObject = $userObjects->find($unitObject["object_id"]);
                        $bookmark = false;
                        if (!empty($userObject)) {
                            $autoPlay = false;
                            $userObjectType = $userObjectBookmarks->get($userObject["_id"]);
                            if(!empty($userObjectType)){
                                $bookmark = true;
                            }
                            $objectType = $objectTypes->get($userObject["object_type_id"]);
                            $tag_name = Tags::find($userObject['tag'])->name ?? "";
                            if($objectType->name == "Video"){
                                // if($general_setting_video){
                                //     $autoPlay = true;
                                // }
                                if($sessionAutoplay){
                                    $autoPlay = true;
                                }
                            }
                            if($objectType->name == "Audio"){
                                // if($general_setting_audio){
                                //     $autoPlay = true;
                                // }
                                if($sessionAutoplay){
                                    $autoPlay = true;
                                }
                            }
                            
                            $object[] = [
                                'object_id' => $userObject["_id"],
                                'tag_id' => $userObject["tag"],
                                'permission' => $unitObject["permission"],
                                'object_name' => $userObject["object_name"],
                                'tag_name' => $tag_name ?? "",
                                'headline' => $userObject["headline"],
                                'subtitle' => $userObject["subtitle"],
                                'description' => $userObject["textarea"],
                                'file' => $userObject["file"] != '' && !(Str::contains($userObject["file"], 'storage/storage/')) ? $appUrl.''.$objectPath.''.$userObject["file"] : '',
                                'thumbnail' => $userObject["thumbnail"] != '' ? $appUrl.''.$objectPath.''.$userObject["thumbnail"] : '',
                                'type' => $objectType["name"] ?? '',
                                'bookmark' => $bookmark,
                                'video_id' => $userObject["video_id"] ?? "", //pased by rugved
                                'saved'  => $saved_obj, 
                                'autoplay' => $autoPlay ?? false,
                                'link_items' => $userObject["link_items"] ?? []
                            ];
                            $totalTime += (float)$userObject["object_time"];
                            $totalTime = number_format($totalTime,2);
                        }
                    }
                }
                // if($savedItem){
                //     $session['saved'] = true;
                // }
                $tags->category_type_name = $category_name ?? "N/A";
                $session['id'] =  $tags["_id"];
                $session['unit_id'] = $unit_id ?? '';
                $session['session'] =  $tags["session_name"];
                $session['headline'] =  $tags["headline"] ?? '';
                $session['text'] =  $tags["text"] ?? '';
                $session['internal_session_name'] =  $tags["internal_session_name"] ?? '';
                $session['session_type'] =  $session_name ?? "N/A";
                $session['category_type'] =  $category_name ?? "N/A";
                $session['object_list'] =  array_values($object);
                // $session['recall_cards'] =  $tags["recall_cards"] ?? [];
                $session['time'] =  $totalTime;
                $session['last_update'] =  $tags["updated_at"];
                
                return ApiResponse::success($session, 'Session list found.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function postSessionAutoplay($id,$unit_id)
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            
            
            $autoplay = [];
            $sessionAutoplay = Autoplay::where('session_id',$id)->where('unit_id',$unit_id)->where('user_id',$user['userid'])->first();
            if(!empty($sessionAutoplay)){
                $autoplay['autoplay'] = false;
                $sessionAutoplay->delete();       
                $msg = 'Session autoplay removed successfully.';
            }else{
                $autoplay['autoplay'] = true;
                $sessionAutoplay = new Autoplay();
                $sessionAutoplay->user_id = $user['userid'];
                $sessionAutoplay->unit_id = $unit_id;
                $sessionAutoplay->session_id = $id;
                $sessionAutoplay->save();
                $msg = 'Session  autoplay added successfully.';
            }
            return ApiResponse::success($autoplay,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: App side returning unit list with completion percentage as well as no. of session detail
    */
    public function getUnitProgramOld(Request $request, $slug = 'Train')
    {
        try {
            if (!$slug) {
                return ApiResponse::error('Slug is required');
            }
            $lockUnlockStatus = 1;
            $appUrl = env('AWS_S3_PATH');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
           
            $userUnitProgress = UserSessionProgress::where('user_id',$user['_id'])->get();
       
            $unitData = [];
            $savedSessionIds = SavedItems::where('user_id',$user['userid'])->pluck('saved_item_id')->toArray();
            $categoryType = CategoryType::where('name', 'LIKE', $slug)->first();
            $defaultProgram = env('DEFAULT_PROGRAM');
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            if(!empty($user->group_id)){
                $group = Group::find($user->group_id);
              
                if($group){
                    $unitIds = array_column($group["group_object"], "object_id");
                    $unitCollectionData = Unit::whereIn('_id', $unitIds )->where('category_type_id', $categoryType["_id"])->get();
                    $unitCollectionData = $unitCollectionData->sortBy(function ($item) use ($unitIds) {
                        return array_search($item['_id'], $unitIds);
                    });
                }else{
                    $unitCollectionData = Unit::whereIn('_id', $default_unitIds )->where('category_type_id', $categoryType["_id"])->get();
                    $unitCollectionData = $unitCollectionData->sortBy(function ($item) use ($default_unitIds) {
                        return array_search($item['_id'], $default_unitIds);
                    });
                }
            }else{
                $unitCollectionData = Unit::whereIn('_id', $default_unitIds )->where('category_type_id', $categoryType["_id"])->get();
                $unitCollectionData = $unitCollectionData->sortBy(function ($item) use ($default_unitIds) {
                    return array_search($item['_id'], $default_unitIds);
                });
            }
            $unit = $unitCollectionData;
         
            $objectIds = [];
            $sessionIds = [];
            foreach ($unit as $value) {
                $unitObjectIds = array_column($value["unit_object"], "object_id");
                $objectIds = array_merge($objectIds, $unitObjectIds);
                $sessionIds = array_merge($sessionIds, $unitObjectIds);
            }
            $objectIds = array_unique($objectIds);
            $sessionIds = array_unique($sessionIds);
            $valueSessionDataArray = Session::whereIn('_id', $sessionIds)->get()->keyBy('_id');
            
            foreach ($unit as $key => $value) {
             
                $unitData[$key]['id'] =  $value["_id"];
                $unitData[$key]['three_session_finished'] =  0;
                $unitData[$key]['program_name'] =  $program_name ?? "";
                $unitData[$key]['title'] =  $value["unit_name"];
                $unitData[$key]['order'] =  (int)$value["order"];
                $unitData[$key]['percentage'] =  0 . '%';
                $noOfSession = 0;
                $unitObjectCount = count($value["unit_object"]);
                if ($unitObjectCount > 0) {
                    $session = [];
                    foreach ($value["unit_object"] as $unitObject) {
                        $lockUnlockStatus = 1;
                        $percentage = 0;
                        $valueSessionData = $valueSessionDataArray->get($unitObject["object_id"]);
                        if ($valueSessionData) {
                            $totalSessionDuration = 0;
                            $objIds = array_column($valueSessionData["session_object"], "object_id");
                            $valueObjData = UserObjectType::whereIn('_id',$objIds)->pluck('object_time')->toArray();
                            if (sizeOf($valueObjData) > 0) {
                                $totalSessionDuration = array_sum($valueObjData);
                            }
                            $session[$unitObject["object_id"]]['id'] = $valueSessionData->_id;
                            if (in_array($valueSessionData->_id, $savedSessionIds)) {
                                $session[$unitObject["object_id"]]['saved'] = true;
                            }else{
                                $session[$unitObject["object_id"]]['saved'] = false;
                            }
                            if($slug == "apply" || $slug == "Apply"){
                                $lockUnlockStatus = 0;
                            }else{
                                $unlockedSession = UserUnlockedSession::where('user_id',$user["_id"])->where('unit_id',$value["_id"])
                                ->where('session_id',$unitObject["object_id"])->first();
                                if($unlockedSession){
                                    $lockUnlockStatus = 0;
                                }
                            }
                    
                            $session[$unitObject["object_id"]]['is_locked'] = $lockUnlockStatus;
                            $session[$unitObject["object_id"]]['seen'] = false;
                            $session[$unitObject["object_id"]]['unit_id'] = $value["_id"];
                            $session[$unitObject["object_id"]]['title'] = $valueSessionData->session_name;
                            $session[$unitObject["object_id"]]['internal_session_name'] = $valueSessionData->internal_session_name ?? "";
                            $session[$unitObject["object_id"]]['headline'] = $valueSessionData->headline ?? '';
                            $session[$unitObject["object_id"]]['text'] = $valueSessionData->text ?? '';
                            $session[$unitObject["object_id"]]['thumbnail'] = $appUrl.'thumbnail.png';
                            $session[$unitObject["object_id"]]['duration'] = number_format($totalSessionDuration,2);
                            $countUserUnitProgress = $userUnitProgress->where('unit_id',$value["_id"])->where('session_id',$valueSessionData->_id)->whereIn('object_id', $objIds)->pluck('object_id')->unique()->count();
                            $countValSessionData = count($valueSessionData->session_object);
                            if ($countUserUnitProgress == $countValSessionData) {
                                $noOfSession++;
                                $session[$unitObject["object_id"]]['seen'] = true;
                            }
                            if ($countUserUnitProgress > 0 && $countValSessionData > 0) {
                                $percentage = ($countUserUnitProgress /$countValSessionData) * 100;
                            }
                            $session[$unitObject["object_id"]]['percentage'] = number_format($percentage, 2) . '%';
                        }
                    }
                }
                if ($noOfSession > 0 && $unitObjectCount > 0) {
                    $unitData[$key]['percentage'] = $noOfSession / $unitObjectCount * 100 . '%';
                }
                $unitData[$key]['session'] = array_values($session);
            }
         
            $unitData = Functions::sortArray($unitData,'');
         
            $filteredData = array_filter($unitData, function ($item) {
                return isset($item['session']);
            });
            $filteredData = array_values($filteredData);
            return ApiResponse::success($filteredData, 'User program list found.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    // public function getUnitProgram(Request $request, $slug = 'Train')
    // {
    //     try {
    //         if (!$slug) {
    //             return ApiResponse::error('Slug is required');
    //         }

    //         $token = $this->getTokenFromHeader();
    //         $user = \JWTAuth::setToken($token)->authenticate();
    //         if (!$user) {
    //             return ApiResponse::error('Getting trouble to fetch user information');
    //         }

    //         $appUrl = env('AWS_S3_PATH');
    //         $savedSessionIds = SavedItems::where('user_id', $user['userid'])->pluck('saved_item_id')->toArray();
    //         $categoryType = CategoryType::where('name', 'LIKE', $slug)->first();
    //         if (!$categoryType) {
    //             return ApiResponse::error('Category type not found');
    //         }

    //         $userUnitProgress = UserSessionProgress::where('user_id', $user['_id'])->get();
    //         $savedSessionIds = SavedItems::where('user_id', $user['userid'])->pluck('saved_item_id')->toArray();
    //         $categoryType = CategoryType::where('name', 'LIKE', $slug)->first();

    //         // Initialize with default group unit IDs
    //         $defaultProgram = env('DEFAULT_PROGRAM');
    //         $groupUnitIds = array_column(Group::where('group_name', $defaultProgram)->first()["group_object"], "object_id");

    //         // Override with user's group unit IDs if available
    //         if (!empty($user->group_id) && $group = Group::find($user->group_id)) {
    //             $groupUnitIds = array_column($group["group_object"], "object_id");
    //         }
    //         // Fetch and sort unit collection data
    //         $unitCollectionData = Unit::whereIn('_id', $groupUnitIds)
    //                                 ->where('category_type_id', $categoryType["_id"])
    //                                 ->get()
    //                                 ->sortBy(function ($item) use ($groupUnitIds) {
    //                                     return array_search($item['_id'], $groupUnitIds);
    //                                 });
    //         $unit = $unitCollectionData; // Now contains the sorted units
    //         // Using Laravel collections to streamline the extraction and deduplication process
    //         $sessionIds = collect($unit)->flatMap(function ($value) {
    //             return array_column($value["unit_object"], "object_id");
    //         })->unique()->values()->all();
            
    //         $valueSessionDataArray = Session::whereIn('_id', $sessionIds)->get()->keyBy('_id');
    //         $userObjectTypeDurations = UserObjectType::all()->pluck('object_time', '_id')->toArray();
    //         // Pre-fetch and map UserUnlockedSessions if they are frequently accessed
    //         $userUnlockedSessionsMap = UserUnlockedSession::where('user_id', $user["_id"])
    //             ->get()
    //             ->keyBy(function ($item) {
    //                 return $item->unit_id . '_' . $item->session_id;
    //             })->toArray();
    //         foreach ($unit as $key => $value) {
    //             $unitData[$key] = [
    //                 'id' => $value["_id"],
    //                 'three_session_finished' => 0, 
    //                 'program_name' => $program_name ?? "",
    //                 'title' => $value["unit_name"],
    //                 'order' => (int)$value["order"],
    //                 'percentage' => '0%', 
    //                 'session' => []
    //             ];
            
    //             // Process each unit_object
    //             $sessionsProcessed = collect($value["unit_object"])->map(function ($unitObject) use ($valueSessionDataArray, $savedSessionIds, $user, $value, $slug, $appUrl, $userObjectTypeDurations, $userUnlockedSessionsMap,$userUnitProgress) {
    //                 $sessionData = $valueSessionDataArray->get($unitObject["object_id"]);
    //                 if (!$sessionData) return null; // Skip if no session data found
            
    //                 // Calculate total session duration using pre-fetched data
    //                 $totalSessionDuration = collect(array_column($sessionData["session_object"], "object_id"))
    //                     ->reduce(function ($carry, $objId) use ($userObjectTypeDurations) {
    //                         return $carry + ($userObjectTypeDurations[$objId] ?? 0);
    //                     }, 0);
            
    //                 $sessionKey = $value["_id"] . '_' . $unitObject["object_id"];
    //                 //$isUnlocked = isset($userUnlockedSessionsMap[$sessionKey]) ;
    //                 $isUnlocked = isset($userUnlockedSessionsMap[$sessionKey]);
    //                 $objIds = array_column($sessionData["session_object"], "object_id");
    //                 $isLocked = !in_array($sessionData->_id, $savedSessionIds) && !($slug === "apply" || $slug === "Apply") && !$isUnlocked;
    //                 $sessionProgressCount = $userUnitProgress->where('unit_id', $value["_id"])->where('session_id', $sessionData->_id)->whereIn('object_id', $objIds)->count();
    //                 $sessionTotalCount = count($sessionData["session_object"]);   
    //                 return [
    //                     'id' => $sessionData->_id,
    //                     'saved' => in_array($sessionData->_id, $savedSessionIds),
    //                     'is_locked' => (int)$isLocked,
    //                     'seen' =>  $sessionProgressCount >= $sessionTotalCount,
    //                     'unit_id' => $value["_id"],
    //                     'title' => $sessionData->session_name,
    //                     'internal_session_name' => $sessionData->internal_session_name ?? "",
    //                     'headline' => $sessionData->headline ?? '',
    //                     'text' => $sessionData->text ?? '',
    //                     'thumbnail' => $appUrl . 'thumbnail.png',
    //                     'duration' => number_format($totalSessionDuration, 2),
    //                     //'percentage' => number_format(($sessionProgressCount / max($sessionTotalCount, 1)) * 100, 2) > 100 ? '100%' : number_format(($sessionProgressCount / max($sessionTotalCount, 1)) * 100, 2). '%'
    //                     'percentage' => number_format(($sessionProgressCount / max($sessionTotalCount, 1))  100, 2) > 100 ? '100%' : round(number_format(($sessionProgressCount / max($sessionTotalCount, 1))  100, 2)). '%'
                        
    //                 ];
    //             })->filter()->values()->all();
    //             $seenSessionsCount = collect($sessionsProcessed)->where('seen', true)->count();
    //             if ($seenSessionsCount > 0) {
    //                 $unitData[$key]['percentage'] = round(number_format(($seenSessionsCount / max(count($value["unit_object"]), 1)) * 100, 2)) . '%';
    //                 // $unitData[$key]['percentage'] = number_format(($seenSessionsCount / max(count($value["unit_object"]), 1)) * 100, 2) . '%';
    //             }
    //             $unitData[$key]['session'] = $sessionsProcessed;
    //         }
    //         $unitData = Functions::sortArray($unitData,'');
    //         $filteredData = array_filter($unitData, function ($item) {
    //             return isset($item['session']);
    //         });
    //         $filteredData = array_values($filteredData);
    //         return ApiResponse::success($filteredData, 'User program list found.');
    //     } catch (\Exception $e) {
    //         return ApiResponse::error($e->getMessage());
    //     }
    // }

    public function deleteRepVideo($id)
    {
        try {
            if(!$id){
                return ApiResponse::error('Rep Review video id required!!');
            }
            $swing = RepReview::find($id);
            if($swing){
                $swing->delete();
                return ApiResponse::successOnly('Rep Review video deleted successfully.');
            }else{
                return ApiResponse::error('Rep Review video not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    

    public function uploadReps(Request $request)
    {
        $appUrl = env('AWS_S3_PATH');
        $swingPath = env('AWS_REP_VIDEO_PATH');
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            
            if($user){
                $validatedData = $request->validate([
                    'duration' => 'required',
                    'file_size' => 'required',
                    'rep_video' => 'required|mimetypes:video/mp4,video/quicktime,video/webm,video/mpeg,video/ogg,video/x-msvideo', // Adjust the maximum file size as needed
                    'submit_to_coach' => 'required'
                ]);
                if(!empty($request->id)){
                    $rep_video = RepReview::find($request->id);
                }else{
                    $rep_video = new RepReview();
                    $rep_video->title =  uniqid();
                } 
                $rep_video->user_id = $user["_id"];
                if ($request->hasFile('rep_video') && $request->file('rep_video')->isValid()) {
                    $down_the_linefile = $request->file('rep_video');
                    $down_the_linefilename = uniqid() . '.' . $down_the_linefile->getClientOriginalExtension();
                    Storage::disk('s3')->putFileAs($swingPath, $down_the_linefile, $down_the_linefilename, 'public');
                    $rep_video->rep_video = $down_the_linefilename;
                    if($request->hasFile('thumbnail')){
                        $file = $request->file('thumbnail');
                        $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                        $path = env('AWS_REP_VIDEO_PATH');
                        Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                        $appUrl = env('AWS_S3_PATH');
                        $path_thumbnail = $appUrl.''.$path;
                        $rep_video->thumbnail = $path_thumbnail.''.$filename;
                    }
                }
                // if ($request->hasFile('rep_video') && $request->file('rep_video')->isValid()) {
                //     $videoFile = $request->file('rep_video');
                //     $videoFilename = uniqid() . '.' . $videoFile->getClientOriginalExtension();
                    
                //     // Save video file to S3
                //     Storage::disk('s3')->putFileAs($swingPath, $videoFile, $videoFilename, 'public');
                    
                //     // Define the path to store the thumbnail locally
                //     $thumbnailFilename = uniqid() . '.jpg';
                //     $thumbnailPath = storage_path('app/public/thumbnail/' . $thumbnailFilename);
                //     dd($thumbnailPath);
                //     // Create the thumbnail using FFmpeg (set to capture at 1 second)
                //     $ffmpegPath = '/usr/bin/ffmpeg'; // Update this with the actual path to ffmpeg
                //     $ffmpegCommand = "$ffmpegPath -i " . escapeshellarg($videoFile->getRealPath()) . 
                //                      " -ss 00:00:01 -vframes 1 " . escapeshellarg($thumbnailPath);
                    
                //     // Execute the command and capture output
                //     exec($ffmpegCommand, $output, $returnVar);
                //     dd($returnVar);
                //     // Check if the thumbnail was successfully created
                //     dd(file_exists($thumbnailPath));
                //     if (file_exists($thumbnailPath)) {
                //         // Save the thumbnail to S3
                //         $s3ThumbnailPath = $swingPath . '/thumbnails/' . $thumbnailFilename;
                //         Storage::disk('s3')->put($s3ThumbnailPath, file_get_contents($thumbnailPath), 'public');
                
                //         // Optionally, delete the local thumbnail file after uploading to S3
                //         unlink($thumbnailPath);
                        
                //         // Save the video and thumbnail filenames in your model (e.g., $rep_video)
                //         $rep_video->rep_video = $videoFilename;
                //         $rep_video->rep_thumbnail = $thumbnailFilename;
                //     }
                // }
                $rep_video->duration = $request->duration ?? "";
                $rep_video->file_size = $request->file_size ?? "";
                if($request->submit_to_coach == "false"){
                    $submit_to_coach = false;
                }else{
                    $submit_to_coach = true;
                }
                if($submit_to_coach === true){
                    $rep_video->submit_to_coach = true;
                    $rep_video->status = "Sent";
                    $rep_video->submit_to_coach_at = now();
                    $rep_video->save();
                    $coach = User::where('user_type','coach')->get();
                    foreach ($coach as $admin) {
                        $coach_name = $admin->full_name ?? "";
                        $user_name = User::find($rep_video->user_id)->full_name ?? "";
                        Mail::to($admin->email)->send(new CoachReminderEmail($rep_video->_id, $coach_name, $user_name));
                    }
                   // $rep_video->rep_video = $rep_video->rep_video != '' ? $appUrl.''.$swingPath.'/thumbnails/'.$rep_video->rep_video : '';
                    $rep_video->rep_video = $rep_video->rep_video != '' ? $appUrl.''.$swingPath.''.$rep_video->rep_video : '';
                    $rep_video->thumbnail = $rep_video->thumbnail ?? "";
                    return ApiResponse::success($rep_video,'Rep video uploaded successfully.');
                   
                }else{
                    $rep_video->submit_to_coach = false;
                    $rep_video->status = "Draft";
                    $rep_video->save();
                    $rep_video->thumbnail = $rep_video->thumbnail ?? "";
                  //  $rep_video->rep_video = $rep_video->rep_video != '' ? $appUrl.''.$swingPath.'/thumbnails/'.$rep_video->rep_video : '';
                    $rep_video->rep_video = $rep_video->rep_video != '' ? $appUrl.''.$swingPath.''.$rep_video->rep_video : '';
                    return ApiResponse::success($rep_video,'Rep video save as draft.');
                    
                }
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getUnitProgram(Request $request, $slug = 'Train')
    {
        try {
            if (!$slug) {
                return ApiResponse::error('Slug is required');
            }

            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }

            $appUrl = env('AWS_S3_PATH');
            $savedSessionIds = SavedItems::where('user_id', $user['userid'])->pluck('saved_item_id')->toArray();
            $categoryType = CategoryType::where('name', 'LIKE', $slug)->first();
            if (!$categoryType) {
                return ApiResponse::error('Category type not found');
            }

            $userUnitProgress = UserSessionProgress::where('user_id', $user['_id'])->get();
            $savedSessionIds = SavedItems::where('user_id', $user['userid'])->pluck('saved_item_id')->toArray();
            $categoryType = CategoryType::where('name', 'LIKE', $slug)->first();

            // Initialize with default group unit IDs
            $defaultProgram = env('DEFAULT_PROGRAM');
            $groupUnitIds = array_column(Group::where('group_name', $defaultProgram)->first()["group_object"], "object_id");

            // Override with user's group unit IDs if available
            if (!empty($user->group_id) && $group = Group::find($user->group_id)) {
                $groupUnitIds = array_column($group["group_object"], "object_id");
            }
            $group = Group::where('_id',$user->group_id)->first();
            $plan_name = $group->plan_name ?? "";
            // Fetch and sort unit collection data
            $unitCollectionData = Unit::whereIn('_id', $groupUnitIds)
                                    ->where('category_type_id', $categoryType["_id"])
                                    ->get()
                                    ->sortBy(function ($item) use ($groupUnitIds) {
                                        return array_search($item['_id'], $groupUnitIds);
                                    });
            $unit = $unitCollectionData; // Now contains the sorted units
            // Using Laravel collections to streamline the extraction and deduplication process
            $sessionIds = collect($unit)->flatMap(function ($value) {
                return array_column($value["unit_object"], "object_id");
            })->unique()->values()->all();
            
            $valueSessionDataArray = Session::whereIn('_id', $sessionIds)->get()->keyBy('_id');
            $userObjectTypeDurations = UserObjectType::all()->pluck('object_time', '_id')->toArray();
            // Pre-fetch and map UserUnlockedSessions if they are frequently accessed
            $userUnlockedSessionsMap = UserUnlockedSession::where('user_id', $user["_id"])
                ->get()
                ->keyBy(function ($item) {
                    return $item->unit_id . '_' . $item->session_id;
                })->toArray();
            foreach ($unit as $key => $value) {
                $unitData[$key] = [
                    'plan_name' => $plan_name ?? "",
                    'id' => $value["_id"],
                    'three_session_finished' => 0, 
                    'program_name' => $program_name ?? "",
                    'title' => $value["unit_name"],
                    'order' => (int)$value["order"],
                    'percentage' => '0%',
                    'session' => []
                ];
            
                // Process each unit_object
                $sessionsProcessed = collect($value["unit_object"])->map(function ($unitObject) use ($valueSessionDataArray, $savedSessionIds, $user, $value, $slug, $appUrl, $userObjectTypeDurations, $userUnlockedSessionsMap,$userUnitProgress) {
                    $sessionData = $valueSessionDataArray->get($unitObject["object_id"]);
                    if (!$sessionData) return null; // Skip if no session data found
            
                    // Calculate total session duration using pre-fetched data
                    $totalSessionDuration = collect(array_column($sessionData["session_object"], "object_id"))
                        ->reduce(function ($carry, $objId) use ($userObjectTypeDurations) {
                            return $carry + ($userObjectTypeDurations[$objId] ?? 0);
                        }, 0);
            
                    $sessionKey = $value["_id"] . '_' . $unitObject["object_id"];
                    //$isUnlocked = isset($userUnlockedSessionsMap[$sessionKey]) ;
                    $isUnlocked = isset($userUnlockedSessionsMap[$sessionKey]);
                    $objIds = array_column($sessionData["session_object"], "object_id");
                    $isLocked = !in_array($sessionData->_id, $savedSessionIds) && !($slug === "apply" || $slug === "Apply") && !$isUnlocked;
                    $sessionProgressCount = $userUnitProgress->where('unit_id', $value["_id"])->where('session_id', $sessionData->_id)->whereIn('object_id', $objIds)->count();
                    $sessionTotalCount = count($sessionData["session_object"]);
                    $overview = Overview::where('session_id', $sessionData->_id)->first();
                    $overviewText = $overview ? $overview->text : '';  
                    return [
                        'id' => $sessionData->_id,
                        'saved' => in_array($sessionData->_id, $savedSessionIds),
                        'is_locked' => (int)$isLocked,
                        'seen' =>  $sessionProgressCount >= $sessionTotalCount,
                        'unit_id' => $value["_id"],
                        'title' => $sessionData->session_name,
                        'internal_session_name' => $sessionData->internal_session_name ?? "",
                        'headline' => $sessionData->headline ?? '',
                        'text' => $overviewText,
                        'thumbnail' => $appUrl . 'thumbnail.png',
                        'description' => $sessionData->description ?? '',
                        'duration' => number_format($totalSessionDuration, 2),
                        'percentage' => number_format(($sessionProgressCount / max($sessionTotalCount, 1)) * 100, 2) > 100 ? '100%' : round(number_format(($sessionProgressCount / max($sessionTotalCount, 1)) * 100, 2)). '%'
                    ];
                })->filter()->values()->all();
                $seenSessionsCount = collect($sessionsProcessed)->where('seen', true)->count();
                if ($seenSessionsCount > 0) {
                    $unitData[$key]['percentage'] = round(number_format(($seenSessionsCount / max(count($value["unit_object"]), 1)) * 100, 2)) . '%';
                }
                $unitData[$key]['session'] = $sessionsProcessed;
            }
            $unitData = Functions::sortArray($unitData,'');
            $filteredData = array_filter($unitData, function ($item) {
                return isset($item['session']);
            });
            $filteredData = array_values($filteredData);
            return ApiResponse::success($filteredData, 'User program list found.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function uploadRenameSwing(Request $request)
    {
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            if($user){
                // Validate request parameters
                $validatedData = $request->validate([
                    'title'   => 'required', // Adjust the maximum file size as needed
                    'swing_id'=> 'required'
                ]);
                $swing = Swing::find($validatedData["swing_id"]);
                $swing->user_id = $user["_id"];
                $swing->title = $validatedData["title"];
                $swing->save();
                return ApiResponse::success($swing,'Swing video name updated successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: overview of session for app
    */
    public function getSessionOverview($id,$unit_id = "")
    {
        try {
            if (!$id) {
                return ApiResponse::error('Session ID is required');
            }
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $session = Session::find($id);
            if (!$session) {
                return ApiResponse::error('Session not found');
            }
            $overview_data = Overview::where('session_id',$id)->first();
            $sumReps = $sumTime = 0;
            if($session){
                $objIds = array_column($session["session_object"], "object_id");
                if(!empty($objIds) && sizeOf($objIds) > 0){
                    $sumReps = UserObjectType::whereIn('_id', $objIds)
                    ->select('reps')
                    ->get()
                    ->sum(function ($userObjectType) {
                        return (int) $userObjectType->reps;
                    });
                    $sumTime = UserObjectType::whereIn('_id', $objIds)
                    ->select('object_time')
                    ->get()
                    ->sum(function ($userObjectType) {
                        return (float)$userObjectType->object_time;
                    });
                }
            }
            $overviewData =[];
            if($overview_data){
                if($overview_data['is_equipments_needed'] == 1){
                    $overview_data['is_equipments_needed'] = true;
                }
                if($overview_data['is_equipments_needed'] == 0){
                    $overview_data['is_equipments_needed'] = false;
                }
                $sessionAutoplay = Autoplay::where('session_id',$id)->where('unit_id',$unit_id)->where('user_id',$user['userid'])->first();
                if($sessionAutoplay){
                    $overviewData['autoplay'] = true;
                }else{
                    $overviewData['autoplay'] = false;
                }
                $overviewData['unit_id'] = $unit_id ?? "";
                $overviewData['headline'] = $overview_data['headline'] ?? "";
                $overviewData['text'] = $overview_data['text'] ?? "";
                $overviewData['time'] = $sumTime ?? 0;
                $overviewData['is_equipments_needed'] = $overview_data['is_equipments_needed'] ?? false;
                $overviewData['equipments'] = $overview_data['equipments'] ?? "";
                $overviewData['move_drills_count'] = $sumReps ?? 0;
                $overviewData['recall_cards_count'] = $overview_data['recall_cards_count'] ?? 0;
                if($overview_data['list_items']){
                    $itemData = [];
                    foreach ($overview_data['list_items'] as $key => $item) {
                        $itemData[ $key]['title'] = "";
                        $itemData[ $key]['description'] = "";
                        $itemData[ $key]['time'] = 0;
                        if (array_key_exists('title', $item)) {
                            if( $item['title'] != null){
                                $itemData[ $key]['title'] = $item['title'];
                            }
                            
                        }
                        if (array_key_exists('description', $item)) {
                            if( $item['description'] != null){
                                $itemData[ $key]['description'] = $item['description'];
                            }
                           
                        }
                        if (array_key_exists('time', $item)) {
                            if($item['time'] != null){
                                $itemData[ $key]['time'] = $item['time'];
                            }
                        }
                    }
                }
                $overviewData['list_items'] = $overview_data['list_items'] ? $itemData : [];
                $overviewData = [$overviewData];
            }else{
                $overviewData = [];
            }
           
            // Return the response
            return ApiResponse::success($overviewData, 'Overview of session found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getForceUpdateApp($device_type)
    {
        try {
            
            $forceUpdateSetting = ForceUpdateSetting::orderBy('created_at','desc')->where('device_type',$device_type)->first();
            return ApiResponse::success($forceUpdateSetting,'Force update detail fetched successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function getSessionClosingDetails($session_id,$unit_id)
    {
        try {
            if (!$session_id) {
                return ApiResponse::error('Session ID is required');
            }
            if (!$unit_id) {
                return ApiResponse::error('Unit ID is required');
            }
          
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $unit = Unit::where('_id',$unit_id)->get();
          
            if ($unit->count() == 0) {
                return ApiResponse::error('Unit not found');
            }
            $session = Session::find($session_id);
            if (!$session) {
                return ApiResponse::error('Session not found');
            }
            $overview_data = Overview::where('session_id',$session_id)->first();
            $sumReps = 0;
              
            if($session){
                $objIds = array_column($session["session_object"], "object_id");
                if(!empty($objIds) && sizeOf($objIds) > 0){
                    $sumReps = UserObjectType::whereIn('_id', $objIds)
                    ->select('reps')
                    ->get()
                    ->sum(function ($userObjectType) {
                        return (int) $userObjectType->reps;
                    });
                    $sumTime = UserObjectType::whereIn('_id', $objIds)
                    ->select('object_time')
                    ->get()
                    ->sum(function ($userObjectType) {
                        return (float)$userObjectType->object_time;
                    });
                }
            }
            $manual_reps_recall_card = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Recall Cards')
                ->get();
            $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
            $manual_reps_movement_drills = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Move Drills')
                ->get();
            $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
            $manual_reps_swing_drills = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Swing Drills')
                ->get();    
            $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
            $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Trust Shots')
                ->get();
            $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0; 
            // Initialize the root data structure
            $newRoot = [
                'unit' => new stdClass(),
                'user_rate' => 0,
            ];
           $appUrl = env('AWS_S3_PATH');
            if($user){
                $sessionIds = collect($unit)->flatMap(function ($unit) {
                    return $unit['unit_object'];
                })->pluck('object_id');  // Extract object IDs from unit progress and retrieve related session data
               
                $sessionData = Session::whereIn('_id', $sessionIds)->get();
             
                // Extract user object type IDs from session data and retrieve related object time data
                $userObjectTypeIds = $sessionData->pluck('session_object.*.object_id')->flatten();
               
                $valueObjData = UserObjectType::whereIn('_id', $userObjectTypeIds)->pluck('object_time')->toArray();
            
                $unitData = [];
                $value = $unit[0];
                // Iterate over unit progress
                $unitData['id'] = $value["_id"];
                $unitData['title'] = $value["unit_name"];
                $unitData['percentage'] = 0;
                $unitData['completed_session'] = 0;

                $userSessionProgress = UserSessionProgress::where('user_id', $user->_id)->get();
                $noOfSession = 0;
                $unitObjectCount = count($value['unit_object']);
                $sessionKey = 0;
                if ($unitObjectCount > 0) {
                    $session = [];
                    $totalSessionDuration = 0;
                    // Iterate over unit objects in the current unit
                    foreach ($value['unit_object'] as $keys => $obj) {
                        $percentage = 0;
                        $sessionDataItem = $sessionData->firstWhere('_id',$obj['object_id']);
                        $objIds = [];
                        if ($sessionDataItem) {
                            if($session_id == $sessionDataItem->_id){
                                $sessionKey = $keys;
                            }

                             // Set session data for the current unit object
                            $session[$keys]['id'] = $sessionDataItem->_id;
                            $session[$keys]['unit_id'] = $unit_id;
                            $session[$keys]['seen'] = false;
                            $session[$keys]['title'] = $sessionDataItem->session_name;
                            $session[$keys]['headline'] = $sessionDataItem->headline;
                            $session[$keys]['text'] = $sessionDataItem->text;
                            $session[$keys]['thumbnail'] =$appUrl.'thumbnail_old.png';
                            $countSessionObject = count($sessionDataItem->session_object) ?? 0;
                            if ($countSessionObject > 0) {
                                if (sizeof($valueObjData) > 0) {
                                    $countValObjData = array_sum($valueObjData);
                                    $totalSessionDuration += $countValObjData;
                                }
                                // $session[$keys]['duration'] = number_format($totalSessionDuration,2);
                                $objIds = array_column($sessionDataItem["session_object"], "object_id");
                                
                                $countUserUnitProgress = $userSessionProgress->where('session_id', $sessionDataItem->_id)->where('unit_id', $unit_id)->whereIn('object_id',$objIds)->pluck('object_id')->unique()->count();
                                // Retrieve user unit progress for the current user and session
                                if ($countUserUnitProgress == $countSessionObject) {
                                    $noOfSession++;
                                    $session[$keys]['seen'] = true;
                                }
                            
                                if ($countUserUnitProgress > 0 && $countSessionObject > 0) {
                                    $percentage = ($countUserUnitProgress / $countSessionObject) * 100;
                                }
                                $session[$keys]['percentage'] = number_format($percentage, 2) ;
                            }
                        }
                    }
                }
                if ($noOfSession > 0 && $unitObjectCount > 0) {
                    $unitData['percentage'] = $noOfSession / $unitObjectCount * 100;
                    $unitData['completed_session'] = $noOfSession;
                }

                $unitData['session'] = $session;
                $unitP = [];
                $intPercent =(float)$unitData['percentage'];
                $unitP['id'] = $unitData["id"];
                $unitP['title'] = $unitData["title"];
                $unitP['percentage'] = number_format($intPercent,2);
                $unitP['completed_session'] = $unitData["completed_session"];

                $newRoot['unit'] = $unitP;
                $newRoot['session'] =  $session[$sessionKey];

                $reps = [];// Set initial reps values
                $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
                $userRecallCardsCountSession = UserRecallCards::where('user_id',$user['userid'])->where('session_id',$session_id)->count();
               // $oldRecallCardCount = $userRecallCardsCount - $userRecallCardsCountSession;

                //recall_raps
                // $recap_reps = SessionRecapTime::where('user_id', $user['_id'])->where('unit_id',$unit_id)->where('session_id',$session_id)->orderBy('created_at','desc')->first();
                // if($recap_reps){
                //     $totalRecapReps =(int) $recap_reps->recap_reps ?? 0;
                // }
               // $userRecapRepsCount = $totalRecapReps ?? 0;
                $recap_reps_all = SessionRecapTime::where('user_id', $user['_id'])->get();
                $all_totalRecapReps = 0;
                if($recap_reps_all->count() > 0){
                    foreach ($recap_reps_all as $recap_reps_a) {
                        $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                    }
                }
                $all_userRecapRepsCount = $all_totalRecapReps;
                //$old_recall_reps = $all_userRecapRepsCount - $userRecapRepsCount;
                $reps['old_recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card + $all_userRecapRepsCount - $userRecallCardsCountSession  ?? 0;
                // $reps['old_recall_cards'] = $oldRecallCardCount + $total_manual_reps_recall_card + $old_recall_reps?? 0;
                $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card + $all_userRecapRepsCount ?? 0;
                $trust_reps = 0;
                $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                    return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                })->values()->all();
                $totalDate = sizeof($sortedDates);
                if( $totalDate > 0){
                    $trust_reps = $totalDate * 40;
                }
                $reps['old_trust_reps'] = $trust_reps + $total_manual_reps_trust ?? 0;
                $reps['trust_reps'] = $trust_reps + $total_manual_reps_trust ?? 0;
                //$docs = UserMovementDrill::where('user_id', $user['_id'])->where('unit_id',$unit_id)->where('session_id',$session_id)->get();
                // $totalReps = 0;
                // foreach ($docs as $doc) {
                //     $totalReps += (int) $doc['reps'];
                // }
                // $userMovementDrillCount = $totalReps;
                $docs_all = UserMovementDrill::where('user_id', $user['_id'])->get();
                $all_totalReps = 0;
                foreach ($docs_all as $doc_a) {
                    $all_totalReps += (int) $doc_a['reps'];
                }
                $all_userMovementDrillCount = $all_totalReps;
               // $old_move_drills = $all_userMovementDrillCount - $userMovementDrillCount;
               // $reps['old_move_drills'] = $old_move_drills  + $total_manual_reps_movement_drills ?? 0;
                $oldMoveDrills = $all_userMovementDrillCount + $total_manual_reps_movement_drills - $sumReps ?? 0;
                if($oldMoveDrills < 0){
                    $oldMoveDrills = 0;
                }
                $reps['old_move_drills'] = $oldMoveDrills ?? 0;
                $reps['move_drills'] = $all_userMovementDrillCount + $total_manual_reps_movement_drills ?? 0;
                $swings = Swing::where('user_id',$user["_id"])->count();
                $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills ?? 0;
                $reps['old_swing_drills'] = $swings + $total_manual_reps_swing_drills ?? 0;
                $trust_shot_data = UserTrustHole::select('trust_hole_no','date')
                                ->where('user_id', $user["userid"])
                                ->whereNotNull('trust_hole_no')
                                ->groupBy('trust_hole_no','date')
                                ->havingRaw('COUNT(DISTINCT hole_type) = 1')
                                ->whereIn('hole_type', ['Drive', 'Approach'])
                                ->get();
                if(!empty($trust_shot_data)){
                    $trust_shots = $trust_shot_data->count();
                }else{
                    $trust_shots = 0;
                }
                $reps['trust_shots'] = $trust_shots ?? 0;
                // $countOfOldReps = $swings + $trust_reps + $old_move_drills + $oldRecallCardCount + $total_manual_reps_movement_drills + $total_manual_reps_recall_card + $total_manual_reps_swing_drills + $total_manual_reps_trust;
                // $countOfReps = $swings + $trust_reps + $all_userMovementDrillCount + $userRecallCardsCount + $total_manual_reps_movement_drills + $total_manual_reps_recall_card + $total_manual_reps_swing_drills + $total_manual_reps_trust;
                $reps['session_reps'] = $sumReps + $userRecallCardsCountSession ?? 0; 
               
                $reps['total_reps'] = $reps['trust_reps'] + $reps['swing_drills'] + $reps['move_drills'] + $reps['recall_cards'] ?? 0; 
                $reps['total_old_reps'] =  $reps['total_reps'] - $reps['session_reps'] ?? 0;
                $newRoot['reps'] = $reps;
                //$todayDate = now()->format('Y-m-d');
                // $trainingStreakData = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$todayDate)->first();
                // $current_training_streak = $trainingStreakData->current_streak ?? 0;
                // $newRoot['training_streak'] = $current_training_streak ?? 0;
                $newRoot['training_streak'] = $user->training_streak ?? 0;
                $today = new DateTime();
                $yesterday = $today->modify('-1 day')->format('Y-m-d');
                $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
                if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                    $newRoot['show_blue'] = 1;
                    $newRoot['training_streak'] = $user->mulligan ?? 1;
                }else{
                    $newRoot['show_blue'] = 0;
                }
                $newRoot['max_training_streak'] = $user->max_training_streak ?? ($user->training_streak ?? 0);
                
                //show weekly form code;
                $showWeeklyForm = 0;
                $countries = Country::pluck('timezone','_id')->toArray();
                $userDetail = User::find($user["_id"]);
                $userTimezone = $countries[$userDetail->country_id] ?? "";
                if($userTimezone != ""){
                    if (Carbon::now($userTimezone)->isSunday()) {
                        $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                        $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                        $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                            $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                            return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                        });
                        if($filteredWeeklyForms->count() == 0){
                            $showWeeklyForm = 1;
                        }
                    }
                }
                $msg = "";
                $finalTime = "";
                $unlockedSessionIds = UserUnlockedSession::where('user_id',$user["_id"])->groupBy('session_id')->pluck("session_id")->toArray();
               
                $userSessionProgressIds = UserSessionProgress::where('user_id',$user["_id"])->whereIn('session_id',$unlockedSessionIds)->groupBy('session_id')->pluck("session_id")->count();
              
                // if(sizeof($unlockedSessionIds) > $userSessionProgressIds){
                //     $msg = "You can wrap up for today, or do another session.  Your call.";
                //     $daily_unlock = false;
                // }else{
                //     $hour = (int)$user->hour ?? "";
                //     $min = (int)$user->min ?? "";
                //     $timeAM = Str::lower($user->time)?? "";
                //     if($hour != "" && $min != "" && $hour > 0 ){
                //         $time = $hour. ":". $min;
                //         $parsedTime = Carbon::parse($time);
                //         $finalTime  =  $parsedTime->format('g:i')." ".$timeAM;
                //     }
                //     $daily_unlock = true;
                //     $msg = "See you tomorrow at ".$finalTime." for your next session.";
                // }
                $daily_unlock = false;
                $msg = "You can wrap up for today, or do another session.  Your call.";
                $newRoot['daily_unlock'] = $daily_unlock;
                $feedback_switch = $user->weekly_rating_switch ?? false;
                if($feedback_switch){
                    $showWeeklyForm = 1;
                }
                $newRoot['weekly_rating_switch'] = $feedback_switch;
                $newRoot['show_weekly_form'] = $showWeeklyForm;
                $newRoot['session_closing_msg'] = $msg;
                return ApiResponse::success($newRoot,'User Unit Progress fetch successfully after session closing');
            }
            
            // Return the response
           // return ApiResponse::success($unitData, 'Session closing details is here.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: overview of trust /shot-check for app
    */
    public function getOverview($type = "trust")
    {
        try {
            if (!$type) {
                return ApiResponse::error('Type is required');
            }
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($type != "trust"){
                $type = "shot-check";
            }
            $overview_data = TrustOverview::where('type',$type)->first();
            if(empty($overview_data)){
                $overview_data =[
                    'is_save' => false,
                    'headline' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
                    'text' => 'Lorem ipsum dolor sit amet, consectetur',
                    'time' => '',
                    'description' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><br><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>'
                ];
            }
            if($type == "trust"){
                $overview_data['trust_key'] = '';
            }
            $overviewData =[];
            
            if($type == "trust"){
                $overviewData['trust_key'] = TrustKey::first()->trust_key ?? "";
                $title = "Trust";
            }else{
                $title = "Shot Check";
            }
            $is_save = false;
            if($overview_data){
                $savedItem = SavedItems::where('type',$type)->where('user_id',$user['userid'])->where('saved_item_id',now()->format('d-m-Y'))->first();
                if($savedItem){
                    $is_save = true;
                }
                $overviewData['id'] = $overview_data['_id'] ?? null;
                $overviewData['type'] = $title ?? "";
                $overviewData['headline'] = $overview_data['headline'] ?? "";
                $overviewData['text'] = $overview_data['text'] ?? "";
                $overviewData['time'] = "";
                $overviewData['is_save'] = $is_save;
                $overviewData['description'] = $overview_data['description'] ?? "";
                $overviewData = [$overviewData];
            }else{
                $overviewData = [];
            }
            return ApiResponse::success($overviewData, 'Overview of '.$title.' found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function SubmitToCoachSwing($id){
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            if($user){
                $swing = Swing::where('user_id',$user["_id"])->where("_id",$id)->first();
                if($swing){
                    if($swing->submit_to_coach === true){
                        return ApiResponse::error('Swing already submitted before for coach review.');
                    }
                    $today = now()->format("Y-m-d");
                    $user_active_coach_review = UserCoachReview::where('user_id',$user["userid"])->where('expiration_date','>=',$today)->where('status','active')->orderBy('created_at')->first();
                   
                    if($user_active_coach_review){
                        $swing->submit_to_coach = true;
                        $swing->save();
                        $newUsedCoachReview = $user_active_coach_review->used_coach_review + 1;
                        $user_active_coach_review->used_coach_review = $newUsedCoachReview;
                        if($user_active_coach_review->coach_review == $newUsedCoachReview ){
                            $user_active_coach_review->status = "expired";
                        }
                        $user_active_coach_review->save();
                        $coach = User::where('user_type','coach')->get();
                        foreach ($coach as $admin) {
                            $coach_name = $admin->full_name ?? "";
                            $user_name = User::find($swing->user_id)->full_name ?? "";
                            Mail::to($admin->email)->send(new CoachReminderEmail($swing->_id, $coach_name, $user_name));
                        }
                    }else{
                        return ApiResponse::error('Insufficient coach review balance. Please buy coach review first.');
                    }
                    return ApiResponse::success(true,'Swing video submitted for coach review');
                }else{
                    return ApiResponse::error('Swing not found.');
                }
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function SubmitToCoachRep($id){
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            if($user){
                $rep_video = RepReview::where('user_id',$user["_id"])->where("_id",$id)->first();
                if($rep_video){
                    if($rep_video->submit_to_coach === true){
                        return ApiResponse::error('Rep video already submitted before for coach review.');
                    }
                    $rep_video->submit_to_coach = true;
                    $rep_video->status = "Sent";
                    $rep_video->save();
                
                    $coach = User::where('user_type','coach')->get();
                    foreach ($coach as $admin) {
                        $coach_name = $admin->full_name ?? "";
                        $user_name = User::find($rep_video->user_id)->full_name ?? "";
                        Mail::to($admin->email)->send(new CoachReminderEmail($rep_video->_id, $coach_name, $user_name));
                    }
                    return ApiResponse::success(true,'Rep video submitted for coach review');
                }else{
                    return ApiResponse::error('Rep video not found.');
                }
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getSearchCategory(){
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $category = [];
            $category['Unit'] = 'Unit';
            $category['Train'] = 'Train';
            $category['Apply'] = 'Apply';
            $category['Shot Check'] = 'Shot Check';
            $category['Swing Video'] = 'Swing Video';
            $category['Coach Review'] = 'Coach Review';
            $category['Recall Cards'] = 'Recall Cards';
            $category['Locker'] = 'Locker';
            $category['Settings'] = 'Settings';
            $category['Help'] = 'Help';
            $date = now()->format('Y-m-d');
            $searchRecent = RecentSearch::where('user_id',$user["userid"])->where('date',$date)->select('search')->get();
            $latest_viewed = [];
            $newRoot =[
                'category' => $category,
                'recent_search' => $searchRecent,
                'latest_viewed' => $latest_viewed
            ];
            return ApiResponse::success($newRoot,'country with timezone successfully');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getSearch(Request $request){
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $defaultProgram = env('DEFAULT_PROGRAM');
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(!empty($request->category)){
                $category = $request->category ?? "Unit";
            }
            $appUrl = env('AWS_S3_PATH');
            $filteredData = [];
            if(!empty($request->search)){   
                $search_item = new RecentSearch();
                $search_item->search = $request->search;
                $search_item->category = $category;
                $search_item->date = now()->format("Y-m-d");
                $search_item->user_id = $user["userid"];
                $search_item->save();
                if($category == "Recall Cards"){
                    $user_recall_cards = UserRecallCards::where('user_id',$user["userid"])->pluck('recall_card_id')->toArraY();
                    $recall_cards = RecallCard::whereIn('_id',$user_recall_cards)
                                    ->where('title','like', '%' . $request->search . '%')
                                    ->where('question_text','like', '%' . $request->search . '%')
                                    ->where('answer_text','like', '%' . $request->search . '%')->get();
                    $recallCardsData = [];
                    foreach ($recall_cards as $key => $value) {
                        $tagData = [];
                        if(!empty($value->tag)){
                            $recallCard_tag = explode(",",$value->tag);
                            if(!empty($recallCard_tag)){
                                foreach ($recallCard_tag as $keyy => $tag) {
                                    $tagData[] = $tags[$tag] ?? "";
                                }
                            }
                        }
                        $filteredArray = array_filter($tagData, function ($value) {
                            return !empty($value);
                        });
                        $recallCardsData[$key]['_id'] = $value['_id'];
                        $recallCardsData[$key]['show'] = $value['show'] ?? true;
                        $recallCardsData[$key]['title'] = $value['title'];
                        $recallCardsData[$key]['question_text'] = $value['question_text'];
                        $recallCardsData[$key]['answer_text'] = $value['answer_text'];
                        $recallCardsData[$key]['question_img'] = $value['question_img'];
                        $recallCardsData[$key]['answer_img'] = $value['answer_img'];
                        $recallCardsData[$key]['level'] = $value['level'];
                        $recallCardsData[$key]['updated_at'] = $value['updated_at'];
                        $recallCardsData[$key]['created_at'] = $value['created_at'];
                        $recallCardsData[$key]['tag'] =  $value['tag'] ?? null;
                        $recallCardsData[$key]['tagName'] =  implode(",",$filteredArray);
                    }                
                    $filteredData = $recallCardsData;
                }
                if($category == "Coach Review"){
                    $filteredData = Functions::coachReview($user, $request->search);
                }
                if($category == "Swing Video"){
                    $filteredData = Functions::swing($user, $request->search);
                }
                if($category == "Unit" || $category == "Train" || $category == "Apply"){
                    $userUnitProgress = UserSessionProgress::where('user_id',$user['_id'])->get();
                    $unitData = [];
                    $objectIds = [];
                    $sessionIds = [];
                    $savedSessionIds = SavedItems::where('user_id',$user['userid'])->pluck('saved_item_id')->toArray();
                    $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                    $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
                    if($category != "Unit"){
                        $categoryType = CategoryType::where('name', 'LIKE', $category)->first();
                        if(!empty($user->group_id)){
                            $group = Group::find($user->group_id);
                            if($group){
                                $unitIds = array_column($group["group_object"], "object_id");
                                $unit = Unit::where('unit_name','like', '%' . $request->search . '%')->where('category_type_id', $categoryType["_id"])->whereIn('_id', $unitIds )->get();
                            }else{
                                $unit = Unit::where('unit_name','like', '%' . $request->search . '%')->where('category_type_id', $categoryType["_id"])->whereIn('_id', $default_unitIds )->get();
                            }
                        }else{
                            $unit = Unit::where('unit_name','like', '%' . $request->search . '%')->where('category_type_id', $categoryType["_id"])->whereIn('_id', $default_unitIds )->get();
                        }
                    }else{
                        if(!empty($user->group_id)){
                            $group = Group::find($user->group_id);
                            if($group){
                                $unitIds = array_column($group["group_object"], "object_id");
                                $unit = Unit::where('unit_name','like', '%' . $request->search . '%')->whereIn('_id', $unitIds )->get();
                            }else{
                                $unit = Unit::where('unit_name','like', '%' . $request->search . '%')->whereIn('_id', $default_unitIds )->get();
                            }
                        }else{
                            $unit = Unit::where('unit_name','like', '%' . $request->search . '%')->whereIn('_id', $default_unitIds )->get();
                        }
                    }
                    foreach ($unit as $value) {
                        $unitObjectIds = array_column($value["unit_object"], "object_id");
                        $objectIds = array_merge($objectIds, $unitObjectIds);
                        $sessionIds = array_merge($sessionIds, $unitObjectIds);
                    }
                    $objectIds = array_unique($objectIds);
                    $sessionIds = array_unique($sessionIds);
                    $valueSessionDataArray = Session::whereIn('_id', $sessionIds)->get()->keyBy('_id');
                    foreach ($unit as $key => $value) {
                        $unitData[$key]['id'] =  $value["_id"];
                        $unitData[$key]['title'] =  $value["unit_name"];
                        $unitData[$key]['order'] =  (int)$value["order"];
                        $unitData[$key]['percentage'] =  0 . '%';
                        $noOfSession = 0;
                        $unitObjectCount = count($value["unit_object"]);
                        if ($unitObjectCount > 0) {
                            $session = [];
                            foreach ($value["unit_object"] as $unitObject) {
                                $percentage = 0;
                                $valueSessionData = $valueSessionDataArray->get($unitObject["object_id"]);
                                if ($valueSessionData) {
                                    $totalSessionDuration = 0;
                                    $objIds = array_column($valueSessionData["session_object"], "object_id");
                                
                                    $valueObjData = UserObjectType::whereIn('_id',$objIds)->pluck('object_time')->toArray();
                                    if (sizeOf($valueObjData) > 0) {
                                        $totalSessionDuration = array_sum($valueObjData);
                                    }
                                    $session[$unitObject["object_id"]]['id'] = $valueSessionData->_id;
                                    if (in_array($valueSessionData->_id, $savedSessionIds)) {
                                        $session[$unitObject["object_id"]]['saved'] = true;
                                    }else{
                                        $session[$unitObject["object_id"]]['saved'] = false;
                                    }
                                    $session[$unitObject["object_id"]]['seen'] = false;
                                    $session[$unitObject["object_id"]]['unit_id'] = $value["_id"];
                                    $session[$unitObject["object_id"]]['title'] = $valueSessionData->session_name;
                                    $session[$unitObject["object_id"]]['internal_session_name'] = $valueSessionData->internal_session_name ?? "";
                                    
                                    $session[$unitObject["object_id"]]['headline'] = $valueSessionData->headline ?? '';
                                    $session[$unitObject["object_id"]]['text'] = $valueSessionData->text ?? '';
                                    $session[$unitObject["object_id"]]['thumbnail'] = $appUrl.'thumbnail_old.png';
                                    $session[$unitObject["object_id"]]['duration'] = number_format($totalSessionDuration,2);
                                    $countUserUnitProgress = $userUnitProgress->where('unit_id',$value["_id"])->where('session_id',$valueSessionData->_id)->whereIn('object_id', $objIds)->pluck('object_id')->unique()->count();
                                    $countValSessionData = count($valueSessionData->session_object);
                                    if ($countUserUnitProgress == $countValSessionData) {
                                        $noOfSession++;
                                        $session[$unitObject["object_id"]]['seen'] = true;
                                    }
                                    if ($countUserUnitProgress > 0 && $countValSessionData > 0) {
                                        $percentage = ($countUserUnitProgress /$countValSessionData) * 100;
                                    }
                                    $session[$unitObject["object_id"]]['percentage'] = number_format($percentage, 2) . '%';
                                }
                            }
                        }
                        if ($noOfSession > 0 && $unitObjectCount > 0) {
                            $unitData[$key]['percentage'] = $noOfSession / $unitObjectCount * 100 . '%';
                        }
                        $unitData[$key]['session'] = array_values($session);
                    }
                    $unitData = Functions::sortArray($unitData,'order');
                    $filteredData = array_filter($unitData, function ($item) {
                        return isset($item['session']);
                    });
                    $filteredData = array_values($filteredData);
                }
                if($category == "Shot Check"){
                    $newRoot = [];
                    $shotCheckDates = UserShotCheck::where('user_id',$user['userid'])
                                        ->where(function($query) use ($request) {
                                            $searchTerm = '%' . $request->search . '%';
                                            $query->where('date', 'like', $searchTerm)
                                                ->orWhere('location', 'like', $searchTerm)
                                                ->orWhere('distance', 'like', $searchTerm)
                                                ->orWhere('direction', 'like', $searchTerm)
                                                ->orWhere('curve', 'like', $searchTerm)
                                                ->orWhere('contact', 'like', $searchTerm)
                                                ->orWhere('face', 'like', $searchTerm);
                                        })->groupBy('date')->orderBy('date','desc')->pluck('date')->toArray();
                    foreach ($shotCheckDates as $currentDate) {
                        $shotChecks = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->get();
                        //$shotCheckCount = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->count();
                        $newRoot[] = [
                            'date' => $currentDate,
                            'shot_check_count' => $shotChecks->count(),
                            'shot_checks' => $shotChecks,
                        ];
                    }
                    $filteredData = $newRoot;
                }
                if($category == "Trust"){
                    $newRoot = [];
                    $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->where('trust_hole_no','!=',NULL)
                                        ->where(function($query) use ($request) {
                                            $searchTerm = '%' . $request->search . '%';
                                            $query->where('trust_hole_no', 'like', $searchTerm)
                                                ->orWhere('hole_type', 'like', $searchTerm)
                                                ->orWhere('date', 'like', $searchTerm)
                                                ->orWhere('location', 'like', $searchTerm)
                                                ->orWhere('temperature', 'like', $searchTerm)
                                                ->orWhere('warm_up_time', 'like', $searchTerm)
                                                ->orWhere('direction', 'like', $searchTerm)
                                                ->orWhere('alignment', 'like', $searchTerm)
                                                ->orWhere('trust_key_percent', 'like', $searchTerm)
                                                ->orWhere('pre_shot_percent', 'like', $searchTerm)
                                                ->orWhere('post_shot_percent', 'like', $searchTerm)
                                                ->orWhere('curve', 'like', $searchTerm)
                                                ->orWhere('contact', 'like', $searchTerm)
                                                ->orWhere('face', 'like', $searchTerm);
                                        })->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                    $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                        return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                    })->values()->all();
                    foreach ($sortedDates as $currentDate) {
                        $shotCheckDrives = UserTrustHole::where('date',$currentDate)->where('hole_type','Drive')->where('user_id',$user['userid'])->get();
                        $shotCheckApproach = UserTrustHole::where('date',$currentDate)->where('hole_type','Approach')->where('user_id',$user['userid'])->get();
                        $trustHoleDataArray = [];
                        for ($i=1; $i <=18 ; $i++) {
                            $is_drive_data =  $shotCheckDrives->firstWhere('trust_hole_no', $i);
                            $is_approach_data = $shotCheckApproach->firstWhere('trust_hole_no', $i);
                            if(($is_drive_data) || ($is_approach_data)){
                                $trustHoleData['trust_hole_no'] = $i;
                                $trustHoleData['drive'] = [
                                    'direction' => $is_drive_data->direction ?? "",
                                    'curve' => $is_drive_data->curve ?? "",
                                    'contact' => $is_drive_data->contact ?? "",
                                    'face' => $is_drive_data->face ?? "",
                                    'alignment' => $is_drive_data->alignment ?? "",
                                    'distance' => $is_drive_data->distance ?? "",
                                ];
                                $trustHoleData['approach'] = [
                                    'direction' => $is_approach_data->direction ?? "",
                                    'curve' => $is_approach_data->curve ?? "",
                                    'contact' => $is_approach_data->contact ?? "",
                                    'face' => $is_approach_data->face ?? "",
                                    'alignment' => $is_approach_data->alignment ?? "",
                                    'distance' => $is_approach_data->distance ?? "",
                                ];
                                array_push($trustHoleDataArray,$trustHoleData);
                            }
                        }
                        $trustHoleMarkedDetails = 0;
                        $trustHoleMarkedDetails = UserTrustHole::where('date', $currentDate)
                                                    ->where('user_id', $user['userid'])
                                                    ->whereNotNull('trust_hole_no')
                                                    ->whereNotNull('hole_type')
                                                    ->pluck('trust_hole_no')
                                                    ->unique()
                                                    ->count();
                        $trustHoleDetails = UserTrustHole::where('date',$currentDate)->where('user_id',$user['userid'])->where('trust_key_percent','!=',NULL)->first();
                        $newRoot[] = [
                            'date' => $currentDate,
                            'trust_hole_marked_count' => $trustHoleMarkedDetails,
                            'trustHoles' => $trustHoleDataArray,
                            'trust_key_percent' => $trustHoleDetails->trust_key_percent ?? 0,
                            'pre_shot_percent' => $trustHoleDetails->pre_shot_percent ?? 0,
                            'post_shot_percent' => $trustHoleDetails->post_shot_percent ?? 0
                        ];
                    }
                    $filteredData = $newRoot;
                }
            }
            return ApiResponse::success($filteredData,'searched data found');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: trust quote for user
    */
    public function getTrustQuote()
    {
        try{
            $quote = TrustQuote::first();
            if(!$quote){
                $quote = [];
            }else{
                $quote = [$quote];
            }
            return ApiResponse::success($quote,'Trust quote found successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: locker's detail for each listing type like, history, saved, coach_review and swing
    */
    public function getLockerDetail(Request $request,$slug = 'history')
    {
        try{
            if(!$slug){
                return ApiResponse::error('Slug are required');
            }
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            switch ($slug) {
                case 'history':
                    $finalData = Functions::lockerDetailHistory($user);
                    return ApiResponse::success($finalData,'User Session history found successfully.');
                    break;

                case 'saved':
                    $finalDataSaved = Functions::mySaved($user);
                    return ApiResponse::success($finalDataSaved,'User saved Session found successfully.');
                    break;

                case 'coach_review':
                    $finalDataReview = Functions::coachReview($user);
                    return ApiResponse::success($finalDataReview,'Coach review found successfully.');
                    break;

                case 'swing':
                    $finalDataReview = Functions::swing($user);
                    return ApiResponse::success($finalDataReview,'Swing video found successfully.');
                    break;
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Once object is finished user call below and mark as completed 
    */
    public function getCompleteMarkold($id,$session_id,$unit_id = "")
    {
        try{
            $showWeeklyForm = 0;
            if (!$id) {
                return ApiResponse::error('Object id required');
            }
            if (!$session_id) {
                return ApiResponse::error('Session id required');
            }
            $today = now()->format('Y-m-d');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $object = UserObjectType::find($id);
            $countries = Country::pluck('timezone','_id')->toArray();
            //get user session progress detail
            $userSessionProgressQ = UserSessionProgress::where('user_id', $user["_id"]);
            
            if($session_id != ""){
                $userSessionProgressQ = $userSessionProgressQ->where('session_id',$session_id);
            }
            if($unit_id != ""){
                $userSessionProgressQ = $userSessionProgressQ->where('unit_id',$unit_id);
            }
            $userSessionProgress = $userSessionProgressQ->where('object_id', $id)->first();
            $recallCards = 0;
            $shoRecallCard = false;
            $checkRecall = false;
            $userDetail = User::find($user["_id"]);
            $training_streak = $userDetail->training_streak ?? 0;
            $max_training_streak = $userDetail->max_training_streak ?? ($userDetail->training_streak ?? 0);
            if(!$userSessionProgress){
                $userSessionProgress = new UserSessionProgress;
                $userSessionProgress->user_id = $user["_id"];
                $userSessionProgress->session_id = $session_id;
                $userSessionProgress->unit_id = $unit_id ?? "";
                $userSessionProgress->object_id = $id;
                $userSessionProgress->save();
            }
            //Recap session is not giving a user reps thts why changed
            $userMovementDrill = new UserMovementDrill();
            $userMovementDrill->user_id = $user["_id"];
            $userMovementDrill->unit_id = $unit_id ?? "";
            $userMovementDrill->session_id = $session_id;
            $userMovementDrill->object_id = $id;
            $userMovementDrill->reps = (int)$object->reps ?? 0;
            $userMovementDrill->save();
            //assign recall card as session of this object already finished now
            $session_data = Session::find($session_id);
            $sessionObjs = count($session_data["session_object"]) ?? 0;
            $objIds = array_column($session_data["session_object"], "object_id");
            $recallCardId = array_column($session_data["recall_cards"], "recall_card_id");
            $recallCards = $session_data['recall_cards'];
            $recallCardsCnt = count($recallCards) ?? 0;
            $recapTime = 0;
            $sessionMoveDrillsEntryCount = UserMovementDrill::where('session_id',$session_id)->where('unit_id',$unit_id)->where('user_id', $user['_id'])->whereIn('object_id',$objIds)->count();
            if($sessionObjs != 0){
                $recapTime = $sessionMoveDrillsEntryCount/$sessionObjs;
            }
            if($recapTime > 1)
            {
                if (is_int($recapTime)) {
                    $sessionRecapTimeCount = SessionRecapTime::where('session_id',$session_id)->where('unit_id',$unit_id)->where('user_id', $user['_id'])->count();
                    $sessionRecapTime = $recapTime - 1;
                    if($sessionRecapTimeCount == $sessionRecapTime){
                    }else{
                        $sessionRecapTime = new SessionRecapTime();
                        $sessionRecapTime->user_id = $user["_id"];
                        $sessionRecapTime->session_id = $session_id;
                        $sessionRecapTime->unit_id = $unit_id;
                        $sessionRecapTime->recap_reps = $recallCardsCnt;
                        $sessionRecapTime->save();
                    }
                }
            }
            
            $userSessionProgressCheckFinishedQ = UserSessionProgress::where('user_id', $user["_id"])->where('session_id', $userSessionProgress->session_id)->whereIn('object_id',$objIds);
            if($unit_id != ""){
                $userSessionProgressCheckFinishedQ = $userSessionProgressCheckFinishedQ->where('unit_id', $userSessionProgress->unit_id);
            }
            $userSessionProgressCheckFinished = $userSessionProgressCheckFinishedQ->count();
           
            $recallCardsCount = UserRecallCards::where('session_id',$userSessionProgress->session_id)->whereIn('recallCardId',$recallCardId)->where('user_id',$user['userid'])->count();
            
            if($userSessionProgressCheckFinished >= $sessionObjs){
                if(!empty($recallCards) && (count($recallCards) != $recallCardsCount)){
                    UserRecallCards::where('session_id',$userSessionProgress->session_id)->where('user_id',$user['userid'])->delete();
                    foreach ( $recallCards as $keyx => $recall_card) {
                        $userRecallCards = new UserRecallCards();
                        $userRecallCards->user_id = $user['userid'];
                        $userRecallCards->session_id = $session_id;
                        $userRecallCards->interval = 1;
                        $userRecallCards->due_date = now()->format('Y-m-d');
                        $userRecallCards->recall_card_id = $recall_card['recall_card_id'];
                        $userRecallCards->save();
                    }
                }
                $mulligan = $user->mulligan ?? 0;
                if(empty($userDetail->last_updated_training_streak ) || $userDetail->last_updated_training_streak == "" || $userDetail->last_updated_training_streak == null){
                    $training_streak = 1;
                    $max_training_streak = 1;
                }else{
                    $lastDate = $userDetail->last_updated_training_streak;
                    if($today != $lastDate || $userDetail->training_streak == 0){
                        $last_updated_training_streak = new DateTime($lastDate);
                        $current_date = new DateTime($today);
                        $interval = $current_date->diff($last_updated_training_streak);
                        $max_training_streak = $userDetail->max_training_streak ?? 1;
                        $yesterday = $current_date->modify('-1 day')->format('Y-m-d');
                        
                        //check if last_updated date of training is not yesterday
                        if((int)$interval->format('%R%a') == 0 && $userDetail->training_streak == 0){
                            $training_streak = $training_streak + 1;
                            $mulligan = 0;
                        }else if((int)$interval->format('%R%a') < -1){
                            $findMulligan = UserTrainingStreak::where('date',$yesterday)->where('mulligan',1)->where('user_id',$user->userid)->first();
                            if($findMulligan){
                                $training_streak = $training_streak + 1;
                                $mulligan = 0;
                            }else{
                                $training_streak = 1;
                            }
                             //check if last_updated date of training is  yesterday
                        }else if((int)$interval->format('%R%a') == -1){
                            $training_streak = $training_streak + 1;
                        }else{
                            $training_streak = $user->training_streak;
                            $today = $userDetail->last_updated_training_streak;
                        }
                    }else{
                        $training_streak = $user->training_streak;
                        $today = $userDetail->last_updated_training_streak;
                    }
                }
                $userDetail->training_streak = $training_streak;
                if($training_streak > $max_training_streak){
                    $userDetail->max_training_streak = $training_streak;
                }
                $userDetail->last_updated_training_streak = $today;
                $userDetail->mulligan = 0;
                // $userDetail->mulligan = $mulligan;
                $userDetail->save();
                
                //add user training streak logs
                $userTrainingStreak = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$today)->first();
                if($userTrainingStreak){
                    if($userTrainingStreak->current_streak == 0){
                        $userTrainingStreak->current_streak = $userDetail->training_streak ?? 1;
                        $userTrainingStreak->mulligan = 0;
                        $userTrainingStreak->save();
                    }
                }else{
                    $userTrainingStreak = new UserTrainingStreak();
                    $userTrainingStreak->user_id = $user['userid'];
                    $userTrainingStreak->date = $today;
                    $userTrainingStreak->current_streak = $userDetail->training_streak ?? 1;
                    $userTrainingStreak->mulligan = 0;
                    $userTrainingStreak->save();
                }
                //show weekly form code;
                $userTimezone = $countries[$userDetail->country_id] ?? "";
                if($userTimezone != ""){
                    if (Carbon::now($userTimezone)->isSunday()) {
                        $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                        $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                        $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                            $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                            return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                        });
                        if($filteredWeeklyForms->count() == 0){
                            $showWeeklyForm = 1;
                        }
                    }
                }
            }
            
            $recallCardsCount_ = UserRecallCards::where('session_id',$userSessionProgress->session_id)->where('user_id',$user['userid'])->count();
            if($recallCardsCount_ > 0){
                $shoRecallCard = true;
            }
           
            $newRoot = [
                'show_recall_card' => $shoRecallCard,
                'show_weekly_form' => $showWeeklyForm
            ];
            return ApiResponse::success($newRoot, 'User completed that object successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCompleteMark($id,$session_id,$unit_id = "")
    {
        try{
            $showWeeklyForm = 0;
            if (!$id) {
                return ApiResponse::error('Object id required');
            }
            if (!$session_id) {
                return ApiResponse::error('Session id required');
            }
            $today = now()->format('Y-m-d');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $object = UserObjectType::find($id);
            $countries = Country::pluck('timezone','_id')->toArray();
            //get user session progress detail
            $userSessionProgressQ = UserSessionProgress::where('user_id', $user["_id"]);
            
            if($session_id != ""){
                $userSessionProgressQ = $userSessionProgressQ->where('session_id',$session_id);
            }
            if($unit_id != ""){
                $userSessionProgressQ = $userSessionProgressQ->where('unit_id',$unit_id);
            }
            $userSessionProgress = $userSessionProgressQ->where('object_id', $id)->first();
            $recallCards = 0;
            $shoRecallCard = false;
            $checkRecall = false;
            $userDetail = User::find($user["_id"]);
            $max_training_streak = $userDetail->max_training_streak ?? ($userDetail->training_streak ?? 0);
            if(!$userSessionProgress){
                $userSessionProgress = new UserSessionProgress;
                $userSessionProgress->user_id = $user["_id"];
                $userSessionProgress->session_id = $session_id;
                $userSessionProgress->unit_id = $unit_id ?? "";
                $userSessionProgress->object_id = $id;
                $userSessionProgress->save();
            }
            //Recap session is not giving a user reps thts why changed
            $userMovementDrill = new UserMovementDrill();
            $userMovementDrill->user_id = $user["_id"];
            $userMovementDrill->unit_id = $unit_id ?? "";
            $userMovementDrill->session_id = $session_id;
            $userMovementDrill->object_id = $id;
            $userMovementDrill->reps = (int)$object->reps ?? 0;
            $userMovementDrill->save();
            //assign recall card as session of this object already finished now
            $session_data = Session::find($session_id);
            $sessionObjs = count($session_data["session_object"]) ?? 0;
            $objIds = array_column($session_data["session_object"], "object_id");
            $recallCardId = array_column($session_data["recall_cards"], "recall_card_id");
            $recallCards = $session_data['recall_cards'];
            $recallCardsCnt = count($recallCards) ?? 0;
            $recapTime = 0;
            $sessionMoveDrillsEntryCount = UserMovementDrill::where('session_id',$session_id)->where('unit_id',$unit_id)->where('user_id', $user['_id'])->whereIn('object_id',$objIds)->count();
            if($sessionObjs != 0){
                $recapTime = $sessionMoveDrillsEntryCount/$sessionObjs;
            }
            if($recapTime > 1)
            {
                if (is_int($recapTime)) {
                    $sessionRecapTimeCount = SessionRecapTime::where('session_id',$session_id)->where('unit_id',$unit_id)->where('user_id', $user['_id'])->count();
                    $sessionRecapTime = $recapTime - 1;
                    if($sessionRecapTimeCount == $sessionRecapTime){
                    }else{
                        $sessionRecapTime = new SessionRecapTime();
                        $sessionRecapTime->user_id = $user["_id"];
                        $sessionRecapTime->session_id = $session_id;
                        $sessionRecapTime->unit_id = $unit_id;
                        $sessionRecapTime->recap_reps = $recallCardsCnt;
                        $sessionRecapTime->save();
                    }
                }
            }
            
            $userSessionProgressCheckFinishedQ = UserSessionProgress::where('user_id', $user["_id"])->where('session_id', $userSessionProgress->session_id)->whereIn('object_id',$objIds);
            if($unit_id != ""){
                $userSessionProgressCheckFinishedQ = $userSessionProgressCheckFinishedQ->where('unit_id', $userSessionProgress->unit_id);
            }
            $userSessionProgressCheckFinished = $userSessionProgressCheckFinishedQ->count();
           
            $recallCardsCount = UserRecallCards::where('session_id',$userSessionProgress->session_id)->whereIn('recallCardId',$recallCardId)->where('user_id',$user['userid'])->count();
            $userTimezone = $countries[$userDetail->country_id] ?? "UTC";
            $currentDateTime = Carbon::now($userTimezone);
            $currentDateInUserTimezone = $currentDateTime->format('Y-m-d');
            $yesterdayDate = $currentDateTime->subDay()->format('Y-m-d');
           
            if($userSessionProgressCheckFinished >= $sessionObjs){
                if(!empty($recallCards) && (count($recallCards) != $recallCardsCount)){
                    UserRecallCards::where('session_id',$userSessionProgress->session_id)->where('user_id',$user['userid'])->delete();
                    foreach ( $recallCards as $keyx => $recall_card) {
                        $userRecallCards = new UserRecallCards();
                        $userRecallCards->user_id = $user['userid'];
                        $userRecallCards->session_id = $session_id;
                        $userRecallCards->interval = 1;
                        $userRecallCards->due_date = now()->format('Y-m-d');
                        $userRecallCards->recall_card_id = $recall_card['recall_card_id'];
                        $userRecallCards->save();
                    }
                }
                $userTrainingStreakToday = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$currentDateInUserTimezone)->first();
                
                if($userTrainingStreakToday ){
                    if($userTrainingStreakToday->current_streak == 0){
                        $userTrainingStreakYesterday = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$yesterdayDate)->first();
                        if($userTrainingStreakYesterday){
                            $training_streak = $userTrainingStreakYesterday->current_streak + 1;
                        }else{
                            $training_streak = 1; 
                        }
                        $userTrainingStreakToday->current_streak = $training_streak;
                        $userTrainingStreakToday->mulligan = 0;
                        $userTrainingStreakToday->save();
                        if($training_streak > $max_training_streak){
                            $userDetail->max_training_streak = $training_streak;
                        }
                        $userDetail->training_streak = $userTrainingStreakToday->current_streak ?? 1;
                        $userDetail->last_updated_training_streak = $currentDateInUserTimezone;
                        $userDetail->save();
                    }
                }else{
                    $userTrainingStreakYesterday = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$yesterdayDate)->first();
                    if($userTrainingStreakYesterday){
                        $training_streak = $userTrainingStreakYesterday->current_streak + 1;
                    }else{
                        $training_streak = 1; 
                    }
                    $userTrainingStreakToday = new UserTrainingStreak();
                    $userTrainingStreakToday->user_id = $user['userid'];
                    $userTrainingStreakToday->date = $currentDateInUserTimezone;
                    $userTrainingStreakToday->current_streak = $training_streak ?? 1;
                    $userTrainingStreakToday->mulligan = 0;
                    $userTrainingStreakToday->save();
                    if($training_streak > $max_training_streak){
                        $userDetail->max_training_streak = $training_streak;
                    }
                    $userDetail->training_streak = $userTrainingStreakToday->current_streak ?? 1;
                    $userDetail->last_updated_training_streak = $currentDateInUserTimezone;
                    $userDetail->save();
                }
                //show weekly form code
                if (Carbon::now($userTimezone)->isSunday()) {
                    $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                    $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                        $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                        return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                    });
                    if($filteredWeeklyForms->count() == 0){
                        $showWeeklyForm = 1;
                    }
                }
            }
            
            $recallCardsCount_ = UserRecallCards::where('session_id',$userSessionProgress->session_id)->where('user_id',$user['userid'])->count();
            if($recallCardsCount_ > 0){
                $shoRecallCard = true;
            }
           
            $newRoot = [
                'show_recall_card' => $shoRecallCard,
                'show_weekly_form' => $showWeeklyForm
            ];
            return ApiResponse::success($newRoot, 'User completed that object successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCompleteMarkStreakOldStr($id,$session_id,$unit_id = "")
    {
        try{
            $showWeeklyForm = 0;
            if (!$id) {
                return ApiResponse::error('Object id required');
            }
            if (!$session_id) {
                return ApiResponse::error('Session id required');
            }
            $today = now()->format('Y-m-d');
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $object = UserObjectType::find($id);
            $countries = Country::pluck('timezone','_id')->toArray();
            //get user session progress detail
            $userSessionProgressQ = UserSessionProgress::where('user_id', $user["_id"]);
            
            if($session_id != ""){
                $userSessionProgressQ = $userSessionProgressQ->where('session_id',$session_id);
            }
            if($unit_id != ""){
                $userSessionProgressQ = $userSessionProgressQ->where('unit_id',$unit_id);
            }
            $userSessionProgress = $userSessionProgressQ->where('object_id', $id)->first();
            $recallCards = 0;
            $shoRecallCard = false;
            $checkRecall = false;
            $userDetail = User::find($user["_id"]);
            $training_streak = $userDetail->training_streak ?? 0;
            $max_training_streak = $userDetail->max_training_streak ?? ($userDetail->training_streak ?? 0);
            if(!$userSessionProgress){
                $userSessionProgress = new UserSessionProgress;
                $userSessionProgress->user_id = $user["_id"];
                $userSessionProgress->session_id = $session_id;
                $userSessionProgress->unit_id = $unit_id ?? "";
                $userSessionProgress->object_id = $id;
                $userSessionProgress->save();
            }
            //Recap session is not giving a user reps thts why changed
            $userMovementDrill = new UserMovementDrill();
            $userMovementDrill->user_id = $user["_id"];
            $userMovementDrill->unit_id = $unit_id ?? "";
            $userMovementDrill->session_id = $session_id;
            $userMovementDrill->object_id = $id;
            $userMovementDrill->reps = (int)$object->reps ?? 0;
            $userMovementDrill->save();
            //assign recall card as session of this object already finished now
            $session_data = Session::find($session_id);
            $sessionObjs = count($session_data["session_object"]) ?? 0;
            $objIds = array_column($session_data["session_object"], "object_id");
            $recallCardId = array_column($session_data["recall_cards"], "recall_card_id");
            $recallCards = $session_data['recall_cards'];
            $recallCardsCnt = count($recallCards) ?? 0;
            $recapTime = 0;
            $sessionMoveDrillsEntryCount = UserMovementDrill::where('session_id',$session_id)->where('unit_id',$unit_id)->where('user_id', $user['_id'])->whereIn('object_id',$objIds)->count();
            if($sessionObjs != 0){
                $recapTime = $sessionMoveDrillsEntryCount/$sessionObjs;
            }
            if($recapTime > 1)
            {
                if (is_int($recapTime)) {
                    $sessionRecapTimeCount = SessionRecapTime::where('session_id',$session_id)->where('unit_id',$unit_id)->where('user_id', $user['_id'])->count();
                    $sessionRecapTime = $recapTime - 1;
                    if($sessionRecapTimeCount == $sessionRecapTime){
                    }else{
                        $sessionRecapTime = new SessionRecapTime();
                        $sessionRecapTime->user_id = $user["_id"];
                        $sessionRecapTime->session_id = $session_id;
                        $sessionRecapTime->unit_id = $unit_id;
                        $sessionRecapTime->recap_reps = $recallCardsCnt;
                        $sessionRecapTime->save();
                    }
                }
            }
            
            $userSessionProgressCheckFinishedQ = UserSessionProgress::where('user_id', $user["_id"])->where('session_id', $userSessionProgress->session_id)->whereIn('object_id',$objIds);
            if($unit_id != ""){
                $userSessionProgressCheckFinishedQ = $userSessionProgressCheckFinishedQ->where('unit_id', $userSessionProgress->unit_id);
            }
            $userSessionProgressCheckFinished = $userSessionProgressCheckFinishedQ->count();
           
            $recallCardsCount = UserRecallCards::where('session_id',$userSessionProgress->session_id)->whereIn('recallCardId',$recallCardId)->where('user_id',$user['userid'])->count();
            
            if($userSessionProgressCheckFinished >= $sessionObjs){
                if(!empty($recallCards) && (count($recallCards) != $recallCardsCount)){
                    UserRecallCards::where('session_id',$userSessionProgress->session_id)->where('user_id',$user['userid'])->delete();
                    foreach ( $recallCards as $keyx => $recall_card) {
                        $userRecallCards = new UserRecallCards();
                        $userRecallCards->user_id = $user['userid'];
                        $userRecallCards->session_id = $session_id;
                        $userRecallCards->interval = 1;
                        $userRecallCards->due_date = now()->format('Y-m-d');
                        $userRecallCards->recall_card_id = $recall_card['recall_card_id'];
                        $userRecallCards->save();
                    }
                }
                $userTimezone = $countries[$userDetail->country_id] ?? "";
                if($userTimezone != ""){
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                }else{
                    $currentDateInUserTimezone = $today;
                }
                $mulligan = $user->mulligan ?? 0;
                if(empty($userDetail->last_updated_training_streak ) || $userDetail->last_updated_training_streak == "" || $userDetail->last_updated_training_streak == null){
                    $training_streak = 1;
                    $max_training_streak = 1;
                }else{
                    $lastDate = $userDetail->last_updated_training_streak;
                    if($currentDateInUserTimezone != $lastDate || $userDetail->training_streak == 0){
                        $last_updated_training_streak = new DateTime($lastDate);
                        $current_date = new DateTime($currentDateInUserTimezone);
                        $interval = $current_date->diff($last_updated_training_streak);
                        $max_training_streak = $userDetail->max_training_streak ?? 1;
                        $yesterday = $current_date->modify('-1 day')->format('Y-m-d');
                        
                        //check if last_updated date of training is not yesterday
                        if((int)$interval->format('%R%a') == 0 && $userDetail->training_streak == 0){
                            $training_streak = $training_streak + 1;
                            $mulligan = 0;
                        }else if((int)$interval->format('%R%a') < -1){
                            $findMulligan = UserTrainingStreak::where('date',$yesterday)->where('mulligan',1)->where('user_id',$user->userid)->first();
                            if($findMulligan){
                                $training_streak = $training_streak + 1;
                                $mulligan = 0;
                            }else{
                                $training_streak = 1;
                            }
                             //check if last_updated date of training is  yesterday
                        }else if((int)$interval->format('%R%a') == -1){
                            $training_streak = $training_streak + 1;
                        }else{
                            $training_streak = $user->training_streak;
                            $today = $userDetail->last_updated_training_streak;
                        }
                    }else{
                        $training_streak = $user->training_streak;
                        $today = $userDetail->last_updated_training_streak;
                    }
                }
                $userDetail->training_streak = $training_streak;
                if($training_streak > $max_training_streak){
                    $userDetail->max_training_streak = $training_streak;
                }
                $userDetail->last_updated_training_streak = $currentDateInUserTimezone;
                $userDetail->mulligan = 0;
                // $userDetail->mulligan = $mulligan;
                $userDetail->save();

                $userTimezone = $countries[$userDetail->country_id] ?? "";
                if($userTimezone != ""){
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                }else{
                    $currentDateInUserTimezone = $today;
                }
                //add user training streak logs
                $userTrainingStreak = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$currentDateInUserTimezone)->first();
                if($userTrainingStreak){
                    if($userTrainingStreak->current_streak == 0){
                        $userTrainingStreak->current_streak = $userDetail->training_streak ?? 1;
                        $userTrainingStreak->mulligan = 0;
                        $userTrainingStreak->save();
                    }
                }else{
                    $userTrainingStreak = new UserTrainingStreak();
                    $userTrainingStreak->user_id = $user['userid'];
                    $userTrainingStreak->date = $currentDateInUserTimezone;
                    $userTrainingStreak->current_streak = $userDetail->training_streak ?? 1;
                    $userTrainingStreak->mulligan = 0;
                    $userTrainingStreak->save();
                }
                //show weekly form code;
                
                
                if($userTimezone != ""){
                    if (Carbon::now($userTimezone)->isSunday()) {
                        $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                        $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                            $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                            return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                        });
                        if($filteredWeeklyForms->count() == 0){
                            $showWeeklyForm = 1;
                        }
                    }
                }
            }
            
            $recallCardsCount_ = UserRecallCards::where('session_id',$userSessionProgress->session_id)->where('user_id',$user['userid'])->count();
            if($recallCardsCount_ > 0){
                $shoRecallCard = true;
            }
           
            $newRoot = [
                'show_recall_card' => $shoRecallCard,
                'show_weekly_form' => $showWeeklyForm
            ];
            return ApiResponse::success($newRoot, 'User completed that object successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment:  trophy list
    */
    public function getTrophies(Request $request)
    {
        try{
            $searchTerm = $request->input('search');
            $appUrl = env('AWS_S3_PATH');
            $trophyPath = env('AWS_TROPHY_PATH');
            $query = Trophie::query();
            if (!empty($searchTerm)) {
                $query->where('name', 'like', '%' . $searchTerm . '%');
            }
            $trophyData = $query->get()->groupBy('trophie_type');
            $responseData = [];
            foreach ($trophyData as $group => $trophies) {
                $trophyGroup = [
                    'group_name' => $group, // Replace with actual group name
                    'trophies' => [],
                ];
                foreach ($trophies as $trophy) {
                    $date = new DateTime($trophy->received_date);
                    $formattedDate = $date->format('d F, y');
                    $trophyItem = [
                        'id' => $trophy->_id,
                        'name' => $trophy->name,
                        'description' => $trophy->description,
                        'image_front' => $trophy->trophie_front != "" ? $appUrl."".$trophyPath."".$trophy->trophie_front : "",
                        'image_back' => $trophy->trophie_back != "" ? $appUrl."".$trophyPath."".$trophy->trophie_back : "",
                        'retrieved' => true, // Replace with actual retrieved status
                        'retrieved_on' => $formattedDate, // Replace with actual retrieved date
                    ];
                    $trophyGroup['trophies'][] = $trophyItem;
                }
                $responseData[] = $trophyGroup;
            }
            return ApiResponse::success($responseData,'Trophies list found successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: list of trophies for admin
    */
    public function getTrophiesAdmin(Request $request)
    {
        try{
            $searchTerm = $request->input('search');
            $appUrl = env('AWS_S3_PATH');
            $trophyPath = env('AWS_TROPHY_PATH');
            $query = Trophie::query();

            if (!empty($searchTerm)) {
                $query->where('name', 'like', '%' . $searchTerm . '%');
            }

            $trophyData = $query->get();
            $responseData = [];
                foreach ($trophyData as $key => $trophy) {
                    $date = new DateTime($trophy->received_date);
                    $formattedDate = $date->format('d F, y');
                    // Output the result
                    $trophyItem[$key] = [
                        'id' => $trophy->_id,
                        'type' =>$trophy->trophie_type,
                        'name' => $trophy->name,
                        'description' => $trophy->description,
                        'image_front' => $trophy->trophie_front != "" ? $appUrl."".$trophyPath."".$trophy->trophie_front : "",
                        'image_back' => $trophy->trophie_back != "" ? $appUrl."".$trophyPath."".$trophy->trophie_back : "",
                        'retrieved' => true, // Replace with actual retrieved status
                        'retrieved_on' => $formattedDate, // Replace with actual retrieved date
                    ];
                }
            return ApiResponse::success($trophyItem,'Trophies list found successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: ads detail based on page
    */
    public function getAds($page='')
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            $query = Ads::query();
            if($page != ""){
                $query = $query->where('page',$page);
            }
            $ads = $query->get();
            $ads->each(function ($ad) use($user){
                $ad->ads_url =  env('AWS_S3_PATH')."".env('AWS_ADS_PATH')."".$ad->ads_url;
                $newRoot['training_streak'] = $user->training_streak ?? 0;
                $today = new DateTime();
                $yesterday = $today->modify('-1 day')->format('Y-m-d');
                $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
                $today = now()->format('Y-m-d');
                // $trainingStreakData = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$today)->first();
                // $current_training_streak = $trainingStreakData->current_streak ?? 0;
               
                // $ad->training_streak = $current_training_streak ?? 0;
                $ad->training_streak = $user->training_streak ?? 0;
                if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                    $ad->show_blue = 1;
                    $ad->training_streak = $user->mulligan ?? 1;
                }else{
                    $ad->show_blue = 0;
                }
                $ad->max_training_streak = $user->max_training_streak ?? ($user->training_streak ?? 0);
            });
            // $newRoot = [
            //     'ads' => $ads,
            //     'training_streak' => $user->training_streak ?? 1,
            //     'max_training_streak' => $user->max_training_streak ?? ($user->training_streak ?? 1)
            // ];
            return ApiResponse::success($ads,'ads found successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function verifyPromo($promoCode)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
           
            $promo_code = PromoCode::where('code',$promoCode)->where('status','active')->first();
        
            if($promo_code){
                if(str_contains($promoCode,'COACH')){
                    return ApiResponse::error('Discount code invalid');
                }else{
                    $plan = Plan::find($promo_code->plan_id);
                    //where('user_id',$user->_id)->
                    $usedPromoCodes = UsedPromoCode::where('promo_code',$promoCode)->count();
                    if($usedPromoCodes >= $promo_code->quantity){
                        return ApiResponse::error('Discount code invalid');
                    }else{
                        $promo_code->plan = strtoupper($plan->name)."".$promo_code->discount;
                        $promo_code->product_id = strtolower($plan->name)."_".$promo_code->discount;
                        $promo_code->tag = strtolower($plan->name)."-".$promo_code->discount."-offer";
                        $promo_code->identifier = ucfirst($plan->name)."".env('IDENTIFIRE');
                        $promo_code->validity_type = $plan->validity_type;
                        
                        if($plan->_id == env('GUIDE_PLAN')){
                            if (stripos( $promo_code->code, 'GREATSWING') !== false) {
                                
                            }else{
                                $promo_code->validity_type = "year";
                            }
                        }
                        $promo_code->validity = $plan->validity;
                        return ApiResponse::success( $promo_code,'Discount successfully added.');
                    }
                }
            }else{
                return ApiResponse::error('Discount code invalid');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }


    public function verifyPromo100($promoCode)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
           
            $promo_code = PromoCode::where('code',$promoCode)->where('status','active')->first();
        
            if($promo_code){
                if(str_contains($promoCode,'COACH') || $promo_code->discount != 100){
                    return ApiResponse::error('Discount code invalid');
                }else{
                    $plan = Plan::find($promo_code->plan_id);
                    //where('user_id',$user->_id)->
                    $usedPromoCodes = UsedPromoCode::where('promo_code',$promoCode)->count();
                    if($usedPromoCodes >= $promo_code->quantity){
                        return ApiResponse::error('Discount code invalid');
                    }else{
                        $promo_code->plan = strtoupper($plan->name)."".$promo_code->discount;
                        $promo_code->product_id = strtolower($plan->name)."_".$promo_code->discount;
                        $promo_code->tag = strtolower($plan->name)."-".$promo_code->discount."-offer";
                        $promo_code->identifier = ucfirst($plan->name)."".env('IDENTIFIRE');
                        return ApiResponse::success( $promo_code,'Discount successfully added.');
                    }
                }
            }else{
                return ApiResponse::error('Discount code invalid');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function getRepVideos(){
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $appUrl = env('AWS_S3_PATH');
            $swingPath = env('AWS_REP_VIDEO_PATH');
            $swings = RepReview::where('user_id', $user["_id"])->orderBy('created_at','desc')->get();

            $swingData = [];
            $i = $swings->count();
            foreach ($swings as $key => $swing) {
                $date = new DateTime($swing->updated_at);
                $formattedDate = $date->format('M j, Y');
                $swingData[$key]['id'] =  $swing->_id;
                $swingData[$key]['title'] =  "Video #".$i;
                $swingData[$key]['user_id'] =  $swing->user_id;
                $swingData[$key]['status'] =  $swing->status;
                $swingData[$key]['coach_review'] = false;
                if(  $swing->status != "Draft" && $swing->status != "Sent"){
                    $admin_coach_review = AdminCoachReview::where('swing_id',$swing->_id)->orderBy('updated_at','desc')->first();
                    if($admin_coach_review){
                        $swingData[$key]['coach_review'] = true;   
                    }
                    $coach_review_at =  $admin_coach_review->created_at;
                    $formatted_coach_review_at = $coach_review_at->format('M j, Y');
                    $swingData[$key]['coach_review_at'] = $formatted_coach_review_at ?? "";
                    $swingData[$key]['coach_review_video'] = $admin_coach_review->vimeo_link ?? "";
                    if($swingData[$key]['coach_review_video'] == ""){
                        $swingData[$key]['msg'] = "Review is still in process. No video Uploaded yet!";
                    } else{
                        $swingData[$key]['msg'] = "";
                    }
                    $swingData[$key]['coach_review_video_thumbnail'] = $admin_coach_review->thumbnail ?? "";
                }
                // $swingData[$key]['rep_video_thumbnail'] = $appUrl.'rep_thumbnail.jpg';
                $swingData[$key]['rep_video_thumbnail']  = $swing->thumbnail ?? "";
                $swingData[$key]['rep_video'] = $swing->rep_video != '' ? $appUrl.''.$swingPath.''.$swing->rep_video : '';  
                $swingData[$key]['duration'] = $swing->duration ?? "";
                $swingData[$key]['file_size'] = $swing->file_size ?? "";
                $swingData[$key]['submit_to_coach'] = $swing->submit_to_coach ?? false;
                $swingData[$key]['status'] =  $swing->status ?? "Draft";
                $swingData[$key]['description'] =  $swing->description ?? "";
                $swingData[$key]['last_update'] = $formattedDate;
                $swingData[$key]['created_at'] = $swing->created_at;
                $swingData[$key]['updated_at'] = $swing->updated_at;
                $i--;
            }
            $newRoot = [
                'rep_review' => $swingData,
            ];
            return ApiResponse::success( $newRoot,'Rep review found successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function verifyCoachPromo($promoCode)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
           
            $promo_code = PromoCode::where('code',$promoCode)->first();
        
            if($promo_code){
                if(str_contains($promoCode,'COACH')){
                    //where('user_id',$user->_id)->
                    $usedPromoCodes = UsedPromoCode::where('promo_code',$promoCode)->count();
                    if($usedPromoCodes >= $promo_code->quantity){
                        return ApiResponse::error('Discount code invalid');
                    }else{
                        $promo_code->plan = "";
                        $promo_code->product_id = "";
                        $promo_code->tag = "coach_".$promo_code->discount;
                        $promo_code->identifier = "coachreview_".$promo_code->discount;
                        return ApiResponse::success( $promo_code,'Discount successfully added.');
                    }
                    
                }else{
                    return ApiResponse::error('Discount code invalid');
                }
            }else{
                return ApiResponse::error('Discount code invalid');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: list of object types
    */
    public function getObjectType()
    {
        try {
            $objectType = ObjectType::all(); // Retrive all object types
            return ApiResponse::success($objectType,'Object type list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: list of category types
    */
    public function getCategoryType()
    {
        try {
            $categoryType = CategoryType::all();
            return ApiResponse::success($categoryType,'Category type list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: list of session types
    */
    public function getSessionType()
    {
        try {
            $categoryType = SessionType::all();
            return ApiResponse::success($categoryType,'Session type list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: 
    */
    public function getTokenFromHeader() {
        try {
            $token = request()->header('Authorization');
            if ($token) {
                $token = substr($token, 7); // Remove 'Bearer ' prefix
            }
            return $token;
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    /**
    * Developer: Apptodate 
    * Comment: comfirm new email's user
    */
    public function confirmcheck(Request $request)
    {
        try {
            $request->validate([
                'userid' =>   'required'
            ]);
            
            $user = User::where('userid', (int)$request->input('userid'))->first();
           
            $is_confirm = false;
            $token = \JWTAuth::fromUser($user);

            if($user){
                if($user->is_confirm == 1){
                    $is_confirm = true;
                    return response()->json([
                        'success' => true,
                        'message' => 'Confirmation status.',
                        'user' => $user,
                        'token' => $token,
                    ]); 
                }else{       
                    return response()->json([
                        'success' => false,
                        'message' => 'Confirmation status.',
                        'user' => "",
                        'token' => "" ,
                    ]); 
                }
            }else{
                return response()->json([
                    'success' => false,
                    'message' => 'Confirmation status.',
                    'user' => "",
                    'token' => "",
                ]);
            }
       
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function confirmProcess(Request $request)
    {
        try {
            //retrieve user data
            $request->validate([
                'type' => 'required'
            ]);
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
           
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $newRoot = [];
            if($user){
                $paymentSetting = PaymentSetting::first();
                if($request->type == "appCarousel"){
                    $user->appCarousel = true;
                }
                if($request->type == "planOverView"){
                    $user->planOverView = true;
                }
                if($request->type == "aboutFisio"){
                    $user->aboutFisio = true;
                }
                if($request->type == "initialFreeTrail"){
                    $user->initialFreeTrail = true;
                }
                if($request->type == "dailyReminder"){
                    $user->dailyReminder = true;
                }
                if($request->type == "letsStart"){
                    $user->letsStart = true;
                }
                if($request->type == "letsStart"){
                    $user->letsStart = true;
                }
                if($request->type == "aboutYou"){
                    $user->aboutYou= true;
                }
                if($request->type == "acknowledgement"){
                    $user->acknowledgement= true;
                }
                if($request->type == "convertToFreeTrail"){
                    $user->convertToFreeTrail= true;
                }
                if($request->type == "convertFreeSuccess"){
                    $user->convertFreeSuccess= true;
                }
                if($request->type == "allow_notification"){
                    $user->allow_notification= true;
                }
                if($request->type == "dailyReminderSelection"){
                    $user->dailyReminderSelection= true;
                }
                if($request->type == "selectTimezone"){
                    $user->selectTimezone= true;
                }
                if($request->type == "see_available_plans"){
                    $user->see_available_plans = true;
                }
                if($request->type == "check_plans"){
                    $user->check_plans = true;
                }
                if($request->type == "has_answered"){
                    $user->has_answered = true;
                }
                $user->save();
                if($request->type == "convertToFreeTrail"){
                    $userBillingHistoryDataExist = UserBillingHistory::where('user_id',$user["_id"])->where('status','active')->first();
                    if($userBillingHistoryDataExist){
                    }else{
                        $userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->where('status','active')->where('amount',0)->first();
                        if($userBillingHistory){}else{
                                $userBillingHistory = new UserBillingHistory();
                                $userBillingHistory->transaction_no = Functions::generateUniqueNumber();
                                $userBillingHistory->user_id = $user["_id"];
                                $userBillingHistory->plan_id = "65e12b53bff860305975192f"; // need to do dynamic later
                                $userBillingHistory->amount = 0;
                                $userBillingHistory->status = "active";
                                $userBillingHistory->payment_status = "Paid";
                                $userBillingHistory->payment_method = "";
                                $userBillingHistory->expiry_date = now()->addDays(7)->format('Y-m-d H:i:s');
                                $userBillingHistory->save();
                        }
                    }
                }
                
                $purchased = $paymentSetting->free_app ?? false;
                $FreeUser = FreeUser::where('email', $user->email)->count();
                if($FreeUser > 0){
                    $purchased = true;
                }

                $newRoot['free_app'] =  $purchased;
                return ApiResponse::success($newRoot,'Confirm Process saved successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    /**
    * Developer: Apptodate 
    * Comment: check registration process status for training intention, friend support, on boarding question filled or not
    */
    public function registrationProcessCheck(Request $request)
    {
        try {
            $request->validate([
                'userid' => 'required'
            ]);
            $is_free= false;;
            $user = User::where('userid', (int)$request->input('userid'))->first();
            $is_confirm = $aboutUsStatus = $trainingIntentionStatus = $contactPersonStatus = false;
            if($user){
                if($user->is_confirm == 1){
                    $is_confirm = true;
                }
                $trainingIntention = UserTrainingPlan::where('user_id', $user["userid"])->count();
                if($trainingIntention > 0){
                    $trainingIntentionStatus = true;
                }
                $contactPerson = UserContactPerson::where('user_id', $user["userid"])->count();
                if($contactPerson > 0){
                    $contactPersonStatus = true;
                }
                // $questionIds = Question::where('can_skip',false)->pluck('_id')->toArray();
                
                // $userQuestions = UserQuestionAnswer::whereIn('question_id',$questionIds)->where('user_id', $user["userid"])->groupBy('question_id')->pluck('question_id')->toArray();
             
                // if((sizeof($questionIds) == sizeof($userQuestions) && sizeof($questionIds) != 0) || ($user->has_answered)){
                //     $aboutUsStatus = true;
                // }
                // if(sizeof($questionIds) == sizeof($userQuestions)){
                //     $aboutUsStatus = true;
                // }

                $questionIds = Question::where('can_skip',false)->pluck('_id')->toArray();
                if(sizeof($questionIds) == 0){
                    $aboutUsStatus = true;
                }else{
                    $userQuestions = UserQuestionAnswer::whereIn('question_id',$questionIds)->where('user_id', $user["userid"])->groupBy('question_id')->pluck('question_id')->toArray();
             
                    if(sizeof($questionIds) == sizeof($userQuestions)){
                        $aboutUsStatus = true;
                    }
                }
                // $appCarousel = $user->appCarousel ?? false;
                $planOverView = $user->planOverView ?? false;
                $aboutFisio = $user->aboutFisio ?? false;
                $initialFreeTrail = $user->initialFreeTrail ?? false;
                $see_available_plans = $user->see_available_plans ?? false;
                $check_plans = $user->check_plans ?? false;
                $dailyReminder = $user->dailyReminder ?? false;
                $letsStart = $user->letsStart ?? false;
                $aboutYou = $user->aboutYou ?? false;
                $acknowledgement = $user->acknowledgement ?? false;
                $convertToFreeTrail = $user->convertToFreeTrail ?? false;
                $convertFreeSuccess = $user->convertFreeSuccess ?? false;
                $dailyReminderSelection = $user->dailyReminderSelection ?? false;
                $selectTimezone = $user->selectTimezone ?? false;
                $allow_notification = $user->allow_notification ?? false;
                $paymentSetting = PaymentSetting::first();

                if($paymentSetting->free_app === true){
                    $initialFreeTrail = true;
                    $convertToFreeTrail = true;
                    $is_free= true;
                    $check_plans = true;
                }
                $subscription = UserBillingHistory::where('user_id',$user->_id)->first();
                if($subscription){
                    $initialFreeTrail = true;
                    $convertToFreeTrail = true;
                    // $convertFreeSuccess = true;
                    $see_available_plans = true;
                    $check_plans = true;
                }

                $appCarousel = true;
            
                // $initialFreeTrail = true;
                // $convertToFreeTrail = true;
                $freeUser = FreeUser::where('email', $user->email)->count();
                if($freeUser > 0){
                    $initialFreeTrail = true;
                    $convertToFreeTrail = true;
                    $is_free= true;
                }
                $aboutYou = true;
                $acknowledgement = true;
                $planOverView  = true;
                $aboutFisio = true;
                // $initialFreeTrail = true;
                // $convertToFreeTrail = true;
                $new_flow = false;
                $flowSetting = FlowSetting::first();
                $new_flow = $flowSetting->new_flow ?? false;
                $ultra_plan_id = env('ULTRA_PLAN');
                $ultra_plan = plan::find($ultra_plan_id);
                if($is_free == true){
                    $check_plans = true;
                }
                $guide_plan_id = env('GUIDE_PLAN');
                $guide_plan = plan::find($guide_plan_id);
                
                $data = [
                    'ultra_plan' => $ultra_plan,
                    'guide_plan' => $guide_plan,
                    'user_name' => $user->full_name,
                    'is_free' =>$is_free ?? false,
                    'plan' => $user->plan ?? "Good",
                    'confirm_email' => $is_confirm,
                    'about_us' => $aboutUsStatus,
                    'training_intention' => $trainingIntentionStatus,
                    'friend_support' => $contactPersonStatus,
                    'lets_go' => true,
                    'appCarousel'  => $appCarousel,
                    'planOverView' => $planOverView,
                    'aboutFisio'  => $aboutFisio,
                    'initialFreeTrail' => $initialFreeTrail,
                    'see_available_plans' => $see_available_plans,
                    'check_plans' => $check_plans,
                    'dailyReminder' => $dailyReminder,
                    'letsStart' => $letsStart,
                    'aboutYou'  => $aboutYou,
                    'acknowledgement' => $acknowledgement,
                    'convertToFreeTrail'  => $convertToFreeTrail,
                    'convertFreeSuccess' => $convertFreeSuccess,
                    'dailyReminderSelection' => $dailyReminderSelection,
                    'selectTimezone' => $selectTimezone,
                    'allow_notification' => $allow_notification ?? false,
                    'new_flow' => $new_flow ?? false,
                    'is_reminder_later_reminder_once' => $user->is_reminder_later_reminder_once ?? false
                ];
                return ApiResponse::success($data,'Registration Process status.');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    

    public function getPurchaseHistory()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
           
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else{
               
                $userBillingHistory = UserBillingHistory::where('user_id',$user["_id"])->orderBy('created_at','desc')->get();
                foreach ($userBillingHistory as $key => $userBillingHistorydata) {
                    $plan = Plan::find($userBillingHistorydata->plan_id);
                    $userBillingHistorydata->plan_name = $plan->name ?? "";
                }
                return ApiResponse::success($userBillingHistory,'Purchase History list found.');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: While any notes pinned  by user
    */
    
    public function allowNotification($type = true)
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                if($type == "true" && $type == true){
                    $type = true;
                }else{
                    $type = false;
                }
                $user->allow_notification_permission = $type;  
                $user->save(); 
                return ApiResponse::success($user,'Notification permission setting changed successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function pinNotes($note_id)
    {
        try {
            $token = $this->getTokenFromHeader();   
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$note_id){
                return ApiResponse::error('Note id required!!');
            }
            $pinned = [];
            $pinned_note = Note::where('_id','!=',$note_id)->where('type','note')->where('user_id',$user['userid'])->where('is_pinned',true)->count();
         
            
            $note = Note::where('_id',$note_id)->where('user_id',$user['userid'])->first();
            if($note){
                if($note->is_pinned == true){//|| $note->is_pinned == null
                    $pinned['is_pinned'] = false;
                    $msg = "unpinned";
                }else{
                    $pinned['is_pinned'] = true;
                    $msg = "pinned";
                }
                $note->is_pinned = $pinned['is_pinned'];  
                $note->save(); 
                return ApiResponse::success($pinned,'Note '.$msg.' successfully.');
            }else{
                return ApiResponse::error('Note not found!');
            }
           
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }


    private function generateToken(User $user)
    {
        $payload = [
            'iss' => env('APP_URL'),
            'sub' => $user->id,
            'iat' => time(),
            'exp' => strtotime('+1 day'),
        ];

        return JWT::encode($payload, env('JWT_SECRET'));
    }

    public function createCustomer(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                $token = $request->input('token_id'); // Assuming the token is sent via POST request
                $email = $user["email"];
                $name = $user["full_name"];
                Stripe::setApiKey(env('STRIPE_SECRET'));
                $customerId = $user->stripe_customer_id;
                // $customerExists = $customerId ? Customer::retrieve($customerId) : null;
                if (!$customerId) {
                    $customer = Customer::create(['email' => $email,'name' => $name]);

                    // Convert the token to a Payment Method and attach it to the customer
                    $paymentMethod = PaymentMethod::create([
                        'type' => 'card',
                        'card' => ['token' => $token],
                    ]);
                    $paymentMethod->attach(['customer' => $customer->id]);
        
                    // Optionally, set the Payment Method as default for the customer
                    $customer->invoice_settings = ['default_payment_method' => $paymentMethod->id];
                    $customer->save();
        
                    // Retrieve the updated customer details
                    $updatedCustomer = Customer::retrieve($customer->id, [
                        'expand' => ['invoice_settings.default_payment_method'],
                    ]);
                } else {
                    // Retrieve the existing customer
                    $customer = Customer::retrieve($customerId);

                    // Create a payment method from the token
                    $paymentMethod = PaymentMethod::create([
                        'type' => 'card',
                        'card' => ['token' => $token],
                    ]);

                    // Attach the new payment method to the customer
                    $paymentMethod->attach(['customer' => $customer->id]);

                    // Optionally, set this payment method as the default for the customer
                    $customer->invoice_settings = ['default_payment_method' => $paymentMethod->id];
                    $customer->save();

                }
                $user->stripe_customer_id = $customer->id;
                $user->save();
               
                if ($customer) {
                    return ApiResponse::success($customer,'Customer created successfully.');
                }else{
                    return ApiResponse::error('Failed to create customer or customer sources not available');
                }
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
        
    }

    public function getCustomerCard()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                Stripe::setApiKey(config('services.stripe.secret'));
                $cards = [];
                $customerId = $user->stripe_customer_id ?? "";
                if($customerId != ""){
                    $paymentMethods = PaymentMethod::all([
                        'customer' => $customerId,
                        'type' => 'card', // Specify the type of payment methods to retrieve
                    ]);
                
                    $cards = [];
                    $customer = Customer::retrieve($customerId);
                    $defaultPaymentMethodId = $customer->invoice_settings->default_payment_method;
                    foreach ($paymentMethods->data as $paymentMethod) {
                        $isDefault = $paymentMethod->id === $defaultPaymentMethodId;
                        // For each payment method, extract the card details and add to $cards array
                        $cards[] = [
                            'name' => $user->full_name ?? "",
                            'id' => $paymentMethod->id,
                            'brand' => $paymentMethod->card->brand,
                            'last4' => $paymentMethod->card->last4,
                            'exp_month' => $paymentMethod->card->exp_month,
                            'exp_year' => $paymentMethod->card->exp_year,
                            'is_default' => $isDefault
                            // You can include more details here as needed
                            // 'is_default' logic will depend on your application's handling of default payment methods
                        ];
                    }
                    return ApiResponse::success($cards,'card list found successfully.');
                }else{
                    return ApiResponse::success($cards,'card list found successfully.');
                    //return ApiResponse::error('Getting trouble to fetch user card information');
                }
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function deleteCustomerCard($cardId)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                Stripe::setApiKey(env('STRIPE_SECRET'));
                $customerId = $user->stripe_customer_id;
                // Retrieve all card payment methods for the customer
                $paymentMethods = PaymentMethod::all([
                    'customer' => $customerId,
                    'type' => 'card',
                ]);
                // Check how many card payment methods the customer has
                if (count($paymentMethods->data) <= 1) {
                    return ApiResponse::error('You must have at least one card on file. Please add a new card before deleting this one.');
                }else{
                    $customer = Customer::retrieve($customerId);
                    $defaultPaymentMethodId = $customer->invoice_settings->default_payment_method;
                    if (count($paymentMethods->data) == 2) {
                        foreach ($paymentMethods->data as $paymentMethod) {
                            if ($paymentMethod->id !== $cardId) {
                                $newDefaultPaymentMethodId = $paymentMethod->id;
                                $customer->invoice_settings = ['default_payment_method' => $newDefaultPaymentMethodId];
                                $customer->save();
                                $paymentMethod = PaymentMethod::retrieve($cardId);
                                $paymentMethod->detach();
                                break;
                            }
                        }
                        return ApiResponse::successOnly('Customer Card deleted successfully.');
                    }else{
                        if ($cardId === $defaultPaymentMethodId) {
                            return ApiResponse::error('Please assign default card from  another available card first.');
                        }else{
                            $paymentMethod = PaymentMethod::retrieve($cardId);
                            $paymentMethod->detach();
                            return ApiResponse::successOnly('Customer Card deleted successfully.');
                        }
                    }
                }
                // If more than one card exists, proceed to delete the specified card
                
                
            }
        }  catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function makeDefaultCard($cardId)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else { 
                Stripe::setApiKey(env('STRIPE_SECRET'));
                $customerId = $user->stripe_customer_id;
                $customer = Customer::retrieve($customerId);
                if($customer){
                    // Update the customer's default payment method
                    $customer->invoice_settings = ['default_payment_method' => $cardId];
                    $customer->save();
                    return ApiResponse::successOnly('Card has been modified as default payment method');
                }else{
                    return ApiResponse::error('Getting trouble to fetch customer information from stripe');
                }
            }
        }  catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function AddEditSubScription($cardId)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }else {     
                Stripe::setApiKey(env('STRIPE_SECRET'));
                $customerId = $user->stripe_customer_id;
                $customer = Customer::retrieve($customerId);
                if($customer){
                    $customer->invoice_settings = ['default_payment_method' => $cardId];
                    $customer->save();
                    return ApiResponse::successOnly('Card has been modified as default payment method');
                }else{
                    return ApiResponse::error('Getting trouble to fetch customer information from stripe');
                }
            }
        }  catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function userDailyReminder(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            
            $request->validate([
                'skip' => 'required',
                'hour' => 'nullable',
                'min' => 'nullable',
                'time' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            $skip = true;
            if($request->skip == "true"){
                $skip = true;
            }else if($request->skip == "false"){
                $skip = false;
            }else{
                $skip = $request->skip;
            }
            $user->skip_reminder = $skip;
         
            if($skip === false && $request->hour != '' && $request->min != '' && $request->time != ''){
                $user->hour = (int)$request->hour ?? "";
                $user->min = (int)$request->min ?? "";
                $user->time = $request->time ?? "";
            }

            $user->save();
            $set_daily_reminder = ($user->skip_reminder == true ) ? false : true;
            $set_daily_reminder_time = "";
            $hour = $min = $timeAM = "";
            if( $set_daily_reminder == true){
                $hour = ($user->hour != '') ? (int)$user->hour : 6;
                $min = ($user->min != '') ? (int)$user->min : 0;
                $timeAM = Str::upper($user->time)?? "AM";
                if($hour != "" && $min != "" && $hour > 0 ){
                    $time = $hour. ":". $min;
                    $parsedTime = Carbon::parse($time);
                    $finalTime  =  $parsedTime->format('g:i')." ".$timeAM;
                }
                $set_daily_reminder_time = $finalTime ?? "";
            }

            $response = [
                'hour' => $hour,
                'min' => $min,
                'time' => $timeAM,
                'skip_reminder' => $user->skip_reminder,
                'set_daily_reminder' => $set_daily_reminder,
                'set_daily_reminder_time' => $set_daily_reminder_time
            ];
            
            return ApiResponse::success($response,'Daily reminder time added successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getUserProgressTrackingApp(){
        try{
            $newRoot = [
                'user' => [],
            ];
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
                                                  
            $defaultProgram = env('DEFAULT_PROGRAM');
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
            $user->group_id = $user->group_id == 0 ? $defaultGroup->_id : $user->group_id;
            $group = Group::find($user->group_id);
            $user->group_name = $group->group_name ?? $defaultProgram;
            
            $categoryTypeTrain = CategoryType::where('name', 'LIKE', 'Train')->first();
            $categoryTypeApply = CategoryType::where('name', 'LIKE', 'Apply')->first();
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            
            $unitOrderMap = [];
            foreach ($defaultGroup["group_object"] as $in => $obj) {
                $unitOrderMap[$obj['object_id']] = $in + 1; 
            }
            if(!empty($user->group_id)){
                $group = Group::find($user->group_id);
                if($group){
                    $unitOrderMap = [];
                    $unitIds = array_column($group["group_object"], "object_id");
                    foreach ($group["group_object"] as $in => $obj) {
                        $unitOrderMap[$obj['object_id']] = $in + 1;
                    }
                    $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $unitIds )->get();
                    $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $unitIds )->get();
                }else{
                    $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                    $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                }
            }else{
                $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
            }
            $unitIdsFilter = $units->pluck('_id')->toArray();
            $applyIdsFilter = $apply->pluck('_id')->toArray();
            //$userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$unitIdsFilter)->groupBy('unit_id','session_id')->pluck('unit_id','session_id')->count();
            $userSessionProgress = UserSessionProgress::where('user_id', $user->_id)
                                    ->whereIn('unit_id', $unitIdsFilter)
                                    ->groupBy('unit_id', 'session_id')
                                    ->selectRaw('unit_id, session_id')  // Select the grouped columns
                                    ->get()
                                    ->count();
            $userSessionProgressApply = UserSessionProgress::where('user_id', $user->_id)
                                        ->whereIn('unit_id', $applyIdsFilter)
                                        ->groupBy('unit_id', 'session_id')
                                        ->selectRaw('unit_id, session_id')  // Select the grouped columns
                                        ->get()
                                        ->count();
           // UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$applyIdsFilter)->groupBy('unit_id','session_id')->pluck('unit_id','session_id')->count();
            $trustHoles = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
            $sortedDates = collect($trustHoles)->sortBy(function ($date) {
                return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
            })->values()->all();
            $uniqueEntriesTrust = sizeof($sortedDates);
            $newRoot['user'] = $user;
            $userStreakData = UserTrainingStreak::where('user_id',$user["userid"])
                                ->where(function ($query) {
                                    $query->where('current_streak', '>', 0)
                                        ->orWhere('mulligan', '>', 0);
                                })->get();
            $newRoot['training_streak'] = $user->training_streak ?? 0;
            $newRoot['streak_calender'] = $userStreakData ?? [];
            $today = new DateTime();
            $yesterday = $today->modify('-1 day')->format('Y-m-d');
            $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
            if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                $newRoot['show_blue'] = 1;
                $newRoot['training_streak'] = $user->mulligan ?? 1;
            }else{
                $newRoot['show_blue'] = 0;
            }
            $newRoot['max_training_streak'] = $user->max_training_streak ?? ($user->training_streak ?? 0);
            $newRoot['user_progress_train'] = $userSessionProgress ?? 0;
            $newRoot['user_progress_apply'] = $userSessionProgressApply ?? 0;
            $newRoot['user_progress_trust'] = $uniqueEntriesTrust ?? 0;

            $manual_reps_recall_card = UserManualReps::where('user_id', $user["_id"])
            ->where('reps_type', 'Recall Cards')
            ->get();
            $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
            $manual_reps_movement_drills = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Move Drills')
                ->get();
            $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
            $manual_reps_swing_drills = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Swing Drills')
                ->get();    
            $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
            $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                ->where('reps_type', 'Trust Shots')
                ->get();
            $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
            $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
                $recap_reps_all = SessionRecapTime::where('user_id', $user['_id'])->get();
                $all_totalRecapReps = 0;
                if($recap_reps_all->count() > 0){
                    foreach ($recap_reps_all as $recap_reps_a) {
                        $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                    }
                }
                $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card +$all_totalRecapReps ?? 0 ;
                $docs = UserMovementDrill::where('user_id', $user['_id'])->get();
                $totalReps = 0;
                foreach ($docs as $doc) {
                    $totalReps += (int) $doc['reps'];
                }
                $userMovementDrillCount = $totalReps;
                $trust_reps = 0;
                $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                    return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                })->values()->all();
                $totalDate = sizeof($sortedDates);
                if( $totalDate > 0){
                    $trust_reps = $totalDate * 40;
                }
                $reps['move_drills'] =  $userMovementDrillCount + $total_manual_reps_movement_drills ?? 0;
                $swings = Swing::where('user_id',$user["_id"])->count();
                $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills?? 0;
                $reps['trust_shots'] = $trust_reps + $total_manual_reps_trust?? 0;
                $calculatedReps =  $reps['trust_shots'] + $reps['swing_drills'] + $reps['move_drills'] + $reps['recall_cards'] ?? 0;
                $newRoot['total_reps'] = $calculatedReps ?? 0;
                return ApiResponse::success($newRoot,'User detail fetch successfully');
            
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
}
