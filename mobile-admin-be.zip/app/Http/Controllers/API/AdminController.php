<?php

namespace App\Http\Controllers\API;
use App\Helpers\ApiResponse;
use App\Helpers\Functions;
use App\Http\Controllers\Controller;
use App\Mail\CoachReminderEmail;
use App\Mail\ContactUsEmail;
use App\Models\DisplayImages;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\ContactUs;
use App\Models\TermService;
use App\Models\Question;
use App\Models\Faq;
use App\Models\Tags;
use App\Models\ObjectType;
use App\Models\CategoryType;
use App\Models\InformationCenter;
use App\Models\InformationCenterImages;
use App\Models\UserQuestionAnswer;
use App\Models\UserUnitProgress;
use App\Models\UserTrainingPlan;
use App\Models\UserContactPerson;
use Firebase\JWT\JWT;
use App\Mail\ForgetpasswordEmail;
use App\Models\About;
use App\Models\AdminCoachReview;
use App\Models\Ads;
use App\Models\CoachReview;
use App\Models\Country;
use App\Models\FlowSetting;
use App\Models\ForceUpdateSetting;
use App\Models\FreeUser;
use App\Models\Fundamental;
use App\Models\Group;
use App\Models\Guide;
use App\Models\GuideFundamental;
use App\Models\Note;
use App\Models\Notification;
use App\Models\Overview;
use App\Models\PaymentSetting;
use App\Models\Plan;
use App\Models\PromoCode;
use App\Models\RecallCard;
use App\Models\RepReview;
use App\Models\Session;
use App\Models\SessionRecapTime;
use App\Models\UserObjectBookmark;
use App\Models\SessionType;
use App\Models\Swing;
use App\Models\Trophie;
use App\Models\TrustOverview;
use App\Models\TrustQuote;
use App\Models\TrustKey;
use App\Models\Unit;
use App\Models\UsedPromoCode;
use App\Models\UserBillingHistory;
use App\Models\UserCoachReview;
use App\Models\UserFcmToken;
use App\Models\UserManualReps;
use App\Models\UserMovementDrill;
use App\Models\UserObjectType;
use App\Models\UserRecallCards;
use App\Models\UserSelfCheckCheckObject;
use App\Models\UserSelfReportObject;
use App\Models\UserSessionProgress;
use App\Models\UserShotCheck;
use App\Models\UserTrainingStreak;
use App\Models\UserTrustHole;
use App\Models\UserWeeklySurvey;
use App\Rules\VideoMimeRule;
use Carbon\Carbon;
use DateTime;
use Exception;
use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Str;
use Mockery\Undefined;
use stdClass;
use Stripe\Customer;
use Stripe\PaymentMethod;
use Stripe\Stripe;

use Google\Client;
use Illuminate\Validation\Rule;
use Vimeo\Vimeo;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api',['except' => ['confirmcheck','getImages','forgotpassword','confirmPassword','registrationProcessCheck']]);
    }
    function getAccessToken($serviceAccountPath) {
        $client = new Client();
        $client->setAuthConfig($serviceAccountPath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->useApplicationDefaultCredentials();
        $token = $client->fetchAccessTokenWithAssertion();
        return $token['access_token'];
    }
    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can store onboarding question
    */
    public function getUserObjects(Request $request)
    {
        try {
            $userObjCollection = UserObjectType::all();

            if ($userObjCollection->isEmpty()) {
                return ApiResponse::success([], 'No object types found.');
            }

            $newRoot = $userObjCollection->map(function ($tag) {
                return [
                    'id' => $tag->_id,
                    'object_name' => $tag->object_name,
                    'object_time' => $tag->object_time,
                    'category_type_id' => $tag->category_type_id,
                    'reps' => $tag->reps ?? 0,
                ];
            });

            return ApiResponse::success($newRoot, 'Object type list found.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function storeQuestion(Request $request)
    {
        try {
            // Validate request parameters
            $validatedData = $request->validate([
                'text' => 'required|string',
                'question_type' => 'required|string',
                'can_skip' => 'nullable|boolean'
            ]);
            if($validatedData['question_type'] == "rating"){
                $validatedData1 = $request->validate([
                    'text_ip_1' => 'required|string',
                    'text_ip_10' => 'required|string',
                ]);
            }else{
                $validatedData1 = $request->validate([
                    'answers' => 'required|array',
                    'answers.*' => 'required|string',
                ]);
            }
            //store question information
            $questionLatest = Question::count();
            $question = new Question();
            $question->text = $validatedData['text'];
            
            $question->question_type = $validatedData['question_type'];
            if($validatedData['question_type'] == "rating"){
                $question->text_ip_1 = $validatedData1['text_ip_1'];
                $question->text_ip_10 = $validatedData1['text_ip_10'];
            }else{
                $question->answers = $validatedData1['answers'];
            }
            $question->can_skip = $validatedData['can_skip'] ?? false;
            if(!empty($request->order)){
                $question->order = $request->order;
            }else{
                $question->order = $questionLatest+1;
            }
            if(!empty($request->subtitle)){
                $question->subtitle = $request->subtitle;
            }else{
                $question->subtitle = "";
            }
            $question->save();
    
            return ApiResponse::success($question,'Question store successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function storeForceUpdate(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            // Validate request parameters
            $validatedData = $request->validate([
                'version' => 'required|string',
                'version_code' => 'required|integer',
                'device_type' => 'required|string',
                'description' => 'required|string',
                'force_update' => 'required|boolean'
            ]);
         
            if(!empty($request->id)){
                $forceUpdateSetting = ForceUpdateSetting::find($request->id);
            }else{
                $forceUpdateSetting = new ForceUpdateSetting();
            }
            $forceUpdateSetting->version = $request->version;
            $forceUpdateSetting->version_code = $request->version_code;
            $forceUpdateSetting->device_type = $request->device_type;
            $forceUpdateSetting->description = $request->description ?? "";
            $forceUpdateSetting->force_update = $request->force_update ?? false;
            $forceUpdateSetting->save();
    
            return ApiResponse::success($forceUpdateSetting,'Force update set successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function updatePaymentFreeToUser(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            // Validate request parameters
            $validatedData = $request->validate([
                'is_free' => 'required|boolean',
                'user_id' => 'required|string',
            ]);
         
            $user = User::find($request->user_id);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user->is_free = $request->is_free ?? false;
            $user->save();
            // if( $user->is_free != false){
            //     $userCoachReview = new UserCoachReview();
            //     $userCoachReview->user_id = $user->userid;
            //     $userCoachReview->coach_review = 6;
            //     $userCoachReview->used_coach_review = 0;
            //     $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
            //     $userCoachReview->status = 'active';
            //     $userCoachReview->save();
            // }
            
            return ApiResponse::success($user,'User setting for payment free or paid successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function deleteForceUpdate($id)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            $forceUpdateSetting = ForceUpdateSetting::find($id);
            if($forceUpdateSetting){
                $forceUpdateSetting->delete();
                return ApiResponse::success($forceUpdateSetting,'Force update setting deleted successfully.');
            }else{
                return ApiResponse::error('Invalid Details!');
            }
          
    
            
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function getForceUpdate()
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            $forceUpdateSetting = ForceUpdateSetting::orderBy('created_at','desc')->get();
            return ApiResponse::success($forceUpdateSetting,'Force update list successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function getPaymentMethodOfUser($user_id){
        try{
          
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user = User::find($user_id);
            if(!$user){
                return ApiResponse::error('User not found!');
            }else{
                $payment_method = [
                    
                ];
                
                return ApiResponse::success($data,'Here is payment method list.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getPaymentHistoryOfUser(Request $request,$user_id)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user = User::find($user_id);
            if(!$user){
                return ApiResponse::error('User not found!');
            }else{
                $req_param = $request->all();// Retrieve the request parameters
                $sortColumn = $req_param['sort'] ?? "";
                $filterColumn = $req_param['filterBy'] ?? "";
                $filteredVal = $req_param['filteredVal'] ?? "";
            
                $userBillingHistory = UserBillingHistory::where('user_id',$user_id)->orderBy('created_at','desc')->get();
                foreach ($userBillingHistory as $key => $recallCard) {
                    $plan = Plan::find($recallCard->plan_id);

                    $plan_name = $plan->name ?? "";
                    if($plan_name == "Ultra"){
                        $plan_name = "Pro";
                    }
                    if($plan_name == "Free 7-Day Trial"){
                        $plan_name = "7-Day Trial";
                    }
                    $recallCard->plan = $plan_name ?? "";
                }
                
                $sortedData = Functions::sortArray($userBillingHistory,$sortColumn);//applied sorting
                $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//applied filter
                $totalRecallCards = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
                $totalPage = !empty($request->per_page ) ? $totalRecallCards/ $request->per_page : 1;
                if(!empty( $request->per_page) && !empty( $request->page)){
                    $perPage = $request->per_page ;
                    $page = $request->page;
                    $currentPage  = $page - 1;
                    if (is_array($filteredResponse)) {
                        $filteredResponse = collect($filteredResponse);
                    }
                    $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                    $filteredResponse = array_values($pagedData);
                }
                
                $newRoot = [
                    'total_page' => ceil($totalPage),
                    'total_billing_history' => $totalRecallCards,
                    'billing_history' => $filteredResponse
                ];
                return ApiResponse::success($newRoot,'Billing History list found.');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getPaymentHistoryAll()
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $userBillingHistory = UsedPromoCode::orderBy('created_at','desc')->get();
            foreach ($userBillingHistory as $key => $recallCard) {
                $user = User::find($recallCard->user_id);
                $recallCard->user =  $user->full_name ?? "";
                $recallCard->email =  $user->email ?? "";
            }
            return ApiResponse::success($userBillingHistory,'Used Promo code list found.');
          
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getGuide()
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_GUIDE_PATH');
            $step_img_path = env('AWS_GUIDE_STEP_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            $guides = Guide::all();//get folder list by logged in user
            $guideData = [];
            if($guides->count() > 0){
             
                foreach ($guides as $key => $guide) {
                    $guideData[$key]['id'] = $guide->_id;
                    $guideData[$key]['title'] = $guide->title;
                    $guideData[$key]['description'] = $guide->description;
                    $guideData[$key]['updated_at'] = $guide->updated_at;
                    $fundamentals = GuideFundamental::where('guide_id',$guide->id)->get();
                    if($fundamentals->count() > 0){
                        $fundamentalsData = [];
                        foreach ($fundamentals as $keyy => $fundamental) {
                            $fundamentalsData[$keyy]['id'] = $fundamental->_id;
                            $fundamentalsData[$keyy]['name'] = $fundamental->title;
                            $fundamentalsData[$keyy]['description'] = $fundamental->description;
                            $fundamentalsData[$keyy]['main_image'] =  $fundamental->main_image != "" ? $appUrl."".$path."".$fundamental->main_image :"";
                            $fundamentalsData[$keyy]['secondary_image'] =  $fundamental->secondary_image != "" ? $appUrl."".$path."".$fundamental->secondary_image :"";
                            $fundamentalsData[$keyy]['secondary_vimeo_link'] =  $fundamental->secondary_vimeo_link ?? "";
                            if (!empty($fundamental->micro_move_steps)) {
                                $micro_move_steps_data = $fundamental->micro_move_steps;
                                if(!empty($micro_move_steps_data)){
                                    foreach ($micro_move_steps_data as $keyq => &$micro_move_steps) {
                                        if (!empty($micro_move_steps['steps'])) {
                                            foreach ($micro_move_steps['steps'] as $keyt => &$step) {
                                                // Check if 'vimeo_link' exists and is not empty, else set to an empty string
                                                $step['details'] = !empty($step['details']) ? $step['details'] : '';
                                                $step['vimeo_link'] = !empty($step['vimeo_link']) ? $step['vimeo_link'] : '';
                                                $step['image'] = !empty($step['image']) ? $appUrl."".$step_img_path."".$step['image'] :"";
                                            }
                                            unset($step); // Best practice to unset the reference to prevent potential future bugs
                                        }
                                    }
                                    unset($micro_move_steps); // Unset the reference after the loop
                                }
                            }else{
                                $micro_move_steps_data = [];
                            }
                            
                            $fundamentalsData[$keyy]['micro_moves'] = $micro_move_steps_data ?? [];

                            $fundamentalsData[$keyy]['updated_at'] = $fundamental->updated_at ?? "";
                        }
                        $guideData[$key]['fundamentals'] = $fundamentalsData;
                    }
                }
            }
            return ApiResponse::success($guideData,'Here is Guide list.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getFundamentals()
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            $fundamentals = Fundamental::all();//get folder list by logged in user
            $fundamentalData = [];
            if($fundamentals->count() > 0){
             
                foreach ($fundamentals as $key => $fundamental) {
                    $fundamentalData[$key]['id'] = $fundamental->_id;
                    $fundamentalData[$key]['name'] = $fundamental->name;
                    $fundamentalData[$key]['headline'] = $fundamental->headline ?? "";
                    $fundamentalData[$key]['text'] = $fundamental->text ?? "";
                    $fundamentalData[$key]['vimeo_link'] = $fundamental->vimeo_link ?? "";
                }
            }
            return ApiResponse::success($fundamentalData,'Here is fundamental list.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updateFundamental(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'fundamental_id' => 'required',
                'headline' => 'required',
                'text' => 'required',
                'vimeo_link' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            $fundamental = Fundamental::find($request->fundamental_id);
            if(!$fundamental){
                return ApiResponse::error('Fundamental not found!!');
            }
            $fundamental->headline = $request->headline;
            $fundamental->text = $request->text;
            if($request->hasFile('video')){
                $file = $request->file('video');
                $filePath = $file->getPathname();
                $fileName = $file->getClientOriginalName();
                $vimeo = new Vimeo(
                    "782629a63bc327483978632274a9c468bbf3326f",
                    "O4h9TvQDG+akyF097q+sOodzGi3p3/vMCGnm52j9J3zJMc9LZx4Jk4LL/BNVp1ohckDCa4+3/kIRTbAbFZ7x511oivwK1z2zTIUBfmaL1/zgHnz5xZq/hMpMoTLroiGQ",
                    "6a0d7f9b2949f9f03146fe44def94bfc"
                );
                ini_set('sys_temp_dir', storage_path('app/tmp'));
                $uri = $vimeo->upload($filePath, [
                    'name' => $fileName,
                    'description' => 'fundamental video'
                ]);
             
                $videoData = $vimeo->request($uri);
      
                $videoLink = $videoData["body"]["link"] ?? "";
                $fundamental->vimeo_link = $videoLink;
            }else{
                $fundamental->vimeo_link = $request->vimeo_link ?? "";
            }
            $fundamental->save();
            return ApiResponse::success($fundamental,'Fundamental details updated successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function postGuide(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'title' => 'required',
                'description' => 'required'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(isset($request->id)){
                $guide = Guide::find($request->id);
                if(!$guide){
                    return ApiResponse::error('Guide not found!!');
                }
                $status = 'updated';
            }else{
                $guide = new Guide();
                $status = 'added';
            }
            $guide->title = $request->title;
            $guide->description = $request->description;
            $guide->save();
            $fundamentalsData = [];
            $guide->fundamentals = $fundamentalsData;
            return ApiResponse::success($guide,'Guide '.$status.' successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function postGuideFundamentals(Request $request)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_GUIDE_PATH');
            $step_img_path = env('AWS_GUIDE_STEP_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'guide_id' => 'required',
                'name' => 'required',
                'description' => 'required',
                'main_image' => 'nullable',
                'secondary_image' => 'nullable',
                'secondary_vimeo_link' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $guide = Guide::find($request->guide_id);
            if(!$guide){
                return ApiResponse::error('Guide not found!!');
            }
            if(isset($request->id)){
                $guide_fundamental = GuideFundamental::find($request->id);
                if(!$guide_fundamental){
                    return ApiResponse::error('Guide Fundamental not found!!');
                }
                $status = 'updated';
            }else{
                $guide_fundamental = new GuideFundamental();
                $status = 'added';
            }
            $guide_fundamental->guide_id = $request->guide_id;
            $guide_fundamental->title = $request->name;
            $guide_fundamental->description = $request->description;
            $main_image = $secondary_image = "";
            
            if($request->hasFile('main_image')){
                $validatedData = $request->validate([
                    'main_image' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_main_image = $request->file('main_image');
                $filename_main_img = uniqid() . '_main_img.' . $file_main_image->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_main_image, $filename_main_img, 'public');
                $main_image = $filename_main_img;
                $guide_fundamental->main_image = $main_image;
            }
            if($request->hasFile('secondary_image')){
                $validatedData = $request->validate([
                    'secondary_image' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_secondary_image = $request->file('secondary_image');
                $filename_secondary_image = uniqid() . '_secondary_image.' . $file_secondary_image->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_secondary_image, $filename_secondary_image, 'public');
                $secondary_image = $filename_secondary_image;
                $guide_fundamental->secondary_image = $secondary_image;
            }
            if(isset($request->id) && $request->main_image == "" ){
                $guide_fundamental->main_image = "";
            }
            if(isset($request->id) && $request->secondary_image == "" ){
                $guide_fundamental->secondary_image = "";
            }
            $guide_fundamental->secondary_vimeo_link = $request->secondary_vimeo_link  ?? "";
            $micro_move_steps_data = [];
            // $micro_move_steps = json_decode($request->micro_move_steps) ;
            // if(!empty($micro_move_steps)){
            //     foreach($micro_move_steps as $key => $micro_moves){
            //         $micro_move_steps_data[$key]['title'] = $micro_moves->title ?? "";
            //         $micro_move_steps_data[$key]['description'] = $micro_moves->description ?? "";
            //         $micro_move_steps_data[$key]['updated_at'] = $micro_moves->updated_at ?? "";
                  
            //         if(!empty($micro_moves->steps)){
            //             foreach ($micro_moves->steps as $keyy => $step) {
            //                 $steps[$keyy]['details'] = $step->detail ?? "";
            //                 $steps[$keyy]['vimeo_link'] = $step->vimeo_link ?? "";
            //                 if( $step->image != ""){
            //                     $imageOld = $step->image;
            //                     if (Str::contains( $step->image,'guide_step_')) {
            //                         $steps[$keyy]['image'] =$imageOld;
            //                     }else{
            //                         $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $step->image));
            //                         $fileName = 'guide_step_' . uniqid() . '.png';
            //                         $filePath = $step_img_path."" . $fileName;
            //                         $imageUplaod = Storage::disk('s3')->put($filePath,  $imageData, 'public');
            //                         $steps[$keyy]['image'] = $fileName;
            //                     }
                                
            //                 }else{
            //                     $steps[$keyy]['image'] = "";
            //                 }
            //             }   
            //         }
            //         $micro_move_steps_data[$key]['steps'] = $steps;
            //     }
            // }
            // $guide_fundamental->micro_move_steps = $micro_move_steps_data;
            $micro_move_steps = json_decode($request->micro_move_steps);
            if (!empty($micro_move_steps)) {
                foreach ($micro_move_steps as $key => $micro_moves) {
                    // Initialize steps array here to ensure it's reset for each micro_move
                    $steps = []; 

                    $micro_move_steps_data[$key]['title'] = $micro_moves->title ?? "";
                    $micro_move_steps_data[$key]['description'] = $micro_moves->description ?? "";
                    $micro_move_steps_data[$key]['updated_at'] = $micro_moves->updated_at ?? "";
                
                    if (!empty($micro_moves->steps)) {
                        foreach ($micro_moves->steps as $keyy => $step) {
                            $steps[$keyy]['details'] = $step->detail ?? "";
                            $steps[$keyy]['vimeo_link'] = $step->vimeo_link ?? "";
                            if ($step->image != "") {
                                $imageOld = $step->image;
                                if (Str::contains($step->image, 'guide_step_')) {
                                    $parts = explode("/",  $imageOld);
                                    // Get the last index of the array
                                    $imageNew = end($parts);
                                    $steps[$keyy]['image'] = $imageNew;
                                } else {
                                    $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $step->image));
                                    $fileName = 'guide_step_' . uniqid() . '.png';
                                    $filePath = $step_img_path . "" . $fileName;
                                    $imageUpload = Storage::disk('s3')->put($filePath, $imageData, 'public');
                                    $steps[$keyy]['image'] = $fileName;
                                }
                            } else {
                                $steps[$keyy]['image'] = "";
                            }
                        }   
                    }
                    $micro_move_steps_data[$key]['steps'] = $steps; // Assign the reset $steps array for this micro_move
                }
            }
            $guide_fundamental->micro_move_steps = $micro_move_steps_data;
            $guide_fundamental->save();
            $guide_fundamental->main_image_url = $guide_fundamental->main_image != "" ? $appUrl."".$path."".$guide_fundamental->main_image :"";
            $guide_fundamental->secondary_image_url = $guide_fundamental->secondary_image != "" ? $appUrl."".$path."".$guide_fundamental->secondary_image :"";
            return ApiResponse::success($guide_fundamental,'Guide fundamentals '.$status.' successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function deleteGuideFundamentals($id, $guide_id)
    {
        try{
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(!$id){
                return ApiResponse::error("Guide fundamental id required!");
            }
            if(!$guide_id){
                return ApiResponse::error("Guide fundamental's guide id required!");
            }
            $guide_fundamental = GuideFundamental::where('_id',$id)->where('guide_id',$guide_id)->first();
            if($guide_fundamental){
                $guide_fundamental->delete();
                return ApiResponse::successOnly('Guide fundamental deleted successfully.');
            }else{
                return ApiResponse::error('Guide fundamental not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }


    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can get welcome question
    */
    public function getQuestion(Request $request)
    {
        try {
            // Retrieve the request parameters
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
            
            $questions = Question::orderBy('order')->get();
            foreach ($questions as $key => $question) {
                $question->order = $question->order ?? null;
                $question->answers = $question->answers ?? [];
                $question->text_ip_1 = $question->text_ip_1 ?? "";
                $question->text_ip_10 = $question->text_ip_10 ?? "";
            }
            //applied sorting
            $sortedData = Functions::sortArray($questions,$sortColumn);
            //applied filter
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);
            return ApiResponse::success($filteredResponse,'Question list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can update welcome question
    */
    public function updateQuestion(Request $request)
    {
        try {
            // Validate request parameters
            $validatedData = $request->validate([
                'question_id' => 'required',
                'text' => 'required|string',
                'question_type' => 'required|string',
                'can_skip' => 'nullable|boolean'
            ]);
            if($validatedData['question_type'] == "rating"){
                $validatedData1 = $request->validate([
                    'text_ip_1' => 'required|string',
                    'text_ip_10' => 'required|string',
                ]);
            }else{
                $validatedData1 = $request->validate([
                    'answers' => 'required|array',
                    'answers.*' => 'required|string',
                ]);
            }
            // Find the question by its ID
            $question = Question::find($request->question_id);
            
            if($question){
                // Update the question attributes based on the validated data
                $can_skip  = $question->can_skip != "" ? $question->can_skip  : false ;
                $question->text = $validatedData['text'];
                if($validatedData['question_type'] == "rating"){
                    $question->text_ip_1 = $validatedData1['text_ip_1'];
                    $question->text_ip_10 = $validatedData1['text_ip_10'];
                }else{
                    $question->answers = $validatedData1['answers'];
                }
                $question->question_type = $validatedData['question_type'];
                $question->can_skip = $validatedData['can_skip'] ?? $can_skip;
                if(!empty($request->order)){
                    $question->order = $request->order;
                }
                if(!empty($request->subtitle)){
                    $question->subtitle = $request->subtitle;
                }
                $question->save();
                return ApiResponse::success($question,'Question store successfully.');
            }else{
                return ApiResponse::error('Question not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can drag and order welcome question
    */
    public function dragQuestion(Request $request)
    {
        try {
            $details = $request->all();
            $questions = Question::all();
            if($questions->count() != sizeof($details)){
                return ApiResponse::error('Invalid Request!');
            }else{
                $i = 1;
                foreach ($details as $detail) {
                    $question = Question::find($detail['question_id']);
                    $question->order = $i;
                    $question->save(); 
                    $i++;
                }
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can store/update recall cards
    */
    public function storeRecallCards(Request $request)
    {
        try { // Validate request parameters
            $path = env('AWS_RECALL_CARD_PATH');
            $appUrl = env('AWS_S3_PATH');
            $validatedData = $request->validate([
                'question_text' => 'required|string',
                'answer_text' => 'required|string',
                'level' => 'required|integer',
                'tag' => 'nullable',
                'order' => ['required', 'integer'],
            ]);
            $order = intval($request->order);
            $existingOrderCount = RecallCard::where('order', $order)->count();
            if ($existingOrderCount > 0) {
                return ApiResponse::error('The order value is already taken.');
            }
            //store recall cards information
            if(!empty($request->id)){
                $recallCard = RecallCard::find($request->id);
                $title = $request->title ?? $recallCard->title;
                $question_text = $validatedData['question_text'] ?? $recallCard->question_text;
                $answer_text = $validatedData['answer_text'] ?? $recallCard->answer_text;
                $level = $validatedData['level'] ?? $recallCard->level;
                // $learn_more_video = $recallCard->learn_more_video;
                $question_img = $recallCard->question_img;
                $answer_img = $recallCard->answer_img;
                $recallCard->order = intval($request->order) ?? (intval($recallCard->order) ?? 0);
            }else{
                $recallCard = new RecallCard();
                $recallCard->order = $request->order ?? 0;
                $title = $request->title;
                $question_text = $validatedData['question_text'];
                $answer_text = $validatedData['answer_text'];
                $level = $validatedData['level'];
                // $learn_more_video = "";
                $question_img = "";
                $answer_img = "";
            }

            $link_items = [];
            if(!empty($request->link_items)){
                $reqLinkItem = json_decode($request->link_items);
                foreach ($reqLinkItem as $key => $val) {
                    $link_items[$key]['title'] = $val->title ?? "";
                    $link_items[$key]['link'] = $val->link ?? "";
                    $link_items[$key]['description'] = $val->description ?? "";
                }
                $recallCard->link_items = $link_items;
            }else{
                $recallCard->link_items = $link_items;
            }
            if(!empty($request->object_id)){
                $recallCard->object_id = $request->object_id ?? "";
            }else{
                $recallCard->object_id = "";
            }
            if(!empty($request->object_type_id)){
                $recallCard->object_type_id = $request->object_type_id ?? "";
            }
            if(!empty($request->object_type)){
                $recallCard->object_type = $request->object_type ?? "";
            }
         
            if($request->hasFile('question_img')){
                $validatedData = $request->validate([
                    'question_img' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_question_img = $request->file('question_img');
                $filename_question_img = uniqid() . '_recall_question_img_.' . $file_question_img->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_question_img, $filename_question_img, 'public');
                $question_img = $filename_question_img;
            }else{
                if($request->has('question_img')){
                    if($request->question_img == ""){
                        $question_img = "";
                    }
                }
            }
            if($request->hasFile('answer_img')){
                $validatedData = $request->validate([
                    'answer_img' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_answer_img = $request->file('answer_img');
                $filename_answer_img = uniqid() . '_recall_answer_img_.' . $file_answer_img->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_answer_img, $filename_answer_img, 'public');
                $answer_img = $filename_answer_img;
            }else{
                if($request->has('answer_img')){
                    if($request->answer_img == ""){
                        $answer_img = "";
                    }
                }
            }
            $recallCard->show = $request->show ?? true;
         //   $recallCard->learn_more_video = $learn_more_video;
            $recallCard->question_img = $question_img;
            $recallCard->answer_img = $answer_img;
            $recallCard->title = $title;
            $recallCard->question_text = $question_text;
            $recallCard->answer_text = $answer_text;
            $recallCard->level = $level ?? 0;
            if(!empty($request->tag)){
                $recallCard->tag =$request->tag ?? null;
            }
            $recallCard->save();
            $recallCard->learn_more_video = "";
            $recallCard->question_img = $recallCard->question_img != "" ? $appUrl."".$path."".$recallCard->question_img :"";
            $recallCard->answer_img = $recallCard->answer_img != "" ? $appUrl."".$path."".$recallCard->answer_img :"";
            // $recallCard->learn_more_video = $recallCard->learn_more_video != "" ? $appUrl."".$path."".$recallCard->learn_more_video :"";
            return ApiResponse::success($recallCard,'Recall Card detail stored successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function sendPushNotificationToUsers(Request $request)
    {
        try { 
            $validatedData = $request->validate([
                'title_text' => 'required',
                'body_text' => 'required',
                'user_ids' => 'nullable|array'
            ]);
              
            $title_text = $validatedData['title_text'];
            $body_text = $validatedData['body_text'];
        
            if (!empty($validatedData['user_ids'])) {
                $req_user_ids = $validatedData['user_ids'];
                foreach ($req_user_ids as $user_id) {
                   
                    $user = User::find($user_id["userid"]);
                    if ($user) {
                        if (isset($user->fcm_token) && !empty($user->fcm_token)) {
                            $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();
                            if($userFcmTokens->count() > 0){
                                foreach ($userFcmTokens as $userFcmToken) {
                                    $response = $this->sendNotification($userFcmToken, $title_text, $body_text);
                                    $messageId = "";
                                    if (isset($response['name'])) {
                                        // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                        $MessageData = explode('/',$response['name']);
                                        $messageId = $MessageData[3] ?? "";
                                    }
                                    if ($messageId != "") {
                                        $notification = new Notification();
                                        $notification->title = $title_text;
                                        $notification->description = $body_text;
                                        $notification->user_id = $user->userid;
                                        $notification->is_read = false;
                                        $notification->save();
                                    }
                                }
                            }else{
                                $response = $this->sendNotification($user->fcm_token, $title_text, $body_text);
                                $messageId = "";
                                if (isset($response['name'])) {
                                    // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                    $MessageData = explode('/',$response['name']);
                                    $messageId = $MessageData[3] ?? "";
                                }
                                if ($messageId != "") {
                                    $notification = new Notification();
                                    $notification->title = $title_text;
                                    $notification->description = $body_text;
                                    $notification->user_id = $user->userid;
                                    $notification->is_read = false;
                                    $notification->save();
                                }
                            }
                           
                        } 
                    }
                }
                return ApiResponse::successOnly('Push notification sent successfully.');
            }else{
                return ApiResponse::error('Please select user first.');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function recallCardSettingUpdate(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'recall_card_ids' => 'nullable|array',
                'show' => 'boolean'
            ]);
            if (!empty($validatedData['recall_card_ids'])) {
                $req_recall_card_ids = $validatedData['recall_card_ids'];
                foreach ($req_recall_card_ids as $recall_card_id) {
                    $recall_card = RecallCard::find($recall_card_id["id"]);
                    $recall_card->show = $validatedData['show'];
                    $recall_card->save();
                }
                return ApiResponse::successOnly('Recall card setting updated successfully.');
            }else{
                return ApiResponse::error('Please select recall card first.');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function sendPushNotificationToUsersOld(Request $request)
    {
        try { // Validate request parameters
            $validatedData = $request->validate([
                'title_text' => 'required',
                'body_text' => 'required',
                'user_ids' => 'nullable'
            ]);
              
            $title_text = $validatedData['title_text'];
            $body_text = $validatedData['body_text'];
          
            if(!empty($request->user_ids)){
                $req_user_ids = json_decode($request->user_ids);
                foreach ($req_user_ids as $key => $val) {
                    $user = User::find($val->userId);
                    if($user){
                        $response = $this->sendNotification($user->fcm_token,$title_text,$body_text);
                        // $data = json_decode($response);
                        // if ($data !== null && $data->success == 1 ) {
                        //     $messageId = $data->results[0]->message_id;
                        // } else {
                        //     $messageId = "";
                        // }
                        if (isset($response['name'])) {
                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                            $MessageData = explode('/',$response['name']);
                            $messageId = $MessageData[3] ?? "";
                        } else {
                            // echo 'Error in response: ' . $response;
                            $messageId = "";
                        }
                        if ($messageId != "") {
                            $notification = new Notification();
                            $notification->title = $title_text;
                            $notification->description = $body_text;
                            $notification->user_id = $user->userid;
                            $notification->is_read = false;
                            $notification->save();
                        }
                    }
                }
                return ApiResponse::successOnly('Push notification sent successfully.');
            }else{
                return ApiResponse::error('Please select user first.');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can get recall cards
    */
    public function getRecallCards(Request $request)
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_RECALL_CARD_PATH');
            $objectPath = env('AWS_OBJECT_IMAGES_PATH');
            $token = $this->getTokenFromHeader();
            $req_param = $request->all();// Retrieve the request parameters
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
            $tags = Tags::pluck('name','_id')->toArray();
            $recallCards = RecallCard::orderBy('order','asc')->get();
            foreach ($recallCards as $key => $recallCard) {
                $tagData = [];
                $recallCard->question_img = $recallCard->question_img ?? null;
                $recallCard->answer_img = $recallCard->answer_img ?? null;
                $recallCard->tag = $recallCard->tag ?? null;
                $recallCard->order = intval($recallCard->order) ?? 0;
                $recallCard->show = $recallCard->show ?? true;
                if(!empty($recallCard->tag)){
                    $recallCard_tag = explode(",",$recallCard->tag);
                    if(!empty($recallCard_tag)){
                        foreach ($recallCard_tag as $key => $tag) {
                            $tagData[] = $tags[$tag] ?? "";
                        }
                    }
                }
                // Remove empty and null values
                $filteredArray = array_filter($tagData, function ($value) {
                    return !empty($value);
                });
                $recallCard->tagName = implode(",",$filteredArray);
                $recallCard->learn_more_video ="";
               // $recallCard->learn_more_video = $recallCard->learn_more_video != "" ? $appUrl."".$path."".$recallCard->learn_more_video :"";
                $recallCard->question_img = $recallCard->question_img != "" ? $appUrl."".$path."".$recallCard->question_img :"";
                $recallCard->answer_img = $recallCard->answer_img != "" ? $appUrl."".$path."".$recallCard->answer_img :"";
                $recallCard->link_items = $recallCard->link_items ?? [];
                // if($recallCard->object_id != ""){
                //     $userObject = UserObjectType::find($recallCard->object_id);
                //     $objectType = ObjectType::find($userObject->object_type_id);
                //     $recallCard->object_type = $objectType->name ?? '';
                //     $recallCard->object_type = $objectType->name ?? '';
                //     $recallCard->object_name = $userObject->object_name ?? "";
                //     $recallCard->object_file  =  $userObject->file != '' && !(Str::contains($userObject["file"], 'storage/storage/')) ? $appUrl.''.$objectPath.''.$userObject->file : '';
                //     $recallCard->object_video_id = $userObject->video_id ?? "";
                //     $recallCard->object_type_id = $userObject->object_type_id ?? "";
                //     $recallCard->object_headline = $userObject->headline ?? "";
                //     $recallCard->object_subtitle = $userObject->subtitle ?? "";
                //     $recallCard->object_description = $userObject->description ?? "";
                // }else{
                //     $recallCard->object_type_id = '';
                //     $recallCard->object_type = '';
                //     $recallCard->object_name = '';
                //     $recallCard->object_file  = '';
                //     $recallCard->object_video_id = "";
                //     $recallCard->object_headline = "";
                //     $recallCard->object_subtitle = "";
                //     $recallCard->object_description =  "";
                // }
            }
            
            $sortedData = Functions::sortArray($recallCards,$sortColumn);//applied sorting
            $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['title','question_text','answer_text','tagName','created_at']);//applied filter
            $totalRecallCards = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            $totalPage = !empty($request->per_page ) ? $totalRecallCards/ $request->per_page : 1;
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ;
                $page = $request->page;
                $currentPage  = $page - 1;
                if (is_array($filteredResponse)) {
                    $filteredResponse = collect($filteredResponse);
                }
                $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                $filteredResponse = array_values($pagedData);
            }
            
            $newRoot = [
                'total_page' => ceil($totalPage),
                'total_recall_cards' => $totalRecallCards,
                'recall_cards' => $filteredResponse
            ];
            return ApiResponse::success($newRoot,'Recall cards list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can delete recall cards
    */
    public function deleteRecallCards($id)
    {
        try {
            if(!$id){
                return ApiResponse::error('Recall Card id required!!');
            }
            $recallCard = RecallCard::find($id);
            if($recallCard){
                $recallCard->delete();
                return ApiResponse::successOnly('Recall Card deleted successfully.');
            }else{
                return ApiResponse::error('Recall Card not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function uploadCoachReview(Request $request)
    {
        $appUrl = env('AWS_S3_PATH');
        $path = env('AWS_COACH_REVIEW_PATH');
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                // Validate request parameters
                $validatedData = $request->validate([
                    'file' => 'required|mimetypes:video/mp4,video/quicktime,video/webm,video/mpeg,video/ogg,video/x-msvideo' // Adjust the maximum file size as needed
                ]);
        
    
                if ($request->hasFile('file') && $request->file('file')->isValid()) {
                    // $extension = $request->file('file')->getClientOriginalExtension();
                    //$path = $request->file('file')->store('public/storage/coach_review');
                    //$fileUploaded = Storage::url($path);
                    $coach_review = new CoachReview();
                    $coach_review->user_id = $user["_id"];
                    //$coach_review->file = $fileUploaded;

                    $file = $request->file('file');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $coach_review->file = $filename;
                    $coach_review->save();
                    return ApiResponse::success($coach_review,'Coach review video uploaded successfully.');
                }
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function uploadSwing(Request $request)
    {
        $appUrl = env('AWS_S3_PATH');
        $swingPath = env('AWS_SWING_PATH');
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            
            if($user){
                // $validatedData = $request->validate([
                //     'face_on_duration' => 'required',
                //     'down_the_line_duration' => 'required',
                //     'down_the_line' => 'required|mimetypes:video/mp4,video/quicktime,video/webm,video/mpeg,video/ogg,video/x-msvideo', // Adjust the maximum file size as needed
                //     'face_on' => 'required|mimetypes:video/mp4,video/quicktime,video/webm,video/mpeg,video/ogg,video/x-msvideo', // Adjust the maximum file size as needed
                //     'direction' => 'nullable',
                //     'curve' => 'nullable',
                //     'face' => 'nullable',
                //     'contact' => 'nullable',
                //     'description' => 'nullable',
                //     'submit_to_coach' => 'required'
                // ]);
                if(!empty($request->id)){
                    $swing = Swing::find($request->id);
                }else{
                    $swing = new Swing();
                }
                
                $swing->user_id = $user["_id"];
                if ($request->hasFile('face_on') && $request->file('face_on')->isValid()) {
                    $file = $request->file('face_on');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    Storage::disk('s3')->putFileAs($swingPath, $file, $filename, 'public');
                    $swing->face_on = $filename;
                }
                if ($request->hasFile('down_the_line') && $request->file('down_the_line')->isValid()) {
                    $down_the_linefile = $request->file('down_the_line');
                    $down_the_linefilename = uniqid() . '.' . $down_the_linefile->getClientOriginalExtension();
                    Storage::disk('s3')->putFileAs($swingPath, $down_the_linefile, $down_the_linefilename, 'public');
                    $swing->down_the_line = $down_the_linefilename;
                }
                $swing->status = "Pending";
                $swing->title =  uniqid();
                $swing->face_on_duration = $request->face_on_duration ?? "";
                $swing->down_the_line_duration = $request->down_the_line_duration ?? "";
                
                $swing->direction = $request->direction ?? "";
                $swing->curve = $request->curve ?? "";
                $swing->contact = $request->contact ?? "";
                $swing->face = $request->face ?? "";
                $swing->description = $request->description ?? "";
                $swing->down_the_line_filesize = $request->down_the_line_filesize ?? "";
                $swing->face_on_filesize = $request->face_on_filesize ?? "";
                if($request->submit_to_coach == "false"){
                    $submit_to_coach = false;
                }else{
                    $submit_to_coach = true;
                }
             
               
                if($submit_to_coach === true){
                    $today = now()->format("Y-m-d");
                    $user_active_coach_review = UserCoachReview::where('user_id',$user["userid"])->where('expiration_date','>=',$today)->where('status','active')->orderBy('created_at')->first();
                
                    if($user_active_coach_review){
                        $swing->submit_to_coach = true;
                        $swing->submit_to_coach_at = now();
                        $swing->save();
                        $newUsedCoachReview = $user_active_coach_review->used_coach_review + 1;
                        $user_active_coach_review->used_coach_review = $newUsedCoachReview;
                        if($user_active_coach_review->coach_review == $newUsedCoachReview ){
                            $user_active_coach_review->status = "expired";
                        }
                        $user_active_coach_review->save();

                        $coach = User::where('user_type','coach')->get();
                        foreach ($coach as $admin) {
                            $coach_name = $admin->full_name ?? "";
                            $user_name = User::find($swing->user_id)->full_name ?? "";
                            Mail::to($admin->email)->send(new CoachReminderEmail($swing->_id, $coach_name, $user_name));
                        }
                        $showWeeklyForm = 0;
                        $countries = Country::pluck('timezone','_id')->toArray();
                        $userDetail = User::find($user["_id"]);
                        $userTimezone = $countries[$userDetail->country_id] ?? "";
                        
                        if ( $userTimezone!= "" && Carbon::now($userTimezone)->isSunday()) {
                            $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                            $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                            $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                                $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                            });
                            if($filteredWeeklyForms->count() == 0){
                                $showWeeklyForm = 1;
                            }
                        }
                        $swing->show_weekly_form = $showWeeklyForm ?? 0;
                        $swing->down_the_line = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                        $swing->face_on = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                        return ApiResponse::success($swing,'Swing video uploaded successfully.');
                    }else{
                        $swing->submit_to_coach = false;
                        $swing->save();
                        $showWeeklyForm = 0;
                        $countries = Country::pluck('timezone','_id')->toArray();
                        $userDetail = User::find($user["_id"]);
                        $userTimezone = $countries[$userDetail->country_id] ?? "";
                        
                        if ( $userTimezone!= "" && Carbon::now($userTimezone)->isSunday()) {
                            $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                            $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                            $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                                $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                            });
                            if($filteredWeeklyForms->count() == 0){
                                $showWeeklyForm = 1;
                            }
                        }
                        $swing->show_weekly_form = $showWeeklyForm ?? 0;
                        $swing->down_the_line = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                        $swing->face_on = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                        return ApiResponse::success($swing,'Swing video uploaded successfully but it not get sent to coach due to Insufficient coach review balance. Please buy coach review first.');
                    }
                }else{
                    $swing->submit_to_coach = false;
                        $swing->save();
                        $showWeeklyForm = 0;
                        $countries = Country::pluck('timezone','_id')->toArray();
                        $userDetail = User::find($user["_id"]);
                        $userTimezone = $countries[$userDetail->country_id] ?? "";
                        
                        if ( $userTimezone!= "" && Carbon::now($userTimezone)->isSunday()) {
                            $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                            $weeklyForms = UserWeeklySurvey::where('user_id',$userDetail->_id)->get();
                            $filteredWeeklyForms = $weeklyForms->filter(function ($weeklyForm) use ($userTimezone, $currentDateInUserTimezone) {
                                $createdAtInUserTimezoneWeeklyForms = Carbon::parse($weeklyForm->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                return $createdAtInUserTimezoneWeeklyForms === $currentDateInUserTimezone;
                            });
                            if($filteredWeeklyForms->count() == 0){
                                $showWeeklyForm = 1;
                            }
                        }
                        $swing->show_weekly_form = $showWeeklyForm ?? 0;
                        $swing->down_the_line = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                        $swing->face_on = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                        return ApiResponse::success($swing,'Swing video uploaded successfully but it not get sent to coach due to Insufficient coach review balance. Please buy coach review first.');
                    
                }
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function sendresetpasswordLink(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $admin = \JWTAuth::setToken($token)->authenticate();
            
            if(!$admin) {
                return ApiResponse::error('Trouble fetching admin user information');
            }
            //validate req parameter
            $request->validate([
                'user_id' => 'required'
            ]);
            //retrieve user data
            $user = User::find($request->user_id);
            
            if($user){
                //send forgot password email
                $token = Password::broker()->createToken($user);

                if($user->country_id != ""){
                    $country = Country::find($user->country_id);
                    $userTimezone = $country->timezone ?? "";
                }else{
                    $userTimezone = "";
                }
                $tokenInstance = DB::table('password_resets')
                                ->where('email', $user->email)
                                ->first();

                if ($tokenInstance) {
                    if($userTimezone != ""){
                        $created_at = Carbon::now($userTimezone)->format('Y-m-d H:i:s');
                    }else{
                        $created_at = Carbon::now()->format('Y-m-d H:i:s');
                    }
                    DB::table('password_resets')
                    ->where('_id', $tokenInstance['_id'])
                    ->update([
                        'created_at' => $created_at
                    ]);
                }

                $link = env('ADMIN_URL') . "forgetpassword/" . $token."/".$user->email;
                
                Mail::to($user["email"])->send(new ForgetpasswordEmail($user["id"],$link));
                return ApiResponse::successOnly('Reset password link sent successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getNotificationByUser($user_id, Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            $req_param = $request->all();// Retrieve the request parameters
            $sortColumn = $req_param['sortBy'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
            $userNotification = User::find($user_id);
        
            $notification = Notification::where('user_id',$userNotification->userid)->orderBy('created_at','desc')->get(); //get all notification of user
     
            $sortedData = Functions::sortArray($notification,$sortColumn);//applied sorting
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//applied filter
            $totalNotifications = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
                $totalPage = !empty($request->per_page ) ? $totalNotifications/ $request->per_page : 1;
                if(!empty( $request->per_page) && !empty( $request->page)){
                    $perPage = $request->per_page ;
                    $page = $request->page;
                    $currentPage  = $page - 1;
                    if (is_array($filteredResponse)) {
                        $filteredResponse = collect($filteredResponse);
                    }
                    $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                    $filteredResponse = array_values($pagedData);
                }
                
                $newRoot = [
                    'total_page' => ceil($totalPage),
                    'total_notifications' => $totalNotifications,
                    'notifications' => $filteredResponse,
                    'current_page' => $request->page ?? 1
                ];
            return ApiResponse::success($newRoot,'Here is the notification history.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side coach can add coach review
    */
    public function updateCoachReview(Request $request)
    {
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $path = env('AWS_COACH_REVIEW_PATH');
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            if($user->user_type != "coach") {
                return ApiResponse::error('Only coach can add review on this.');
            }
            if($user){
                // Validate request parameters
                $validatedData = $request->validate([
                    'swing_id' => 'required',
                    'status' => 'required',
                    // 'description' => 'required',
                    // 'vimeo_link' => 'required',
                    
                    // 'title' => 'nullable',
                    // 'comment' => 'nullable',
                    // 'rating' => 'nullable',
                    // 'file' => 'nullable|mimetypes:video/mp4,video/quicktime,video/webm,video/mpeg,video/ogg,video/x-msvideo' // Adjust the maximum file size as needed
                ]);
                $swing = Swing::find($validatedData["swing_id"]);
                if(!$swing){
                    return ApiResponse::error('Trouble fetching swing video information');
                }
                if(!empty($request->id)){
                    $updt_status = "updated";
                    $admin_coach_review = AdminCoachReview::find($request->id);
                }else{
                    $updt_status = "added";
                    $admin_coach_review = new AdminCoachReview();
                }
                // if($validatedData["status"] == "Reviewed"){
                    $admin_coach_review->coach_id = $user["_id"];
                    $admin_coach_review->type = "Coach Review";
                    $admin_coach_review->swing_id = $validatedData["swing_id"];
                    $admin_coach_review->status = $validatedData["status"];
                    $admin_coach_review->description = $request->description ?? "";
                    $admin_coach_review->vimeo_link = $request->vimeo_link ?? "";
                    if(!empty($request->drills)){
                        $drills = [];
                        if(!empty($request->drills)){
                            $reqLinkItem = json_decode($request->drills);
                            foreach ($reqLinkItem as $key => $val) {
                                $drills[$key]['object_id'] = $val->object_id ?? "";
                            }
                            $admin_coach_review->drills = $drills;
                        }else{
                            $admin_coach_review->drills = $drills;
                        }
                    }
                    $admin_coach_review->save();
                    // $admin_coach_review->title = $validatedData["title"] ?? "";
                    // $admin_coach_review->comment = $validatedData["comment"] ?? "";
                    // $admin_coach_review->rating = (float)$validatedData["rating"] ?? 0;
                    // if ($request->hasFile('file') && $request->file('file')->isValid()) {
                    //     // $extension = $request->file('file')->getClientOriginalExtension();
                    //     // $path = $request->file('file')->store('public/storage/coach_review');
                    //     // $fileUploaded = Storage::url($path);
                    //     // $admin_coach_review->file = $fileUploaded;
                    //     $file = $request->file('file');
                    //     $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    //     Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    //     $admin_coach_review->file = $filename;
                    // }
                    
                // }else{
                //     $admin_coach_review = [];
                // }
                $swing->status = $validatedData["status"];
                $swing->save();
                if($validatedData["status"]  == "Completed"){
                    $app_user = User::find($swing->user_id);
               
                    if(!empty($app_user->fcm_token)){
                        $title = 'Swing Video Ready';
                        $body = 'Your Swing Video has been reviewed by a Fisio™ coach. To view click on "Swing Review" on the Feedback page.';
                        $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();
                        if($userFcmTokens->count() > 0){
                            foreach ($userFcmTokens as $userFcmToken) {
                                $messageId = "";
                                $response = $this->sendNotification($userFcmToken,$title,$body);
                                if (isset($response['name'])) {
                                    $MessageData = explode('/',$response['name']);
                                    $messageId = $MessageData[3] ?? "";
                                }
                                if ($messageId != "") {
                                    $notification = new Notification();
                                    $notification->title = $title;
                                    $notification->description = $body;
                                    $notification->user_id = $app_user->userid;
                                    $notification->is_read = false;
                                    $notification->save();
                                }
                            }
                        }else{
                            $messageId = "";
                            $response = $this->sendNotification($app_user->fcm_token,$title,$body);
                            if (isset($response['name'])) {
                                $MessageData = explode('/',$response['name']);
                                $messageId = $MessageData[3] ?? "";
                            }
                            if ($messageId != "") {
                                $notification = new Notification();
                                $notification->title = $title;
                                $notification->description = $body;
                                $notification->user_id = $app_user->userid;
                                $notification->is_read = false;
                                $notification->save();
                            }
                        }
                    }
                }
                return ApiResponse::success($admin_coach_review,'Coach Review '.$updt_status.' successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function updateSkipReminder(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            //$path = env('AWS_COACH_REVIEW_PATH');
            if(!$user) {
                return ApiResponse::error('Trouble fetching` user information');
            }else{
                $validatedData = $request->validate([
                    'user_id' => 'required',
                ]);
                $user = User::find($request->user_id);
                $daily_reminder = $user->skip_reminder ?? true;
                if($daily_reminder == true){
                    $user->skip_reminder = false;
                    $updt_status = "false";
                    $user->dailyReminder = true;  
                    $user->dailyReminderSelection = true;
                }else{
                    $user->skip_reminder = true;
                    $user->dailyReminder = false;  
                    $user->dailyReminderSelection = false;
                    $updt_status = "true";
                }
                $user->save();
                return ApiResponse::success($user,'Skip reminder set as '.$updt_status.' successfully.');
            }

        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function updateFreeUser(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
          //  $path = env('AWS_COACH_REVIEW_PATH');
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }else{
                $validatedData = $request->validate([
                    'email' => 'required',
                ]);  
                if(!empty($request->id)){
                    $updt_status = "updated";
                    $FreeUser = FreeUser::find($request->id);
                }else{
                    $updt_status = "added";
                    $FreeUser = new FreeUser();
                }
                $FreeUser->email = $request->email;
                $FreeUser->admin_id = $user->_id;
                $FreeUser->save();
                return ApiResponse::success($FreeUser,'Free User Email '.$updt_status.' successfully.');
            }

        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updateCoachRepReview(Request $request)
    {
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
          //  $path = env('AWS_COACH_REVIEW_PATH');
            if(!$user) {
                return ApiResponse::error('Trouble fetching user information');
            }
            if($user->user_type != "coach") {
                return ApiResponse::error('Only coach can add review on this.');
            }
            if($user){
                // Validate request parameters
                $validatedData = $request->validate([
                    'swing_id' => 'required',
                    'status' => 'required',
                   // 'video' => 'required|mimes:mp4,mov,avi|max:20000' // Set your own validation rules
                ]);
                $swing = RepReview::find($validatedData["swing_id"]);
                if(!$swing){
                    return ApiResponse::error('Trouble fetching rep review video information');
                }
                if(!empty($request->id)){
                    $updt_status = "updated";
                    $admin_coach_review = AdminCoachReview::find($request->id);
                }else{
                    $updt_status = "added";
                    $admin_coach_review = new AdminCoachReview();
                }
              
                // if($validatedData["status"] == "Reviewed"){
                    $admin_coach_review->coach_id = $user["_id"];
                    $admin_coach_review->swing_id = $validatedData["swing_id"];
                    $admin_coach_review->type = "Rep Review";
                    $admin_coach_review->status = $validatedData["status"];
                    $admin_coach_review->description = $request->description ?? "";

                    if($request->hasFile('video')){
                        $file = $request->file('video');
                        $filePath = $file->getPathname();
                        $fileName = $file->getClientOriginalName();
                        $vimeo = new Vimeo(
                            "782629a63bc327483978632274a9c468bbf3326f",
                            "O4h9TvQDG+akyF097q+sOodzGi3p3/vMCGnm52j9J3zJMc9LZx4Jk4LL/BNVp1ohckDCa4+3/kIRTbAbFZ7x511oivwK1z2zTIUBfmaL1/zgHnz5xZq/hMpMoTLroiGQ",
                            "6a0d7f9b2949f9f03146fe44def94bfc"
                        );
                        ini_set('sys_temp_dir', storage_path('app/tmp'));
                        // Upload the video to Vimeo
                        $uri = $vimeo->upload($filePath, [
                            'name' => $fileName,
                            'description' => 'Rep Review Video from Coach'
                        ]);
                     
                        // Get video information (optional)
                        $videoData = $vimeo->request($uri);
              
                        $videoLink = $videoData["body"]["link"] ?? "";
                        
                        $admin_coach_review->vimeo_link = $videoLink;
                        $admin_coach_review->videoData = $videoData ?? [];
                        $admin_coach_review->thumbnail = $videoData['body']["uploader"]['pictures']['base_link'] ?? "";
                        // $thumbnailLink = $videoData['body']['pictures']['sizes'][0]['link'];
                    }else{
                        $admin_coach_review->vimeo_link = $request->vimeo_link ?? "";
                    }
                   
                    $admin_coach_review->save();
                    if($validatedData["status"]  == "Completed"){
                        $swing->status ="Complete";
                    }else{
                        $swing->status = "Feedback";
                    }
                    $swing->review_status = $validatedData["status"];
                    $swing->save();
                if($validatedData["status"]  == "Completed"){
                    $app_user = User::find($swing->user_id);
                    if(!empty($app_user->fcm_token)){
                        $title = 'Rep Review Ready';
                        $body = 'Your Rep Review Video has been reviewed by a Fisio™ trainer. To view click on "Rep Review" on the Home page.';
                        $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();
                        if($userFcmTokens->count() > 0){
                            foreach ($userFcmTokens as $userFcmToken) {
                                $messageId = "";
                                $response = $this->sendNotification($userFcmToken,$title,$body);
                                if (isset($response['name'])) {
                                    $MessageData = explode('/',$response['name']);
                                    $messageId = $MessageData[3] ?? "";
                                }
                                if ($messageId != "") {
                                    $notification = new Notification();
                                    $notification->title = $title;
                                    $notification->description = $body;
                                    $notification->user_id = $app_user->userid;
                                    $notification->is_read = false;
                                    $notification->save();
                                }
                            }
                        }else{
                            $messageId = "";
                            $response = $this->sendNotification($app_user->fcm_token,$title,$body);
                            if (isset($response['name'])) {
                                $MessageData = explode('/',$response['name']);
                                $messageId = $MessageData[3] ?? "";
                            }
                            if ($messageId != "") {
                                $notification = new Notification();
                                $notification->title = $title;
                                $notification->description = $body;
                                $notification->user_id = $app_user->userid;
                                $notification->is_read = false;
                                $notification->save();
                            }
                        }
                    }
                }
                return ApiResponse::success($admin_coach_review,'Rep Review '.$updt_status.' successfully.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    // public function sendNotification($fcmToken,$title,$body)
    // {
    //     $projectId = env('FCM_PROJECT_ID');
    //     $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
    //     // $serverKey = env('FCM_SERVER_KEY'); // Replace with your FCM server key
    //     // $headers = [
    //     //     'Authorization: key=' . $serverKey,
    //     //     'Content-Type: application/json',
    //     // ];
    //     $serviceAccountPath = storage_path(env('GOOGLE_SERVICE_ACCOUNT_PATH'));
    //     $accessToken = $this->getAccessToken($serviceAccountPath);
    //     $headers = [
    //         'Authorization: Bearer ' . $accessToken,
    //         'Content-Type: application/json'
    //     ];
    //     // $data = [
    //     //     'to' => $fcmToken,
    //     //     "priority" =>  "high",
    //     //     "data" => [
    //     //         "click_action"  =>  "FLUTTER_NOTIFICATION_CLICK",
    //     //         "id"            =>  "1",
    //     //         "status"        =>  "done",
    //     //         "info"          =>  [
    //     //             "title"  => $title,
    //     //             'body' => $body,
    //     //         ]
    //     //     ],
    //     //     'notification' => [
    //     //         'title' => $title,
    //     //         'body' => $body,
    //     //     ],
    //     // ];
    //     $data = [
    //         'token' => $fcmToken,
    //         "priority" =>  "high",
    //         "data" => [
    //             "click_action"  =>  "FLUTTER_NOTIFICATION_CLICK",
    //             "id"            =>  "1",
    //             "status"        =>  "done",
    //             "info"          =>  [
    //                 "title"  => $title,
    //                 'body' => $body,
    //             ]
    //         ],
    //         'notification' => [
    //             'title' => $title,
    //             'body' => $body,
    //         ],
    //     ];
    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    //     curl_setopt($ch, CURLOPT_POST, true);
    //     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    //     $response = curl_exec($ch);
        
    //     if ($response === false) {
    //         echo 'cURL error: ' . curl_error($ch);// Handle the error if cURL request fails
    //     }
    //     curl_close($ch);
    //     return $response;
    // }
    public function sendNotification($fcmToken,$title,$body)
    {
        $projectId = env('FCM_PROJECT_ID');
        $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
        $serviceAccountPath = storage_path(env('GOOGLE_SERVICE_ACCOUNT_PATH'));
        $accessToken = $this->getAccessToken($serviceAccountPath);

        $headers = [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ];
        $message = [
            'token' => $fcmToken,
            'notification' => [
            'title' => $title,
            'body' => $body,
            ],
           ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['message' => $message]));
        $response = curl_exec($ch);
         if ($response === false) {
         throw new Exception('Curl error: ' . curl_error($ch));
         }
        curl_close($ch);
        return json_decode($response, true);

    }


    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can delete coach review
    */
    public function deleteCoachReview($id)
    {
        try {
            if(!$id){
                return ApiResponse::error('Coach review id required!!');
            }
            $admin_coach_review = AdminCoachReview::find($id);
            if($admin_coach_review){
                $admin_coach_review->delete();
                return ApiResponse::successOnly('Coach review deleted successfully.');
            }else{
                return ApiResponse::error('Coach review not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: app side admin can delete swing video
    */
    public function deleteSwing($id)
    {
        try {
            if(!$id){
                return ApiResponse::error('Swing video id required!!');
            }
            $swing = Swing::find($id);
            if($swing){
                $swing->delete();
                return ApiResponse::successOnly('Swing video deleted successfully.');
            }else{
                return ApiResponse::error('Swing video not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side admin can delete welcome question
    */
    public function deleteQuestion($id)
    {
        try {
            if(!$id){
                return ApiResponse::error('Question id required!!');
            }
            $question = Question::find($id);
            if($question){
                $question->delete();
                return ApiResponse::successOnly('Question deleted successfully.');
            }else{
                return ApiResponse::error('Question not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: ads detail based on page
    */
    public function getQuote(Request $request)
    {
        try{
            $quote = TrustQuote::all();
            return ApiResponse::success($quote,'Trust quote found successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getAdminListDecBefore(Request $request)
    {
        $req_param = $request->all();
        $sortColumn = $req_param['sort'] ?? "";
        $filterColumn = $req_param['filterBy'] ?? "";
        $filteredVal = $req_param['filteredVal'] ?? "";
        $unit_name_array = $session_name_array = [];
        try {
            $arrayField = array("_id","full_name", "email", "user_type","registered_at","userid","is_confirm","updated_at","created_at");
            $perPage = $request->per_page ?? 10; // Number of users per page
            // $search = $request->input('search');
            $type = $request->input('type');
          
            if($type == 'user'){
                $filter = $req_param['filter_dashboard'] ?? "";
                $threeDaysAgo = Carbon::now()->subDays(3);
                $sevenDaysAgo = Carbon::now()->subDays(7);
                $fourDaysAgo = Carbon::now()->subDays(4);
                $query = User::whereIn('user_type', ['user']);
                $unit_name_array = Unit::pluck('unit_name','_id')->toArray();
                $session_name_array = Session::pluck('session_name','_id')->toArray();
                $free_plan_usersID = User::where('user_type','user')->where('is_confirm',1)->pluck('_id')->toArray();
                $basic_plan_usersID = [];
                $premium_plan_usersID = [];
                $pro_plan_usersID = [];
                $plans = Plan::pluck('_id','name')->toArray();
         
                    
                $userIds = User::where('user_type','user')->where('is_confirm',1)->pluck("_id")->toArray();
                $basic_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Basic"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
                $premium_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Premium"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
                $pro_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Ultra"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
                $free_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Free 7-Day Trial"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
            
                if($filter == "free_plan_count"){
                    $query = $query->whereIn('_id',$free_plan_usersID);
                }
                if($filter == "basic_plan_count"){
                    $query = $query->whereIn('_id',$basic_plan_usersID);
                }
                if($filter == "premium_plan_count"){
                    $query = $query->whereIn('_id',$premium_plan_usersID);
                }
                if($filter == "pro_plan_count"){
                    $query = $query->whereIn('_id',$pro_plan_usersID);
                }
                if($filter == "weekly_rating_count"){
                    $weekly_rating_count = UserWeeklySurvey::where('rating','<',3)->groupBy('user_id')->pluck('user_id')->toArray();
                    $query = $query->whereIn('_id',$weekly_rating_count);
                }
                if($filter == "scc_rating_count"){
                    $scc_rating_count = UserSelfCheckCheckObject::where('answer_2',"I’m struggling to understand it and do it")->groupBy('user_id')->pluck('user_id')->toArray();
                    $query = $query->whereIn('_id',$scc_rating_count);
                }
                if($filter == "session_rating_count"){
                    $query = $query->whereIn('_id',[]);
                }
                $users = User::where('user_type','user')->where('last_login_at','!=',NULL)->where('last_login_at','!=',"")->get();
                $withinthreeDayLoginCount_User = [];
                $fourtosevenDayLoginCount_User = [];
                $morethansevenDayLoginCount_User = [];
                if($users->count() > 0){
                    foreach ($users as $user) {
                        $lastLogin = Carbon::parse($user->last_login_at);
                        if($lastLogin->greaterThanOrEqualTo($threeDaysAgo)){
                            $withinthreeDayLoginCount_User[] = $user->userid;
                        } else if ($lastLogin->between($sevenDaysAgo, $fourDaysAgo, true)) {
                            $fourtosevenDayLoginCount_User[] = $user->userid;
                        } else if ($lastLogin->lessThan($sevenDaysAgo)) {
                            $morethansevenDayLoginCount_User[] = $user->userid;
                        }else{
                            $fourtosevenDayLoginCount_User[] = $user->userid;
                        }
                    }
                }
                if($filter == "withinthreeDayLoginCount"){
                    $query = $query->whereIn('userid',$withinthreeDayLoginCount_User);
                }
                if($filter == "fourtosevenDayLoginCount"){
                    $query = $query->whereIn('userid',$fourtosevenDayLoginCount_User);
                }
                if($filter == "morethansevenDayLoginCount"){
                    $query = $query->whereIn('userid',$morethansevenDayLoginCount_User);
                }
            }else{
                $query = User::whereIn('user_type', ['coach', 'admin']);
            }
            if (substr($sortColumn, 0, 1) === "-") {
                $columnName = substr($sortColumn, 1);
                $typeOfSort ="desc";
            } else {
                $columnName = $sortColumn;
                $typeOfSort = "asc";
            }
            if($filteredVal != ""){
                if($filterColumn != ""){
                    $query = $query->where($filterColumn,'like', '%' . $filteredVal . '%');
                }else{
                    $query = $query->where(function ($query) use ($arrayField, $filteredVal) {
                        foreach ($arrayField as $field) {
                            $query->orWhere($field, 'like', '%' . $filteredVal . '%');
                        }
                    });
                }
            }
            if($sortColumn != ""){
                $query = $query->orderBy($columnName,$typeOfSort);
            }
            $users = $query->paginate($perPage);
            $defaultProgram = env('DEFAULT_PROGRAM');
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            
            $users->getCollection()->transform(function ($user) use($default_unitIds,$defaultGroup ) {
                $unitPosition = $sessionPosition = "";
                if(!empty($user->group_id)){
                    $group = Group::find($user->group_id);
                    if($group){
                        $unitIds = array_column($group["group_object"], "object_id");
                        $unit = Unit::whereIn('_id', $unitIds )->get();
                        $unit = $unit->sortBy(function ($item) use ($unitIds) {
                            return array_search($item['_id'], $unitIds);
                        });
                    }else{
                        $unit = Unit::whereIn('_id', $default_unitIds )->get();
                        $unit = $unit->sortBy(function ($item) use ($default_unitIds) {
                            return array_search($item['_id'], $default_unitIds);
                        });
                    }
                }else{
                    $unit = Unit::whereIn('_id', $default_unitIds )->get();
                    $unit = $unit->sortBy(function ($item) use ($default_unitIds) {
                        return array_search($item['_id'], $default_unitIds);
                    });
                }   
                $totalRepReviews = RepReview::where('user_id',$user->_id)->count();
                $userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->orderBy('created_at','desc')->first();
                $unitPosition = $sessionPosition = "";
                if($userSessionProgress){
                    $i=1;
                    foreach ($unit as $value) {
                        $unitObjectIds = array_column($value["unit_object"], "object_id");
                        if($userSessionProgress->unit_id == $value->_id){
                            $unitPosition = $i;
                            $position = array_search($userSessionProgress->session_id, $unitObjectIds);
                            if($position !== false){
                                $sessionPosition = $position + 1 ?? "";
                            }else{
                                $sessionPosition = "";
                            }
                        }
                        $i++;
                    }
                }
               // if(!empty($userSessionProgress->unit_id)){
                //     $user->unit_name = $unit_name_array[$userSessionProgress->unit_id] ?? "";
                // }else{
                //     $user->unit_name = "";
                // }
                // if(!empty($userSessionProgress->session_id)){
                //     $user->session_name =  $session_name_array[$userSessionProgress->session_id] ?? "";
                // }else{
                //     $user->session_name = "";
                // }
                $user->unit_name = $unitPosition ?? "";
                $user->status = $user->status ?? true;
                $user->session_name = $sessionPosition ?? "";
                $defaultProgram = env('DEFAULT_PROGRAM');
                if ($user->group_id !== null) {
                    $group = Group::find($user->group_id);
                    $user->group_name = $group->group_name ?? $defaultProgram;
                    $user->customized_plan_name = $group->plan_name ?? "";
                }else{
                    $user->group_id = $defaultGroup->_id;
                    $user->group_name = $defaultProgram;
                    $user->customized_plan_name = $defaultGroup->plan_name ?? "";
                }
                if ($user->registered_at !== null) {
                    $user->registered_at = $user->registered_at->format('Y-m-d H:i');
                }
                $user->registered_date = $user->registered_at != "" ? $user->registered_at->format('Y-m-d H:i a') : "";
                if ($user->last_login_at !== null) {
                    $user->login_date = Carbon::parse($user->last_login_at)->format('Y-m-d h:i a');
                }else{
                    $user->login_date = "";
                }
                $firstname = $user->first_name ?? "";
                $lastname = $user->last_name ?? "";
                if($firstname == "" && $user->full_name != ""){
                    $nameParts = explode(' ', trim($user->full_name));
                    $firstname = $nameParts[0] ?? '';
                    $lastname = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';
                }
                $user->first_name = $firstname;
                $user->last_name = $lastname;
                $user->allow_notification_permission = $user->allow_notification_permission ?? true;
                $daysUntilExpiry = 0;
                if($user->user_type == 'user'){
                    $userBillingData = UserBillingHistory::where('user_id',$user->_id)->where('status','active')->where('payment_status','Paid')->orderBy('created_at', 'desc')->first();
                    if($userBillingData && $user->created_at !== null){
                        $currentDate = Carbon::now();
                        $created_date = Carbon::parse($userBillingData->created_at);
                        $daysUntilExpiry = $currentDate->diffInDays($created_date);
                    }
                }
                $user->days_subscribed = $daysUntilExpiry > 0 ? $daysUntilExpiry : 0;
                $user->total_rep_reviews = $totalRepReviews ?? 0;
                return $user;
            });
            return ApiResponse::success($users);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function weeklyRatingSwitchForUser($user_id)
    {
        try {
            $token = $this->getTokenFromHeader();   
            $admin = \JWTAuth::setToken($token)->authenticate();
            if(!$admin) {
                return ApiResponse::error('Trouble fetching admin information');
            }
            $switch_weekly_rating = [];
            $user = User::find($user_id);
            if(!$user) {
                return ApiResponse::error('User not found.');
            }
            $user->weekly_rating_switch = $user->weekly_rating_switch ?? false;
            if($user->weekly_rating_switch == true){//|| $note->is_pinned == null
                $switch_weekly_rating['weekly_rating_switch'] = false;
                $status = "off";
            }else{
                $status = "on";
                $switch_weekly_rating['weekly_rating_switch'] = true;
            }
            $user->weekly_rating_switch = $switch_weekly_rating['weekly_rating_switch'];  
            $user->save(); 
            return ApiResponse::success($switch_weekly_rating,'Weekly rating swtch turned '.$status.' for user '.$user->full_name );
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getAdminList(Request $request)
    {
        $req_param = $request->all();
        $sortColumn = $req_param['sort'] ?? "";
        $filterColumn = $req_param['filterBy'] ?? "";
        $filteredVal = $req_param['filteredVal'] ?? "";
        $unit_name_array = $session_name_array = [];
        try {
            $arrayField = array("_id","full_name", "email", "user_type","registered_at","userid","is_confirm","updated_at","created_at");
            $perPage = $request->per_page ?? 10; // Number of users per page
            // $search = $request->input('search');
            $type = $request->input('type');
            $tagNames = Tags::pluck('name', '_id');
            if($type == 'user'){
                $filter = $req_param['filter_dashboard'] ?? "";
                $threeDaysAgo = Carbon::now()->subDays(3);
                $sevenDaysAgo = Carbon::now()->subDays(7);
                $fourDaysAgo = Carbon::now()->subDays(4);
                $query = User::whereIn('user_type', ['user']);
               
                $unit_name_array = Unit::pluck('unit_name','_id')->toArray();
                $session_name_array = Session::pluck('session_name','_id')->toArray();
                $free_plan_usersID = User::where('user_type','user')->where('is_confirm',1)->pluck('_id')->toArray();
                $basic_plan_usersID = [];
                $premium_plan_usersID = [];
                $pro_plan_usersID = [];
                $plans = Plan::pluck('_id','name')->toArray();
         
                    
                $userIds = User::where('user_type','user')->where('is_confirm',1)->pluck("_id")->toArray();
                $basic_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Basic"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
                $premium_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Premium"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
                $pro_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Ultra"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
                $free_plan_usersID = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Free 7-Day Trial"])->where('status','active')->where('payment_status','Paid')->pluck('user_id')->toArray();
            
                if($filter == "free_plan_count"){
                    $query = $query->whereIn('_id',$free_plan_usersID);
                }
                if($filter == "basic_plan_count"){
                    $query = $query->whereIn('_id',$basic_plan_usersID);
                }
                if($filter == "premium_plan_count"){
                    $query = $query->whereIn('_id',$premium_plan_usersID);
                }
                if($filter == "pro_plan_count"){
                    $query = $query->whereIn('_id',$pro_plan_usersID);
                }
                if($filter == "weekly_rating_count"){
                    $weekly_rating_count = UserWeeklySurvey::where('rating','<',3)->groupBy('user_id')->pluck('user_id')->toArray();
                    $query = $query->whereIn('_id',$weekly_rating_count);
                }
                if($filter == "scc_rating_count"){
                    $scc_rating_count = UserSelfCheckCheckObject::where('answer_2',"I’m struggling to understand it and do it")->groupBy('user_id')->pluck('user_id')->toArray();
                    $query = $query->whereIn('_id',$scc_rating_count);
                }
                if($filter == "session_rating_count"){
                    $query = $query->whereIn('_id',[]);
                }
                $users = User::where('user_type','user')->where('last_login_at','!=',NULL)->where('last_login_at','!=',"")->get();
                $withinthreeDayLoginCount_User = [];
                $fourtosevenDayLoginCount_User = [];
                $morethansevenDayLoginCount_User = [];
                if($users->count() > 0){
                    foreach ($users as $user) {
                        $lastLogin = Carbon::parse($user->last_login_at);
                        if($lastLogin->greaterThanOrEqualTo($threeDaysAgo)){
                            $withinthreeDayLoginCount_User[] = $user->userid;
                        } else if ($lastLogin->between($sevenDaysAgo, $fourDaysAgo, true)) {
                            $fourtosevenDayLoginCount_User[] = $user->userid;
                        } else if ($lastLogin->lessThan($sevenDaysAgo)) {
                            $morethansevenDayLoginCount_User[] = $user->userid;
                        }else{
                            $fourtosevenDayLoginCount_User[] = $user->userid;
                        }
                    }
                }
                if($filter == "withinthreeDayLoginCount"){
                    $query = $query->whereIn('userid',$withinthreeDayLoginCount_User);
                }
                if($filter == "fourtosevenDayLoginCount"){
                    $query = $query->whereIn('userid',$fourtosevenDayLoginCount_User);
                }
                if($filter == "morethansevenDayLoginCount"){
                    $query = $query->whereIn('userid',$morethansevenDayLoginCount_User);
                }
            }else{
                $query = User::whereIn('user_type', ['coach', 'admin']);
            }
            if (substr($sortColumn, 0, 1) === "-") {
                $columnName = substr($sortColumn, 1);
                $typeOfSort ="desc";
            } else {
                $columnName = $sortColumn;
                $typeOfSort = "asc";
            }
            if($filteredVal != ""){
                if($filterColumn != ""){
                    $query = $query->where($filterColumn,'like', '%' . $filteredVal . '%');
                    if($filterColumn == "tag_name"){
                        $tagId = Tags::where('name','like', '%' . $filteredVal . '%')->pluck('_id')->toArray();
                        if(!empty($tagId)){
                            $query = $query->whereIn('tag_id',$tagId);
                        }
                    }
                }else{
                    $query = $query->where(function ($query) use ($arrayField, $filteredVal) {
                        foreach ($arrayField as $field) {
                            $query->orWhere($field, 'like', '%' . $filteredVal . '%');
                        }
                    });
                }
            }
            if($sortColumn != ""){
                $query = $query->orderBy($columnName,$typeOfSort);
            }
            $users = $query->paginate($perPage);
            $defaultProgram = env('DEFAULT_PROGRAM');
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            $categoryTypeTrain = CategoryType::where('name', 'LIKE', 'Train')->first();
            $categoryTypeApply = CategoryType::where('name', 'LIKE', 'Apply')->first();
            $users->getCollection()->transform(function ($user) use($default_unitIds,$defaultGroup,$categoryTypeTrain,$categoryTypeApply,$tagNames) {
                $unitPosition = $sessionPosition = "";
                if(!empty($user->group_id)){
                    $group = Group::find($user->group_id);
                    if($group){
                        $unitIds = array_column($group["group_object"], "object_id");
                        $unit = Unit::whereIn('_id', $unitIds )->get();
                        $unit = $unit->sortBy(function ($item) use ($unitIds) {
                            return array_search($item['_id'], $unitIds);
                        });
                    }else{
                        $unit = Unit::whereIn('_id', $default_unitIds )->get();
                        $unit = $unit->sortBy(function ($item) use ($default_unitIds) {
                            return array_search($item['_id'], $default_unitIds);
                        });
                    }
                }else{
                    $unit = Unit::whereIn('_id', $default_unitIds )->get();
                    $unit = $unit->sortBy(function ($item) use ($default_unitIds) {
                        return array_search($item['_id'], $default_unitIds);
                    });
                }   

                if(!empty($user->group_id)){
                    $group = Group::find($user->group_id);
                    if($group){
                        $unitOrderMap = [];
                        $unitIds = array_column($group["group_object"], "object_id");
                        foreach ($group["group_object"] as $in => $obj) {
                            $unitOrderMap[$obj['object_id']] = $in + 1;
                        }
                        $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $unitIds )->get();
                        $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $unitIds )->get();
                    }else{
                        $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                        $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                    }
                }else{
                    $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                    $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                }
                $totalRepReviews = RepReview::where('user_id',$user->_id)->count();
                $userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->orderBy('created_at','desc')->first();
                $unitPosition = $sessionPosition = "";
                if($userSessionProgress){
                    $i=1;
                    foreach ($unit as $value) {
                        $unitObjectIds = array_column($value["unit_object"], "object_id");
                        if($userSessionProgress->unit_id == $value->_id){
                            $unitPosition = $i;
                            $position = array_search($userSessionProgress->session_id, $unitObjectIds);
                            if($position !== false){
                                $sessionPosition = $position + 1 ?? "";
                            }else{
                                $sessionPosition = "";
                            }
                        }
                        $i++;
                    }
                }
                $user->unit_name = $unitPosition ?? "";
                $user->status = $user->status ?? true;
                $user->session_name = $sessionPosition ?? "";
                $defaultProgram = env('DEFAULT_PROGRAM');
                if ($user->group_id !== null) {
                    $group = Group::find($user->group_id);
                    $user->group_name = $group->group_name ?? $defaultProgram;
                    $user->customized_plan_name = $group->plan_name ?? "";
                }else{
                    $user->group_id = $defaultGroup->_id;
                    $user->group_name = $defaultProgram;
                    $user->customized_plan_name = $defaultGroup->plan_name ?? "";
                }
                if ($user->registered_at !== null) {
                    $user->registered_at = $user->registered_at->format('Y-m-d H:i');
                }
                $user->registered_date = $user->registered_at != "" ?  Carbon::parse($user->registered_at)->format('M j, Y') : "";
                if ($user->last_login_at !== null) {
                    // $user->login_date = Carbon::parse($user->last_login_at)->format('Y-m-d h:i a');
                    $user->login_date = Carbon::parse($user->last_login_at)->format('M j, Y');
                }else{
                    $user->login_date = "";
                }
                $firstname = $user->first_name ?? "";
                $lastname = $user->last_name ?? "";
                if($firstname == "" && $user->full_name != ""){
                    $nameParts = explode(' ', trim($user->full_name));
                    $firstname = $nameParts[0] ?? '';
                    $lastname = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : '';
                }
                $user->first_name = $firstname;
                $user->last_name = $lastname;
                $user->allow_notification_permission = $user->allow_notification_permission ?? true;
                $daysUntilExpiry = 0;
                if($user->user_type == 'user'){
                    $userBillingData = UserBillingHistory::where('user_id',$user->_id)->where('status','active')->where('payment_status','Paid')->orderBy('created_at', 'desc')->first();
                    if($userBillingData && $user->created_at !== null){
                        $currentDate = Carbon::now();
                        $created_date = Carbon::parse($userBillingData->created_at);
                        $daysUntilExpiry = $currentDate->diffInDays($created_date);
                    }
                }
                $user->days_subscribed = $daysUntilExpiry > 0 ? $daysUntilExpiry : 0;
                $user->total_rep_reviews = $totalRepReviews ?? 0;
                if($user->user_type == "user"){
                    $reps = [];
                    $manual_reps_recall_card = UserManualReps::where('user_id', $user->_id)
                        ->where('reps_type', 'Recall Cards')
                        ->get();
                    $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
                    $manual_reps_movement_drills = UserManualReps::where('user_id', $user->_id)
                        ->where('reps_type', 'Move Drills')
                        ->get();
                    $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
                    $manual_reps_swing_drills = UserManualReps::where('user_id',$user->_id)
                        ->where('reps_type', 'Swing Drills')
                        ->get();    
                    $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
                    $manual_reps_trust = UserManualReps::where('user_id',$user->_id)
                        ->where('reps_type', 'Trust Shots')
                        ->get();
                    $recap_reps_all = SessionRecapTime::where('user_id', $user->_id)->get();
                    $all_totalRecapReps = 0;
                    if($recap_reps_all->count() > 0){
                        foreach ($recap_reps_all as $recap_reps_a) {
                            $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                        }
                    }
                    $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
                    // Set initial reps values
                    $userRecallCardsCount = UserRecallCards::where('user_id',$user->userid)->count();
                    $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card + $all_totalRecapReps;
                    $docs = UserMovementDrill::where('user_id',$user->_id)->get();
                
                    $totalReps = 0;
                    foreach ($docs as $doc) {
                        $totalReps += (int) $doc['reps'];
                    }
                    $userMovementDrillCount = $totalReps;
                    $trust_reps = 0;
                    $shotCheckDates = UserTrustHole::where('user_id',$user->userid)->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                    $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                        return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                    })->values()->all();
                    $totalDate = sizeof($sortedDates);
                    if( $totalDate > 0){
                        $trust_reps = $totalDate * 40;
                    }
                    $reps['move_drills'] =  $userMovementDrillCount + $total_manual_reps_movement_drills ?? 0;
                    $swings = Swing::where('user_id',$user->_id)->count();
                    $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills?? 0;
                    $reps['trust_shots'] = $trust_reps + $total_manual_reps_trust?? 0;
                    // $calculatedReps = $totalReps + $userRecallCardsCount + $total_manual_reps_recall_card + $trust_reps + $swings + $total_manual_reps_movement_drills + $total_manual_reps_recall_card + $total_manual_reps_swing_drills + $total_manual_reps_trust ?? 0;
                    $calculatedReps =  $reps['trust_shots'] + $reps['swing_drills'] + $reps['move_drills'] + $reps['recall_cards'];
                    $user->totalRepCount = $calculatedReps ?? 0;

                    $unitIdsFilter = $units->pluck('_id')->toArray();
                    $applyIdsFilter = $apply->pluck('_id')->toArray();
                    //$userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$unitIdsFilter)->groupBy('unit_id','session_id')->pluck('unit_id','session_id')->count();
                    $userSessionProgressCount = UserSessionProgress::where('user_id', $user->_id)
                                            ->whereIn('unit_id', $unitIdsFilter)
                                            ->groupBy('unit_id', 'session_id')
                                            ->selectRaw('unit_id, session_id')  // Select the grouped columns
                                            ->get()
                                            ->count();
                    $userSessionProgressApplyCount = UserSessionProgress::where('user_id', $user->_id)
                                                ->whereIn('unit_id', $applyIdsFilter)
                                                ->groupBy('unit_id', 'session_id')
                                                ->selectRaw('unit_id, session_id')  // Select the grouped columns
                                                ->get()
                                                ->count();

                    // Train Sessions (#)
                    $user->user_progress_train = $userSessionProgressCount ?? 0;

                    // Apply Sessions (#)
                    $user->user_progress_apply = $userSessionProgressApplyCount ?? 0;

                    // Trust Sessions (#)
                    $trustHolesArray = UserTrustHole::where('user_id',$user->userid)->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                    $sortedDatesTrustHoles = collect($trustHolesArray)->sortBy(function ($trust_date) {
                        return \Carbon\Carbon::createFromFormat('d-m-Y', $trust_date);
                    })->values()->all();
                    $uniqueEntriesTrust = sizeof($sortedDatesTrustHoles);
                    $user->user_progress_trust = $uniqueEntriesTrust ?? 0;
                    $userWeeklyRating = UserWeeklySurvey::where('user_id',$user->_id)->orderBy('created_at','desc')->first();
                    $user->weekly_rating = $userWeeklyRating->rating ?? '';
                    $user->tag_name = "";
                    $user->tag_id = $user->tag_id ?? "";
                    if($user->tag_id != ""){
                        $tagName = [];
                        $tags =  explode(",",$user->tag_id);
                        if(!empty($tags)){
                            foreach($tags as $tag){
                                $tagName[] = $tagNames[$tag] ?? "";
                            }
                        }
                        $user->tag_name = implode(',', $tagName);
                    }
                    $user_billing_history = UserBillingHistory::where('user_id',$user->_id)->where('status','active')->first(); 
                    if($user_billing_history){
                        $plan = Plan::find($user_billing_history->plan_id);
                        $user->subscribed_plan = $plan->name ?? "";
                        $user->applied_promo_code = $user_billing_history->promo_code ?? "" ;
                        $user->renewal_date = Carbon::parse($user_billing_history->expiry_date)->format('M j, Y');
                        $user->billed_amount = $user_billing_history->amount ?? $plan->amount ;
                    }else{
                        $user->subscribed_plan ="";
                        $user->applied_promo_code =  "" ;
                        $user->renewal_date = "";
                        $user->billed_amount = "";
                    }
                    $user->weekly_rating_switch = $user->weekly_rating_switch ?? false;
                }
                

                return $user;
            });
            return ApiResponse::success($users);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCustomerCardByUser($user_id)
    {
        try {
            $token = $this->getTokenFromHeader();
            $admin = \JWTAuth::setToken($token)->authenticate();
            if(!$admin) {
                return ApiResponse::error('Getting trouble to fetch admin information');
            }else {

                $user = User::find($user_id);
                
                if($user) {
                    Stripe::setApiKey(config('services.stripe.secret'));
                    $cards = [];
                    $customerId = $user->stripe_customer_id ?? "";
                    if($customerId != ""){
                        $paymentMethods = PaymentMethod::all([
                            'customer' => $customerId,
                            'type' => 'card', // Specify the type of payment methods to retrieve
                        ]);
                    
                        $cards = [];
                        $customer = Customer::retrieve($customerId);
                        $defaultPaymentMethodId = $customer->invoice_settings->default_payment_method;
                        foreach ($paymentMethods->data as $paymentMethod) {
                            $isDefault = $paymentMethod->id === $defaultPaymentMethodId;
                            // For each payment method, extract the card details and add to $cards array
                            $cards[] = [
                                'name' => $user->full_name ?? "",
                                'id' => $paymentMethod->id,
                                'brand' => $paymentMethod->card->brand,
                                'last4' => $paymentMethod->card->last4,
                                'exp_month' => $paymentMethod->card->exp_month,
                                'exp_year' => $paymentMethod->card->exp_year,
                                'is_default' => $isDefault
                                // You can include more details here as needed
                                // 'is_default' logic will depend on your application's handling of default payment methods
                            ];
                        }
                        return ApiResponse::success($cards,'card list found successfully.');
                    }else{
                        return ApiResponse::success($cards,'card list found successfully.');
                        //return ApiResponse::error('Getting trouble to fetch user card information');
                    }
                }
                else{
                    return ApiResponse::error('User not found');
                }
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCoachListOld(Request $request)
    {
        $req_param = $request->all();
        $sortColumn = $req_param['sort'] ?? "";
        $filterColumn = $req_param['filterBy'] ?? "";
        $filteredVal = $req_param['filteredVal'] ?? "";
        try {
            $arrayField = array("_id","full_name", "email", "user_type","registered_at","userid","is_confirm","updated_at","created_at");
            $perPage = 10; 
            $query = User::where('user_type', 'coach');
            if (substr($sortColumn, 0, 1) === "-") {
                $columnName = substr($sortColumn, 1);
                $typeOfSort ="desc";
            } else {
                $columnName = $sortColumn;
                $typeOfSort = "asc";
            }
            if($filteredVal != ""){
                if($filterColumn != ""){
                    $query = $query->where($filterColumn,'like', '%' . $filteredVal . '%');
                }else{
                    $query = $query->where(function ($query) use ($arrayField, $filteredVal) {
                        foreach ($arrayField as $field) {
                            $query->orWhere($field, 'like', '%' . $filteredVal . '%');
                        }
                    });
                }
            }
            if($sortColumn != ""){
                $query = $query->orderBy($columnName,$typeOfSort);
            }
            $users = $query->paginate($perPage);
            $users->getCollection()->transform(function ($user) {
                if ($user->registered_at !== null) {
                    $user->registered_at = $user->registered_at->format('Y-m-d H:i');
                }
                $user->registered_date = $user->registered_at != "" ? $user->registered_at->format('Y-m-d H:i a') : "";
                if ($user->last_login_at !== null) {
                    $user->login_date = Carbon::parse($user->last_login_at)->format('Y-m-d h:i a');
                }else{
                    $user->login_date = "";
                }
                $adminCoachReview = AdminCoachReview::where('coach_id',$user->_id)->where('status','Completed')->count();
                $user->total_completed_tickets = $adminCoachReview ?? 0;
                $adminCoachReviewTickets = AdminCoachReview::where('coach_id',$user->_id)->count();
                $user->total_hours = $adminCoachReviewTickets * 48 ?? 0;
                $user->avg_response_time = "10 min";
                return $user;
            });
            return ApiResponse::success($users);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCoachList(Request $request)
    {
        $req_param = $request->all();
        $sortColumn = $req_param['sort'] ?? "";
        $filterColumn = $req_param['filterBy'] ?? "";
        $filteredVal = $req_param['filteredVal'] ?? "";
        
        try {
            $arrayField = array("_id","full_name", "email", "user_type","registered_at","userid","is_confirm","updated_at","created_at");
            $perPage = 10; 
            $users = User::where('user_type', 'coach')->get();
            foreach ($users as $key => $user) {
                if ($user->registered_at !== null) {
                    $user->registered_at = $user->registered_at->format('Y-m-d H:i');
                }
                $user->registered_date = $user->registered_at != "" ? $user->registered_at->format('Y-m-d H:i a') : "";
                if ($user->last_login_at !== null) {
                    $user->login_date = Carbon::parse($user->last_login_at)->format('Y-m-d h:i a');
                }else{
                    $user->login_date = "";
                    
                }
                $adminCoachReview = AdminCoachReview::where('coach_id',$user->_id)->where('status','Completed')->count();
                $user->total_completed_tickets = $adminCoachReview ?? 0;
                $adminCoachReviewTickets = AdminCoachReview::where('coach_id',$user->_id)->count();
                $user->total_hours = $adminCoachReviewTickets * 48 ?? 0;
                $user->avg_response_time = "10 min";
            }
            $sortedData = Functions::sortArray($users,$sortColumn);
            $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['full_name','total_completed_tickets','registered_date','avg_response_time','total_hours']);
            $total_swing = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            $totalPage = !empty($request->per_page ) ? $total_swing / $request->per_page : 1;
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $currentPage  = $page - 1;
                if (is_array($filteredResponse)) {
                    $filteredResponse = collect($filteredResponse);
                }
                $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                $filteredResponse = array_values($pagedData);
            }
                
            $newRoot = [
                "coach_count" => $total_swing,
                "coaches" => $filteredResponse,
                "total_coach"=> ceil($totalPage) ?? 1
            ];
            
            return ApiResponse::success($newRoot);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can update user detail
    */
    public function updateUser(Request $request, $id)
    {
        try {
            $user = User::where('userid', (int)$id)->first();
            if (!$user) {
                return ApiResponse::error('User not found');
            }
            $user->full_name = $request->input('name') ?? $user->name;
            $user->first_name = $request->input('first_name') ?? $user->first_name;
            $user->last_name = $request->input('last_name') ?? $user->last_name;
            if($request->input('first_name') != "")
            {
                $user->full_name =  $request->input('first_name'). " ". ($request->input('last_name') ?? $user->last_name);
            }
            $user->email = $request->input('email') ?? $user->email;

            $user->status = $request->input('status') ?? $user->status;
            $defaultProgram = env('DEFAULT_PROGRAM');
            $defaultGroup = Group::where('group_name',$defaultProgram)->first();
            if(!empty($request->id)){
                $user->group_id = $request->group_id ?? ($user->group_id ?? $defaultGroup->_id);
            }else{
                $user->group_id = $request->group_id ?? $defaultGroup->_id;
            }
            $user->save();
            return ApiResponse::success($user,'User updated successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can delete user 
    */
    public function deleteUser($id)
    {
        try {
            $user = User::where('userid', (int)$id)->first();
            if (!$user) {
                return ApiResponse::error('User not found');
            }
            UserQuestionAnswer::where('user_id',$user->userid)->delete();
            $user->delete();
            return ApiResponse::success('User deleted successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel get list of the training intention
    */
    public function getTrainigIntention()
    {
        try{
            $newRoot = [
                'training_intention' => [],
                'friend_support' => [],
            ];
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $userQuestion = UserTrainingPlan::where('user_id', $user["userid"])->get();                
                $trainingIntention = [];
                if($userQuestion){
                    foreach ($userQuestion as $key => $value) {
                        $trainingIntention[$key]['id'] = $value["_id"];
                        $trainingIntention[$key]['day'] = $value["day"];
                        $trainingIntention[$key]['time'] = $value["time"];
                        $trainingIntention[$key]['location'] = $value["location"];
                    }
                    $collection = new Collection($trainingIntention);
                    $daysOrder  = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
                    $sortedCollection = $collection->sortBy(function ($item) use ($daysOrder) {
                        return array_search($item['day'], $daysOrder);
                    });
                    $sortedTrainingDays = $sortedCollection->values()->all();
                }else{
                    $sortedTrainingDays = [];
                }
                $userContactPerson = UserContactPerson::where('user_id', $user["userid"])->get();
                $contactPerson = [];
                if($userContactPerson){
                    foreach ($userContactPerson as $key => $value) {
                        $contactPerson[$key]['id'] = $value["_id"];
                        $contactPerson[$key]['name'] = $value["person_name"];
                        $contactPerson[$key]['phone'] = $value["phone"];
                    }
                }
                $newRoot['plan'] = $user->plan ?? "Good";
                $newRoot['training_intention'] = $sortedTrainingDays;
                $newRoot['friend_support'] = $contactPerson;
                return ApiResponse::success($newRoot,'User detail fetch successfully');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel update list of the training intention
    */
    public function updateTrainigIntention(Request $request)
    {
        try{
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'day' => 'required',
                'time' => 'required',
                'location' => 'required',
            ]);
            if($user){
                // Add/update plan for user
                if(!empty($request->plan)){
                    $user->plan = $request->plan;
                    $user->save();
                }
            }
            if(!empty($request->id)){
                // Update existing training intention
                $userTrainingPlan = UserTrainingPlan::where('user_id', $user["userid"])
                                    ->where('_id', $request->id)
                                    ->firstOrFail(); // Used "firstOrFail" to throw an exception if the record is not found
                $userTrainingPlan->day = $request->day;
                $userTrainingPlan->time = $request->time;
                $userTrainingPlan->location = $request->location;
                $userTrainingPlan->save();
                return ApiResponse::success($userTrainingPlan,'Training intention updated successfully');
            }else{
                // Add new training intention
                $userTrainingPlan = UserTrainingPlan::where('user_id', $user["userid"])
                                    ->where('day', $request->day)
                                    ->firstOrNew();
                $userTrainingPlan->day = $request->day;
                $userTrainingPlan->user_id = $user["userid"];
                $userTrainingPlan->time = $request->time;
                $userTrainingPlan->location = $request->location;
                $userTrainingPlan->save();
                return ApiResponse::success($userTrainingPlan,'Training intention added successfully');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment:  Admin panel delete list of the training intention
    */
    public function deleteTrainigIntention($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Training intention id required!!');
            }
            $question = UserTrainingPlan::find($id);
            if($question){
                $question->delete();
                return ApiResponse::successOnly('Training intention deleted successfully.');
            }else{
                return ApiResponse::error('Training intention not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel update list of FAQ 
    */
    public function updateFaq(Request $request)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_FAQ_PATH');
            $request->validate([
                'question' => 'required',
                'answer' => 'required',
            ]);
            if(isset($request->id)){
                $faq = Faq::where('_id', $request->id)->first();
                $faq->question = $request->question;
                $faq->answer = $request->answer;
              
                $msg='Faq update successfully';
            }else{
                $faq = new Faq();
                $faq->question = $request->question;
                $faq->answer = $request->answer;
             
                $msg = 'Faq added successfully';
            }
            $main_image = "";
            $faq->order  = $request->order ?? 0;
            if($request->hasFile('image')){
                $validatedData = $request->validate([
                    'image' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_main_image = $request->file('image');
                $filename_main_img = uniqid() . '_image.' . $file_main_image->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_main_image, $filename_main_img, 'public');
                $main_image = $filename_main_img;
                $faq->image = $main_image;
            }
            if(isset($request->id) && $request->image == "" ){
                $faq->image = "";
            }
            $faq->vimeo_link = $request->vimeo_link ?? "";
            $faq->save();
            $faq->image_url = $faq->image != "" ? $appUrl."".$path."".$faq->image :"";
            return ApiResponse::success($faq,$msg);
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    public function updateTrustKey(Request $request)
    {
        try{
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'trust_key' => 'required',
            ]);
            if(isset($request->id)){
                $trustKey = TrustKey::find($request->id);
                $trustKey->trust_key = $request->trust_key;
                $trustKey->date = $request->date ?? "";
                $trustKey->created_by = $user["_id"] ?? "";
                $trustKey->save();
                return ApiResponse::success($trustKey,'Trust Key updated successfully');
            }else{
                $trustKey = new TrustKey();
                $trustKey->trust_key = $request->trust_key;
                $trustKey->date = $request->date ?? "";
                $trustKey->created_by = $user["_id"] ?? "";
                $trustKey->save();
                return ApiResponse::success($trustKey,'Trust Key added successfully');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel get list of FAQ 
    */
    public function getFaq()
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_FAQ_PATH');
            $faqs = Faq::orderBy('order', 'asc')->get();
            foreach ($faqs as $faq) {
                $faq->image = $faq->image ?? "";
                $faq->vimeo_link = $faq->vimeo_link ?? "";
                $faq->image_url = $faq->image != "" ? $appUrl."".$path."".$faq->image :"";
                $faq->order  = intval($faq->order) ?? 0;
            }
            return ApiResponse::success($faqs,'Faq fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    public function getTrustKey()
    {
        try{
            $faqs = TrustKey::all();
            return ApiResponse::success($faqs,'Trust Key fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel delete list of FAQ 
    */
    public function deleteFaq($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Faq id required!!');
            }
            $faq = Faq::find($id);
            if($faq){
                $faq->delete();
                return ApiResponse::successOnly('Faq deleted successfully.');
            }else{
                return ApiResponse::error('Faq not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }

    public function deleteTrustKey($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Trust Key id required!!');
            }
            $faq = TrustKey::find($id);
            if($faq){
                $faq->delete();
                return ApiResponse::successOnly('Trust Key deleted successfully.');
            }else{
                return ApiResponse::error('Trust Key not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can update contact us details
    */
    public function updateContactUsOld(Request $request)
    {
        try{
            $request->validate([
                'subject' => 'required',
                'message' => 'required',
                'email' => 'required',
            ]);
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $contactUs = new ContactUs();
            $contactUs->subject = $request->subject;
            $contactUs->message = $request->message;
            $contactUs->email = $request->email;
            $contactUs->user_id = $user["_id"];
            $contactUs->save();
            return ApiResponse::successOnly('Contact us added successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function updateContactUs(Request $request)
    {
        try{
            $request->validate([
                'subject' => 'required',
                'message' => 'required',
                'email' => 'required',
            ]);
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $contactUs = new ContactUs();
            $contactUs->subject = $request->subject;
            $contactUs->message = $request->message;
            $contactUs->email = $request->email;
            $contactUs->user_id = $user["_id"];
            $contactUs->save();
            
            // Send a contact us mail
            Mail::to('kurt@fisiotraining.com')->send(new ContactUsEmail($contactUs));
            
            return ApiResponse::successOnly('Contact us added successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
   

    /**
    * Developer: Apptodate 
    * Comment: Get token from header and authenticate user
    */
    public function getTokenFromHeader() {
        try {
            $token = request()->header('Authorization');
            if ($token) {
                $token = substr($token, 7); // Remove 'Bearer ' prefix
            }
            return $token;
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        
    }

    public function updateTags(Request $request)
    {
        try{
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'name' => 'required',
                'type' => 'nullable'
            ]);
            if(isset($request->id)){
                $tags = Tags::where('_id', $request->id)->first();
                $tags->name = $request->name;
                $tags->type = $request->type;
                $tags->user_id = $user["_id"];
                $tags->save();
                return ApiResponse::success($tags,'tags update successfully');
            }else{
                $tags = new Tags();
                $tags->name = $request->name;
                $tags->type = $request->type;
                $tags->user_id = $user["_id"];
                $tags->save();
                return ApiResponse::success($tags,'tags added successfully');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully sign out']);
    }

    public function postAboutFisio(Request $request)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_ABOUT_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'headline' => 'required',
                'subtitle' => 'required',
                'text' => 'nullable',
                'image' => 'nullable',
                'vimeo_links' => 'nullable',
                'order' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(isset($request->id)){
                $about = About::find($request->id);
                if(!$about){
                    return ApiResponse::error('About fisio detail not found!!');
                }
                $status = 'updated';
            }else{
                $about = new About();
                $status = 'added';
            }
            $maxOrder = About::max('order');
            $about->headline = $request->headline;
            $about->subtitle = $request->subtitle;
            $about->text = $request->text ?? '';;
            $about->order = (int)$request->order ?? (int)($maxOrder + 1 ?? 1);
            $main_image = "";
            
            if($request->hasFile('image')){
                $validatedData = $request->validate([
                    'image' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_main_image = $request->file('image');
                $filename_main_img = uniqid() . '_image.' . $file_main_image->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_main_image, $filename_main_img, 'public');
                $main_image = $filename_main_img;
                $about->image = $main_image;
            }
            if(isset($request->id) && $request->image == "" ){
                $about->image = "";
            }
            $about->vimeo_links = $request->vimeo_links ?? "";
            // $about->vimeo_links = $vimeo_link ?? []; 
            // $link_items = [];
            // if(!empty($request->vimeo_links)){
            //     $reqLinkItem = json_decode($request->vimeo_links);
            //     foreach ($reqLinkItem as $key => $val) {
            //         $link_items[$key]['title'] = $val->title ?? "";
            //         $link_items[$key]['link'] = $val->link ?? "";
            //         $link_items[$key]['description'] = $val->description ?? "";
            //     }
            //     $about->vimeo_links = $link_items;
            // }else{
            //     $about->vimeo_links = $link_items;
            // }
            $about->save();
            $about->image_url = $about->image != "" ? $appUrl."".$path."".$about->image :"";
            return ApiResponse::success($about,'About Fisio details '.$status.' successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function postAboutFisioOld(Request $request)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_ABOUT_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'headline' => 'required',
                'subtitle' => 'required',
                'text' => 'required',
                'image' => 'nullable',
                'vimeo_links' => 'nullable',
                'order' => 'nullable'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if(isset($request->id)){
                $about = About::find($request->id);
                if(!$about){
                    return ApiResponse::error('About fisio detail not found!!');
                }
                $status = 'updated';
            }else{
                $about = new About();
                $status = 'added';
            }
            $maxOrder = About::max('order');
            $about->headline = $request->headline;
            $about->subtitle = $request->subtitle;
            $about->text = $request->text;
            $about->order = (int)$request->order ?? (int)($maxOrder + 1 ?? 1);
            $main_image = "";
            
            if($request->hasFile('image')){
                $validatedData = $request->validate([
                    'image' => 'required|mimes:jpeg,png,jpg'
                ]);
                $file_main_image = $request->file('image');
                $filename_main_img = uniqid() . '_image.' . $file_main_image->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_main_image, $filename_main_img, 'public');
                $main_image = $filename_main_img;
                $about->image = $main_image;
            }
            if(isset($request->id) && $request->image == "" ){
                $about->image = "";
            }
            $about->vimeo_links = $request->vimeo_links ?? "";
            // $about->vimeo_links = $vimeo_link ?? [];
            // $link_items = [];
            // if(!empty($request->vimeo_links)){
            //     $reqLinkItem = json_decode($request->vimeo_links);
            //     foreach ($reqLinkItem as $key => $val) {
            //         $link_items[$key]['title'] = $val->title ?? "";
            //         $link_items[$key]['link'] = $val->link ?? "";
            //         $link_items[$key]['description'] = $val->description ?? "";
            //     }
            //     $about->vimeo_links = $link_items;
            // }else{
            //     $about->vimeo_links = $link_items;
            // }
            $about->save();
            $about->image_url = $about->image != "" ? $appUrl."".$path."".$about->image :"";
            return ApiResponse::success($about,'About Fisio details '.$status.' successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updateOrderFAQ(Request $request)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_FAQ_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            $request->validate([
                'faq_list' => 'required'
            ]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }  
            $reqLinkItem = json_decode($request->faq_list);
            foreach ($reqLinkItem as $key => $about) {
                $aboutDetail = Faq::find($about->id);
                $aboutDetail->order = $about->order;
                $aboutDetail->save();
            }
            $about_list = Faq::orderBy('order', 'asc')->get();
            foreach ($about_list as $key => $about) {
                $about->image = $about->image  ?? "";
                $about->vimeo_link = $about->vimeo_link ?? "";
                $about->order  =  $about->order ?? 0;
                $about->image_url = $about->image != "" ? $appUrl."".$path."".$about->image :"";
            }
            return ApiResponse::success($about_list,'FAQ details found successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function deleteAboutFisio($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('About Fisio detail id required!!');
            }
            $tags = About::find($id);
            if($tags){
                $tags->delete();
                return ApiResponse::successOnly('About Fisio detail deleted successfully.');
            }else{
                return ApiResponse::error('About Fisio detail not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getAboutFisio()
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_ABOUT_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate();
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $about_list = About::orderBy('order', 'asc')->get();
            foreach ($about_list as $key => $about) {
                $about->image_url = $about->image != "" ? $appUrl."".$path."".$about->image :"";
            }
            return ApiResponse::success($about_list,'About Fisio details found successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: Admin panel regading tag crud delete tag
    */
    public function deleteTags($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Tags id required!!');
            }
            $tags = Tags::find($id);
            if($tags){
                $tags->delete();
                return ApiResponse::successOnly('Tags deleted successfully.');
            }else{
                return ApiResponse::error('Tags not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel regading tag crud list of tag
    */
    public function getTags(Request $request)
    {
        $req_param = $request->all();
        try {
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            $tagIds = Tags::groupBy('user_id')->pluck('user_id');
            $users = User::whereIn('_id', $tagIds)->pluck('full_name', '_id');
            $tags = Tags::all();
            foreach ($tags as $tag) {
                $tag->user_name = $users[$tag->user_id] ?? "N/A";
                $tag->type =  $tag->type ?? "Content";
            }
            $sortedData = Functions::sortArray($tags,$sortColumn);
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);
            $totalTags = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            $totalPage = !empty($request->per_page ) ? $totalTags/ $request->per_page : 1;
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $currentPage  = $page - 1;
                if (is_array($filteredResponse)) {
                    $filteredResponse = collect($filteredResponse);
                }
                $pagedData = $filteredResponse->slice($currentPage * $perPage, $perPage)->toArray();
                $filteredResponse = array_values($pagedData);
            }
            
            $newRoot = [
                'total_page' => ceil($totalPage),
                'total_tags' => $totalTags,
                'tags' => $filteredResponse
            ];
            return ApiResponse::success($newRoot,'Tags list found.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage object and below function can update object
    */
    public function updateUserObjectTypeOld(Request $request)
    {
        try {
            $path = env('AWS_OBJECT_IMAGES_PATH');
            $validatedData = $request->validate([
                'object_type_id' => 'required',
                'category_type_id' => 'required',
                'object_name' => 'required|string',
                'headline' => 'required|string',
                // 'subtitle' => 'required|string',
                'textarea' => 'required|string',
                'equipment' => 'required|string',
                'object_time' => 'required',
                'tag' => 'required',
                'video_id' => 'nullable'
            ]);
           
            if($request->id){
                $userObjectType = UserObjectType::find($request->id);
            }else{
                $userObjectType = new UserObjectType();
            }
            $userObjectType->object_type_id = $validatedData['object_type_id'];
            $userObjectType->category_type_id = $validatedData['category_type_id'];
            $userObjectType->object_name = $validatedData['object_name'];
            $userObjectType->headline = $validatedData['headline'];
            $userObjectType->subtitle = $validatedData['subtitle'] ?? "";
            $userObjectType->textarea = $validatedData['textarea'];
            $userObjectType->equipment = $validatedData['equipment'];
            $userObjectType->object_time = $validatedData['object_time'];
            $userObjectType->tag = $validatedData['tag'];
           
            if(!empty($request->is_drill)){
             
                if($request->is_drill == "true" && $request->is_drill == true ){
                    $userObjectType->is_drill = true;
                }else{
                    $userObjectType->is_drill = false;
                }
            }else{
                $userObjectType->is_drill = false;
            }
            if(!empty($request->order)){
                $userObjectType->order = $request->order;
            }
            
            $userObjectType->reps = $request->reps ?? 0;
            
            if(!empty($request->video_id)){
                $userObjectType->video_id = $request->video_id;
            }
            $link_items = [];
            if(!empty($request->link_items)){
                $reqLinkItem = json_decode($request->link_items);
                foreach ($reqLinkItem as $key => $val) {
                    $link_items[$key]['title'] = $val->title ?? "";
                    $link_items[$key]['link'] = $val->link ?? "";
                    $link_items[$key]['description'] = $val->description ?? "";
                }
                $userObjectType->link_items = $link_items;
            }else{
                $userObjectType->link_items = $link_items;
            }
            if ($request->hasFile('thumbnail') && $request->file('thumbnail')->isValid()) {
                $file_thumbnail = $request->file('thumbnail');
                $filename_thumbnail = uniqid() . '.' . $file_thumbnail->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_thumbnail, $filename_thumbnail, 'public');
                $userObjectType->thumbnail = $filename_thumbnail;
            }
            if ($request->hasFile('file') && $request->file('file')->isValid()) {
               
                $extension = $request->file('file')->getClientOriginalExtension();
                if ($extension === 'mp3') {
                    $file = $request->file('file');
                    $fileHash = str_replace('.' . $file->extension(), '', $file->hashName());
                    $filename = $fileHash . '.' . $request->file('file')->getClientOriginalExtension();
                    // $source = Storage::putFileAs('public/storage', $file, $filename);
                    // $source = explode('/',$source);
                    // $source = $source[1].'/'.$source[2];
                    // $userObjectType->file = '/storage/'.$source;
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $userObjectType->file = $filename;
                } else {
                    // $path = $request->file('file')->store('public/storage');
                    // $userObjectType->file = Storage::url($path);
                    $file = $request->file('file');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $userObjectType->file = $filename;
                }
            }
            $userObjectType->save();
            return ApiResponse::success($userObjectType,'User object type store successfully.');

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function updateUserObjectType(Request $request)
    {
        try {
            $path = env('AWS_OBJECT_IMAGES_PATH');
            $validatedData = $request->validate([
                'object_type_id' => 'required',
                'category_type_id' => 'required',
                'object_name' => 'required|string',
                'headline' => 'required|string',
                'subtitle' => 'nullable|string',
                'textarea' => 'required|string',
                'equipment' => 'required|string',
                'object_time' => 'required',
                'tag' => 'required',
                'video_id' => 'nullable'
            ]);
           
            if($request->id){
                $userObjectType = UserObjectType::find($request->id);
            }else{
                $userObjectType = new UserObjectType();
            }
            $userObjectType->object_type_id = $validatedData['object_type_id'];
            $userObjectType->category_type_id = $validatedData['category_type_id'];
            $userObjectType->object_name = $validatedData['object_name'];
            $userObjectType->headline = $validatedData['headline'];
            $userObjectType->subtitle = isset($validatedData['subtitle']) ? $validatedData['subtitle'] : ''; 
            $userObjectType->textarea = $validatedData['textarea'];
            $userObjectType->equipment = $validatedData['equipment'];
            $userObjectType->object_time = $validatedData['object_time'];
            $userObjectType->tag = $validatedData['tag'];
           
            if(!empty($request->is_drill)){
             
                if($request->is_drill == "true" && $request->is_drill == true ){
                    $userObjectType->is_drill = true;
                }else{
                    $userObjectType->is_drill = false;
                }
            }else{
                $userObjectType->is_drill = false;
            }
            if(!empty($request->order)){
                $userObjectType->order = $request->order;
            }
            
            $userObjectType->reps = $request->reps ?? 0;
            
            if(!empty($request->video_id)){
                $userObjectType->video_id = $request->video_id;
            }
            $link_items = [];
            if(!empty($request->link_items)){
                $reqLinkItem = json_decode($request->link_items);
                foreach ($reqLinkItem as $key => $val) {
                    $link_items[$key]['title'] = $val->title ?? "";
                    $link_items[$key]['link'] = $val->link ?? "";
                    $link_items[$key]['description'] = $val->description ?? "";
                }
                $userObjectType->link_items = $link_items;
            }else{
                $userObjectType->link_items = $link_items;
            }
            if ($request->hasFile('thumbnail') && $request->file('thumbnail')->isValid()) {
                $file_thumbnail = $request->file('thumbnail');
                $filename_thumbnail = uniqid() . '.' . $file_thumbnail->getClientOriginalExtension();
                Storage::disk('s3')->putFileAs($path, $file_thumbnail, $filename_thumbnail, 'public');
                $userObjectType->thumbnail = $filename_thumbnail;
            }
            if ($request->hasFile('file') && $request->file('file')->isValid()) {
               
                $extension = $request->file('file')->getClientOriginalExtension();
                if ($extension === 'mp3') {
                    $file = $request->file('file');
                    $fileHash = str_replace('.' . $file->extension(), '', $file->hashName());
                    $filename = $fileHash . '.' . $request->file('file')->getClientOriginalExtension();
                    // $source = Storage::putFileAs('public/storage', $file, $filename);
                    // $source = explode('/',$source);
                    // $source = $source[1].'/'.$source[2];
                    // $userObjectType->file = '/storage/'.$source;
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $userObjectType->file = $filename;
                } else {
                    // $path = $request->file('file')->store('public/storage');
                    // $userObjectType->file = Storage::url($path);
                    $file = $request->file('file');
                    $filename = uniqid() . '.' . $file->getClientOriginalExtension();
                    Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                    $userObjectType->file = $filename;
                }
            }
            $userObjectType->save();
            return ApiResponse::success($userObjectType,'User object type store successfully.');

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage object and below function can list object
    */
    public function getUserObjectTypeOld(Request $request)
    {
        try {
            $req_param = $request->all();// Get request parameters
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            
            $userObjCollection = UserObjectType::all(); // Retrieve all user object types
            $userObjectTypeCount = $userObjCollection->count();
            if($request->per_page === null && $request->page=== null){
                $totalPage = 1;
            }else{
                $perPage = $request->per_page; // Set the default number of items per page to 10, but you can change it.
                $page = $request->page; // Get the requested page number from the request.
                $totalPage = $userObjectTypeCount/$perPage;
            }
           
            //$tagIds = $userObjCollection->pluck('tag'); // Retrieve tag IDs
            $tagNames = Tags::pluck('name', '_id');// Retrieve tag names for all tag IDs
            $userIds = $userObjCollection->pluck('object_type_id');  // Retrieve user IDs
            $userNames = ObjectType::whereIn('_id', $userIds)->pluck('name', '_id');// Retrieve user names for all user IDs
            $categoryTypeIds = $userObjCollection->pluck('category_type_id'); // Retrieve category type IDs
            $categoryNames = CategoryType::whereIn('_id', $categoryTypeIds)->pluck('name', '_id');// Retrieve category names for all category type IDs
            $session = Session::get(); // Get all sessions
            foreach ($userObjCollection as $tag) {
                $tag->reps = $tag->reps ?? 0;
                $tag->file = $tag->file != "" ? env('AWS_S3_PATH')."".env('AWS_OBJECT_IMAGES_PATH')."".$tag->file:"";
                $tag->order =  $tag->order ?? null;
                $tag->video_id =  $tag->video_id ?? ""; //static passed by rugved in place of null
                $tag->session_allocated = false; // Initialize session_allocated property as false
                foreach ($session as $sessionObj) {
                    if (!empty($sessionObj["session_object"])) {
                        foreach ($sessionObj["session_object"] as $object) {
                            if ($object["object_id"] == $tag['_id']) {
                                $tag->session_allocated = true; // Set session_allocated property to true if object is allocated in a session
                                break;
                            }
                        }
                    }
                }
                $tagName = [];
                if (!empty($tag['tag'])) {
                    if (isset($tagNames[$tag['tag']])) {
                        $tagName[] = $tagNames[$tag['tag']];
                    }
                }
                $user_name = $userNames[$tag['object_type_id']] ?? "N/A";
                $category_name = $categoryNames[$tag['category_type_id']] ?? "N/A";
                $tag->object_type_name = $user_name;
                $tag->category_type_name = $category_name;
                $tagName = [];
                if($tag->tag != ""){
                    $tags =  explode(",",$tag->tag);
                    if(!empty($tags)){
                        foreach($tags as $tag_id){
                            $tagName[] = $tagNames[$tag_id] ?? "";
                        }
                    }
                }
                $tag->tag_name = implode(',', $tagName);
            }
            // $userObjCollection_ = $userObjCollection[]
          
            $sortedData = Functions::sortArray($userObjCollection,$sortColumn);//sort the data
         
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//filter the data

            if($request->per_page === null && $request->page=== null){
                $newRoot = [
                    "total_count" => $userObjectTypeCount,
                    "objects" => $filteredResponse,
                    "total_page"=> ceil($totalPage) ?? 0
                ];
            }else{
                if($filteredVal != ""){
                    $userObjectTypeCount = count($filteredResponse);
                    $paginatedData = $filteredResponse->forPage($page, $perPage);
                }else{
                    $paginator = new LengthAwarePaginator($filteredResponse, count($filteredResponse), $perPage, $page);
                    $paginatedData = $paginator->items();
                    $userObjectTypeCount = $paginator->total();
                }
                $totalPage = $userObjectTypeCount/$perPage;
                if(ceil($totalPage) == 0){
                    $totalPage = 1;
                }
                $paginatedObjects = [];

                // Loop through the paginated data and extract the objects
                foreach ($paginatedData as $pageData) {
                    $paginatedObjects[] = $pageData;
                }
                $newRoot = [
                    "total_count" => $userObjectTypeCount,
                    "objects" => $paginatedObjects,
                    "total_page"=> ceil($totalPage) ?? 1
                ];
            }
            return ApiResponse::success($newRoot,'object Type list found.'); 
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getUserObjectType(Request $request)
    {
        try {
            $req_param = $request->all();// Get request parameters
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            
            $userObjCollection = UserObjectType::all(); // Retrieve all user object types
           
            //$tagIds = $userObjCollection->pluck('tag'); // Retrieve tag IDs
            $tagNames = Tags::pluck('name', '_id');// Retrieve tag names for all tag IDs
           // $userIds = $userObjCollection->pluck('object_type_id');  // Retrieve user IDs
           ///whereIn('_id', $userIds)->
            $userNames = ObjectType::pluck('name', '_id');// Retrieve user names for all user IDs
            //$categoryTypeIds = $userObjCollection->pluck('category_type_id'); // Retrieve category type IDs
            // whereIn('_id', $categoryTypeIds)->
            $categoryNames = CategoryType::pluck('name', '_id');// Retrieve category names for all category type IDs
           
            foreach ($userObjCollection as $tag) {
                $tag->reps = $tag->reps ?? 0;
                $tag->is_drill = $tag->is_drill ?? false;
                $tag->file = $tag->file != "" ? env('AWS_S3_PATH')."".env('AWS_OBJECT_IMAGES_PATH')."".$tag->file:"";
                $tag->thumbnail = $tag->thumbnail  != "" ? env('AWS_S3_PATH')."".env('AWS_OBJECT_IMAGES_PATH')."".$tag->thumbnail  :"";
                $tag->order =  $tag->order ?? null;
                $tag->video_id =  $tag->video_id ?? ""; //static passed by rugved in place of null
                $tag->session_allocated = false; // Initialize session_allocated property as false
                $tag->link_items = $tag->link_items ?? [];
                // foreach ($session as $sessionObj) {
                //     if (!empty($sessionObj["session_object"])) {
                //         foreach ($sessionObj["session_object"] as $object) {
                //             if ($object["object_id"] == $tag['_id']) {
                //                 $tag->session_allocated = true; // Set session_allocated property to true if object is allocated in a session
                //                 break;
                //             }
                //         }
                //     }
                // }
             
                $tag->object_type_name = $userNames[$tag['object_type_id']] ?? "N/A";
                $tag->category_type_name = $categoryNames[$tag['category_type_id']] ?? "N/A";
                $tagName = [];
                if($tag->tag != ""){
                    $tags =  explode(",",$tag->tag);
                    if(!empty($tags)){
                        foreach($tags as $tag_id){
                            $tagName[] = $tagNames[$tag_id] ?? "";
                        }
                    }
                }
                $tag->tag_name = implode(',', $tagName);
            }
            $sortedData = Functions::sortArray($userObjCollection,$sortColumn);//applied sorting
            $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['object_name','category_type_name','tag_name','object_time']);//applied filter
            $userObjectTypeCount = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            $totalPage = !empty($request->per_page ) ? $userObjectTypeCount/ $request->per_page : 1;
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $currentPage  = $page - 1;
                if (is_array($filteredResponse)) {
                    $filteredResponse = collect($filteredResponse);
                }
                $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                $filteredResponse = array_values($pagedData);
            }
            
            $newRoot = [
                'total_page' => ceil($totalPage),
                'total_count' => $userObjectTypeCount,
                'objects' => $filteredResponse
            ];
            return ApiResponse::success($newRoot,'object Type list found.'); 
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getUserObjectTypeBySessionID($session_id)
    {
        try {
            $sessions = Session::find($session_id); // Get all sessions
            $sessionObjId = array_column($sessions["session_object"], "object_id");
            $userObj = UserObjectType::whereIn('_id',$sessionObjId)->pluck('_id','object_name')->toArray();
            $overview_data = Overview::where('session_id' , $session_id)->first();
            $newRoot =[
                'objects' => $userObj,
                'overview' => [
                    'headline' => $overview_data['headline'] ?? "",
                    'text' => $overview_data['text'] ?? "",
                    'time' =>  $overview_data['time'] ?? 0,
                    'is_equipments_needed' =>  $overview_data['is_equipments_needed'] ?? false,
                    'equipments' => $overview_data['equipments'] ?? "",
                    'move_drills_count' => $overview_data['move_drills_count'] ?? 0,
                    'recall_cards_count' => $overview_data['recall_cards_count'] ?? 0,
                    'list_items' => $overview_data['list_items'] ?? []
                ]
            ];
            return ApiResponse::success($newRoot,'object Type list found.'); 
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function getUserObjectTypeDrillsOnly(Request $request)
    {
        try {
            $req_param = $request->all();// Get request parameters
            // $sortColumn = $req_param['sort'] ?? "";
            // $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            
            $userObjCollectionQ = UserObjectType::where('is_drill',true);
            if($filteredVal != ""){
                $userObjCollectionQ = $userObjCollectionQ->where('object_name','like','%'.$filteredVal.'%');
            }
            $userObjCollection = $userObjCollectionQ->get(); // Retrieve all user object types
            //$tagIds = $userObjCollection->pluck('tag'); // Retrieve tag IDs
            $tagNames = Tags::pluck('name', '_id');// Retrieve tag names for all tag IDs
            $userIds = $userObjCollection->pluck('object_type_id');  // Retrieve user IDs
            $userNames = ObjectType::whereIn('_id', $userIds)->pluck('name', '_id');// Retrieve user names for all user IDs
            $categoryTypeIds = $userObjCollection->pluck('category_type_id'); // Retrieve category type IDs
            $categoryNames = CategoryType::whereIn('_id', $categoryTypeIds)->pluck('name', '_id');// Retrieve category names for all category type IDs
            $session = Session::get(); // Get all sessions
            foreach ($userObjCollection as $tag) {
                $tag->reps = $tag->reps ?? 0;
                $tag->is_drill = $tag->is_drill ?? false;
                $tag->file = $tag->file != "" ? env('AWS_S3_PATH')."".env('AWS_OBJECT_IMAGES_PATH')."".$tag->file:"";
                $tag->thumbnail = $tag->thumbnail != "" ? env('AWS_S3_PATH')."".env('AWS_OBJECT_IMAGES_PATH')."".$tag->thumbnail:"";
                $tag->order =  $tag->order ?? null;
                $tag->video_id =  $tag->video_id ?? ""; //static passed by rugved in place of null
                $tag->session_allocated = false; // Initialize session_allocated property as false
                $tag->link_items = $tag->link_items ?? [];
                foreach ($session as $sessionObj) {
                    if (!empty($sessionObj["session_object"])) {
                        foreach ($sessionObj["session_object"] as $object) {
                            if ($object["object_id"] == $tag['_id']) {
                                $tag->session_allocated = true; // Set session_allocated property to true if object is allocated in a session
                                break;
                            }
                        }
                    }
                }
                $tagName = [];
                if (!empty($tag['tag'])) {
                    if (isset($tagNames[$tag['tag']])) {
                        $tagName[] = $tagNames[$tag['tag']];
                    }
                }
                $user_name = $userNames[$tag['object_type_id']] ?? "N/A";
                $category_name = $categoryNames[$tag['category_type_id']] ?? "N/A";
                $tag->object_type_name = $user_name;
                $tag->category_type_name = $category_name;
                $tagName = [];
                if($tag->tag != ""){
                    $tags =  explode(",",$tag->tag);
                    if(!empty($tags)){
                        foreach($tags as $tag_id){
                            $tagName[] = $tagNames[$tag_id] ?? "";
                        }
                    }
                }
                $tag->tag_name = implode(',', $tagName);
            }

            // $sortedData = Functions::sortArray($userObjCollection,$sortColumn);//applied sorting
            // $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//applied filter
            // $userObjectTypeCount = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            // $totalPage = !empty($request->per_page ) ? $userObjectTypeCount/ $request->per_page : 1;
            // if(!empty( $request->per_page) && !empty( $request->page)){
            //     $perPage = $request->per_page ?? 10;
            //     $page = $request->page ?? 1;
            //     $currentPage  = $page - 1;
            //     if (is_array($filteredResponse)) {
            //         $filteredResponse = collect($filteredResponse);
            //     }
            //     $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
            //     $filteredResponse = array_values($pagedData);
            // }
            
            // $newRoot = [
            //     'total_page' => ceil($totalPage),
            //     'total_count' => $userObjectTypeCount,
            //     'objects' => $filteredResponse
            // ];
            return ApiResponse::success($userObjCollection,'Drills list found.'); 
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    /**
    * Developer: Apptodate 
    * Comment:  get shot check list for admin 
    */
    public function getShotCheck(Request $request)
    {
        try {
            $req_param = $request->all();// Get request parameters
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            $shotChecks = UserShotCheck::all();
            
            foreach ($shotChecks as $key => $shotCheck) {
                $user = User::where('userid',$shotCheck->user_id)->first();
                $shotCheck->user_name = $user->full_name ??"";
            }
            $sortedData = Functions::sortArray($shotChecks,$sortColumn);//sort the data
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//filter the data
            return ApiResponse::success($filteredResponse,'shot check found successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getFreeUser(Request $request)
    {
        try {
            $req_param = $request->all();// Get request parameters
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            $FreeUsers = FreeUser::all();
            $sortedData = Functions::sortArray($FreeUsers,$sortColumn);//sort the data
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//filter the data
            return ApiResponse::success($filteredResponse,'Free User Emails found successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment:  get Trust hole list for admin 
    */
    public function getTrustHole(Request $request)
    {
        try {
            $req_param = $request->all();// Get request parameters
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            $trustHoles = UserTrustHole::all();
            
            foreach ($trustHoles as $key => $trustHole) {
                $user = User::where('userid',$trustHole->user_id)->first();
                $trustHole->user_name = $user->full_name ??"";
            }
            $sortedData = Functions::sortArray($trustHoles,$sortColumn);//sort the data
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);//filter the data
            return ApiResponse::success($filteredResponse,'Trust hole found successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage object and below function can delete object
    */
    public function deleteUserObjectType($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Object type id required!!');
            }
            $tags = UserObjectType::find($id);

            if($tags){
                $sessions = Session::all();
                foreach ($sessions as $session) {
                    $sessionObjectData = $session->session_object;
                    $indexesToRemove = array_keys(array_filter($sessionObjectData, function ($item) use ($id) {
                        return $item['object_id'] === $id;
                    }));
                    $filteredSessionObject = array_filter($sessionObjectData, function ($item) use ($id) {
                        return $item['object_id'] !== $id;
                    });
                    $session->session_object = array_values($filteredSessionObject);
                    $session->save();
                    $overview = Overview::where('session_id', $session->_id)->first();

                    if ($overview) {
                        $session_overview_items = $overview->list_items;
                        if (!empty($session_overview_items)) {
                            foreach ($indexesToRemove as $index) {
                                unset($session_overview_items[$index]);
                            }
                            $session_overview_items = array_values($session_overview_items);
                            $overview->list_items = $session_overview_items;
                            $overview->save();
                        }
                    }
                }
                $tags->delete();
                return ApiResponse::successOnly('Object type deleted successfully.');
            }else{
                return ApiResponse::error('Object type not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Session crud and below finction can manage update session details 
    */
    public function updateSession(Request $request)
    {
        try {
            // Validate request parameters
            $validatedData = $request->validate([
                'session_type_id' => 'required',
                'category_type_id' => 'required',
                'session_name' => 'required',
                'description' => 'nullable',
                'session_object' => 'required|array',
                'session_object.*.object_id' => 'required',
                'session_object.*.permission' => 'required',
                'overview' => 'nullable'
            ]);
            
            if( $request->id){
                // Update existing session if ID is provided
                $session = Session::find($request->id);

                if (!$session) {
                    // Handle the case where the session is not found
                    return ApiResponse::error('Session not found!!');
                }
            }else{
                // Create a new session if ID is not provided
                $session = new Session();
            }
            // Assign values to session model properties
            $session->session_type_id = $validatedData['session_type_id'];
            $session->category_type_id = $validatedData['category_type_id'];
            $session->session_name = $validatedData['session_name'];
            $session->internal_session_name = $request->internal_session_name ?? "";
            $session->session_object = $validatedData['session_object'];
            $session->description = $validatedData['description'] ?? "";
            if(!empty($request->headline)){
                $session->headline = $request->headline;
            }
            
            if(!empty($request->text)){
                $session->text = $request->text;
            }
            if($request->has('recall_cards')){
                $session->recall_cards = $request->recall_cards;
                if( $request->id){
                    $recall_card_ids = array_column( $request->recall_cards, 'recall_card_id');
                    if(!empty($recall_card_ids)){
                            //delete other recall cards which is already assigned
                        UserRecallCards::where('session_id',$request->id)->whereNotIn('recall_card_id', $recall_card_ids)->delete();
                    }else{
                        UserRecallCards::where('session_id',$request->id)->delete();
                    }
                    
                }
            }
            if(!empty($request->order)){
                $session->order = $request->order;
            }
            // if($request->hasFile('session_img')){
            //     $file_session_img = $request->file('session_img');
            //     $filename_session_img= uniqid() . '_session_img_.' . $file_session_img->getClientOriginalExtension();
            //     $file_session_img->storeAs('session-images', $filename_session_img, 'public');
            //     $imageAccessUrl_session_img = Storage::disk('public')->url('session-images/' . $filename_session_img);
            //     $session->session_img = $imageAccessUrl_session_img;
            // }
            $session->save(); // Save the session
            
            if(!empty($request->overview)){
                $overview_data = $request->overview;
                $overview = Overview::where('session_id' , $session->_id)->first();
                if($overview){
                    $overview->headline =  $overview_data['headline'] ?? $overview->headline;
                    $overview->text =  $overview_data['text'] ??  "";
                    $overview->time =  $overview_data['time'] ?? $overview->time;
                    $overview->is_equipments_needed =  $overview_data['is_equipments_needed'] ?? $overview->is_equipments_needed;
                    $overview->equipments =  $overview_data['equipments'] ?? $overview->equipments;

                    $overview->move_drills_count =  $overview_data['move_drills_count'] ?? $overview->move_drills_count;
                    $overview->recall_cards_count =  $overview_data['recall_cards_count'] ?? $overview->recall_cards_count;
                    $overview->list_items =  $overview_data['list_items'] ?? $overview->list_items;
                }else{
                    $overview = new Overview();
                    $overview->session_id = $session->_id;
                    $overview->headline =  $overview_data['headline'] ?? "";
                    $overview->text =  $overview_data['text'] ?? "";
                    $overview->time =  $overview_data['time'] ?? 0;
                    $overview->is_equipments_needed =  $overview_data['is_equipments_needed'] ?? false;
                    $overview->equipments =  $overview_data['equipments'] ?? "";

                    $overview->move_drills_count =  $overview_data['move_drills_count'] ?? 0;
                    $overview->recall_cards_count =  $overview_data['recall_cards_count'] ?? 0;
                    $overview->list_items =  $overview_data['list_items'] ?? [];
                }
                $overview->save();
            }
            $session->overview = $request->overview ?? null;
            // Return the response
            return ApiResponse::success($session,'Session store successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Session crud and below finction can manage list sessions 
    */
    public function getSessionOld(Request $request)
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            $session = []; // Initialize an array to store session data
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $tags = Session::paginate($perPage, ['*'], 'page', $page); // Paginate sessions
            }else{
                $tags = Session::get();
            }
            // Retrieve session and category type IDs for the tags
            $tagSessionTypeIds = $tags->pluck('session_type_id');
            $tagCategoryTypeIds = $tags->pluck('category_type_id');

            // Retrieve category types and session types related to the tags
            $categoryTypes = CategoryType::whereIn('_id', $tagCategoryTypeIds)->pluck('name', '_id');
            $sessionTypes = SessionType::whereIn('_id', $tagSessionTypeIds)->pluck('name', '_id');

            $sessionObjectIds = []; // Initialize an array to store session object IDs
            foreach ($tags as $tag) {
                if (!empty($tag["session_object"])) {
                    // Get session object IDs for all tags
                    $sessionObjectIds = array_merge($sessionObjectIds, array_column($tag["session_object"], "object_id"));
                }
            }
            // Get user object data for the session object IDs
            $userObjectData = UserObjectType::whereIn('_id', $sessionObjectIds)->get();
         
            foreach ($tags as $key => $tag) {
                $object = []; // Initialize an array to store session objects
                $totalTime = 0;
                if (!empty($tag["session_object"])) {
                    foreach ($tag["session_object"] as $keyy => $unitObject) {
                        $userObject = $userObjectData->firstWhere('_id', $unitObject["object_id"]);
                        if ($userObject) {
                            $object[$keyy]['object_id'] = $userObject["_id"];
                            $object[$keyy]['permission'] = $unitObject["permission"];
                            $totalTime += (float) $userObject["object_time"];
                            $totalTime = number_format($totalTime,2);
                        }
                    }
                }
                // Assign values to session data array
                $tag->category_type_name = $categoryTypes[$tag->category_type_id] ?? "N/A";
                $filteredData = array_values(array_filter($object, function ($item) {
                    return isset($item['object_id']);
                }));
                $session[$key]['session_type_id'] = $tag["session_type_id"];
                $session[$key]['category_type_id'] = $tag["category_type_id"];
                $session[$key]['id'] = $tag["_id"];
                $session[$key]['order'] = $tag["order"];
                $session[$key]['session'] = $tag["session_name"];
                $session[$key]['internal_session_name'] = $tag["internal_session_name"] ?? "";
                $session[$key]['headline'] = $tag["headline"] ?? "";
                $session[$key]['text'] = $tag["text"] ?? "";
                $session[$key]['thumbnail'] = $appUrl."thumbnail_old.png";
                
                $session[$key]['session_type'] = $sessionTypes[$tag->session_type_id] ?? "N/A";
                $session[$key]['category_type'] = $categoryTypes[$tag->category_type_id] ?? "N/A";
                $session[$key]['object_list'] = $filteredData;
                $session[$key]['recall_cards'] = $tag['recall_cards'] ?? [];
                $session[$key]['time'] = number_format($totalTime,2);
                $session[$key]['last_update'] = $tag["updated_at"];
                $overview_data = Overview::where('session_id',$tag["_id"])->first();
                $session[$key]['overview'] = [
                    'headline' => $overview_data['headline'] ?? "",
                    'text' => $overview_data['text'] ?? "",
                    'time' =>  $overview_data['time'] ?? 0,
                    'is_equipments_needed' =>  $overview_data['is_equipments_needed'] ?? false,
                    'equipments' => $overview_data['equipments'] ?? "",
                    'move_drills_count' => $overview_data['move_drills_count'] ?? 0,
                    'recall_cards_count' => $overview_data['recall_cards_count'] ?? 0,
                    'list_items' => $overview_data['list_items'] ?? []
                ];
            }
            $sortedData = Functions::sortArray($session,$sortColumn);
            $filteredResponse = Functions::filterArrayByField($sortedData, $filteredVal, $filterColumn);
            if($filteredVal != ""){
                $totalSession = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            }else{
                $totalSession =  Session::get()->count() ?? 0 ;
            }
          
            $totalPage = !empty($request->per_page ) ? $totalSession/ $request->per_page : 1;
            $response = [
                'data' => $filteredResponse,
                'total_session' => $totalSession,
                'total_page' => ceil($totalPage)
                //'current_page' => $tags->currentPage(),
                // 'first_page_url' => $tags->url(1),
                // 'from' => $tags->firstItem(),
                // 'last_page' => $tags->lastPage(),
                // 'last_page_url' => $tags->url($tags->lastPage()),
                // 'next_page_url' => $tags->nextPageUrl(),
                // 'path' => $tags->path(),
                // 'per_page' => $tags->perPage(),
                // 'prev_page_url' => $tags->previousPageUrl(),
                // 'to' => $tags->lastItem(),
            ];
            // Return the response
            return ApiResponse::success($response, 'Session list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getSession(Request $request)
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn  = $req_param['filterBy'] ?? "";
            $filteredVal  = $req_param['filteredVal'] ?? "";
            $session = []; // Initialize an array to store session data
            $tags = Session::get();
            // Retrieve session and category type IDs for the tags
            $tagSessionTypeIds = $tags->pluck('session_type_id');
            $tagCategoryTypeIds = $tags->pluck('category_type_id');

            // Retrieve category types and session types related to the tags
            $categoryTypes = CategoryType::whereIn('_id', $tagCategoryTypeIds)->pluck('name', '_id');
            $sessionTypes = SessionType::whereIn('_id', $tagSessionTypeIds)->pluck('name', '_id');

            $sessionObjectIds = []; // Initialize an array to store session object IDs
            foreach ($tags as $tag) {
                if (!empty($tag["session_object"])) {
                    // Get session object IDs for all tags
                    $sessionObjectIds = array_merge($sessionObjectIds, array_column($tag["session_object"], "object_id"));
                }
            }
            // Get user object data for the session object IDs
            $userObjectData = UserObjectType::whereIn('_id', $sessionObjectIds)->get();
         
            foreach ($tags as $key => $tag) {
                $object = []; // Initialize an array to store session objects
                $totalTime = 0;
                if (!empty($tag["session_object"])) {
                    foreach ($tag["session_object"] as $keyy => $unitObject) {
                        $userObject = $userObjectData->firstWhere('_id', $unitObject["object_id"]);
                        if ($userObject) {
                            $object[$keyy]['object_id'] = $userObject["_id"];
                            $object[$keyy]['permission'] = $unitObject["permission"];
                            $totalTime += (float) $userObject["object_time"];
                            $totalTime = number_format($totalTime,2);
                        }
                    }
                }
                // Assign values to session data array
                $tag->category_type_name = $categoryTypes[$tag->category_type_id] ?? "N/A";
                $filteredData = array_values(array_filter($object, function ($item) {
                    return isset($item['object_id']);
                }));
                $session[$key]['session_type_id'] = $tag["session_type_id"];
                $session[$key]['category_type_id'] = $tag["category_type_id"];
                $session[$key]['id'] = $tag["_id"];
                $session[$key]['order'] = $tag["order"];
                $session[$key]['session'] = $tag["session_name"];
                $session[$key]['internal_session_name'] = $tag["internal_session_name"] ?? "";
                $session[$key]['headline'] = $tag["headline"] ?? "";
                $session[$key]['text'] = $tag["text"] ?? "";
                $session[$key]['thumbnail'] = $appUrl."thumbnail_old.png";
                $session[$key]['description'] = $tag["description"] ?? "";
                
                $session[$key]['session_type'] = $sessionTypes[$tag->session_type_id] ?? "N/A";
                $session[$key]['category_type'] = $categoryTypes[$tag->category_type_id] ?? "N/A";
                $session[$key]['object_list'] = $filteredData;
                $session[$key]['recall_cards'] = $tag['recall_cards'] ?? [];
                $session[$key]['time'] = number_format($totalTime,2);
                $session[$key]['last_update'] = $tag["updated_at"];
                $overview_data = Overview::where('session_id',$tag["_id"])->first();
                $session[$key]['overview'] = [
                    'headline' => $overview_data['headline'] ?? "",
                    'text' => $overview_data['text'] ?? "",
                    'time' =>  $overview_data['time'] ?? 0,
                    'is_equipments_needed' =>  $overview_data['is_equipments_needed'] ?? false,
                    'equipments' => $overview_data['equipments'] ?? "",
                    'move_drills_count' => $overview_data['move_drills_count'] ?? 0,
                    'recall_cards_count' => $overview_data['recall_cards_count'] ?? 0,
                    'list_items' => $overview_data['list_items'] ?? []
                ];
            }
            $sortedData = Functions::sortArray($session,$sortColumn);//applied sorting
            $filteredResponse = Functions::filterArrayByField($sortedData, $filteredVal, $filterColumn);//applied filter
            $totalSession = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            $totalPage = !empty($request->per_page ) ? $totalSession/ $request->per_page : 1;
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $currentPage  = $page - 1;
                if (is_array($filteredResponse)) {
                    $filteredResponse = collect($filteredResponse);
                }
                $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                $filteredResponse = array_values($pagedData);
            }
            
            $response = [
                'total_page' => ceil($totalPage),
                'total_session' => $totalSession,
                'data' => $filteredResponse
            ];
            // Return the response
            return ApiResponse::success($response, 'Session list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    // public function getSessionOverview($id,unit_id, Request $request)
    // {
    //     try {
    //         // Get request parameters
    //         $req_param = $request->all();
    //         $sortColumn = $req_param['sort'] ?? "";
    //         $filterColumn  = $req_param['filterBy'] ?? "";
    //         $filteredVal  = $req_param['filteredVal'] ?? "";
    //         $session = []; // Initialize an array to store session data
    //         $tags = Session::get(); // Paginate sessions

    //         // Retrieve session and category type IDs for the tags
    //         $tagSessionTypeIds = $tags->pluck('session_type_id');
    //         $tagCategoryTypeIds = $tags->pluck('category_type_id');

    //         // Retrieve category types and session types related to the tags
    //         $categoryTypes = CategoryType::whereIn('_id', $tagCategoryTypeIds)->pluck('name', '_id');
    //         $sessionTypes = SessionType::whereIn('_id', $tagSessionTypeIds)->pluck('name', '_id');

    //         $sessionObjectIds = []; // Initialize an array to store session object IDs
    //         foreach ($tags as $tag) {
    //             if (!empty($tag["session_object"])) {
    //                 // Get session object IDs for all tags
    //                 $sessionObjectIds = array_merge($sessionObjectIds, array_column($tag["session_object"], "object_id"));
    //             }
    //         }
    //         // Get user object data for the session object IDs
    //         $userObjectData = UserObjectType::whereIn('_id', $sessionObjectIds)->get();
           
         
    //         foreach ($tags as $key => $tag) {
    //             $object = []; // Initialize an array to store session objects
    //             $totalTime = 0;

    //             if (!empty($tag["session_object"])) {
    //                 foreach ($tag["session_object"] as $keyy => $unitObject) {
    //                     $userObject = $userObjectData->firstWhere('_id', $unitObject["object_id"]);
                        
    //                     if ($userObject) {
    //                         $object[$keyy]['object_id'] = $userObject["_id"];
    //                         $object[$keyy]['permission'] = $unitObject["permission"];
    //                         // $objTime =  $userObject["object_time"] ?? 0;
    //                         $totalTime += (float) $userObject["object_time"];
    //                         //$totalTime += (int)$userObject["object_time"];
    //                         $totalTime = number_format($totalTime,2);
    //                     }
    //                 }
    //             }
               
    //             // Assign values to session data array
    //             $tag->category_type_name = $categoryTypes[$tag->category_type_id] ?? "N/A";
    //             $filteredData = array_values(array_filter($object, function ($item) {
    //                 return isset($item['object_id']);
    //             }));
               
    //             $session[$key]['session_type_id'] = $tag["session_type_id"];
    //             $session[$key]['category_type_id'] = $tag["category_type_id"];
    //             $session[$key]['id'] = $tag["_id"];
    //             $session[$key]['unit_id'] = $unit_id;
    //             $session[$key]['order'] = $tag["order"];
    //             $session[$key]['session'] = $tag["session_name"];
    //             $session[$key]['headline'] = $tag["headline"] ?? "";
    //             $session[$key]['text'] = $tag["text"] ?? "";
    //             $session[$key]['session_type'] = $sessionTypes[$tag->session_type_id] ?? "N/A";
    //             $session[$key]['category_type'] = $categoryTypes[$tag->category_type_id] ?? "N/A";
    //             $session[$key]['object_list'] = $filteredData;
    //             $session[$key]['recall_cards'] = $tag['recall_cards'] ?? [];
    //             $session[$key]['time'] = $totalTime;
    //             $session[$key]['last_update'] = $tag["updated_at"];
    //             $overview_data = Overview::where('session_id',$tag["_id"])->first();
    //             $session[$key]['overview'] = [
    //                 'headline' => $overview_data['headline'] ?? "",
    //                 'text' => $overview_data['text'] ?? "",
    //                 'time' =>  $overview_data['time'] ?? 0,
    //                 'is_equipments_needed' =>  $overview_data['is_equipments_needed'] ?? false,
    //                 'equipments' => $overview_data['equipments'] ?? "",
    //                 'move_drills_count' => $overview_data['move_drills_count'] ?? 0,
    //                 'recall_cards_count' => $overview_data['recall_cards_count'] ?? 0,
    //                 'list_items' => $overview_data['list_items'] ?? []
    //             ];
                
    //         }
    //         // Sort the session data
    //         $sortedData = Functions::sortArray($session,$sortColumn);
    //         // Filter the session data
    //         $filteredResponse = Functions::filterArrayByField($sortedData, $filteredVal, $filterColumn);
    //         // Build the response array with pagination information
    //         $response = [
    //             //'current_page' => $tags->currentPage(),
    //             'data' => $filteredResponse,
    //            // 'first_page_url' => $tags->url(1),
    //             // 'from' => $tags->firstItem(),
    //             // 'last_page' => $tags->lastPage(),
    //             // 'last_page_url' => $tags->url($tags->lastPage()),
    //             // 'next_page_url' => $tags->nextPageUrl(),
    //             // 'path' => $tags->path(),
    //             // 'per_page' => $tags->perPage(),
    //             // 'prev_page_url' => $tags->previousPageUrl(),
    //             // 'to' => $tags->lastItem(),
    //             // 'total' => $tags->total(),
    //         ];
    //         // Return the response
    //         return ApiResponse::success($response, 'Session list found.');
    //     }catch (\Exception $e) {
    //         return ApiResponse::error($e->getMessage());
    //     }
    // }
    

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Session crud and below function can manage delete sessions 
    */
    public function deleteSession($id)
    {
        try{
            
            if(!$id){
                return ApiResponse::error('Session id required!!');
            }

            $tags = Session::find($id);

            if($tags){
                $tags->delete();
                return ApiResponse::successOnly('Session deleted successfully.');
            }else{
                return ApiResponse::error('Session not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Unit crud and below function can manage update unit
    */
    public function updateUnit(Request $request)
    {
        try {
            // Validate request parameters
            $validatedData = $request->validate([
                'category_type_id' => 'required',
                'unit_name' => 'required',
                'unit_object' => 'required|array',
                'unit_object.*.object_id' => 'required',
                'unit_object.*.permission' => 'required',
                'unit_object.*.time' => 'nullable',
                'internal_unit_name' => 'nullable',
            ]);
            
            if( $request->id){
                $unit = Unit::find($request->id);
            }else{
                $unit = new Unit();
            }
            
            $unit->category_type_id = $validatedData['category_type_id'];
            $unit->unit_name = $validatedData['unit_name'];
            $unit->internal_unit_name = $validatedData['internal_unit_name'] ?? "";
            $unit->unit_object = $validatedData['unit_object'];
            if(!empty($request->order)){
                $unit->order = $request->order;
            }
            $unit->save();
            
            return ApiResponse::success($unit,'Unit store successfully.');

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Group crud and below function can manage update Group
    */
    public function updateGroup(Request $request)
    {
        try {
            // Validate request parameters
            $validatedData = $request->validate([
                'group_name' => 'required',
                'group_object' => 'required|array',
                'group_object.*.object_id' => 'required',
                'group_object.*.time' => 'nullable',
                'tag' => 'nullable',
                'plan_name' => 'nullable'
            ]);
            if( $request->id){
                $group = Group::find($request->id);
            }else{
               
               $group = new Group();
            }
            $group->group_name = $validatedData['group_name'];
            $group->plan_name = $validatedData['plan_name'] ?? "";
            $group->group_object = $validatedData['group_object'];
            $group->tag = $validatedData['tag'];
            if(!empty($request->order)){
                $group->order = $request->order;
            }
            $group->save();
            return ApiResponse::success($group,'Group store successfully.');

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Group assign to multiple user
    */
    public function assignGroupUser(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'user_list' => 'required|array',
                'group_id' => 'required'
            ]);
            $group = Group::find($validatedData['group_id']);
            if(!$group){
                return ApiResponse::error('Trouble fetching group information.');
            }
            if(!empty($validatedData['user_list'])){
                $userData = User::whereIn('_id', $validatedData['user_list'])->get();
                foreach($validatedData['user_list'] as $user_id){
                    $user = $userData->find($user_id);
                    $user->group_id = $group->id;
                    $user->save();
                }
            }
            return ApiResponse::successOnly('Group assigned to users successfully.');

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Trophies and below function can manage update trophy
    */
    public function updateTrophies(Request $request)
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $trophyPath = env('AWS_TROPHY_PATH');
            $validatedData = $request->validate([
                'name' => 'required',
                'trophie_type' => 'required',
                'description' => 'required',
                'received_date' => 'required',
                'trophie_back' => 'required|image|mimes:jpeg,png,jpg|max:20480',
                'trophie_front' => 'required|image|mimes:jpeg,png,jpg|max:20480'
            ]);// Validate request parameters
            
            if(!empty($request->id)){
                $trophies = Trophie::find($request->id);
                $name = $request->name ?? $trophies->name;
                $description = $validatedData['description'] ?? $trophies->description;
                $received_date = $validatedData['received_date'] ?? $trophies->received_date;
                $trophie_type = $validatedData['trophie_type'] ?? $trophies->trophie_type ;
            }else{
                $trophies = new Trophie();
                $name = $request->name;
                $description = $validatedData['description'];
                $received_date = $validatedData['received_date'];
                $trophie_type = $validatedData['trophie_type'];
            }
            $trophies->name = $name;
            $trophies->description = $description;
            $trophies->received_date = $received_date;
            $trophies->trophie_type = $trophie_type;
            
            if($request->hasFile('trophie_front')){
                $file_question_img = $request->file('trophie_front');
                $filename_question_img = uniqid() . '_trophie_front_.' . $file_question_img->getClientOriginalExtension();
                //$file_question_img->storeAs('trophie_front', $filename_question_img, 'public');
                //$imageAccessUrl_question_img = Storage::disk('public')->url('trophie_front/' . $filename_question_img);
                //$trophies->trophie_front = $imageAccessUrl_question_img;
                Storage::disk('s3')->putFileAs($trophyPath, $file_question_img, $filename_question_img, 'public');
                $trophies->trophie_front = $filename_question_img;
            }
            if($request->hasFile('trophie_back')){
                $file_answer_img = $request->file('trophie_back');
                $filename_answer_img = uniqid() . '_trophie_back_.' . $file_answer_img->getClientOriginalExtension();
                //$file_answer_img->storeAs('trophie_back', $filename_answer_img, 'public');
                //$imageAccessUrl_answer_img = Storage::disk('public')->url('trophie_back/' . $filename_answer_img);
                //$trophies->trophie_back = $imageAccessUrl_answer_img;
                Storage::disk('s3')->putFileAs($trophyPath, $file_answer_img, $filename_answer_img, 'public');
                $trophies->trophie_back = $filename_answer_img;
            }
            $trophies->save();
            $trophies->trophie_front = $appUrl."".$trophyPath."".$trophies->trophie_front;
            $trophies->trophie_back = $appUrl."".$trophyPath."".$trophies->trophie_back;
            return ApiResponse::success($trophies,'Trophy store successfully.');

        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Trophies crud and below function can manage delete trophy 
    */
    public function deleteTrophies($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Trophy id required!!');
            }
            $trophy = Trophie::find($id);
            if($trophy){
                $trophy->delete();
                return ApiResponse::successOnly('Trophy deleted successfully.');
            }else{
                return ApiResponse::error('Trophy not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage ads and below function can manage update ads
    */
    public function updateAds(Request $request)
    {
        try {
            $appUrl = env('AWS_S3_PATH');
            $validatedData = $request->validate([
                'title' => 'required',
                'page' => 'required',
                'type' => 'required',
                'file' => 'required|mimes:jpeg,png,jpg,gif,mp4,quicktime',
            ]);// Validate request parameters
            if(!empty($request->id)){
                $ads = Ads::find($request->id);
                $title =  $validatedData['title'] ?? $ads->title;
                $page = $validatedData['page'] ?? $ads->page;
                $type = $validatedData['type'] ?? $ads->type;
            }else{
                $ads = new Ads();
                $title = $request->title;
                $page = $validatedData['page'];
                $type = $validatedData['type'];
            }
            $ads->title = $title;
            $ads->page = $page;
            $ads->type = $type;
            // if ($request->hasFile('file') && $request->file('file')->isValid()) {
            //     $file = $request->file('file');
            //     // Generate a unique filename to prevent naming conflicts
            //     $filename = uniqid() . '_ads.' . $file->getClientOriginalExtension();
            //     // Move the uploaded file to the storage directory
            //     $file->storeAs('public/ads', $filename);
            //     // Now you can get the public URL for the uploaded file
            //     $publicUrl = Storage::disk('public')->url('ads/' . $filename);
            // }
            if ($request->hasFile('file') && $request->file('file')->isValid()) {
                $file = $request->file('file');
                $filename = uniqid() . '_ads.' . $file->getClientOriginalExtension();
                $path = env('AWS_ADS_PATH');
				Storage::disk('s3')->putFileAs($path, $file, $filename, 'public');
                $ads->ads_url = $filename;
            }
           
            $ads->save();
            $ads->ads_url = $appUrl."".env('AWS_ADS_PATH')."".$filename;
            return ApiResponse::success($ads,'Ads store successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    
    public function assignTag(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $admin = User::find($userToken["_id"]);
            if(!$admin){
                return ApiResponse::error('Getting trouble to fetch admin information');
            }
            $validatedData = $request->validate([
                'tag_id' => 'required',
                'user_id'=> 'required'
            ]);
            $user = User::find($request->user_id);
            if(!$user){
                return ApiResponse::error('User not found!');
            }
            
            $user->tag_id =  $request->tag_id;
            $user->save();
            return ApiResponse::success($user,'Tag assigned successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updatePromo(Request $request)
    {
        try {
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $validatedData = $request->validate([
                'code' => 'required',
                'discount' => 'required',
                'plan_id' => 'required'
            ]);
            if(isset($request->id)){
                $promo_codes = PromoCode::find($request->id);
            }else{
                $promo_codes = new PromoCode();
            }
          
            $promo_codes->code = $request->code;
            $promo_codes->discount =  $request->discount;
            $promo_codes->quantity =  $request->quantity;
            $promo_codes->plan_id = $request->plan_id;
            $promo_codes->save();
       
            return ApiResponse::success($promo_codes,'Promo Code store successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage quote and below function can manage update quote
    */
    public function updateQuote(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'title' => 'required',
                'quote' => 'required',
                'quote_by' => 'required'
            ]);// Validate request parameters
            if(!empty($request->id)){
                $quote = TrustQuote::find($request->id);
                $title =  $validatedData['title'] ?? $quote->title;
                $quote_data = $validatedData['quote'] ?? $quote->quote;
                $quote_by = $validatedData['quote_by'] ?? $quote->quote_by;
                $status = 'updated';
               
            }else{
                $quote = new TrustQuote();
                $title =$validatedData['title'];
                $quote_data = $validatedData['quote'];
                $quote_by = $validatedData['quote_by'];
                $status = 'added';
            }
            $quote->title = $title;
            $quote->quote = $quote_data;
            $quote->quote_by = $quote_by;
            $quote->shown = false;
            $quote->save();
            return ApiResponse::success($quote,'Quote details '.$status.' successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage overview and below function can manage update overview
    */
    public function updateOverview(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'headline' => 'required',
                'text' => 'required',
                'description' => 'required',
                'type' => 'required',
                'time' => 'required'
            ]);// Validate request parameters
            if(!empty($request->id)){
                $overview = TrustOverview::find($request->id);
                $headline =  $validatedData['headline'] ?? $overview->headline;
                $text = $validatedData['text'] ?? $overview->text;
                $description = $validatedData['description'] ?? $overview->description;
                $type = $validatedData['type'] ?? $overview->type;
                $time = $validatedData['time'] ?? $overview->time;
                $status = 'updated';
               
            }else{
                $overview = new TrustOverview();
                $headline =  $validatedData['headline'] ?? "";
                $text = $validatedData['text'] ?? "";
                $description = $validatedData['description'] ?? "";
                $type = $validatedData['type'] ?? "trust";
                $time = $validatedData['time'] ?? 0;
                $status = 'added';
            }
            $overview->headline = $headline;
            $overview->text = $text;
            $overview->description = $description;
            $overview->type = $type;
            $overview->time = $time;
            $overview->save();
            return ApiResponse::success($overview,'Overview details '.$status.' successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }


    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Ads crud and below function can manage delete ads 
    */
    public function deleteAds($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Ads id required!!');
            }
            $ads = Ads::find($id);
            if($ads){
                $ads->delete();
                return ApiResponse::successOnly('Ads deleted successfully.');
            }else{
                return ApiResponse::error('Ads not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getPromo(Request $request)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            $req_param = $request->all();
       
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
         
            $plans = Plan::pluck('name', '_id');
            $promo_codes = PromoCode::where('status','active')->get();
            foreach ($promo_codes as $promo_code) {
                $promo_code->plan_name = $plans[$promo_code->plan_id] ?? "N/A";
                $promo_code->quantity = $promo_code->quantity ?? 0;
                $promo_code->used_quantity = UsedPromoCode::where('promo_code', $promo_code->$promo_code)->count();
            }
            $sortedData = Functions::sortArray($promo_codes,$sortColumn);
            $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);
            $totalTags = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            $totalPage = !empty($request->per_page ) ? $totalTags/ $request->per_page : 1;
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $currentPage  = $page - 1;
                if (is_array($filteredResponse)) {
                    $filteredResponse = collect($filteredResponse);
                }
                $pagedData = $filteredResponse->slice($currentPage * $perPage, $perPage)->toArray();
                $filteredResponse = array_values($pagedData);
            }
            
            $newRoot = [
                'total_page' => ceil($totalPage),
                'total_tags' => $totalTags,
                'promo_codes' => $filteredResponse
            ];
            return ApiResponse::success($newRoot,'Promo Code list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getPlan()
    {
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $plans = Plan::where('amount','!=',0)->get();
                return ApiResponse::success($plans,'Payment plan detail fetched successfully.');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function deletePromo($id)
    {
        try{
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if (!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            
            if(!$id){
                return ApiResponse::error('Promo Code id required!!');
            }
            $ads = PromoCode::find($id);
            if($ads){
                $ads->delete();
                return ApiResponse::successOnly('Promo Code deleted successfully.');
            }else{
                return ApiResponse::error('Promo Code not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage quote crud and below function can manage delete quote 
    */
    public function deleteQuote($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Quote id required!!');
            }
            $quote = TrustQuote::find($id);
            if($quote){
                $quote->delete();
                return ApiResponse::successOnly('Quote deleted successfully.');
            }else{
                return ApiResponse::error('Quote not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Unit crud and below function can manage list of unit
    */

    public function getUnit(Request $request)
    {
        try {
             // Get request parameters
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
            // Retrieve all units
            
            if(!empty( $request->per_page) && !empty( $request->page)){
                $perPage = $request->per_page ?? 10;
                $page = $request->page ?? 1;
                $unitCollectionData = Unit::paginate($perPage, ['*'], 'page', $page); 
            }else{
                $unitCollectionData = Unit::get();
            }
            
            $unitCollection = $unitCollectionData->sortBy(function ($item) {
                return (int) $item->order;
            })->values()->all();  

            $unitData = []; // Initialize an array to store unit data
            $sessionData = []; // Initialize an array to store session data
            // Retrieve category types related to units
            $tag_category_type_id = $unitCollectionData->pluck('category_type_id');
            $categoryTypes = CategoryType::whereIn('_id', $tag_category_type_id)->pluck('name', '_id');
           
            // Fetch all session and session type IDs from the unit collection
            $sessionIds = [];
            foreach ($unitCollection as $unitObj) {
                if (isset($unitObj["unit_object"])) {
                    foreach ($unitObj["unit_object"] as $sessionUnitObj) {
                        $sessionIds[] = $sessionUnitObj["object_id"];
                    }
                }
            }
        
            // Fetch session and session type data in a single query
            $sessions = Session::whereIn('_id', $sessionIds)->get();
            $sessionTypeIds = $sessions->pluck('session_type_id')->unique()->toArray();
            $sessionTypes = SessionType::whereIn('_id', $sessionTypeIds)->get();
            // Retrieve user object IDs from session collection
            $userObjectIds = $sessions->pluck('session_object.*.object_id')->flatten()->unique()->toArray();
            // Fetch user objects outside the loop
            $userObjects = UserObjectType::whereIn('_id', $userObjectIds)->get();
            // Iterate through each unit object
            foreach ($unitCollection as $key => $unitObj) {
                $unitTotalTime = 0;
                $sessionData = []; // Initialize sessionData for each unitObj
                if (isset($unitObj["unit_object"])) {
                    foreach ($unitObj["unit_object"] as $unitsession => $sessionUnitObj) {
                        $sessionCollection = $sessions->firstWhere('_id', $sessionUnitObj["object_id"]);
                        $totalTime = 0;
                        if (!empty($sessionCollection)) {
                            $sessionTypeCollection = $sessionTypes->firstWhere('_id', $sessionCollection["session_type_id"]);
                            $sessionData[$unitsession]['id'] = $sessionCollection["_id"];
                            $sessionData[$unitsession]['internal_session_name'] = $sessionCollection["internal_session_name"] ?? "";
                            $sessionData[$unitsession]['session_name'] = $sessionCollection["session_name"];
                            $sessionData[$unitsession]['headline'] = $sessionCollection["headline"] ?? '';
                            $sessionData[$unitsession]['text'] = $sessionCollection["text"] ?? '';
                            $sessionData[$unitsession]['session_type'] = $sessionTypeCollection["name"] ?? '';
                            $sessionData[$unitsession]['permission'] = $sessionUnitObj["permission"];
                            
                            if (!empty($sessionCollection["session_object"])) {
                                $userObjectIds = array_column($sessionCollection["session_object"], 'object_id');
                                $filteredUserObjects = $userObjects->whereIn('_id',$userObjectIds);
                                foreach ($filteredUserObjects  as $userObject) {
                                    $totalTime += (float) $userObject["object_time"];
                                    $totalTime = number_format($totalTime,2);
                                }
                            }
                            $sessionData[$unitsession]['session_time'] = $totalTime ?? 0;
                        }
                        $unitTotalTime +=$totalTime;
                    }
                }
                // Build the unit data array
                $unitData[$key]['id'] = $unitObj["_id"];
                $unitData[$key]['unit'] = $unitObj["unit_name"];
                $unitData[$key]['internal_unit_name'] = $unitObj["internal_unit_name"] ?? "";
                $unitData[$key]['order'] =  $unitObj["order"] == null ? 10000 : $unitObj["order"];
                $unitData[$key]['time'] = number_format($unitTotalTime,2);
                $unitData[$key]['session'] = !empty($sessionData) ? array_values($sessionData) : []; // Store sessionData as array values
                $unitData[$key]['category_type'] = $categoryTypes[$unitObj["category_type_id"]] ?? "N/A";
                $unitData[$key]['category_type_id'] = $unitObj["category_type_id"];
                $unitData[$key]['last_update'] = $unitObj["updated_at"];
            }
            $sortedData = Functions::sortArray($unitData ,$sortColumn);
            $filteredResponse = Functions::filterArrayByField($sortedData, $filteredVal, $filterColumn);
            if($filteredVal != ""){
                $totalUnit = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
            }else{
                $totalUnit = Unit::get()->count();
            }
            $totalPage = !empty($request->per_page) ? $totalUnit / $request->per_page : 1;
            $newRoot = [
                'units' => $filteredResponse,
                'total_unit' => $totalUnit,
                'total_page' => ceil($totalPage) ?? 1
            ];
            return ApiResponse::success($newRoot,'Unit list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Group crud and below function can manage list of Group
    */

    public function getGroup(Request $request)
    {
        try {
             // Get request parameters
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
            // Retrieve all units
            $groupCollectionData = Group::orderBy('created_at','asc')->get();
            $groupCollection = [];
            $tagNames = Tags::pluck('name', '_id');// Retrieve tag names for all tag IDs
            $groupCollection = $groupCollectionData->sortBy(function ($item) {
                return (int) $item->order;
            })->values()->all();
            foreach ($groupCollection as $key => $group) {
                $tagName = [];
                if($group->tag != ""){
                    $tags =  explode(",",$group->tag);
                    if(!empty($tags)){
                        foreach($tags as $tag_id){
                            $tagName[] = $tagNames[$tag_id] ?? "";
                        }
                    }
                    $group->tag_name = implode(',', $tagName);
                }else{
                    $group->tag = "";
                    $group->tag_name = "";
                }
            }
            
            // Fetch session and session type data in a single query
            $sortedData = Functions::sortArray($groupCollection ,$sortColumn);
            $filteredResponse = Functions::filterArrayByFieldProgram($sortedData, $filteredVal, $filterColumn);
            return ApiResponse::success($filteredResponse,'Group list found.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin side list reports
    */
    public function getReport(Request $request)
    {
        try{
            $appUrl = env('AWS_S3_PATH');
            $notesPath = env('AWS_NOTES_REPORTS_IMAGE_PATH');
            $token = $this->getTokenFromHeader();
            $userToken = \JWTAuth::setToken($token)->authenticate(); //user token verified
            $user = User::find($userToken["_id"]);
            if(!$user){
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $searchTerm = $request->input('search'); //filter for name
            $query = Note::query(); 
            $perPage = $request->per_page ?? 10; // Set the default number of items per page to 10, but you can change it.
            $page = $request->page ??  1; // Get the requested page number from the request.
            $query->where('type', '!=','note');
            if (!empty($searchTerm)) { //filter in notes title and desc.
                $query->where(function ($q) use ($searchTerm) {
                    $q->where('title', 'like', '%' . $searchTerm . '%')->orWhere('description', 'like', '%' . $searchTerm . '%');
                });
            }
            $query = $query->orderBy('created_at','desc');
            $reportsCount =$query->count();
            $totalPage = $reportsCount/$perPage;
            $notes = $query->paginate($perPage, ['*'], 'page', $page); //get notes list by logged in user
            
            $users = User::pluck('full_name','userid')->toArray();
         
            foreach ($notes as $key => $note) {
                $notes[$key]['user_name'] =  $users[$note->user_id] ?? "";
                $notes[$key]['file'] = $note->file != "" ? $note->file : "";
                $notes[$key]['thumbnail'] = $appUrl.'thumbnail_old.png';
            }

            $newRoot =[
                'reports' => $notes,
                'report_count' => $reportsCount,
                'total_page' => ceil($totalPage)
            ];
            return ApiResponse::success($newRoot,'Here is Report list.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin user can view coach reviews
    */
    public function getCoachReview($swing_id)
    {   
        $appUrl = env('AWS_S3_PATH');
        $coachReviewPath = env('AWS_COACH_REVIEW_PATH');
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $swing = Swing::find($swing_id);
                if(!$swing){
                    return ApiResponse::error('Unable to fetch swing video details!');
                }
                $coachReviewsData = [];
                $coachReviews = AdminCoachReview::where('swing_id',$swing_id)->get();
                foreach ($coachReviews as $key => $coachReview) {
                    $coach = User::find( $coachReview["coach_id"]);
                    $coachReviewsData[$key]['id'] =  $coachReview["_id"];
                    $coachReviewsData[$key]['swing_id'] =  $coachReview["swing_id"];
                    $coachReviewsData[$key]['title'] =  $coachReview["title"] ?? "Feedback name";
                    $coachReviewsData[$key]['status'] =  $coachReview['status'] ?? "";
                    $coachReviewsData[$key]['comment'] = $coachReview["comment"] ?? "";
                    $coachReviewsData[$key]['rating'] = $coachReview["rating"] ?? 0;
                    $coachReviewsData[$key]['user_id'] =  $user["_id"];
                    $coachReviewsData[$key]['user_name'] =   User::find( $user["_id"])->full_name ?? "";
                    $coachReviewsData[$key]['coach_id'] =  $coachReview["coach_id"];
                    $coachReviewsData[$key]['coach_name'] = $coach->full_name ?? "" ;
                    $coachReviewsData[$key]['file'] =  $coachReview["file"] != "" ? $appUrl.''.$coachReviewPath.''.$coachReview["file"] :"";
                    $coachReviewsData[$key]['created_at'] =  $coachReview["created_at"];
                    $coachReviewsData[$key]['last_update'] =  $coachReview["updated_at"];
                }
                return ApiResponse::success($coachReviewsData,'Coach reviews list found.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getCoachReviewDetail($id)
    {   
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                $admin_coach_review = AdminCoachReview::find($id);
                if(!$admin_coach_review){
                    return ApiResponse::error('Unable to fetch coach review details!');
                }else{
                    $swing = Swing::find($admin_coach_review->swing_id);
                    if(!$swing){
                        return ApiResponse::error('Unable to fetch swing video details!');
                    }
                    $coach = User::find( $admin_coach_review->coach_id);
                    $coachReviewsData['id'] =  $admin_coach_review->id;
                    $coachReviewsData['swing_id'] =  $admin_coach_review->swing_id;
                    $coachReviewsData['description'] =  $admin_coach_review->description ?? "";
                    $coachReviewsData['drills'] =  $admin_coach_review->drills ?? [];
                    $coachReviewsData['coach_id'] =  $admin_coach_review->coach_id;
                    $coachReviewsData['coach_name'] = $coach->full_name ?? "" ;
                    $coachReviewsData['vimeo_link'] =  $admin_coach_review->vimeo_link ?? "";
                    $coachReviewsData['created_at'] =  $admin_coach_review->created_at;
                    $coachReviewsData['last_update'] =  $admin_coach_review->updated_at;
                    return ApiResponse::success($coachReviewsData,'Coach reviews detail found.');
                }
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage coach reviews crud and below function can manage list of coach reviews
    */
    public function getCoachReviewList(Request $request)
    {   
        $appUrl = env('AWS_S3_PATH');
        $coachReviewPath = env('AWS_COACH_REVIEW_PATH');
        try {
            // Get token from header and authenticate user
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user){
                // $swingIds = Swing::where('user_id',$user["_id"])->pluck('_id')->toArray();
                $coachReviewsData = [];
                if($user->user_type == "coach"){
                    $coachReviews = AdminCoachReview::where('coach_id',$user["_id"])->get();
                }else{
                    $coachReviews = AdminCoachReview::all();
                }
                if($coachReviews->count() > 0){
                    $userData = User::get();
                    foreach ($coachReviews as $key => $coachReview) {
                        $coach = $userData->firstWhere('_id', $coachReview["coach_id"]);
                        $user_details = $userData->firstWhere('_id', $user["_id"]);
                        $coachReviewsData[$key]['id'] =  $coachReview["_id"];
                        $coachReviewsData[$key]['swing_id'] =  $coachReview["swing_id"];
                        $coachReviewsData[$key]['title'] =  $coachReview["title"] ?? "Feedback name";
                        $coachReviewsData[$key]['status'] =  $coachReview['status'] ?? "";
                        $coachReviewsData[$key]['comment'] = $coachReview["comment"] ?? "";
                        $coachReviewsData[$key]['rating'] = $coachReview["rating"] ?? 0;
                        $coachReviewsData[$key]['user_id'] =  $user["_id"];
                        $coachReviewsData[$key]['user_name'] =  $user_details->full_name ?? "";
                        $coachReviewsData[$key]['coach_id'] =  $coachReview["coach_id"];
                        $coachReviewsData[$key]['coach_name'] = $coach->full_name ?? "" ;
                        $coachReviewsData[$key]['file'] =  $coachReview["file"] != "" ? $appUrl.''.$coachReviewPath.''.$coachReview["file"] :"";
                        $coachReviewsData[$key]['created_at'] =  $coachReview["created_at"];
                        $coachReviewsData[$key]['last_update'] =  $coachReview["updated_at"];
                    }
                }
                //applied sorting
                $sortedData = Functions::sortArray($coachReviewsData,$sortColumn);
                //applied filter
                $filteredResponse = Functions::filterArrayByFieldArray($sortedData, $filteredVal, $filterColumn);
                return ApiResponse::success($filteredResponse,'Coach reviews list found.');
            }else{
                return ApiResponse::error('User not found');
            }
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    public function getSwingOld(Request $request)
    {   
        $appUrl = env('AWS_S3_PATH');
        $swingPath = env('AWS_SWING_PATH');
        $repvideoPath = env('AWS_REP_VIDEO_PATH');
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $sortColumn = $request['sort'] ?? "";
            $filterColumn = $request['filterBy'] ?? "";
            $filteredVal = $request['filteredVal'] ?? "";
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user->user_type == "coach"){
                $swings = Swing::where('submit_to_coach', true)
                ->orderBy('created_at', 'desc')
                ->get();
                $swings2 = RepReview::where('submit_to_coach', true)
                ->orderBy('created_at', 'desc')
                ->get();

                $user_ids = $swings->pluck('user_id')->unique();
                $users = User::whereIn('_id', $user_ids)->get()->keyBy('_id');

                // Filter swings to only include those with existing users
                $validSwings = $swings->filter(function ($swing) use ($users) {
                    return $users->has($swing->user_id);
                });
               
                $validSwings2 = $swings2->filter(function ($swing2) use ($users) {
                    return $users->has($swing2->user_id);
                });

                if($validSwings->count() > 0){
                    $mergedSwings = $validSwings->merge($validSwings2);
                }else{
                    $mergedSwings = $validSwings2;
                }
                $swing_ids = $mergedSwings->pluck('_id')->unique();
                $swing_ids2 = $validSwings2->pluck('_id')->unique()->toArray();
                
                $coach_reviews = AdminCoachReview::whereIn('swing_id', $swing_ids)->get()->keyBy('swing_id');
               
                $coach_ids = $coach_reviews->pluck('coach_id')->unique();
                $coaches = User::whereIn('_id', $coach_ids)->get()->keyBy('_id');

                foreach ($mergedSwings as $key => $swing) {
                    $user = $users->get($swing->user_id);
                    $coach_review = $coach_reviews->get($swing->_id);
                   
                    if (in_array($swing->_id, $swing_ids2)) {
                        $swing->status = $swing->review_status ?? "Pending";
                        $swing->type = "Rep Review";
                    }else{
                        $swing->status = $swing->status ?? "Pending";
                        $swing->type = "Coach Review";
                    }
                    if ($coach_review) {
                        $coach = $coaches->get($coach_review->coach_id);
                        $swing->coach_name = $coach->full_name ?? '';
                        $swing->coach_review_id = $coach_review->_id ?? '';
                        $swing->coach_review = [
                            'id' => $coach_review->_id,
                            'vimeo_link' => $coach_review->vimeo_link,
                            'thumbnail' =>   $coach_review->thumbnail  ?? "",
                            'description' => $coach_review->description ?? "",
                            'drills' => $coach_review->drills ?? [],
                            'status' => $coach_review->status
                        ];
                    } else {
                        $swing->coach_name = '';
                        $swing->coach_review_id = '';
                        $swing->coach_review = [];
                    }

                    if($swing->status == "Completed"){
                        $swing->remaining_hours =0;
                    } else{
                        // Parse the created_at and updated_at dates
                        $created_date = Carbon::parse($swing->created_at);
                        $current_date = Carbon::parse($swing->updated_at);
                        $now = Carbon::now();

                        // Calculate the difference in hours
                        $diff_in_hours = $now->diffInHours($current_date);

                        $remaining_hours = 48 - $diff_in_hours;

                        // Check if the difference is 48 hours or more
                        if ($diff_in_hours >= 48) {
                            $time_difference = 0;
                        } else {
                            $time_difference = $remaining_hours;
                        }

                        $swing->remaining_hours = $time_difference;
                    }
                    
                   
                    $swing->user_name = $user->full_name ?? '';
                    
                    $swing->rep_video = !empty($swing->rep_video) ? $appUrl . $repvideoPath . $swing->rep_video : '';
                    $swing->file_size =   $swing->file_size ?? "";
                    $swing->duration = $swing->duration ?? "";
                    $swing->down_the_line_filesize = $swing->down_the_line_filesize ?? "";
                    $swing->face_on_filesize = $swing->face_on_filesize ?? "";
                    $swing->down_the_line = !empty($swing->down_the_line) ? $appUrl . $swingPath . $swing->down_the_line : '';
                    $swing->face_on = !empty($swing->face_on) ? $appUrl . $swingPath . $swing->face_on : '';
                    
                }

                $sortedData = Functions::sortArray($mergedSwings, $sortColumn);
                $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['title', 'user_name', 'remaining_hours', 'status']);

                $total_swing = !empty($filteredResponse) ? count($filteredResponse) : 0;
                $totalPage = !empty($request->per_page) ? ceil($total_swing / $request->per_page) : 1;

                if (!empty($request->per_page) && !empty($request->page)) {
                    $perPage = $request->per_page ?? 10;
                    $page = $request->page ?? 1;
                    $currentPage = $page - 1;
                    if (is_array($filteredResponse)) {
                        $filteredResponse = collect($filteredResponse);
                    }
                    $pagedData = $filteredResponse->slice($currentPage * $perPage, $perPage)->all();
                    $filteredResponse = array_values($pagedData);
                }

                $newRoot = [
                    "swings_count" => $total_swing,
                    "swings" => $filteredResponse,
                    "total_page" => $totalPage ?? 1
                ];

                return ApiResponse::success($newRoot, 'Swing list found.');
              
            }else{
                    $swings = Swing::where('submit_to_coach',true)->orderBy('created_at','desc')->get();
                    $swings2 = RepReview::where('submit_to_coach', true)
                                ->orderBy('created_at', 'desc')
                                ->get();

                    $user_ids = $swings->pluck('user_id')->unique();
                    $users = User::whereIn('_id', $user_ids)->get()->keyBy('_id');

                    // Filter swings to only include those with existing users
                    $validSwings = $swings->filter(function ($swing) use ($users) {
                        return $users->has($swing->user_id);
                    });
                    $validSwings2 = $swings2->filter(function ($swing2) use ($users) {
                        return $users->has($swing2->user_id);
                    });
                    // Get swing IDs of valid swings
                    if($validSwings->count() > 0){
                        $mergedSwings = $validSwings->merge($validSwings2);
                    }else{
                        $mergedSwings = $validSwings2;
                    }
              
                    $swing_ids = $mergedSwings->pluck('_id')->unique();
                    $swing_ids2 = $validSwings2->pluck('_id')->unique()->toArray();
                    $coach_reviews = AdminCoachReview::whereIn('swing_id', $swing_ids)->get()->keyBy('swing_id');

                    $coach_ids = $coach_reviews->pluck('coach_id')->unique();
                    $coaches = User::whereIn('_id', $coach_ids)->get()->keyBy('_id');

                    foreach ($mergedSwings as $key => $swing) {
                        $user = $users->get($swing->user_id);
                        $coach_review = $coach_reviews->get($swing->_id);

                        //$swing->status = $swing->status ?? "Pending";
                        if (in_array($swing->_id, $swing_ids2)) {
                            $swing->status = $swing->review_status ?? "Pending";
                            $swing->type = "Rep Review";
                        }else{
                            $swing->status = $swing->status ?? "Pending";
                            $swing->type = "Coach Review";
                        }

                        if ($coach_review) {
                            $coach = $coaches->get($coach_review->coach_id);
                            $swing->coach_name = $coach->full_name ?? '';
                            $swing->coach_review_id = $coach_review->_id ?? '';
                            $swing->coach_review = [
                                'id' => $coach_review->_id,
                                'vimeo_link' => $coach_review->vimeo_link,
                                'description' => $coach_review->description ?? "",
                                'drills' => $coach_review->drills ?? [],
                                'status' => $coach_review->status
                            ];
                        } else {
                            $swing->coach_name = '';
                            $swing->coach_review_id = '';
                            $swing->coach_review = [];
                        }
                        
                        
                        if($swing->status == "Completed"){
                            $swing->remaining_hours =0;
                        } else
                        {
                            // Parse the created_at and updated_at dates
                            $created_date = Carbon::parse($swing->created_at);
                            $current_date = Carbon::parse($swing->updated_at);
                            $now = Carbon::now();

                            // Calculate the difference in hours
                            $diff_in_hours = $now->diffInHours($current_date);

                            $remaining_hours = 48 - $diff_in_hours;

                            // Check if the difference is 48 hours or more
                            if ($diff_in_hours >= 48) {
                                $time_difference = 0;
                            } else {
                                $time_difference = $remaining_hours;
                            }
                            $swing->remaining_hours = $time_difference;
                        }
                        $swing->user_name = $user->full_name ?? '';
                        $swing->rep_video = !empty($swing->rep_video) ? $appUrl . $repvideoPath . $swing->rep_video : '';
                        $swing->file_size =   $swing->file_size ?? "";
                        $swing->duration = $swing->duration ?? "";
                        $swing->down_the_line_filesize = $swing->down_the_line_filesize ?? "";
                        $swing->face_on_filesize = $swing->face_on_filesize ?? "";
                        $swing->down_the_line = !empty($swing->down_the_line) ? $appUrl . $swingPath . $swing->down_the_line : '';
                        $swing->face_on = !empty($swing->face_on) ? $appUrl . $swingPath . $swing->face_on : '';
                    }
                   
                    $sortedData = Functions::sortArray($mergedSwings,$sortColumn);
                    $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['title', 'user_name', 'remaining_hours','status']);
                    $total_swing = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
                    $totalPage = !empty($request->per_page ) ? $total_swing / $request->per_page : 1;
                 
                    if(!empty( $request->per_page) && !empty( $request->page)){
                        $perPage = $request->per_page ?? 10;
                        $page = $request->page ?? 1;
                        $currentPage  = $page - 1;
                        if (is_array($filteredResponse)) {
                            $filteredResponse = collect($filteredResponse);
                        }
                        $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                    
                        $filteredResponse = array_values($pagedData);
                    }
                
                    $newRoot = [
                        "swings_count" => $total_swing,
                        "swings" => $filteredResponse,
                        "total_page"=> ceil($totalPage) ?? 1
                    ];
                    return ApiResponse::success($newRoot,'swing list found.');
             
            }
            
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    public function getSwing(Request $request)
    {   
        $appUrl = env('AWS_S3_PATH');
        $swingPath = env('AWS_SWING_PATH');
        $repvideoPath = env('AWS_REP_VIDEO_PATH');
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            $sortColumn = $request['sort'] ?? "";
            $filterColumn = $request['filterBy'] ?? "";
            $filteredVal = $request['filteredVal'] ?? "";
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            if($user->user_type == "coach"){
                $swings = Swing::where('submit_to_coach',true)->orderBy('created_at','desc')->get();
                
                $swings2 = RepReview::where('submit_to_coach', true)
                            ->orderBy('created_at', 'desc')
                            ->get();
            
                
                if($swings->count() > 0){
                    $validSwings = $swings->merge($swings2);
                }else{
                    $validSwings = $swings2;
                }
                $user_ids = $validSwings ->pluck('user_id')->unique();
                $users = User::whereIn('_id', $user_ids)->get()->keyBy('_id');
                $swing_ids = $validSwings->pluck('_id')->unique();
                $swing_ids2 = $swings2->pluck('_id')->unique()->toArray();
                
                $coach_reviews = AdminCoachReview::whereIn('swing_id', $swing_ids)->get()->keyBy('swing_id');
               
                $coach_ids = $coach_reviews->pluck('coach_id')->unique();
                $coaches = User::whereIn('_id', $coach_ids)->get()->keyBy('_id');
                
                foreach ($validSwings as $key => $swing) {
                    $user = $users->get($swing->user_id);
                    $coach_review = $coach_reviews->get($swing->_id);
                   
                    if (in_array($swing->_id, $swing_ids2)) {
                        $swing->status = $swing->review_status ?? "Pending";
                        $swing->type = "Rep Review";
                    }else{
                        $swing->status = $swing->status ?? "Pending";
                        $swing->type = "Coach Review";
                    }
                    if ($coach_review) {
                        $coach = $coaches->get($coach_review->coach_id);
                        $swing->coach_name = $coach->full_name ?? '';
                        $swing->coach_review_id = $coach_review->_id ?? '';
                        $swing->coach_review = [
                            'id' => $coach_review->_id,
                            'vimeo_link' => $coach_review->vimeo_link,
                            'thumbnail' =>   $coach_review->thumbnail  ?? "",
                            'description' => $coach_review->description ?? "",
                            'drills' => $coach_review->drills ?? [],
                            'status' => $coach_review->status
                        ];
                    } else {
                        $swing->coach_name = '';
                        $swing->coach_review_id = '';
                        $swing->coach_review = [];
                    }

                    if($swing->status == "Completed"){
                        $swing->remaining_hours =0;
                    } else{
                        // Parse the created_at and updated_at dates
                        $created_date = Carbon::parse($swing->created_at);
                        $current_date = Carbon::parse($swing->updated_at);
                        $now = Carbon::now();

                        // Calculate the difference in hours
                        $diff_in_hours = $now->diffInHours($current_date);

                        $remaining_hours = 48 - $diff_in_hours;

                        // Check if the difference is 48 hours or more
                        if ($diff_in_hours >= 48) {
                            $time_difference = 0;
                        } else {
                            $time_difference = $remaining_hours;
                        }

                        $swing->remaining_hours = $time_difference;
                    }
                    
                   
                    $swing->user_name = $user->full_name ?? '';
                    
                    $swing->rep_video = !empty($swing->rep_video) ? $appUrl . $repvideoPath . $swing->rep_video : '';
                    $swing->file_size =   $swing->file_size ?? "";
                    $swing->duration = $swing->duration ?? "";
                    $swing->down_the_line_filesize = $swing->down_the_line_filesize ?? "";
                    $swing->face_on_filesize = $swing->face_on_filesize ?? "";
                    $swing->down_the_line = !empty($swing->down_the_line) ? $appUrl . $swingPath . $swing->down_the_line : '';
                    $swing->face_on = !empty($swing->face_on) ? $appUrl . $swingPath . $swing->face_on : '';
                    
                }

                $sortedData = Functions::sortArray($validSwings, $sortColumn);
                $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['title', 'user_name', 'remaining_hours', 'status']);

                $total_swing = !empty($filteredResponse) ? count($filteredResponse) : 0;
                $totalPage = !empty($request->per_page) ? ceil($total_swing / $request->per_page) : 1;

                if (!empty($request->per_page) && !empty($request->page)) {
                    $perPage = $request->per_page ?? 10;
                    $page = $request->page ?? 1;
                    $currentPage = $page - 1;
                    if (is_array($filteredResponse)) {
                        $filteredResponse = collect($filteredResponse);
                    }
                    $pagedData = $filteredResponse->slice($currentPage * $perPage, $perPage)->all();
                    $filteredResponse = array_values($pagedData);
                }

                $newRoot = [
                    "swings_count" => $total_swing,
                    "swings" => $filteredResponse,
                    "total_page" => $totalPage ?? 1
                ];

                return ApiResponse::success($newRoot, 'Swing list found.');
              
            }else{
                    $swings = Swing::where('submit_to_coach',true)->orderBy('created_at','desc')->get();
                
                    $swings2 = RepReview::where('submit_to_coach', true)
                                ->orderBy('created_at', 'desc')
                                ->get();
                
                   
                    if($swings->count() > 0){
                        $validSwings = $swings->merge($swings2);
                    }else{
                        $validSwings = $swings2;
                    }
                    $user_ids = $validSwings ->pluck('user_id')->unique();
                    $users = User::whereIn('_id', $user_ids)->get()->keyBy('_id');
                    // Filter swings to only include those with existing users
                    // $mergedSwings = $validSwings->filter(function ($swing) use ($users) {
                    //     return $users->has($swing->user_id);
                    // });
              
                    $swing_ids = $validSwings->pluck('_id')->unique();
                    $swing_ids2 = $swings2->pluck('_id')->unique()->toArray();
                    $coach_reviews = AdminCoachReview::whereIn('swing_id', $swing_ids)->get()->keyBy('swing_id');

                    $coach_ids = $coach_reviews->pluck('coach_id')->unique();
                    $coaches = User::whereIn('_id', $coach_ids)->get()->keyBy('_id');
                 
                    foreach ($validSwings as $key => $swing) {
                        $user = $users->get($swing->user_id);
                        $coach_review = $coach_reviews->get($swing->_id);

                        //$swing->status = $swing->status ?? "Pending";
                        if (in_array($swing->_id, $swing_ids2)) {
                            $swing->status = $swing->review_status ?? "Pending";
                            $swing->type = "Rep Review";
                        }else{
                            $swing->status = $swing->status ?? "Pending";
                            $swing->type = "Coach Review";
                        }

                        if ($coach_review) {
                            $coach = $coaches->get($coach_review->coach_id);
                            $swing->coach_name = $coach->full_name ?? '';
                            $swing->coach_review_id = $coach_review->_id ?? '';
                            $swing->coach_review = [
                                'id' => $coach_review->_id,
                                'vimeo_link' => $coach_review->vimeo_link,
                                'description' => $coach_review->description ?? "",
                                'drills' => $coach_review->drills ?? [],
                                'status' => $coach_review->status
                            ];
                        } else {
                            $swing->coach_name = '';
                            $swing->coach_review_id = '';
                            $swing->coach_review = [];
                        }
                        if($swing->status == "Completed"){
                            $swing->remaining_hours =0;
                        } else
                        {
                            // Parse the created_at and updated_at dates
                            $created_date = Carbon::parse($swing->created_at);
                            $current_date = Carbon::parse($swing->updated_at);
                            $now = Carbon::now();

                            // Calculate the difference in hours
                            $diff_in_hours = $now->diffInHours($current_date);

                            $remaining_hours = 48 - $diff_in_hours;

                            // Check if the difference is 48 hours or more
                            if ($diff_in_hours >= 48) {
                                $time_difference = 0;
                            } else {
                                $time_difference = $remaining_hours;
                            }
                            $swing->remaining_hours = $time_difference;
                        }
                        $swing->user_name = $user->full_name ?? '';
                        $swing->rep_video = !empty($swing->rep_video) ? $appUrl . $repvideoPath . $swing->rep_video : '';
                        $swing->file_size =   $swing->file_size ?? "";
                        $swing->duration = $swing->duration ?? "";
                        $swing->down_the_line_filesize = $swing->down_the_line_filesize ?? "";
                        $swing->face_on_filesize = $swing->face_on_filesize ?? "";
                        $swing->down_the_line = !empty($swing->down_the_line) ? $appUrl . $swingPath . $swing->down_the_line : '';
                        $swing->face_on = !empty($swing->face_on) ? $appUrl . $swingPath . $swing->face_on : '';
                    }
                   
                    $sortedData = Functions::sortArray($validSwings,$sortColumn);
                    $filteredResponse = Functions::filterArrayByFieldArrayMultiPle($sortedData, $filteredVal, ['title', 'user_name', 'remaining_hours','status']);
                    $total_swing = !empty($filteredResponse) ? sizeof($filteredResponse): 0;
                    $totalPage = !empty($request->per_page ) ? $total_swing / $request->per_page : 1;
                 
                    if(!empty( $request->per_page) && !empty( $request->page)){
                        $perPage = $request->per_page ?? 10;
                        $page = $request->page ?? 1;
                        $currentPage  = $page - 1;
                        if (is_array($filteredResponse)) {
                            $filteredResponse = collect($filteredResponse);
                        }
                        $pagedData = $filteredResponse->slice($currentPage  * $perPage, $perPage)->all();
                    
                        $filteredResponse = array_values($pagedData);
                    }
                
                    $newRoot = [
                        "swings_count" => $total_swing,
                        "swings" => $filteredResponse,
                        "total_page"=> ceil($totalPage) ?? 1
                    ];
                    return ApiResponse::success($newRoot,'swing list found.');
             
            }
            
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updatePaymentSetting($free_app){
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $freeAppSetting = PaymentSetting::first();
            if($freeAppSetting){
            }else{
                $freeAppSetting = new PaymentSetting();
            }
            $freeAppSetting->free_app = $free_app == "true" && $free_app == true ? true : false;
            $freeAppSetting->admin_id = $user->userid;
            $freeAppSetting->save();
            return ApiResponse::success($freeAppSetting,'Free App Setting updated successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function updateFlowSetting($new_flow){
        try {
            $token = $this->getTokenFromHeader();
            $user = \JWTAuth::setToken($token)->authenticate();
            if(!$user) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $flowSetting = FlowSetting::first();
            if($flowSetting){
            }else{
                $flowSetting = new FlowSetting();
            }
            $flowSetting->new_flow = $new_flow == "true" && $new_flow == true ? true : false;
            $flowSetting->admin_id = $user->userid;
            $flowSetting->save();
            return ApiResponse::success($flowSetting,'Flow Setting updated successfully.');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function dashboard(){
        try {
            $swings = Swing::where('submit_to_coach',true)->get();
            $reviewed_swings =  Swing::where('submit_to_coach',true)->where('status','Completed')->get();
            
            $newRoot = [
                'total_swing' => 0,
                'in_progress_swing' => 0,
                'reviewed_swing' => 0,
                'pending_swing' => 0,
                'avg_response_time' => $avg_response_time ?? ""
            ];
            $total_response_time = 0;
            $avg_response_time = "";
            $count = 0;
            foreach ($reviewed_swings as $key => $swing) {
                $swing_submitted_at = $swing->submit_to_coach_at ?? $swing->created_at;
                $coach_review = AdminCoachReview::where('swing_id',$swing->_id)->where('status','Completed')->first();
                $coach_review_at = $coach_review->created_at;
                if ($coach_review) {
                    $coach_review_at = $coach_review->created_at;
                    $response_time = $coach_review_at->diffInSeconds($swing_submitted_at);
                    $total_response_time += $response_time;
                    $count++;
                }
            }
            if ($count > 0) {
                $avg_response_time_seconds = $total_response_time / $count;
                $hours = floor($avg_response_time_seconds / 3600);
                $minutes = floor(($avg_response_time_seconds % 3600) / 60);
                $avg_response_time = '';
                if ($hours > 0) {
                    $avg_response_time .= $hours."h";
                    // if ($hours > 1) {
                    //     $avg_response_time .= 's';
                    // }
                    $avg_response_time .= ' ';
                }
                if ($minutes > 0) {
                    $avg_response_time .= $minutes."min";
                    // if ($minutes > 1) {
                    //     $avg_response_time .= 's';
                    // }
                }
            }
            $newRoot['avg_response_time'] = $avg_response_time ?? "";
            $newRoot['total_swing'] = $swings->count();
            $newRoot['reviewed_swing'] = $swings->where('status','Completed')->count();
            $newRoot['pending_swing'] = $swings->where('status','Pending')->count();
            $newRoot['in_progress_swing'] =  $newRoot['total_swing'] - ( $newRoot['reviewed_swing'] +  $newRoot['pending_swing']);
           
            return ApiResponse::success($newRoot,'dashboard detail is here!');
        }catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Unit crud and below finction can manage delete unit
    */
    public function deleteUnit($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Unit id required!!');
            }
            $tags = Unit::find($id);
            if($tags){
                $tags->delete();
                return ApiResponse::successOnly('Unit deleted successfully.');
            }else{
                return ApiResponse::error('Unit not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Admin panel can manage Group crud and below function can manage delete Group
    */
    public function deleteGroup($id)
    {
        try{
            if(!$id){
                return ApiResponse::error('Group id required!!');
            }
            $tags = Group::find($id);
            if($tags){
                $tags->delete();
                return ApiResponse::successOnly('Group deleted successfully.');
            }else{
                return ApiResponse::error('Group not found!!');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: UserDashboard api
    */
    public function getUserDashboardData()
    {
        try {
            $withinthreeDayLoginCount = 0;
            $fourtosevenDayLoginCount = 0;
            $morethansevenDayLoginCount = 0;
            $threeDaysAgo = Carbon::now()->subDays(3);
            $sevenDaysAgo = Carbon::now()->subDays(7);
            $fourDaysAgo = Carbon::now()->subDays(4); 

            //activity status
            $users = User::where('user_type','user')->where('last_login_at','!=',NULL)->where('last_login_at','!=',"")->get();
            if($users->count() > 0){
                foreach ($users as $user) {
                    $lastLogin = Carbon::parse($user->last_login_at);
                    if($lastLogin->greaterThanOrEqualTo($threeDaysAgo)){
                        $withinthreeDayLoginCount = $withinthreeDayLoginCount + 1;
                    } else if ($lastLogin->between($sevenDaysAgo, $fourDaysAgo, true)) {
                        $fourtosevenDayLoginCount = $fourtosevenDayLoginCount + 1;
                    } else if ($lastLogin->lessThan($sevenDaysAgo)) {
                        $morethansevenDayLoginCount = $morethansevenDayLoginCount + 1;
                    }else{
                        $fourtosevenDayLoginCount = $fourtosevenDayLoginCount + 1;
                    }
                }
            }
            $loginStatus = [
                'withinthreeDayLoginCount' => $withinthreeDayLoginCount,
                'fourtosevenDayLoginCount' => $fourtosevenDayLoginCount,
                'morethansevenDayLoginCount' => $morethansevenDayLoginCount
            ];

            //rating status
            $weeklyRatingCount = UserWeeklySurvey::where('rating','<',3)->groupBy('user_id')->pluck('user_id')->count();
            $sessionRatingCount = 0;
            $scc_rating_count = UserSelfCheckCheckObject::where('answer_2',"I’m struggling to understand it and do it")->groupBy('user_id')->pluck('user_id')->count();
            $ratingStatus = [
                'weekly_rating_count' => $weeklyRatingCount ?? 0, 
                'session_rating_count' => $sessionRatingCount ?? 0,
                'scc_rating_count' => $scc_rating_count ?? 0
            ];

            $userCount = User::where('user_type','user')->where('is_confirm',1)->count();
            $plans = Plan::pluck('_id','name')->toArray();
         
            $userIds = User::where('user_type','user')->where('is_confirm',1)->pluck("_id")->toArray();
            $basic_plan_count = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Basic"])->where('status','active')->where('payment_status','Paid')->count();
            $premium_plan_count = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Premium"])->where('status','active')->where('payment_status','Paid')->count();
            $pro_plan_count = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Ultra"])->where('status','active')->where('payment_status','Paid')->count();
            $free_plan_count = UserBillingHistory::whereIn('user_id',$userIds)->where('plan_id',$plans["Free 7-Day Trial"])->where('status','active')->where('payment_status','Paid')->count();
            $subscriptionStatus = [
                'free_plan_count' => $free_plan_count ?? 0, 
                'basic_plan_count' => $basic_plan_count ?? 0,
                'premium_plan_count' => $premium_plan_count ?? 0,
                'pro_plan_count' => $pro_plan_count ?? 0
            ];
            $new_flow = false;
            $flowSetting = FlowSetting::first();
            $new_flow = $flowSetting->new_flow ?? false;
           

            $data = [
                'login_at' => $loginStatus,
                'rating' => $ratingStatus,
                'subscription' => $subscriptionStatus,
                'new_flow' => $new_flow ?? false
            ];
            $freeAppSetting = PaymentSetting::first();
            $data['free_app'] = $freeAppSetting->free_app ?? false;
            return ApiResponse::success($data,'User Activity/Rating Status');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    
    /**
    * Developer: Apptodate 
    * Comment: Rating list api for user dashoboard
    */
    public function getUserRatingList(Request $request){
        try{
            $token = $this->getTokenFromHeader();
            $loginuser = \JWTAuth::setToken($token)->authenticate();
            if(!$loginuser) {
                return ApiResponse::error('Getting trouble to fetch logged in user information');
            }else{
                $validatedData = $request->validate([
                    'user_id' => 'required|string'
                ]);
                $user = User::find($validatedData['user_id']);
                if(!$user) {
                    return ApiResponse::error('User not found!');
                }
                $type = $request->type ?? "all";
                $filteredVal = $request->filteredVal ?? ""; 
                $sortColumn = $request->sortBy ?? "-date";
                $rating = [];
                $totalPages = 1;
                $totalRatings = 0;
                if($type == "all" || $type == "weekly_rating"){
                    $weeklyRatings = UserWeeklySurvey::where('user_id',$user["_id"])->get();
                    $weeklyRatings = UserWeeklySurvey::where('user_id',$user["_id"])->get();
                    foreach ($weeklyRatings as $key => $weeklyRating) {
                        $rating[$key]['type'] = "Weekly Rating";
                        $rating[$key]['date'] = Carbon::parse($weeklyRating->created_at)->format('Y-m-d H:i a');
                        $rating[$key]['rating'] = $weeklyRating->rating;
                        $rating[$key]['text'] = $weeklyRating->text ?? "";
                    }
                }
                $maxKey = !empty($rating) ? max(array_keys($rating)) : 0;
                if($type == "all" || $type == "scc_rating"){
                    $sccRatings = UserSelfCheckCheckObject::where('user_id',$user["_id"])->get();
                    foreach ($sccRatings as $key => $sccRating) {
                        $keyy = $maxKey + $key + 1;
                        $rating[$keyy]['type'] = "Self Check Audit";
                        $rating[$keyy]['date'] = Carbon::parse($sccRating->created_at)->format('Y-m-d H:i a');
                        $rating[$keyy]['rating'] = $sccRating->answer_2;
                        $rating[$keyy]['text'] = $sccRating->answer_3;
                    }
                }
                $maxKeyObj = !empty($rating) ? max(array_keys($rating)) : 0;
                if($type == "all" || $type == "session_rating"){
                    $session_ratings = UserSelfReportObject::where('user_id',$user["_id"])->get();
                    foreach ($session_ratings as $key => $session_rating) {
                        $keyz = $maxKeyObj + $key + 1;
                        $rating[$keyz]['type'] = "Train Session Rating";
                        $rating[$keyz]['date'] = Carbon::parse($session_rating->created_at)->format('Y-m-d H:i a');
                        $rating[$keyz]['rating'] = $session_rating->rating;
                        $rating[$keyz]['text'] = $session_rating->text;
                    }
                }

                if($rating != []){
                    
                    $rating = Functions::sortArray($rating,$sortColumn);
                    $filteredRatings = collect($rating);
                    if (!empty($filteredVal)) {
                        $filteredRatings = $filteredRatings->filter(function ($item) use ($filteredVal) {
                            // Check if the filter value is present in any field of the rating object
                            foreach ($item as $field => $value) {
                                if (strpos($value, $filteredVal) !== false) {
                                    return true;
                                }
                            }
                            return false;
                        });
                    }
                    
                    // Paginate the results, assuming 10 items per page
                    $perPage = $request->per_page ?? 10;
                    $page = request('page', 1);
                    $totalRatings = $filteredRatings->count();
                    $totalPages = ceil($totalRatings / $perPage);
                    $paginatedRatings = $filteredRatings->slice(($page - 1) * $perPage, $perPage)->values();
                }
                
                $newRoot = [
                    'ratings' => $paginatedRatings ?? [],
                    'total_page' => $totalPages,
                    'total_rating' => $totalRatings,
                    'current_page' => $page ?? 1
                ];
                return ApiResponse::success($newRoot,'Rating List!');  
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    /**
    * Developer: Apptodate 
    * Comment: Activity list api for user dashoboard
    */
    public function getUserActivityList(Request $request){
        try{
            $token = $this->getTokenFromHeader();
            $loginuser = \JWTAuth::setToken($token)->authenticate();
            if(!$loginuser) {
                return ApiResponse::error('Getting trouble to fetch logged in user information');
            }else{
                $validatedData = $request->validate([
                    'user_id' => 'required|string'
                ]);
                $user = User::find($validatedData['user_id']);
                if(!$user) {
                    return ApiResponse::error('User not found!');
                }
                $type = $request->type ?? "";
                $filteredVal = $request->filteredVal ?? ""; 
                $sortColumn = $request->sortBy ?? "date";
                $data = [];
                $totalPages = $totalRecords = 0;
                if($type == "Trust"){
                    $trustHoles = UserTrustHole::where('user_id',$user->userid)->where('trust_key_percent','>=',0)->where('pre_shot_percent','>=',0)->where('post_shot_percent','>=',0)->get();
                    if(!empty($trustHoles)){
                        foreach ($trustHoles as $key => $trustHole) {
                            $data[$key]['category_type'] = 'Trust';
                            $data[$key]['trust_key_percent'] =  $trustHole->trust_key_percent;
                            $data[$key]['pre_shot_percent'] = $trustHole->pre_shot_percent;
                            $data[$key]['post_shot_percent'] = $trustHole->post_shot_percent;
                            $data[$key]['date'] = Carbon::parse($trustHole->created_at)->format('Y-m-d H:i a');
                        }
                    }
                } else if($type == "Apply" || $type == "Train"){
                    $categoryType = CategoryType::where('name', 'LIKE', $type)->first();
                    $defaultProgram = env('DEFAULT_PROGRAM');
                    $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                    $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
                  
                    if(!empty($user->group_id)){
                        $group = Group::find($user->group_id);
                        if($group){
                            $unitIds = array_column($group["group_object"], "object_id");
                            $units = Unit::where('category_type_id', $categoryType["_id"])->whereIn('_id', $unitIds )->get();
                        }else{
                            $units = Unit::where('category_type_id', $categoryType["_id"])->whereIn('_id', $default_unitIds )->get();
                        }
                    }else{
                        $units = Unit::where('category_type_id', $categoryType["_id"])->whereIn('_id', $default_unitIds )->get();
                    }
                    $unitIdsFilter = $units->pluck('_id')->toArray();
                    $userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$unitIdsFilter)->get();
                    $unitData = Unit::pluck('unit_name','_id')->toArray();
                    $sessionData = Session::pluck('session_name','_id')->toArray();
                    $objectData = UserObjectType::pluck('object_name','_id')->toArray();
                    $key = 0;
                    
                    foreach ($userSessionProgress as  $sessionProgress ) {
                        if($key == 0)
                        {
                            $oldSessionId = $sessionProgress->session_id;
                        }
                        if($oldSessionId != $sessionProgress->session_id){
                            $data[$key]['category_type'] = $type;
                            $data[$key]['unit_name'] = $unitData[$sessionProgress->unit_id];
                            $data[$key]['session_object'] = 'Session';
                            $data[$key]['name'] = $sessionData[$oldSessionId]?? "";
                            $data[$key]['date'] = $sessionProgress->created_at != '' ? Carbon::parse($sessionProgress->created_at)->format('Y-m-d H:i a') : "";
                            $key++;
                        }
                        $data[$key]['category_type'] = $type;
                        $data[$key]['unit_name'] = $unitData[$sessionProgress->unit_id];
                        $data[$key]['session_object'] = 'Object';
                        $data[$key]['name'] = $objectData[$sessionProgress->object_id] ?? "";
                        $data[$key]['date'] = $sessionProgress->created_at != '' ? Carbon::parse($sessionProgress->created_at)->format('Y-m-d H:i a') : "";
                        $oldSessionId = $sessionProgress->session_id;
                        $oldSessionDate = $sessionProgress->created_at;
                        $key++;
                    }
                } else{
                    return ApiResponse::success([],'You’ve not Choose Category');
                }
                if($data != []){
                    $data = Functions::sortArray($data,$sortColumn);
                    $filteredData = collect($data);
                    if (!empty($filteredVal)) {
                        $filteredData = $filteredData->filter(function ($item) use ($filteredVal) {
                            // Check if the filter value is present in any field of the rating object
                            foreach ($item as $field => $value) {
                                if (strpos($value, $filteredVal) !== false) {
                                    return true;
                                }
                            }
                            return false;
                        });
                    }
                    $perPage = $request->per_page ?? 10;
                    $page = request('page', 1);
                    $totalRecords = $filteredData->count();
                    $totalPages = ceil($totalRecords / $perPage);
                    // Paginate the results, assuming 10 items per page
                    $paginatedData = $filteredData->slice(($page - 1) * $perPage, $perPage)->values();
                }
                $newRoot = [
                    'data' => $paginatedData ?? [],
                    'total_page' => $totalPages ?? 1,
                    'total_records' => $totalRecords ?? 0,
                    'current_page' => $page ?? 1
                ];
                return ApiResponse::success($newRoot,'Activity List!');  
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    //feedback list of user dashboard api
    public function getUserFeedbackList(Request $request){
        try{
            $appUrl = env('AWS_S3_PATH');
            $coachReviewPath = env('AWS_COACH_REVIEW_PATH');
            $swingPath = env('AWS_SWING_PATH');
            $token = $this->getTokenFromHeader();
            $loginuser = \JWTAuth::setToken($token)->authenticate();
            if(!$loginuser) {
                return ApiResponse::error('Getting trouble to fetch logged in user information');
            }else{
                $validatedData = $request->validate([
                    'user_id' => 'required|string'
                ]);
                $user = User::find($validatedData['user_id']);
                if(!$user) {
                    return ApiResponse::error('User not found!');
                }
                $type = $request->type ?? "";
                $filteredVal = $request->filteredVal ?? ""; 
                $sortColumn = $request->sortBy ?? "date";
                $data = [];
                $totalPages = $totalRecords = 0;
            
                if($type == "swing"){
                    $swings = Swing::where('user_id',$user->_id)->get();
                    foreach ($swings as $key => $swing) {
                        $data[$key]['type'] = "Swing Videos:";
                        $data[$key]['title'] = $swing->title ?? "";
                        $data[$key]['date'] = Carbon::parse($swing->created_at)->format('Y-m-d H:i a');
                        $data[$key]['down_the_line'] = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                        $data[$key]['face_on'] = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                        //$data[$key]['video_link'] = $swing->file != "" ? $appUrl ."".$swingPath."".$swing->file : "";
                    }
                }else if($type == "coach_review"){
                    $swingIds = Swing::where('user_id',$user->_id)->pluck('_id')->toArray();
                    $data = [];
                    if(!empty($swingIds)){
                        $coachReviews = AdminCoachReview::whereIn('swing_id',$swingIds)->orderBy('created_at','desc')->get();
                        $swings = Swing::where('user_id',$user["_id"])->get();
                        foreach ($coachReviews as $key => $coachReview) {
                            $coach = User::find( $coachReview["coach_id"]);
                            $data[$key]['id'] =  $coachReview["_id"];
                            $data[$key]['type'] = "Coach Reviews:";
                            $data[$key]['swing_id'] =  $coachReview["swing_id"];
                            $swing = $swings->where('_id', $coachReview["swing_id"])->first();
                            $data[$key]['down_the_line'] = $swing->down_the_line != '' ? $appUrl.''.$swingPath.''.$swing->down_the_line : '';
                            $data[$key]['face_on'] = $swing->face_on != '' ? $appUrl.''.$swingPath.''.$swing->face_on : '';
                            //$data[$key]['swing_video'] = $swing->file != "" ? $appUrl ."".$swingPath."".$swing->file : "";
                           // $data[$key]['swing_video_duration'] = $swing->duration ?? "";
                            $data[$key]['face_on_duration'] = $swing->face_on_duration ?? "";
                            $data[$key]['down_the_line_duration'] = $swing->down_the_line_duration ?? "";
                            $data[$key]['down_the_line_filesize'] = $swing->down_the_line_filesize ?? "";
                            $data[$key]['face_on_filesize'] = $swing->face_on_filesize ?? "";
                            $data[$key]['title'] =  $coachReview["title"] ?? "Feedback name";
                            $data[$key]['unit'] =  1;
                            $data[$key]['session'] = "Session Name";
                            $data[$key]['status'] =  $coachReview['status'] ?? "";
                            $data[$key]['comment'] = $coachReview["comment"] ?? "";
                            $data[$key]['coach_name'] = $coach->full_name ?? "" ;
                            $data[$key]['file'] =  $coachReview["file"] != "" ? $appUrl.''.$coachReviewPath.''.$coachReview["file"] :"";
                            
                            $data[$key]['date'] =  Carbon::parse( $coachReview["created_at"])->format('Y-m-d H:i a');
                        }
                    }
                }else if($type == "shot_check"){
                    $shotCheckDates = UserShotCheck::where('user_id',$user->userid)
                                    ->groupBy('date')->orderBy('date','desc')
                                    ->pluck('date')->toArray();
                    foreach ($shotCheckDates as $key => $currentDate) {
                        $shotChecks = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->get();
                        $shotCheckCount = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->count();
                        $data[$key] = [
                            'date' => $currentDate,
                            'shot_check_count' => $shotCheckCount,
                            'shot_checks' => $shotChecks
                        ];
                    }
                }
                if($data != []){
                    $data = Functions::sortArray($data,$sortColumn);
                    $filteredData = collect($data);
                    if (!empty($filteredVal)) {
                        $filteredData = $filteredData->filter(function ($item) use ($filteredVal) {
                            // Check if the filter value is present in any field of the rating object
                            foreach ($item as $field => $value) {
                                if (strpos($value, $filteredVal) !== false) {
                                    return true;
                                }
                            }
                            return false;
                        });
                    }
                    $perPage = $request->per_page ?? 10;
                    $page = request('page', 1);
                    $totalRecords = $filteredData->count();
                    $totalPages = ceil($totalRecords / $perPage);
                    // Paginate the results, assuming 10 items per page
                    $paginatedData = $filteredData->slice(($page - 1) * $perPage, $perPage)->values();
                }
                $newRoot = [
                    'data' => $paginatedData ?? [],
                    'total_page' => $totalPages ?? 1,
                    'total_records' => $totalRecords ?? 0,
                    'current_page' => $page ?? 1
                ];
                return ApiResponse::success($newRoot,'Activity List!');  
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    // public function getUserProgressTrackingNew(){
    //     try{
    //         $newRoot = [];
    //         $token = $this->getTokenFromHeader();
    //         $logInUser = \JWTAuth::setToken($token)->authenticate();
    //         if(!$logInUser) {
    //             return ApiResponse::error('Getting trouble to fetch user information');
    //         }
           
    //         $defaultProgram = env('DEFAULT_PROGRAM');
    //         $defaultGroup = Group::where('group_name',$defaultProgram)->first();
    //         $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
    //         $question = Question::pluck('text','_id')->toArray();
    //         $questionIds = Question::pluck('_id')->toArray();
    //         $categoryTypeTrain = CategoryType::where('name', 'LIKE', 'Train')->first();
    //         $categoryTypeApply = CategoryType::where('name', 'LIKE', 'Apply')->first();

    //         $users = User::where('user_type','user')->where('is_confirm',1)->limit(10)->get();
    //         foreach ($users as $key => $user) {
    //             if($user->first_name == "" && $user->last_name == ""){
    //                 if($user->full_name != ""){
    //                    $names= explode(' ',$user->full_name,2);
    //                     if(sizeof($names) > 1){
    //                         $user->first_name = $names[0];
    //                         $user->last_name = $names[1];
    //                     }else{
    //                         $user->first_name = $user->full_name;
    //                     }
    //                 }
    //             }
              
    //             $user->group_id = $user->group_id == 0 ? $defaultGroup->_id : $user->group_id;
    //             $group = Group::find($user->group_id);
    //             $user->group_name = $group->group_name ?? $defaultProgram;
              
    //             $questionAnswer = UserQuestionAnswer::where('user_id', $user["userid"])->whereIn('question_id',$questionIds)->groupBy('question_id')->pluck('question_id')->toArray();
    //             $userQuestionAnswer = [];
    //             if($questionAnswer){
    //                 foreach ($questionAnswer as $key => $value) {
    //                     $answer = "";
    //                     $questionDetail = Question::find($value);
    //                     if($questionDetail->question_type == "radio"){
    //                         $questionData = UserQuestionAnswer::where('user_id', $user["userid"])->where('question_id', $value)->orderBy('created_at','desc')->first();
    //                         if($questionData){
    //                             $answer = $questionData->answer;
    //                         }
    //                     }else{
    //                         $questionData = UserQuestionAnswer::where('user_id', $user["userid"])->where('question_id', $value)->get();
    //                         if ($questionData->count() > 0) {
    //                             $answers = [];
    //                             foreach ($questionData as $questionAns) {
    //                                 $answers[] = $questionAns['answer'];
    //                             }
    //                             // Remove duplicates from the answers array
    //                             $uniqueAnswers = array_unique($answers);
    //                             // Merge the unique answers into a comma-separated string
    //                             $answer = implode(", ", $uniqueAnswers);
    //                         }
    //                     }
                        
    //                     $userQuestionAnswer[$key]['question'] = $question[$value];
    //                     $userQuestionAnswer[$key]['answer'] = $answer;
    //                 }
    //             }
    //             $unitOrderMap = [];
    //             foreach ($defaultGroup["group_object"] as $in => $obj) {
    //                 $unitOrderMap[$obj['object_id']] = $in + 1; 
    //             }
    //             if(!empty($user->group_id)){
    //                 $group = Group::find($user->group_id);
    //                 if($group){
    //                     $unitOrderMap = [];
    //                     $unitIds = array_column($group["group_object"], "object_id");
    //                     foreach ($group["group_object"] as $in => $obj) {
    //                         $unitOrderMap[$obj['object_id']] = $in + 1;
    //                     }
    //                     $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $unitIds )->get();
    //                     $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $unitIds )->get();
    //                 }else{
    //                     $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
    //                     $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
    //                 }
    //             }else{
    //                 $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
    //                 $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
    //             }
    //             $unitIdsFilter = $units->pluck('_id')->toArray();
    //             $applyIdsFilter = $apply->pluck('_id')->toArray();
    //             $ninetyDaysAgo = Carbon::now()->subDays(90);
    //             $userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$unitIdsFilter)->where('created_at', '>=', $ninetyDaysAgo)->orderBy('created_at','desc')->get();
    //             $userSessionProgressApply = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$applyIdsFilter)->where('created_at', '>=', $ninetyDaysAgo)->orderBy('created_at','desc')->get();
                
    //             $key = 0;
    //             $trainData = [];
    //             $key_apply = 0; 
    //             $applyData = [];
    //             if(!empty($userSessionProgress)){
    //                 foreach ($userSessionProgress as  $sessionProgress ) {
    //                     $sessionId = $sessionProgress->session_id;
    //                     $session = Session::find($sessionId);
    //                     $sessionObject = $session->session_object;
    //                     $sessionOrderMap = [];
    //                     foreach ($sessionObject as $indexNo => $object) {
    //                         $sessionOrderMap[$object['object_id']] = $indexNo + 1; 
    //                     }
    //                     $trainData[$key]['category_type'] = 'Train';
    //                     $trainData[$key]['unit_name']    = $unitOrderMap[$sessionProgress->unit_id] ?? "";
    //                     $trainData[$key]['session_name'] = $sessionOrderMap[$sessionProgress->object_id] ?? "";
    //                     $trainData[$key]['date'] = $sessionProgress->created_at;
    //                     $key++;
    //                 }
    //             }
                
    //             $collection = collect($trainData);

    //             // Group data by date
    //             $groupedData = [];
    //             foreach ($collection as $entry) {
    //                 $dateKey = substr($entry['date'], 0, 10);
    //                 if (!isset($groupedData[$dateKey])) {
    //                     $groupedData[$dateKey] = [];
    //                 }
    //                 $groupedData[$dateKey][] = $entry;
    //             }
    //             // Get the latest entry for each date
    //             $uniqueEntries = [];
    //             foreach ($groupedData as $date => $entries) {
    //                 usort($entries, function($a, $b) {
    //                     return strtotime($b['date']) - strtotime($a['date']);
    //                 });
    //                 $uniqueEntries[] = $entries[0];
    //             }

    //             if(!empty($userSessionProgressApply)){
    //                 foreach ($userSessionProgressApply as  $sessionProgressApply ) {
    //                     $sessionId = $sessionProgressApply->session_id;
    //                     $session = Session::find($sessionId);
    //                     $sessionObject = $session->session_object;
    //                     $sessionOrderMapApply = [];
    //                     foreach ($sessionObject as $index => $object) {
    //                         $sessionOrderMapApply[$object['object_id']] = $index + 1; 
    //                     }
    //                     $applyData[$key_apply]['category_type'] = 'Apply';
    //                     $applyData[$key_apply]['apply_name'] = $unitOrderMap[$sessionProgressApply->unit_id] ?? "";
    //                     $applyData[$key_apply]['session_name'] = $sessionOrderMapApply[$sessionProgressApply->object_id] ?? "";
    //                     $applyData[$key_apply]['date'] = $sessionProgressApply->created_at;
    //                     $key_apply++;
    //                 }
    //             } 
                
    //             $collectionApply = collect($applyData);

    //             // Group data by date
    //             $groupedDataApply = [];
    //             foreach ($collectionApply as $entry) {
    //                 $dateKey = substr($entry['date'], 0, 10);
    //                 if (!isset($groupedDataApply[$dateKey])) {
    //                     $groupedDataApply[$dateKey] = [];
    //                 }
    //                 $groupedDataApply[$dateKey][] = $entry;
    //             }
    //             // Get the latest entry for each date
    //             $uniqueEntriesApply = [];
    //             foreach ($groupedDataApply as $date => $entries) {
    //                 usort($entries, function($a, $b) {
    //                     return strtotime($b['date']) - strtotime($a['date']);
    //                 });
    //                 $uniqueEntriesApply[] = $entries[0];
    //             }

    //             $firstObject = UserSessionProgress::where('user_id',$user->_id)->first();
    //             $newRoot[$key]['user'] = $user;
    //             $newRoot[$key]['user_progress_train'] = $uniqueEntries;
    //             $newRoot[$key]['user_progress_apply'] = $uniqueEntriesApply;
    //             $newRoot[$key]['user_question_answer'] = $userQuestionAnswer;
    //             if( $firstObject){
    //                 $newRoot[$key]['first_object'] = $firstObject->created_at ?? "";
    //             }else{
    //                 $newRoot[$key]['first_object'] =  "";
    //             }
    //         }
    //         return ApiResponse::success($newRoot,'User Process fetched successfully');
    //     } catch (\Exception $e) {
    //         return ApiResponse::error($e->getMessage());
    //     }
    // }

    public function getUserProgressTracking($user_id){
        try{
            $newRoot = [
                'user' => [],
            ];
            $token = $this->getTokenFromHeader();
            $logInUser = \JWTAuth::setToken($token)->authenticate();
            if(!$logInUser) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user = User::find($user_id);
           
            if($user){
                if($user->first_name == "" && $user->last_name == ""){
                    if($user->full_name != ""){
                       $names= explode(' ',$user->full_name,2);
                        if(sizeof($names) > 1){
                            $user->first_name = $names[0];
                            $user->last_name = $names[1];
                        }else{
                            $user->first_name = $user->full_name;
                        }
                    }
                }
                $defaultProgram = env('DEFAULT_PROGRAM');
                $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                $user->group_id = $user->group_id == 0 ? $defaultGroup->_id : $user->group_id;
                $group = Group::find($user->group_id);
                $user->group_name = $group->group_name ?? $defaultProgram;
                $question = Question::pluck('text','_id')->toArray();
                $questionIds = Question::pluck('_id')->toArray();
                $questionAnswer = UserQuestionAnswer::where('user_id', $user["userid"])->whereIn('question_id',$questionIds)->groupBy('question_id')->pluck('question_id')->toArray();
                $userQuestionAnswer = [];
                if($questionAnswer){
                    foreach ($questionAnswer as $key => $value) {
                        $answer = "";
                        $questionDetail = Question::find($value);
                        if($questionDetail->question_type == "radio"){
                            $questionData = UserQuestionAnswer::where('user_id', $user["userid"])->where('question_id', $value)->orderBy('created_at','desc')->first();
                            if($questionData){
                                $answer = $questionData->answer;
                            }
                        }else{
                            $questionData = UserQuestionAnswer::where('user_id', $user["userid"])->where('question_id', $value)->get();
                            if ($questionData->count() > 0) {
                                $answers = [];
                                foreach ($questionData as $questionAns) {
                                    $answers[] = $questionAns['answer'];
                                }
                                // Remove duplicates from the answers array
                                $uniqueAnswers = array_unique($answers);
                                // Merge the unique answers into a comma-separated string
                                $answer = implode(", ", $uniqueAnswers);
                            }
                        }
                        
                        $userQuestionAnswer[$key]['question'] = $question[$value];
                        $userQuestionAnswer[$key]['answer'] = $answer;
                    }
                }
                $categoryTypeTrain = CategoryType::where('name', 'LIKE', 'Train')->first();
                $categoryTypeApply = CategoryType::where('name', 'LIKE', 'Apply')->first();
                $defaultProgram = env('DEFAULT_PROGRAM');
                $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
                
                $unitOrderMap = [];
                foreach ($defaultGroup["group_object"] as $in => $obj) {
                    $unitOrderMap[$obj['object_id']] = $in + 1; 
                }
                if(!empty($user->group_id)){
                    $group = Group::find($user->group_id);
                    if($group){
                        $unitOrderMap = [];
                        $unitIds = array_column($group["group_object"], "object_id");
                        foreach ($group["group_object"] as $in => $obj) {
                            $unitOrderMap[$obj['object_id']] = $in + 1;
                        }
                        $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $unitIds )->get();
                        $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $unitIds )->get();
                    }else{
                        $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                        $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                    }
                }else{
                    $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                    $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                }
                $unitIdsFilter = $units->pluck('_id')->toArray();
                $applyIdsFilter = $apply->pluck('_id')->toArray();
                $ninetyDaysAgo = Carbon::now()->subDays(90);
                $userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$unitIdsFilter)->where('created_at', '>=', $ninetyDaysAgo)->orderBy('created_at','desc')->get();
                $userSessionProgressApply = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$applyIdsFilter)->where('created_at', '>=', $ninetyDaysAgo)->orderBy('created_at','desc')->get();
                
                $key = 0;
                $trainData = [];
                $key_apply = 0; 
                $applyData = [];
                if(!empty($userSessionProgress)){
                    foreach ($userSessionProgress as  $sessionProgress ) {
                        $sessionId = $sessionProgress->session_id;
                        $objectId = $sessionProgress->object_id;
                        $session = Session::find($sessionId);
                        $sessionObject = $session->session_object;
                        $sessionOrderMap = [];
                        foreach ($sessionObject as $indexNo => $object) {
                            $sessionOrderMap[$object['object_id']] = $indexNo + 1; 
                        }
                        $trainData[$key]['category_type'] = 'Train';
                        $trainData[$key]['unit_name']    = $unitOrderMap[$sessionProgress->unit_id] ?? "";
                        $trainData[$key]['session_name'] = $sessionOrderMap[$sessionProgress->object_id] ?? "";
                        $trainData[$key]['date'] = $sessionProgress->created_at;
                        $key++;
                    }
                }
                
                $collection = collect($trainData);

                // Group data by date
                $groupedData = [];
                foreach ($collection as $entry) {
                    $dateKey = substr($entry['date'], 0, 10);
                    if (!isset($groupedData[$dateKey])) {
                        $groupedData[$dateKey] = [];
                    }
                    $groupedData[$dateKey][] = $entry;
                }
                // Get the latest entry for each date
                $uniqueEntries = [];
                foreach ($groupedData as $date => $entries) {
                    usort($entries, function($a, $b) {
                        return strtotime($b['date']) - strtotime($a['date']);
                    });
                    $uniqueEntries[] = $entries[0];
                }

                if(!empty($userSessionProgressApply)){
                    foreach ($userSessionProgressApply as  $sessionProgressApply ) {
                        $sessionId = $sessionProgressApply->session_id;
                        $session = Session::find($sessionId);
                        $sessionObject = $session->session_object;
                        $sessionOrderMapApply = [];
                        foreach ($sessionObject as $index => $object) {
                            $sessionOrderMapApply[$object['object_id']] = $index + 1; 
                        }
                        $applyData[$key_apply]['category_type'] = 'Apply';
                        $applyData[$key_apply]['apply_name'] = $unitOrderMap[$sessionProgressApply->unit_id] ?? "";
                        $applyData[$key_apply]['session_name'] = $sessionOrderMapApply[$sessionProgressApply->object_id] ?? "";
                        $applyData[$key_apply]['date'] = $sessionProgressApply->created_at;
                        $key_apply++;
                    }
                } 
                
                $collectionApply = collect($applyData);

                // Group data by date
                $groupedDataApply = [];
                foreach ($collectionApply as $entry) {
                    $dateKey = substr($entry['date'], 0, 10);
                    if (!isset($groupedDataApply[$dateKey])) {
                        $groupedDataApply[$dateKey] = [];
                    }
                    $groupedDataApply[$dateKey][] = $entry;
                }
                // Get the latest entry for each date
                $uniqueEntriesApply = [];
                foreach ($groupedDataApply as $date => $entries) {
                    usort($entries, function($a, $b) {
                        return strtotime($b['date']) - strtotime($a['date']);
                    });
                    $uniqueEntriesApply[] = $entries[0];
                }

                $firstObject = UserSessionProgress::where('user_id',$user_id)->first();
                $newRoot['user'] = $user;
                $newRoot['user_progress_train'] = $uniqueEntries;
                $newRoot['user_progress_apply'] = $uniqueEntriesApply;
                $newRoot['user_question_answer'] = $userQuestionAnswer;
                if( $firstObject){
                    $newRoot['first_object'] = $firstObject->created_at ?? "";
                }else{
                    $newRoot['first_object'] =  "";
                }
               
                return ApiResponse::success($newRoot,'User detail fetch successfully');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

    public function getAllUserProgressTracking(Request $request)
    {
        try {
            $newRoot = ['users' => []];
            $token = $this->getTokenFromHeader();
            $logInUser = \JWTAuth::setToken($token)->authenticate();
            if (!$logInUser) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }

            // Request parameters for filtering, sorting, and pagination
            $req_param = $request->all();
            $sortColumn = $req_param['sort'] ?? "";
            $filterColumn = $req_param['filterBy'] ?? "";
            $filteredVal = $req_param['filteredVal'] ?? "";

            $arrayField = ["_id", "full_name", "email", "user_type", "registered_at", "userid", "is_confirm", "updated_at", "created_at"];
            $perPage = $request->per_page ?? 10;

            if (substr($sortColumn, 0, 1) === "-") {
                $columnName = substr($sortColumn, 1);
                $typeOfSort = "desc";
            } else {
                $columnName = $sortColumn;
                $typeOfSort = "asc";
            }

            // Filter and sort users
            $query = User::where('user_type', 'user')
                ->where('is_confirm', 1)
                ->whereNotNull('last_login_at')
                ->where('last_login_at', '!=', "");

            if ($filteredVal != "") {
                if ($filterColumn != "") {
                    $query = $query->where($filterColumn, 'like', '%' . $filteredVal . '%');
                } else {
                    $query = $query->where(function ($query) use ($arrayField, $filteredVal) {
                        foreach ($arrayField as $field) {
                            $query->orWhere($field, 'like', '%' . $filteredVal . '%');
                        }
                    });
                }
            }
            if ($sortColumn != "") {
                $query = $query->orderBy($columnName, $typeOfSort);
            }
            $users = $query->paginate($perPage);

            $defaultProgram = env('DEFAULT_PROGRAM');
            $defaultGroup = Group::where('group_name', $defaultProgram)->first();
            $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
            $categoryTypeTrain = CategoryType::where('name', 'LIKE', 'Train')->first();
            $categoryTypeApply = CategoryType::where('name', 'LIKE', 'Apply')->first();

            $groupIds = $users->pluck('group_id')->unique()->toArray();
            if (!in_array(0, $groupIds)) {
                $groupIds[] = 0;
            }

            $groups = Group::whereIn('_id', $groupIds)->get()->keyBy('_id');
            $questions = Question::pluck('text', '_id')->toArray();
            $questionIds = array_keys($questions);

            $ninetyDaysAgo = Carbon::now()->subDays(90);
            $userIds = $users->pluck('userid')->toArray();
            $allUsersID = $users->pluck('_id')->unique()->toArray();

            $allUnits = Unit::where('category_type_id', $categoryTypeTrain["_id"])
                ->orWhere('category_type_id', $categoryTypeApply["_id"])
                ->pluck('_id')
                ->toArray();

            $userSessionProgress = UserSessionProgress::whereIn('user_id', $allUsersID)
                ->whereIn('unit_id', $allUnits)
                ->where('created_at', '>=', $ninetyDaysAgo)
                ->orderBy('created_at', 'desc')
                ->get()
                ->groupBy('user_id');

            $userQuestionAnswers = UserQuestionAnswer::whereIn('user_id', $userIds)
                ->whereIn('question_id', $questionIds)
                ->get()
                ->groupBy('user_id');

            foreach ($users as $user) {
                if ($user->first_name == "" && $user->last_name == "") {
                    if ($user->full_name != "") {
                        $names = explode(' ', $user->full_name, 2);
                        if (sizeof($names) > 1) {
                            $user->first_name = $names[0];
                            $user->last_name = $names[1];
                        } else {
                            $user->first_name = $user->full_name;
                        }
                    }
                }

                $user->group_id = $user->group_id == 0 ? $defaultGroup->_id : $user->group_id;
                $group = $groups->get($user->group_id);
                $user->group_name = $group->group_name ?? $defaultProgram;

                $userQuestionAnswer = [];
                if (isset($userQuestionAnswers[$user->userid])) {
                    $answers = $userQuestionAnswers[$user->userid];
                    foreach ($answers as $answer) {
                        $questionId = $answer->question_id;
                        if (!isset($userQuestionAnswer[$questionId])) {
                            $userQuestionAnswer[$questionId] = [
                                'question' => $questions[$questionId],
                                'answers' => []
                            ];
                        }
                        $userQuestionAnswer[$questionId]['answers'][] = $answer->answer;
                    }
                    foreach ($userQuestionAnswer as $questionId => &$data) {
                        $data['answer'] = implode(", ", array_unique($data['answers']));
                        unset($data['answers']);
                    }
                }

                $unitOrderMap = [];
                foreach ($defaultGroup["group_object"] as $in => $obj) {
                    $unitOrderMap[$obj['object_id']] = $in + 1;
                }

                $unitIds = $default_unitIds;
                if (!empty($user->group_id) && isset($groups[$user->group_id])) {
                    $group = $groups[$user->group_id];
                    $unitIds = array_column($group["group_object"], "object_id");
                    $unitOrderMap = [];
                    foreach ($group["group_object"] as $in => $obj) {
                        $unitOrderMap[$obj['object_id']] = $in + 1;
                    }
                }

                $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $unitIds)->get();
                $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $unitIds)->get();

                $unitIdsFilter = $units->pluck('_id')->toArray();
                $applyIdsFilter = $apply->pluck('_id')->toArray();

               $filteredSessionProgress = isset($userSessionProgress[$user->_id]) ? $userSessionProgress[$user->_id]->filter(function ($progress) use ($unitIdsFilter) {
                    return in_array($progress->unit_id, $unitIdsFilter);
                }) : collect();

                $filteredSessionProgressApply = isset($userSessionProgress[$user->_id]) ? $userSessionProgress[$user->_id]->filter(function ($progress) use ($applyIdsFilter) {
                    return in_array($progress->unit_id, $applyIdsFilter);
                }) : collect();

                $trainData = $this->processSessionProgress($filteredSessionProgress, $unitOrderMap, 'Train');
                $applyData = $this->processSessionProgress($filteredSessionProgressApply, $unitOrderMap, 'Apply');

                $firstObject = UserSessionProgress::where('user_id', $user->_id)->first();

                $newRoot['users'][] = [
                    'user' => $user,
                    'user_progress_train' => $trainData,
                    'user_progress_apply' => $applyData,
                    'user_question_answer' => array_values($userQuestionAnswer),
                    'first_object' => $firstObject->created_at ?? "",
                ];
            }

            // Add pagination metadata to the response
            $paginationData = [
                'per_page' => $users->perPage(),
                'path' => $users->path(),
                'next_page_url' => $users->nextPageUrl() ? $users->nextPageUrl() . "&per_page=" . $perPage : null,
                'last_page_url' => $users->url($users->lastPage()) . "&per_page=" . $perPage,
                'current_page' => $users->currentPage(),
            ];

            $newRoot = array_merge($newRoot, $paginationData);

            return ApiResponse::success($newRoot, 'Users detail fetch successfully');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }
    private function processSessionProgress($sessionProgresses, $unitOrderMap, $categoryType)
    {
        $data = [];
        foreach ($sessionProgresses as $key => $sessionProgress) {
            $sessionId = $sessionProgress->session_id;
            $session = Session::find($sessionId);
            if (!$session) {
                continue;
            }
            $sessionObject = $session->session_object;
            $sessionOrderMap = [];
            foreach ($sessionObject as $indexNo => $object) {
                $sessionOrderMap[$object['object_id']] = $indexNo + 1; 
            }
            $data[$key]['category_type'] = $categoryType;
            $data[$key]['unit_name'] = $unitOrderMap[$sessionProgress->unit_id] ?? "";
            $data[$key]['session_name'] = $sessionOrderMap[$sessionProgress->object_id] ?? "";
            $data[$key]['date'] = $sessionProgress->created_at;
        }

        $collection = collect($data);

        // Group data by date
        $groupedData = [];
        foreach ($collection as $entry) {
            $dateKey = substr($entry['date'], 0, 10);
            if (!isset($groupedData[$dateKey])) {
                $groupedData[$dateKey] = [];
            }
            $groupedData[$dateKey][] = $entry;
        }

        // Get the latest entry for each date
        $uniqueEntries = [];
        foreach ($groupedData as $date => $entries) {
            usort($entries, function($a, $b) {
                return strtotime($b['date']) - strtotime($a['date']);
            });
            $uniqueEntries[] = $entries[0];
        }

        return $uniqueEntries;
    }

    public function getUserProfileData($user_id)
    {
        try{
            $newRoot = [
                'user' => [],
                'training_intention' => [],
                'reps' => [],
                'rate' => [],
                'activity' => [],
                'streak_calender' => []
            ];
            $appUrl = env('AWS_S3_PATH');
            $path = env('AWS_PROFILE_PATH');
            $coachReviewPath = env('AWS_COACH_REVIEW_PATH');
            $swingPath = env('AWS_SWING_PATH');
            $token = $this->getTokenFromHeader();
            $logInUser = \JWTAuth::setToken($token)->authenticate();
            if(!$logInUser) {
                return ApiResponse::error('Getting trouble to fetch user information');
            }
            $user = User::find($user_id);
            if($user){
                $user->status = $user->status ?? true;
                if($user->first_name == "" && $user->last_name == ""){
                    if($user->full_name != ""){
                       $names= explode(' ',$user->full_name,2);
                        if(sizeof($names) > 1){
                            $user->first_name = $names[0];
                            $user->last_name = $names[1];
                        }else{
                            $user->first_name = $user->full_name;
                        }
                    }
                }
                $user->dailyReminder = $user->dailyReminder ?? false;
                $user->skip_reminder = $user->skip_reminder ?? true;
                $user->set_daily_reminder_time = "";
                if($user->skip_reminder == true){
                    $user->set_daily_reminder = false;
                }else{
                    $user->set_daily_reminder = $user->dailyReminder ?? false;
                    if( $user->dailyReminder == true){
                        $hour = (!empty($user->hour) ? (int)$user->hour : 6);
                        $min = (!empty($user->min) ? (int)$user->min : 0);
                        $timeAM = (!empty($user->time) ? Str::upper($user->time) : "AM");
                        if($hour != "" && $min != "" && $hour > 0 ){
                            $time = $hour. ":". $min;
                            $parsedTime = Carbon::parse($time);
                            $finalTime  =  $parsedTime->format('g:i')." ".$timeAM;
                        }
                        $user->set_daily_reminder_time = $finalTime ?? "";
                    }
                }
                // $user->active_plan_name = "Free 7-Day Trial"; 
                $userBillingData = UserBillingHistory::where('user_id',$user["_id"])->where('status','active')->orderBy('created_at', 'desc')->first();

                if(!$userBillingData){
                    $plan_name = "";
                }else{
                    $plan = Plan::find($userBillingData->plan_id);
                    $plan_name = $plan->name ?? "";
    
                    if($plan_name == "Free 7-Day Trial"){
                        $plan_name = "7-Day Trial";
                    }
                }
                $user->active_plan_name = $plan_name ?? "";
                $user->plan_amount = $plan->amount ?? "";
                $user->plan_validity_type = $plan->validity_type ?? "";
                $user->plan_validity = $plan->validity ?? "";
                $user->plan_status = $userBillingData->status ?? "";

                $question = Question::pluck('text','_id')->toArray();
                $questionIds = Question::pluck('_id')->toArray();
             
                $questionAnswer = UserQuestionAnswer::where('user_id', $user["userid"])->whereIn('question_id',$questionIds)->groupBy('question_id')->pluck('question_id')->toArray();
                $userQuestionAnswer = [];
                if($questionAnswer){
                    foreach ($questionAnswer as $key => $value) {
                        $answer = "";
                        $questionDetail = Question::find($value);
                        if($questionDetail->question_type == "radio"){
                            $questionData = UserQuestionAnswer::where('user_id', $user["userid"])->where('question_id', $value)->orderBy('created_at','desc')->first();
                            if($questionData){
                                $answer = $questionData->answer;
                            }
                        }else{
                            $questionData = UserQuestionAnswer::where('user_id', $user["userid"])->where('question_id', $value)->get();
                            if ($questionData->count() > 0) {
                                $answers = [];
                                foreach ($questionData as $questionAns) {
                                    $answers[] = $questionAns['answer'];
                                }
                                // Remove duplicates from the answers array
                                $uniqueAnswers = array_unique($answers);
                                // Merge the unique answers into a comma-separated string
                                $answer = implode(", ", $uniqueAnswers);
                            }
                        }
                        
                        $userQuestionAnswer[$key]['question'] = $question[$value];
                        $userQuestionAnswer[$key]['answer'] = $answer;
                    }
                }
                $trainingPlan = UserTrainingPlan::where('user_id', $user["userid"])->get();
                $trainingIntention = [];
                if($trainingPlan){
                    foreach ($trainingPlan as $key => $value) {
                        $trainingIntention[$key]['day'] = $value["day"];
                        $trainingIntention[$key]['time'] = $value["time"];
                        $trainingIntention[$key]['location'] = $value["location"];
                    }
                    $collection = new Collection($trainingIntention);
                    $daysOrder  = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
                    $sortedCollection = $collection->sortBy(function ($item) use ($daysOrder) {
                        return array_search($item['day'], $daysOrder);
                    });
                    $sortedTrainingDays = $sortedCollection->values()->all();
                }else{
                    $sortedTrainingDays = [];
                }
                $userContactPerson = UserContactPerson::where('user_id', $user["userid"])->get();
                $contactPerson = [];
                if($userContactPerson){
                    foreach ($userContactPerson as $keyuserContactPerson => $value) {
                        $contactPerson[$keyuserContactPerson]['id'] = $value["_id"];
                        $contactPerson[$keyuserContactPerson]['name'] = $value["person_name"];
                        $contactPerson[$keyuserContactPerson]['phone'] = $value["phone"];
                    }
                }
                
                $userStreakData = UserTrainingStreak::where('user_id',$user["userid"])
                ->where(function ($query) {
                    $query->where('current_streak', '>', 0)
                          ->orWhere('mulligan', '>', 0);
                })->get();
                $activity = [];

                $reps = [];
                // Set initial reps values
                $manual_reps_recall_card = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Recall Cards')
                    ->get();
                $total_manual_reps_recall_card = $manual_reps_recall_card->sum('reps') ?? 0;     
                $manual_reps_movement_drills = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Move Drills')
                    ->get();
                $total_manual_reps_movement_drills = $manual_reps_movement_drills->sum('reps') ?? 0;     
                $manual_reps_swing_drills = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Swing Drills')
                    ->get();    
                $total_manual_reps_swing_drills = $manual_reps_swing_drills->sum('reps') ?? 0;     
                $manual_reps_trust = UserManualReps::where('user_id', $user["_id"])
                    ->where('reps_type', 'Trust Shots')
                    ->get();
                $total_manual_reps_trust = $manual_reps_trust->sum('reps') ?? 0;  
                // Set initial reps values
                $userRecallCardsCount = UserRecallCards::where('user_id',$user['userid'])->count();
                $recap_reps_all = SessionRecapTime::where('user_id', $user['_id'])->get();
                $all_totalRecapReps = 0;
                if($recap_reps_all->count() > 0){
                    foreach ($recap_reps_all as $recap_reps_a) {
                        $all_totalRecapReps += (int) $recap_reps_a['recap_reps'];
                    }
                }
                $reps['recall_cards'] = $userRecallCardsCount + $total_manual_reps_recall_card +$all_totalRecapReps ?? 0 ;
                $docs = UserMovementDrill::where('user_id', $user['_id'])->get();
                $totalReps = 0;
                foreach ($docs as $doc) {
                    $totalReps += (int) $doc['reps'];
                }
                $userMovementDrillCount = $totalReps;
                $trust_reps = 0;
                $shotCheckDates = UserTrustHole::where('user_id',$user['userid'])->groupBy('date')->orderBy('created_at','desc')->pluck('date')->toArray();
                $sortedDates = collect($shotCheckDates)->sortBy(function ($date) {
                    return \Carbon\Carbon::createFromFormat('d-m-Y', $date);
                })->values()->all();
                $totalDate = sizeof($sortedDates);
                if( $totalDate > 0){
                    $trust_reps = $totalDate * 40;
                }
                $reps['move_drills'] =  $userMovementDrillCount + $total_manual_reps_movement_drills ?? 0;
                $swings = Swing::where('user_id',$user["_id"])->count();
                $reps['swing_drills'] = $swings + $total_manual_reps_swing_drills?? 0;
                $reps['trust_shots'] = $trust_reps + $total_manual_reps_trust?? 0;
                $calculatedReps = $totalReps + $userRecallCardsCount + $trust_reps + $swings + $total_manual_reps_movement_drills + $total_manual_reps_recall_card + $total_manual_reps_swing_drills + $total_manual_reps_trust ?? 0;
                $currentLevel = $this->calculateBadge($calculatedReps);
                // Update profile picture URL
                $user->profile_picture = $user->profile_picture != "" ? $appUrl."".$path."".$user->profile_picture :"";
                $field = '';
                if($user->country_id != ""){
                    $country = Country::find($user->country_id);
                    $timezone = $country->timezone ?? "";
                    $country_name = $country->name ?? "";
                    $gmtOffSet = $country->gmt_offset ?? "";
                    // if($gmtOffSet == "")
                    // {
                    //     $field = "";
                    // }else{
                    //     $parts = explode(" ", $gmtOffSet);
                    //     $hours = explode(":", $parts[1])[0];
                    //     $hoursInt = (int)$hours;
                    //     $convertedOffset = "(GMT" . sprintf("%+d", $hoursInt) . ")";
                    //     $field ="";
                    //     $newOffset = $convertedOffset;
                    //     if (Str::contains("Eastern (GMT-4)", $newOffset)) {
                    //         $field = "Eastern (GMT-4)";
                    //     } 
                    //     if (Str::contains("Central (GMT-5)", $newOffset)) {
                    //         $field = "Central (GMT-5)";
                    //     }   
                    //     if (Str::contains("Mountain (GMT-6)", $newOffset)) {
                    //         $field = "Mountain (GMT-6)";
                    //     } 
                    //     if (Str::contains("Pacific (GMT-7)", $newOffset)) {
                    //         $field = "Pacific (GMT-7)";
                    //     } 
                    //     if (Str::contains("Alaska (GMT-8)", $newOffset)) {
                    //         $field = "Alaska (GMT-8)";
                    //     } 
                    //     if (Str::contains("Hawaii (GMT-10)", $newOffset)) {
                    //         $field = "Hawaii (GMT-10)";
                    //     } 
                    //     if($field == ""){
                    //         $field =  $country->name. " - ".$country->timezone ?? "";
                    //     }
                    //     //$field =  $country->name. " - ".$country->timezone ?? "";
                    // }
                    $field = $country->utc_offset.": ".$country->standard_time;
                    $flg = $country->flag_url  ?? "";
                }else{
                    $timezone = "";
                    $country_name = ""; $field ="";
                    $flg= "";
                }
                $categoryTypeTrain = CategoryType::where('name', 'LIKE', 'Train')->first();
                $categoryTypeApply = CategoryType::where('name', 'LIKE', 'Apply')->first();
                $defaultProgram = env('DEFAULT_PROGRAM');
                $defaultGroup = Group::where('group_name',$defaultProgram)->first();
                $default_unitIds = array_column($defaultGroup["group_object"], "object_id");
                
                if(!empty($user->group_id)){
                    $group = Group::find($user->group_id);
                    if($group){
                        $unitIds = array_column($group["group_object"], "object_id");
                        $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $unitIds )->get();
                        $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $unitIds )->get();
                    }else{
                        $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                        $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                    }
                }else{
                    $units = Unit::where('category_type_id', $categoryTypeTrain["_id"])->whereIn('_id', $default_unitIds)->get();
                    $apply = Unit::where('category_type_id', $categoryTypeApply["_id"])->whereIn('_id', $default_unitIds)->get();
                }
                $unitIdsFilter = $units->pluck('_id')->toArray();
                $applyIdsFilter = $apply->pluck('_id')->toArray();
                $userSessionProgress = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$unitIdsFilter)->orderBy('created_at','desc')->get();
                $userSessionProgressApply = UserSessionProgress::where('user_id',$user->_id)->whereIn('unit_id',$applyIdsFilter)->orderBy('created_at','desc')->get();
                $unitData = Unit::pluck('unit_name','_id')->toArray();
                $sessionData = Session::pluck('session_name','_id')->toArray();
                $objectData = UserObjectType::pluck('object_name','_id')->toArray();
                $key = 0;
                $key_apply = 0; 
                $applyData = [];
                $trainData = [];
                $trustData = [];
                $trustHoles = UserTrustHole::where('user_id',$user->userid)->where('trust_key_percent','>=',0)->where('pre_shot_percent','>=',0)->where('post_shot_percent','>=',0)->orderBy('created_at','desc')->get();
                if(!empty($trustHoles)){
                    foreach ($trustHoles as $keyTrustHoles => $trustHole) {
                        $trustData[$keyTrustHoles]['category_type'] = 'Trust';
                        $trustData[$keyTrustHoles]['trust_key_percent'] =  $trustHole->trust_key_percent;
                        $trustData[$keyTrustHoles]['pre_shot_percent'] = $trustHole->pre_shot_percent;
                        $trustData[$keyTrustHoles]['post_shot_percent'] = $trustHole->post_shot_percent;
                        $trustData[$keyTrustHoles]['date'] = Carbon::parse($trustHole->created_at)->format('Y-m-d H:i a');
                    }
                }
                foreach ($userSessionProgressApply as  $sessionProgressApply) {
                    if($key_apply == 0)
                    {
                        $oldSessionIdApply = $sessionProgressApply->session_id;
                    }
                    if($oldSessionIdApply != $sessionProgressApply->session_id){
                        $applyData[$key_apply]['category_type'] = 'Train';
                        $applyData[$key_apply]['unit_name'] = $unitData[$sessionProgressApply->unit_id];
                        $applyData[$key_apply]['session_object'] = 'Session';
                        $applyData[$key_apply]['name'] = $sessionData[$oldSessionIdApply]?? "";
                        $applyData[$key_apply]['date'] = $sessionProgressApply->created_at != '' ? Carbon::parse($sessionProgressApply->created_at)->format('Y-m-d H:i a') : "";
                        $key_apply++;
                    }
                    $applyData[$key_apply]['category_type'] = 'Train';
                    $applyData[$key_apply]['unit_name'] = $unitData[$sessionProgressApply->unit_id];
                    $applyData[$key_apply]['session_object'] = 'Object';
                    $applyData[$key_apply]['name'] = $objectData[$sessionProgressApply->object_id] ?? "";
                    $applyData[$key_apply]['date'] = $sessionProgressApply->created_at != '' ? Carbon::parse($sessionProgressApply->created_at)->format('Y-m-d H:i a') : "";
                    $oldSessionIdApply = $sessionProgressApply->session_id;
                    $key_apply++;
                }
                foreach ($userSessionProgress as  $sessionProgress ) {
                    if($key == 0)
                    {
                        $oldSessionId = $sessionProgress->session_id;
                    }
                    if($oldSessionId != $sessionProgress->session_id){
                        $trainData[$key]['category_type'] = 'Train';
                        $trainData[$key]['unit_name'] = $unitData[$sessionProgress->unit_id];
                        $trainData[$key]['session_object'] = 'Session';
                        $trainData[$key]['name'] = $sessionData[$oldSessionId]?? "";
                        $trainData[$key]['date'] = $sessionProgress->created_at != '' ? Carbon::parse($sessionProgress->created_at)->format('Y-m-d H:i a') : "";
                        $key++;
                    }
                    $trainData[$key]['category_type'] = 'Train';
                    $trainData[$key]['unit_name'] = $unitData[$sessionProgress->unit_id];
                    $trainData[$key]['session_object'] = 'Object';
                    $trainData[$key]['name'] = $objectData[$sessionProgress->object_id] ?? "";
                    $trainData[$key]['date'] = $sessionProgress->created_at != '' ? Carbon::parse($sessionProgress->created_at)->format('Y-m-d H:i a') : "";
                    $oldSessionId = $sessionProgress->session_id;
                    $key++;
                }
                $activity['train'] = $trainData;
                $activity['apply'] = $applyData;
                $activity['trust'] = $trustData;
                $newRoot['activity'] = $activity;
                $weeklyRatingData = $sccRatingData = $sessionRatingData = [];
                $weeklyRatings = UserWeeklySurvey::where('user_id',$user["_id"])->orderBy('created_at','desc')->get();
                foreach ($weeklyRatings as $key => $weeklyRating) {
                    $weeklyRatingData[$key]['type'] = "Weekly Rating";
                    $weeklyRatingData[$key]['date'] = Carbon::parse($weeklyRating->created_at)->format('Y-m-d H:i a');
                    $weeklyRatingData[$key]['rating'] = $weeklyRating->rating;
                    $weeklyRatingData[$key]['text'] = $weeklyRating->text ?? "";
                }
                $sccRatings = UserSelfCheckCheckObject::where('user_id',$user["_id"])->orderBy('created_at','desc')->get();
                foreach ($sccRatings as $keyy => $sccRating) {
                    $sccRatingData[$keyy]['type'] = "Self Check Audit";
                    $sccRatingData[$keyy]['date'] = Carbon::parse($sccRating->created_at)->format('Y-m-d H:i a');
                    $sccRatingData[$keyy]['rating'] = $sccRating->answer_2;
                    $sccRatingData[$keyy]['text'] = $sccRating->answer_3;
                }

                $session_ratings = UserSelfReportObject::where('user_id',$user["_id"])->orderBy('created_at','desc')->get();
                foreach ($session_ratings as $keyz => $session_rating) {
                    $sessionRatingData[$keyz]['type'] = "Train Session Rating";
                    $sessionRatingData[$keyz]['date'] = Carbon::parse($session_rating->created_at)->format('Y-m-d H:i a');
                    $sessionRatingData[$keyz]['rating'] = $session_rating->rating;
                    $sessionRatingData[$keyz]['text'] = $session_rating->text;
                }
                $ratingData = [
                    'weekly_rating' => $weeklyRatingData,
                    'session_rating' => $sessionRatingData,
                    'scc_rating' => $sccRatingData
                ];
                $shot_check_count = $swing_count = $coach_review_count = 0;
                $swing_data = $shot_check_data = [];
                $swings = Swing::where('user_id',$user->_id)->get();
                $swing_count = $swings->count();
                foreach ($swings as $key => $swing) {
                    $swing_data[$key]['type'] = "Swing Videos:";
                    $swing_data[$key]['title'] = $swing->title ?? "";
                    $swing_data[$key]['date'] = Carbon::parse($swing->created_at)->format('Y-m-d H:i a');
                    $swing_data[$key]['video_link'] = $swing->file != "" ? $appUrl ."".$swingPath."".$swing->file : "";
                }
                $shotCheckDates = UserShotCheck::where('user_id',$user->userid)
                                    ->groupBy('date')->orderBy('date','desc')
                                    ->pluck('date')->toArray();
                $shot_check_count = sizeof($shotCheckDates) ?? 0;
                foreach ($shotCheckDates as $key => $currentDate) {
                    $shotChecks = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->get();
                    $shotCheckCount = UserShotCheck::where('date',$currentDate)->where('user_id',$user['userid'])->count();
                    $shot_check_data[$key] = [
                        'date' => $currentDate,
                        'shot_check_count' => $shotCheckCount,
                        'shot_checks' => $shotChecks
                    ];
                }
                $swingIds = Swing::where('user_id',$user->_id)->pluck('_id')->toArray();
                $coach_review_data = [];
                if(!empty($swingIds)){
                    $coachReviews = AdminCoachReview::whereIn('swing_id',$swingIds)->orderBy('created_at','desc')->get();
                    $swings = Swing::where('user_id',$user["_id"])->get();
                    foreach ($coachReviews as $key => $coachReview) {
                        $coach = User::find( $coachReview["coach_id"]);
                        $coach_review_data[$key]['id'] =  $coachReview["_id"];
                        $coach_review_data[$key]['type'] = "Coach Reviews:";
                        $coach_review_data[$key]['swing_id'] =  $coachReview["swing_id"];
                        $swing = $swings->where('_id', $coachReview["swing_id"])->first();
                        $coach_review_data[$key]['swing_video'] = $swing->file != "" ? $appUrl ."".$swingPath."".$swing->file : "";
                        $coach_review_data[$key]['swing_video_duration'] = $swing->duration ?? "";
                        $coach_review_data[$key]['title'] =  $coachReview["title"] ?? "Feedback name";
                        $coach_review_data[$key]['unit'] =  1;
                        $coach_review_data[$key]['session'] = "Session Name";
                        $coach_review_data[$key]['status'] =  $coachReview['status'] ?? "";
                        $coach_review_data[$key]['comment'] = $coachReview["comment"] ?? "";
                        $coach_review_data[$key]['coach_name'] = $coach->full_name ?? "" ;
                        $coach_review_data[$key]['file'] =  $coachReview["file"] != "" ? $appUrl.''.$coachReviewPath.''.$coachReview["file"] :"";
                        $coach_review_data[$key]['date'] =  Carbon::parse( $coachReview["created_at"])->format('Y-m-d H:i a');
                    }
                }
                $coach_review_count = sizeof($coach_review_data) ?? 0;
                $feedbackData = [
                    'shot_check_count' => $shot_check_count,
                    'swing_count' => $swing_count,
                    'coach_review_count' => $coach_review_count,
                    'swings' => $swing_data,
                    'shot_checks' => $shot_check_data,
                    'coach_reviews' => $coach_review_data
                ];
                // $today = now()->format('Y-m-d');
                // $countries = Country::pluck('timezone','_id')->toArray();
                // $userDetail = User::find($user->_id);
                // $userTimezone = $countries[$userDetail->country_id] ?? "";
                // if($userTimezone != ""){
                //     $today = Carbon::now($userTimezone);
                // }else{
                //     $today = Carbon::now();
                // }
                // $previousDay = $today->subDay()->format('Y-m-d');
                // $trainingStreakData = UserTrainingStreak::where('user_id',$user['userid'])->where('date',$previousDay)->first();
                // $current_training_streak = $trainingStreakData->current_streak ?? 0;
                $user->group_id = $user->group_id == 0 ? $defaultGroup->_id : $user->group_id;
                $newRoot['rating'] = $ratingData;
                $newRoot['feedback'] = $feedbackData;
                $newRoot['user'] = $user;
                $newRoot['user']['timezone_name'] = $timezone;
                $newRoot['user']['country_name'] = $country_name;
                $newRoot['user']['country_flag'] = $flg ?? "";
                $newRoot['user']['timezone_field'] = $field ?? "";
                $newRoot['plan'] = $user->plan ?? "Good";
                $newRoot['question_answer'] = $userQuestionAnswer;
                $newRoot['training_intention'] = $sortedTrainingDays;
                $newRoot['friend_support'] = $contactPerson;
                $newRoot['reps'] = $reps;
                $newRoot['rate'] =  $currentLevel ?? "";
                $newRoot['training_streak'] = $user->training_streak ?? 0;
                //$newRoot['training_streak'] = $current_training_streak ?? 0;
                $newRoot['streak_calender'] = $userStreakData ?? [];
                $today = new DateTime();
                $yesterday = $today->modify('-1 day')->format('Y-m-d');
                $findMulligan = UserTrainingStreak::where('user_id',$user["userid"])->where('mulligan',1)->where('date',$yesterday)->first();
                if($user->last_updated_training_streak != now()->format('Y-m-d') && $findMulligan){
                    $newRoot['show_blue'] = 1;
                    $newRoot['training_streak'] = $user->mulligan ?? 1;
                }else{
                    $newRoot['show_blue'] = 0;
                }
                $newRoot['max_training_streak'] = $user->max_training_streak ?? ($user->training_streak ?? 0);
                return ApiResponse::success($newRoot,'User detail fetch successfully');
            }else{
                return ApiResponse::error('User not found');
            }
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
        return response()->json(['message' => 'User successfully signout']);
        
    }
    function calculateBadge($totalReps)
    {
        if ($totalReps < 1000) {
            return "";
        } else {
            $num = floor($totalReps / 1000);
            return $num . "K";
        }
    }

    public function getUserAffiliateDeeplinks(Request $request)
    {
        try {
            $users = User::whereNotNull('affiliate_deeplink')
                ->where('affiliate_deeplink', '!=', '')
                ->get();

            $data = $users->groupBy('affiliate_deeplink')
                ->map(function ($users, $deeplink) {
                    return [
                        'affiliate_deeplink' => $deeplink,
                        'users' => $users->toArray(),
                    ];
                })
                ->values()
                ->toArray();

            return ApiResponse::success($data, 'Affiliate deeplink list found successfully.');
        } catch (\Exception $e) {
            return ApiResponse::error($e->getMessage());
        }
    }

}
