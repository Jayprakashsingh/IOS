<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\Functions;
use Stripe\Event;
use Stripe\Exception\SignatureVerificationException;
use Stripe\Webhook;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Log;
use App\Models\User;
use App\Models\UserBillingHistory;
use App\Models\UserCoachReview;
use App\Models\Plan;
use Carbon\Carbon;

class StripeWebhookController extends Controller
{
    public function handleWebhook(Request $request)
    {
        // Verify the request's signature
        try {
            $payload = $request->getContent();
            $sigHeader = $request->header('Stripe-Signature');
            $event = Webhook::constructEvent(
                $payload,
                $sigHeader,
                config('services.stripe.webhook.secret')
            );
           
        } catch (SignatureVerificationException $e) {
            return $this->respondWithBadRequest();
        }
        Log::channel('webhook')->info('Received webhook event: ' . $event->type);
        // Handle the event
        switch ($event->type) {

           case 'customer.subscription.updated':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - Subscription Updated for user - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'customer.subscription.created':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - Subscription Created for user - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'invoice.payment_succeeded':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - Invoice Payment Success - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'invoice.payment_failed':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - Invoice Payment Failed - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'subscription_schedule.updated':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - subscription_schedule.updated - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'subscription_schedule.expiring':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - subscription_schedule.expiring - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'subscription_schedule.created':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - subscription_schedule.created - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            case 'subscription_schedule.completed':
                $subscription = $event->data->object;
                $customerId = $subscription->customer;
                $subscriptionId = $subscription->id;
                $user = User::where('stripe_customer_id', $customerId)->first();
                if ($user) {
                    Log::channel('webhook')->info('Event Detected - subscription_schedule.completed - '.$user->userid );
                    Log::channel('webhook')->info('Event Subscription ID of user - '.$subscriptionId);
                    Log::channel('webhook')->info('Subscription data of customer: ' . $customerId, ['event_data' => $event->toArray()]);
                } else {
                    // Log error if user not found
                    Log::channel('webhook')->error('User not found for customer ID: ' . $customerId);
                }
                break;
            default:
                // Handle unrecognized event
                break;
        }

        return $this->respondWithSuccess();
    }

    protected function respondWithBadRequest()
    {
        return new Response('Bad Request', 400);
    }

    protected function respondWithSuccess()
    {
        return new Response('Webhook Handled', 200);
    }
}
