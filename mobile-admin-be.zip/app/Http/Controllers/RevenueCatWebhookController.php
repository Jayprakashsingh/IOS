<?php

namespace App\Http\Controllers;

use App\Helpers\Functions;
use App\Models\Plan;
use App\Models\PromoCode;
use App\Models\RevenuecatWebhook;
use App\Models\UsedPromoCode;
use App\Models\User;
use App\Models\UserBillingHistory;
use App\Models\UserCancelPlan;
use App\Models\UserCoachReview;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
class RevenueCatWebhookController extends Controller
{
    protected function verifyRevenueCatSignature(Request $request)
    {
        $signature = $request->header('Authorization');
        $secret = config('services.revenuecat.webhook_secret'); // Store this in your .env
     
        if (hash_equals('Bearer ' . $secret, $signature)) {
            return true;
        }
        Log::warning('RevenueCat Webhook Signature Verification Failed.');
        return false;
    }
    protected function handleInitialPurchase($data)
    {
        $appUserId = $data['app_user_id'];
        $store = $data['store'];
        if($store == "PLAY_STORE"){
            $paymentType = "android";
        }else{
            $paymentType = "ios";
        }
        $user = User::where('app_user_id',$appUserId)->first();
      
        $transactionId = $data['transaction_id'];
       
        $purchaseAt = $data['purchased_at_ms']/ 1000;
        $expiryAt = $data['expiration_at_ms']/ 1000;
       
        $purchaseDate = (new DateTime())->setTimestamp($purchaseAt)->format('Y-m-d H:i:s');
        //$expiry_date= (new DateTime())->setTimestamp($expiryAt)->format('Y-m-d H:i:s');
        
        $productId = $data['product_id'];
        if (str_contains(strtolower($productId), 'basic')) {
            $plan = Plan::where('name','Basic')->first();
            $plan_id = $plan->_id;
        } else if (str_contains(strtolower($productId), 'premium')) {
            $plan = Plan::where('name','Premium')->first();
            $plan_id = $plan->_id;
        } else if (str_contains(strtolower($productId), 'ultra')) {
            $plan = Plan::where('name','Ultra')->first();
            $plan_id = $plan->_id;
        }else{
            $plan_id = "";
        }
     
        if($plan_id != ""){
            $user->active_subscription_id = "";
            $user->active_trans_id = $transactionId ?? "";
            $user->payment_method =  $paymentType ?? "";
            $user->save();
            $userBillingHistory = UserBillingHistory::where('user_id',$user['_id'])->where('status','active')->where('app_user_id','!=','')->where('tras_id','')->first();
          
            if($userBillingHistory){
            }else{
                $userBillingHistory = new UserBillingHistory();
                $userBillingHistory->amount = $plan->amount;
                $userBillingHistory->app_user_id = $data['app_user_id'];
                $userBillingHistory->promo_code = "";
                $userBillingHistory->transaction_no = Functions::generateUniqueNumber();

                if($plan->amount == 199){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 3;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
                if($plan->amount == 299){
                    $userCoachReview = new UserCoachReview();
                    $userCoachReview->user_id = $user["userid"];
                    $userCoachReview->coach_review = 6;
                    $userCoachReview->used_coach_review = 0;
                    $userCoachReview->expiration_date = Carbon::now()->addMonths(3)->format("Y-m-d");
                    $userCoachReview->status = 'active';
                    $userCoachReview->save();
                }
            }
            $userBillingHistory->payment_method =  $paymentType ?? "";
            $oldBillingHistoryPlan = UserBillingHistory::where('user_id',$user['_id'])->where('tras_id','!=',$transactionId)->where('tras_id','!=','')->where('status','active')->where('payment_status','Paid')->first();
            
            if($oldBillingHistoryPlan){
                $oldBillingHistoryPlan->status = 'expired';
                $oldBillingHistoryPlan->expiry_date = $purchaseDate;
                $oldBillingHistoryPlan->save();
            }
            $userBillingHistory->user_id = $user["_id"];
            $userBillingHistory->price = $data['price'] ?? 0;
            $userBillingHistory->tras_id = $transactionId ?? "";
            $userBillingHistory->org_tras_id = $data['original_transaction_id']  ?? "";
            $userBillingHistory->user_id = $user->_id;
            $userBillingHistory->status = 'active';
            $userBillingHistory->payment_status = 'Paid';
            if($plan->validity_type == "day"){
                $userBillingHistory->expiry_date = (new DateTime())->setTimestamp($purchaseAt)->modify('+7 days')->format('Y-m-d H:i:s');
                // $userBillingHistory->expiry_date = now()->addDays(7)->format('Y-m-d H:i:s');
            }else{
                $userBillingHistory->expiry_date = $purchaseDateWith3Months = (new DateTime())->setTimestamp($purchaseAt)->modify('+3 months')->format('Y-m-d H:i:s');
            }
            $userBillingHistory->plan_id = $plan->_id;
            $userBillingHistory->save();
        }
        Log::info('Handled Initial Purchase:', [
            'app_user_id' => $appUserId,
            'product_id' => $productId
        ]);
    }
    protected function handleCancellation($data)
    {
        $appUserId = $data['app_user_id'];
        
        $store = $data['store'];
        if($store == "PLAY_STORE"){
            $paymentType = "android";
        }else{
            $paymentType = "ios";
        }
        $user = User::where('app_user_id',$appUserId)->first();
        $expiryAt = $data['expiration_at_ms']/ 1000;
        $expiry_date= (new DateTime())->setTimestamp($expiryAt)->format('Y-m-d H:i:s');
        $cancellationReason = $data['cancel_reason'] ?? "";
        $expiration_reason = $data['expiration_reason'] ?? "";
      
        $productId = $data['product_id'];
        if (str_contains(strtolower($productId), 'basic')) {
            $plan = Plan::where('name','Basic')->first();
            $plan_id = $plan->_id;
        } else if (str_contains(strtolower($productId), 'premium')) {
            $plan = Plan::where('name','Premium')->first();
            $plan_id = $plan->_id;
        } else if (str_contains(strtolower($productId), 'ultra')) {
            $plan = Plan::where('name','Ultra')->first();
            $plan_id = $plan->_id;
        }else{
            $plan_id = "";
        }
      
        if($plan_id != ""){
            $user->active_trans_id = "" ;
            $user->payment_method =  $paymentType ?? "";
            $user->save();
         
            $userBillingHistory = UserBillingHistory::where('user_id',$user->_id)->where('org_tras_id',$data['original_transaction_id'])->where('status','active')->where('app_user_id',$appUserId)->first();
         
            if($userBillingHistory){
                $userBillingHistory->status = 'expired';
                $userBillingHistory->expiry_date = $expiry_date;
                $userBillingHistory->save();
            }
            $plan = new UserCancelPlan();
            $plan->user_id = $user->_id;
            $plan->plan_id = $plan_id;
            $plan->description = $cancellationReason != "" ? $cancellationReason : $expiration_reason;
            $plan->save();
        }
        Log::info('Handled Cancellation:', [
            'app_user_id' => $appUserId,
            'product_id' => $productId
        ]);
    }
    public function handleWebhook(Request $request)
    {
        // if (!$this->verifyRevenueCatSignature($request)) {
        //     return response()->json(['error' => 'Unauthorized'], 401);
        // }
        // Log the payload for debugging
        Log::info('RevenueCat Webhook Payload: ', $request->all());
     
        $eventDataWebhookType = $request->input('event_type');
        $eventDataWebhook = $request->input('event');
 
        $event = $eventDataWebhook;
       
        if( $event['store'] == "PLAY_STORE"){
            $eventType = $event['type'];
        }else if($event['type'] == "CANCELLATION" && $event['store'] == "APP_STORE"){
            $eventType = "CANCELLATION";
        }else{
            $eventType = 'INITIAL_PURCHASE';
        }
        
        switch ($eventType) {
            
            case 'INITIAL_PURCHASE':
                if ($eventType === 'INITIAL_PURCHASE') {
                    $this->handleInitialPurchase($event);
                }
                break;

            case 'PRODUCT_CHANGE': 
                if ($eventType === 'PRODUCT_CHANGE') {
                    $this->handleInitialPurchase($event);
                }
                break;
                
            case 'RENEWAL':
                if ($eventType === 'RENEWAL') {
                    $this->handleInitialPurchase($event);
                }
                break;

            case 'CANCELLATION':
                if ($eventType === 'CANCELLATION') {
                    $this->handleCancellation($event);
                }
                break;
            case 'UNSUBSCRIBE':
                if ($eventType === 'UNSUBSCRIBE') {
                    $this->handleCancellation($event);
                }
                // Handle subscription cancellation event
                break;
            case 'EXPIRATION':
                if ($eventType === 'EXPIRATION') {
                    $this->handleCancellation($event);
                }
                // Handle subscription cancellation event
                break;
            // Add more cases as needed

            default:
                Log::warning('Unhandled RevenueCat event type: ' . $eventType);
        }
        $eventData = new RevenuecatWebhook();
        $eventData->event = $eventDataWebhook;
        $eventData->event_type = $eventDataWebhookType;
        $eventData->save();
        // Return a response to RevenueCat
        return response()->json(['status' => 'success']);
    }
}