<?php

namespace App\Http\Controllers;

use App\Helpers\ApiResponse;
use App\Models\Country;
use Illuminate\Http\Request;
use GuzzleHttp\Client;

class CountryInfoController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api',['except' => ['index']]);
    }

    // function convertUtcOffsetToGmtOffset($utcOffset) {
   
    //     if (preg_match('/UTC([-+]\d{2}):(\d{2})/', $utcOffset, $matches)) {
    //         $hours = intval($matches[1]);
    //         $minutes = intval($matches[2]);

    //         // Calculate the total offset in minutes
    //         $totalOffsetMinutes = ($hours * 60) + $minutes;

    //         // Calculate the GMT offset as the negation of the UTC offset
    //         $gmtOffsetHours = -$hours;
    //         $gmtOffsetMinutes = -$minutes;

    //         return sprintf("GMT%+02d:%02d", $gmtOffsetHours, $gmtOffsetMinutes);
    //     } else {
    //         return "";
    //     }
    // }

    function convertUtcOffsetToGmtFormat($utcOffset) {
        
        // Split the UTC offset string to extract hours and minutes
        list($sign, $hours, $minutes) = sscanf($utcOffset, "UTC%c%d:%d");

        // Calculate the equivalent GMT offset in hours and minutes
        $gmtHours = ($sign === '-') ? -$hours : $hours;
        $gmtMinutes = ($sign === '-') ? -$minutes : $minutes;

        // Format the GMT offset as "(GMT ±HH:MM)"
        $formattedGmtOffset = "(GMT ";
        if ($gmtHours >= 0) {
            $formattedGmtOffset .= '+';
        } else {
            $formattedGmtOffset .= '-';
            $gmtHours = abs($gmtHours);
        }
        $formattedGmtOffset .= str_pad($gmtHours, 2, '0', STR_PAD_LEFT) . ':' . str_pad($gmtMinutes, 2, '0', STR_PAD_LEFT);
        $formattedGmtOffset .= ')';

        return $formattedGmtOffset;
    }

    public function index()
    {
        $client = new Client();
        $url = 'https://restcountries.com/v2/all'; // API endpoint for all countries

        try {
            $response = $client->get($url);
            $countriesData = json_decode($response->getBody(), true);
            $countryInfoList = [];
            foreach ($countriesData as $countryData) {
               // $countryName = $countryData['name'];

                $flagUrl = $countryData['flags']['svg']; // Assuming the first flag is the main flag
              //  $timeZones = $countryData['timezones'];
               $countryCode = $countryData['alpha2Code'];
               $country = Country::where('code',$countryCode)->where('flag_url','')->get();
               if($country->count() > 0){
                    foreach ($country as $c) {
                        $c->flag_url = $flagUrl ?? "";
                        $c->save();
                    }
               }
              
                // if (isset($timeZones) && is_array($timeZones)) {
                //     foreach ($timeZones as &$timeZone) {
                //         $timeZone = $this->convertUtcOffsetToGmtFormat($timeZone);
                //       //  $timeZone = $this->convertUtcOffsetToGmtOffset($timeZone);
                //        // $timeZone = $this->formatGmtOffset($timeZone);
                //       // $timeZone = $this->convertGmtOffset($timeZone);
                //     }
                // }
                // $countryInfoList[] = [
                //     'country_code' => $countryCode,
                //     'country_name' => $countryName,
                //     'flag_url' => $flagUrl,
                //     'time_zones' => $timeZones,
                // ];
            }
            return ApiResponse::success($countryInfoList,'Country detail fetch successfully');
        } catch (\Exception $e) {
            // Handle any errors that occur during the request
            return ApiResponse::error($e->getMessage());
        }
    }

    public function countryList(){

    }

    function convertGmtOffset($gmtOffset) {
            // Split the offset into hours and minutes
            list($sign, $hours, $minutes) = sscanf($gmtOffset, "GMT%c%d:%d");
    
            // Calculate the new GMT offset by subtracting 4 hours and 30 minutes
            $newHours = $hours - 4;
            $newMinutes = $minutes - 30;
    
            // Adjust the hours and minutes if necessary
            if ($newMinutes < 0) {
                $newHours -= 1;
                $newMinutes += 60;
            }
    
            // Format the new GMT offset
            $formattedOffset = "(GMT ";
            if ($sign === '-') {
                $formattedOffset .= '-';
            } else {
                $formattedOffset .= '+';
            }
            $formattedOffset .= abs($newHours);
            if ($newMinutes > 0) {
                $formattedOffset .= ':' . str_pad($newMinutes, 2, '0', STR_PAD_LEFT);
            }
            $formattedOffset .= ')';
    
            return $formattedOffset;
    }
    

}
