<?php

namespace App\Http\Controllers;

use Firebase\JWT\JWT;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class AppleAuthController extends Controller
{
    public function __construct()
    {
            $this->middleware('auth:api',['except' => ['verifyAppleToken']]);
    }
    public function verifyAppleToken(Request $request)
    {
        $identityToken = $request->input('identity_token');
        $identityToken = "eyJraWQiOiJyQlJmVm1xc2puIiwiYWxnIjoiUlMyNTYifQ.eyJpc3MiOiJodHRwczovL2FwcGxlaWQuYXBwbGUuY29tIiwiYXVkIjoiY29tLmRndC5maXNpby5xYSIsImV4cCI6MTczMzIwMjcxNCwiaWF0IjoxNzMzMTE2MzE0LCJzdWIiOiIwMDE0MjcuMzg0YWNjYzE0YjEyNGYwZWJiOTAxMjFhZmExOTVkYTYuMTMxMiIsImNfaGFzaCI6InQtYW9idlM3ekpiN201RnJFaFg5MmciLCJlbWFpbCI6Ijhibnd6cms4NmpAcHJpdmF0ZXJlbGF5LmFwcGxlaWQuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImlzX3ByaXZhdGVfZW1haWwiOnRydWUsImF1dGhfdGltZSI6MTczMzExNjMxNCwibm9uY2Vfc3VwcG9ydGVkIjp0cnVlfQ.SaGwYLy2GJ-0ahp99DUpO1deG4KfUvJdVk43pqS1jBog0tWmcFWuan92lB6UAA2fni1Ne6HXbK5Gm3fX7pkcVVWf3DYiRnVQ9eKhSZeSqjh1UANM-E5QRJrg6Wl3dF5Pcngumze5PFQ8eNkFg3UX0LHaWA3HOLALU8Qrs5RAgeVG0O_ibhwqhcLFlnj3Pa69HeHrgz5fLiTrsA3Tr3Yy6FxYrVyOFgg2FU4Ghli__q9lW1bN5gSoorVFGJSxMx1x9Vf1M-Gyp3KG5r5AGBtA1BYQ8ifPavi7kQDXWb6KE0o-0cadNLi4O3nglYcoqM5kz6hAxXxVlT2x-ddAB7DRbA";
        if (!$identityToken) {
            return response()->json(['error' => 'Identity token is required'], 400);
        }

        try {
            // Apple public keys URL
            $publicKeysUrl = 'https://appleid.apple.com/auth/keys';

            // Fetch Apple's public keys
            $client = new Client();
            $response = $client->get($publicKeysUrl);
            $keys = json_decode($response->getBody(), true);
            $parts = explode('.', $identityToken); // JWT has 3 parts: header, payload, signature
            if (count($parts) !== 3) {
                throw new \Exception('Invalid JWT format');
            }
            $header = json_decode(base64_decode($parts[0]), true);
            dd($header);
            $keyId = $header['kid'] ?? null;

            if (!$keyId) {
                throw new \Exception('Key ID (kid) not found in token header');
            }

            // Find the correct public key
            $publicKeyData = null;
            foreach ($keys['keys'] as $key) {
                if ($key['kid'] === $keyId) {
                    $publicKeyData = $key;
                    break;
                }
            }

            if (!$publicKeyData) {
                return response()->json(['error' => 'Public key not found'], 400);
            }
         
            // Generate the public key
            $publicKey = $this->generatePublicKey($publicKeyData);
            // Decode and verify the identity token

            dd($publicKey);
            $decodedToken = \Firebase\JWT\JWT::decode($identityToken, new \Firebase\JWT\Key($publicKey, 'RS256'));
            dd($decodedToken);
            // Access user information
            $email = $decodedToken->email ?? null;







            // Decode the JWT header to get the key ID (kid)
            //$header = JWT::decode($identityToken, null, ['RS256']);
            //dd($header);
            $keyId = $header->kid;

            // Find the correct public key
            $publicKey = null;
            foreach ($keys['keys'] as $key) {
                if ($key['kid'] == $keyId) {
                    $publicKey = $key;
                    break;
                }
            }

            if (!$publicKey) {
                return response()->json(['error' => 'Public key not found'], 400);
            }

            // Decode and verify the identity token
            $decodedToken = JWT::decode($identityToken, $publicKey, ['RS256']);

            // You can now access the decoded user information, like email
            $email = $decodedToken->email;
            dd($email);
            // Handle the verified data (e.g., create a user or update an existing user)
            // For example, find or create a user:
            $user = \App\Models\User::firstOrCreate(
                ['email' => $email],
                ['name' => $decodedToken->name]
            );

            // Return a response with user information
            return response()->json(['user' => $user], 200);

        } catch (\Exception $e) {
            return response()->json(['error' => 'Token verification failed', 'message' => $e->getMessage()], 400);
        }
    }
    // private function generatePublicKey($keyData)
    // {
    //     $publicKey = "-----BEGIN PUBLIC KEY-----\n";
    //     $publicKey .= chunk_split($keyData['n'], 64, "\n");
    //     $publicKey .= "-----END PUBLIC KEY-----";
    //     return $publicKey;
    // }
    private function generatePublicKey($keyData)
    {
        $pem = 
            "-----BEGIN PUBLIC KEY-----\n" .
            chunk_split(base64_encode(
                $this->generateKeyModulusExponent($keyData['n'], $keyData['e'])
            ), 64, "\n") .
            "-----END PUBLIC KEY-----\n";
        return $pem;
    }

    private function generateKeyModulusExponent($modulus, $exponent)
    {
        $modulus = base64_decode($modulus);
        $exponent = base64_decode($exponent);

        // Construct a binary sequence as per PKCS#1 spec
        $components = [
            'modulus' => $this->encodeLength(strlen($modulus)) . $modulus,
            'exponent' => $this->encodeLength(strlen($exponent)) . $exponent
        ];

        $sequence = "\x30" . $this->encodeLength(strlen($components['modulus'] . $components['exponent']))
            . $components['modulus']
            . $components['exponent'];

        return "\x30" . $this->encodeLength(strlen($sequence)) . $sequence;
    }

    private function encodeLength($length)
    {
        if ($length < 128) {
            return chr($length);
        }

        $temp = '';
        while ($length > 0) {
            $temp = chr($length & 0xff) . $temp;
            $length >>= 8;
        }

        return chr(0x80 | strlen($temp)) . $temp;
    }
}
