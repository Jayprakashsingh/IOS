<?php

namespace App\Console\Commands;

use App\Models\CategoryType;
use App\Models\Country;
use App\Models\LogEntry;
use App\Models\Session;
use App\Models\User;
use App\Models\UserTrainingStreak;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use DateTime;
use Exception;

class TestUpdateStreakAndMulligan extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:test-streak-and-mulligan';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'User earns a "mulligan" (that is a day where he/she does not train, but does not lose his/her streak) after every 2 consecutive days of training.';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try{
            Log::channel('test-upgrade-mulligan-streak')->info('Date -'.Carbon::now());
            $today = now()->format('Y-m-d');
            //->where('userid',158)
            //419,519,
            $users = User::where('user_type','user')->whereIn('userid',[547,419,519,294])->where('country_id','!=',NULL)->where('country_id','!=',"")->get();
          
            if($users->count() > 0){
                $countries = Country::pluck('timezone','_id')->toArray();
                foreach ($users as $user) {
                    Log::channel('test-upgrade-mulligan-streak')->info("User -{$user->userid} - {$user->full_name}");
                    $timezone = $countries[$user->country_id] ?? 'UTC';
                    $currentDateTime = Carbon::now($timezone);
                    $today = $currentDateTime->format('Y-m-d');
                    $currentHour = $currentDateTime->format('H');
                    $yesterdayDay =  Carbon::now($timezone)->subDay();
                    $yesterdayDate = $yesterdayDay->format('Y-m-d');
                  
                    if((int)$currentHour >= 23){
                        $dates = collect(range(0, 1))->map(fn($i) => $yesterdayDay->copy()->subDays($i)->format('Y-m-d'))->all();
                  
                        $userStreakLast7Days = UserTrainingStreak::where('user_id',$user->userid)->where('mulligan',0)->whereIn('date',$dates)->get();
                        
                        Log::channel('test-upgrade-mulligan-streak')->info('Checking user session completion for last 2 days');
                    
                        if($userStreakLast7Days->count() == 2){
                            Log::channel('test-upgrade-mulligan-streak')->info('User qualifies for mulligan after training 2 consecutive days');
                            $reversedDates = array_reverse($dates);
                            $userTrainingStreak = UserTrainingStreak::where('user_id',$user->userid)->where('date',$reversedDates[0])->first();
                            $correctStreak =$userTrainingStreak->current_streak ?? 0;
                            $correctResult = 0;
                            foreach ($reversedDates as $date) {
                                $userTrainingStreak = UserTrainingStreak::where('user_id',$user->userid)->where('date',$date)->where('current_streak',$correctStreak)->first();
                                $correctStreak++;
                                if($userTrainingStreak){
                                    $correctResult++;
                                }
                            }
                         
                            if($correctResult == 2){
                                $userTrainingStreak = UserTrainingStreak::where('user_id',$user->userid)->where('date',$today)->first();
                                
                                if($userTrainingStreak){
                                }else{
                                    $userTrainingStreakYesterday = UserTrainingStreak::where('user_id',$user->userid)->where('date',$yesterdayDate)->first();
                                    $userTrainingStreak = new UserTrainingStreak();
                                    $userTrainingStreak->user_id = $user->userid;
                                    $userTrainingStreak->current_streak =  $userTrainingStreakYesterday->current_streak;
                                    $userTrainingStreak->date = $today;
                                }
                                $userTrainingStreak->mulligan = 1;
                                $userTrainingStreak->save();
                                Log::channel('test-upgrade-mulligan-streak')->info('training performed and mulligan assigned');
                                // if($userTrainingStreak->current_streak > ($user->max_training_streak ?? 0) ){
                                //     $user->max_training_streak = $userTrainingStreak->current_streak;
                                // }else{
                                //     $user->max_training_streak = $user->max_training_streak ?? 0;
                                // }
                                // $user->training_streak = $userTrainingStreak->current_streak;
                                // $user->mulligan = 1;
                                // $user->last_updated_training_streak = $today;
                                // $user->save();
                            }else{
                                Log::channel('test-upgrade-mulligan-streak')->info('streak was not continous increased till 2');
                            }
                        }else{
                            $userTrainingStreak = UserTrainingStreak::where('user_id',$user->userid)->where('date',$today)->first();
                            if($userTrainingStreak){
                            }else{
                                $userTrainingStreak = new UserTrainingStreak();
                                $userTrainingStreakYesterday = UserTrainingStreak::where('user_id',$user->userid)->where('date',$yesterdayDate)->first();
                                if( $user->mulligan == 1){
                                    $userTrainingStreak->current_streak =  $userTrainingStreakYesterday->current_streak;
                                 
                                }else{
                                    $userTrainingStreak->current_streak = 0;
                                }
                                $userTrainingStreak->user_id = $user->userid;
                                $userTrainingStreak->date = $today;
                                //$userTrainingStreak->current_streak = 0;
                                $userTrainingStreak->mulligan = 0;
                                $userTrainingStreak->save();
                                // Log::channel('test-upgrade-mulligan-streak')->info('Made user current streak as 0');
                            }
                            // if($userTrainingStreak->current_streak > ($user->max_training_streak ?? 0) ){
                            //     $user->max_training_streak = $userTrainingStreak->current_streak;
                            // }else{
                            //     $user->max_training_streak = $user->max_training_streak ?? 0;
                            // }
                            // $user->training_streak = $userTrainingStreak->current_streak;
                            // $user->last_updated_training_streak = $today;
                            // $user->save();
                        }
                        //new code for todays entry
                        $userStreakToday = UserTrainingStreak::where('user_id',$user->userid)->where('date',$today)->first();
                        if(!$userStreakToday){
                            $userStreakToday = new UserTrainingStreak();
                            $userStreakToday->user_id = $user->userid;
                            $userStreakToday->date = $today;
                            $userStreakToday->current_streak = 0;
                            $userStreakToday->mulligan = 0;
                            $userStreakToday->save();
                        }
                        $user->training_streak = $userStreakToday->current_streak;
                        if($userStreakToday->current_streak > ($user->max_training_streak ?? 0) ){
                            $user->max_training_streak = $userStreakToday->current_streak;
                        }else{
                            $user->max_training_streak = $user->max_training_streak ?? 0;
                        }
                        $user->mulligan = $userStreakToday->mulligan;
                        $user->last_updated_training_streak = $today;
                        $user->save();
                    }

                }
            }
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Upgrade Streak and Mulligan";
            $logEntry->type =  'info'; 
            $logEntry->message = 'Command executed successfully.';
            $logEntry->save();
        } catch (Exception $e) {
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Upgrade Streak and Mulligan";
            $logEntry->type =  'error';
            $logEntry->message = 'Error executing command: ' . $e->getMessage();
            $logEntry->save();
        }
        
    }
}
