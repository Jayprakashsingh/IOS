<?php

namespace App\Console\Commands;

use App\Models\CategoryType;
use App\Models\Country;
use App\Models\Group;
use App\Models\LogEntry;
use App\Models\Session;
use App\Models\Unit;
use App\Models\User;
use App\Models\UserSessionProgress;
use App\Models\UserUnlockedSession;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class UnlockUserSession extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'unlock:session';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'A user unlocks 1 session every day';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try {
            Log::channel('unlock-session')->info('Date -'.Carbon::now());
            $countries = Country::pluck('timezone','_id')->toArray();
            //->where('_id','65fd630546ace44cb3082788')
            //->where('_id','65a7c58ede044e2a9b034e69')
            $defaultProgram = env('DEFAULT_PROGRAM');
            $users = User::where('user_type','user')->where('country_id','!=',NULL)->where('country_id','!=',"")->get();
            $groupUnitIds = array_column(Group::where('group_name', $defaultProgram)->first()["group_object"], "object_id");
                
            foreach ($users as $user) { 
                // Check if the user has logged in today and it's before 8 PM in their timezone
                if(!empty($user->country_id) ){
                    $userTimezone = $countries[$user->country_id];
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                    if (!empty($user->group_id) && $group = Group::find($user->group_id)) {
                        $groupUnitIds = array_column($group["group_object"], "object_id");
                    }
                    $unitCollectionData = Unit::whereIn('_id', $groupUnitIds)
                                            ->where('category_type_id','64870ab2514154525c6bdb29')
                                            ->get()
                                            ->sortBy(function ($item) use ($groupUnitIds) {
                                                return array_search($item['_id'], $groupUnitIds);
                                            });
                    $unitProgress = $unitCollectionData;
                    $j=0;
                    foreach ($unitProgress as $key => $unit) {
                        foreach ($unit->unit_object as $key => $session) {
                            $unit_id = $unit->id;
                            $session_id = $session['object_id'];
                            $user_id = $user->_id;
                            $userSessionUnlockedToday = UserUnlockedSession::where('user_id',$user_id)->orderBy('created_at','desc')->first();
                            if($userSessionUnlockedToday){
                                $userSessionUnlocked = UserUnlockedSession::where('user_id',$user_id)->where('unit_id',$unit_id)->where('session_id',$session_id)->orderBy('created_at','desc')->first();
                                if($userSessionUnlocked){
                                }else{
                                    if($userSessionUnlockedToday->date != $currentDateInUserTimezone && !$this->isToday($userSessionUnlockedToday->created_at, $userTimezone)){                                            
                                        $userUnlockedSession = new UserUnlockedSession();
                                        $userUnlockedSession->user_id = $user_id;
                                        $userUnlockedSession->unit_id = $unit_id;
                                        $userUnlockedSession->session_id = $session_id;
                                        $userUnlockedSession->date = $currentDateInUserTimezone;
                                        $userUnlockedSession->save();
                                        $j=1;
                                        break;
                                    }else{
                                        Log::channel('unlock-session')->info('user session already unlocked for today for user - - '.$user->userid);
                                    }
                                }
                            }else{
                                $userUnlockedSession = new UserUnlockedSession();
                                $userUnlockedSession->user_id = $user_id;
                                $userUnlockedSession->unit_id = $unit_id;
                                $userUnlockedSession->session_id = $session_id;
                                $userUnlockedSession->date = $currentDateInUserTimezone;
                                $userUnlockedSession->save();
                                $j=1;
                                break;
                            }
                        }
                        if($j == 1){
                            break;
                        }
                    }
                }
            }
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Unlock Session";
            $logEntry->type =  'info';
            $logEntry->message = 'Command executed successfully.';
            $logEntry->save();
        } catch (Exception $e) {
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Unlock Session";
            $logEntry->type =  'error';
            $logEntry->message = 'Error executing command: ' . $e->getMessage();
            $logEntry->save();
        }
        
    }
    private function isToday($date, $timezone)
    {
        return Carbon::parse($date, $timezone)->isToday();
    }
}
