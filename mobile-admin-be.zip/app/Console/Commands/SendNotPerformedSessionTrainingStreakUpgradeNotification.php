<?php

namespace App\Console\Commands;

use App\Models\CategoryType;
use App\Models\Country;
use App\Models\LogEntry;
use App\Models\Notification;
use App\Models\Session;
use App\Models\User;
use App\Models\UserFcmToken;
use App\Models\UserSessionProgress;
use App\Models\UserTrainingStreak;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use DateTimeZone;
use Exception;
use Google\Client;
use Illuminate\Support\Facades\Log;

class SendNotPerformedSessionTrainingStreakUpgradeNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:not-trained-streak-reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send push notification to user as they have not performed any training session today they need to do to update their streak';

    /**
     * Execute the console command.  
     *
     * @return int
     */

    public function handle()
    {
        try{
            Log::channel('not-trained-streak-reminder')->info('Date -'.Carbon::now());
            $type = "End of Day - Not Yet Trained Reminder";
           // $userIds = User::where('skip_reminder',true)->pluck('_id')->toArray();
            $users = User::where('user_type','user')->where('skip_reminder',false)->where('fcm_token','!=',NULL)->where('fcm_token','!=',"")->where('country_id','!=',NULL)->where('country_id','!=',"")->get();
            if($users->count() > 0){
                $countries = Country::pluck('timezone','_id')->toArray();
                foreach ($users as $user) {
                    $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();

                    Log::channel('not-trained-streak-reminder')->info('User -'.$user->userid.' - '.$user->full_name);
                    $timezone = $countries[$user->country_id];
                    $currentDateTime = Carbon::now($timezone);
                    $currentHour = $currentDateTime->format('H');
                    $today = $currentDateTime->format('Y-m-d');
                    $yesterdayDate = $currentDateTime->subDay()->format('Y-m-d');
                    
                    Log::channel('not-trained-streak-reminder')->info('Hour - '.$currentHour);
                 
                    if((int)$currentHour >= 19){
                        $userTrainingStreak = UserTrainingStreak::where('user_id',$user->userid)->where('current_streak','>',0)->where('date',$today)->first();
                    
                        if($userTrainingStreak){
                            Log::channel('not-trained-streak-reminder')->info('User Has performed training session and updated streak today');
                        }else{
                            $userTrainingStreakData = UserTrainingStreak::where('user_id',$user["userid"])->where('date',$yesterdayDate)->first();
                           
                            $old_training_streak = $userTrainingStreakData->current_streak ?? 0;
                            $training_streak = $old_training_streak + 1;
                            $title = $body = "Extend your Fisio™ training streak from ".$old_training_streak." to ".$training_streak." by completing your next session before midnight.";
                            
                            $notification = Notification::where('user_id',$user->userid)->where('type',$type)->orderBy('created_at','desc')->first();
                            if($notification){
                                if(!$this->isToday($notification->created_at, $timezone)){
                                    if($userFcmTokens->count() > 0){
                                        foreach ($userFcmTokens as $userFcmToken) {
                                            $messageId = "";
                                            $response = $this->sendNotification($userFcmToken,$title,$body);
                                            if (isset($response['name'])) {
                                                // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                                $MessageData = explode('/',$response['name']);
                                                $messageId = $MessageData[3] ?? "";
                                            }
                                            if ($messageId != "") {
                                                $notification = new Notification();
                                                $notification->type = $type;
                                                $notification->title = $title;
                                                $notification->description = $body;
                                                $notification->user_id = $user->userid;
                                                $notification->is_read = false;
                                                $notification->save();
                                                Log::channel('not-trained-streak-reminder')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                            }else{
                                                Log::channel('not-trained-streak-reminder')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                            }
                                        }
                                    }else{
                                        $messageId = "";
                                        $response = $this->sendNotification($user->fcm_token,$title,$body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->type = $type;
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('not-trained-streak-reminder')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('not-trained-streak-reminder')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                        }
                                    }
                                    
                                }else{
                                    Log::channel('not-trained-streak-reminder')->info('Push notification already sent for today for --'.$user->full_name . " - ".$user->userid); 
                                }
                            }else{
                                if($userFcmTokens->count() > 0){
                                    foreach ($userFcmTokens as $userFcmToken) {
                                        $messageId = "";
                                        $response = $this->sendNotification($userFcmToken,$title,$body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->type = $type;
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('not-trained-streak-reminder')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('not-trained-streak-reminder')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                        }
                                    }
                                }else{
                                    $messageId = "";
                                    $response = $this->sendNotification($user->fcm_token,$title,$body);
                                    if (isset($response['name'])) {
                                        // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                        $MessageData = explode('/',$response['name']);
                                        $messageId = $MessageData[3] ?? "";
                                    }
                                    if ($messageId != "") {
                                        $notification = new Notification();
                                        $notification->type = $type;
                                        $notification->title = $title;
                                        $notification->description = $body;
                                        $notification->user_id = $user->userid;
                                        $notification->is_read = false;
                                        $notification->save();
                                        Log::channel('not-trained-streak-reminder')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                    }else{
                                        Log::channel('not-trained-streak-reminder')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                    }
                                }
                                
                            }
                        }
                    }else{
                        Log::channel('not-trained-streak-reminder')->info('user not have 7pm yet');
                    }
                }
            }else{
                Log::channel('not-trained-streak-reminder')->info('user has not selected timezone or not have device token registered .');
            }
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Not Yet trained Streak Reminder";
            $logEntry->type =  'info';
            $logEntry->message = 'Command executed successfully.';
            $logEntry->save();
        } catch (Exception $e) {
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Not Yet trained Streak Reminder";
            $logEntry->type = 'error';
            $logEntry->message = 'Error executing command: ' . $e->getMessage();
            $logEntry->save();
        }
            
    }
    private function getAccessToken($serviceAccountPath) {
        $client = new Client();
        $client->setAuthConfig($serviceAccountPath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->useApplicationDefaultCredentials();
        $token = $client->fetchAccessTokenWithAssertion();
        return $token['access_token'];
    }
    private function sendNotification($fcmToken, $title,$body)
    {
        Log::channel('upcoming-session')->info('In Send Notification Code');
        $projectId = env('FCM_PROJECT_ID');
        $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
        $serviceAccountPath = storage_path(env('GOOGLE_SERVICE_ACCOUNT_PATH'));
        $accessToken = $this->getAccessToken($serviceAccountPath);

        $headers = [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ];
        $message = [
            'token' => $fcmToken,
            'notification' => [
            'title' => $title,
            'body' => $body,
            ],
           ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['message' => $message]));
        $response = curl_exec($ch);
         if ($response === false) {
         throw new Exception('Curl error: ' . curl_error($ch));
         }
        curl_close($ch);
        return json_decode($response, true);
    }
}
