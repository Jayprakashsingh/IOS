<?php

namespace App\Console\Commands;

use App\Models\CategoryType;
use App\Models\Country;
use App\Models\Notification;
use App\Models\Session;
use App\Models\User;
use App\Models\UserFcmToken;
use App\Models\UserSessionProgress;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use DateTimeZone;
use Exception;
use Google\Client;
use Illuminate\Support\Facades\Log;

class SendNotPerformedSessionNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:not-performed-session-notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send push notification to user as they have not performed any training session today';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handleOld()
    {
        Log::channel('not-performed-session-notification')->info('Date -'.Carbon::now());

        $startOfDay = Carbon::today()->startOfDay();
        $endOfDay = Carbon::today()->endOfDay();
        $categoryTypeIdForTrainingSession = CategoryType::where('name','Train')->pluck('_id');
       
        if(!empty($categoryTypeIdForTrainingSession[0])){
            $trainingSessionIds = Session::where('category_type_id',$categoryTypeIdForTrainingSession[0])->pluck('_id')->toArray();
        }else{
            $trainingSessionIds = [];
        }
       
        $userSessionProgress = UserSessionProgress::whereIn('session_id',$trainingSessionIds)->where('created_at', '>=', $startOfDay)
                                ->where('created_at', '<=', $endOfDay)->groupBy('user_id')->pluck('user_id')->toArray();
        $notificationHavingUsers = Notification::where('created_at', '>=', $startOfDay)->where('created_at', '<=', $endOfDay)
                                    ->where( "title", "It’s not too late to train today!")
                                    ->pluck('user_id')->toArray();
        $usersQ = User::where('user_type','user')->whereNotIn('_id',$userSessionProgress)->where('fcm_token','!=',NULL)->where('fcm_token','!=',""); // Get users who have not performed any activity today
     
        if(!empty($notificationHavingUsers)){
            $usersQ = $usersQ->whereNotIn('userid',$notificationHavingUsers);
        }
        $users = $usersQ->get();
        if($users->count() > 0){
            foreach ($users as $user) {
                $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();
                // if(!empty($user->fcm_token)){
                    $title = "It’s not too late to train today!";
                    $body = "It’s not too late to train today!";
                   
                    if($user->country_id != ""){
                        Log::channel('not-performed-session-notification')->info('User HERE__________________ '.$user->full_name );
                        $timezone = Country::find($user->country_id)->timezone ?? "";
                     
                        if($timezone != ""){
                            Log::channel('not-performed-session-notification')->info('User - '.$user->name);
                            $timezone1 = new DateTimeZone($timezone);
                            $currentTime = new DateTime("now", $timezone1);
                            $hour = $currentTime->format('H');
                           
                            if((int)$hour == 22){
                                if($userFcmTokens->count() > 0){
                                    foreach ($userFcmTokens as $userFcmToken) {
                                        $messageId = "";
                                        $response = $this->sendNotification($userFcmToken,$user->device_type,$title,$body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                        }
                                    }
                                }else{
                                    $messageId = "";
                                    $response = $this->sendNotification($user->fcm_token,$user->device_type,$title,$body);
                                    if (isset($response['name'])) {
                                        // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                        $MessageData = explode('/',$response['name']);
                                        $messageId = $MessageData[3] ?? "";
                                    }
                                    if ($messageId != "") {
                                        $notification = new Notification();
                                        $notification->title = $title;
                                        $notification->description = $body;
                                        $notification->user_id = $user->userid;
                                        $notification->is_read = false;
                                        $notification->save();
                                        Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                    }else{
                                        Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                    }
                                }
                            }
                        }else{
                            Log::channel('not-performed-session-notification')->info('User not selected timezone for notification '.$user->full_name );
                        }
                    }else{
                        Log::channel('not-performed-session-notification')->info('User not selected timezone for notification'.$user->full_name);
                    }
                // }else{
                //     Log::channel('not-performed-session-notification')->info('User device token missing');
                // }
            }
        }else{
            Log::channel('not-performed-session-notification')->info('All user have performed training session today.');
        }
    }

    public function handle()
    {
        Log::channel('not-performed-session-notification')->info('Date -'.Carbon::now());
        $title = $body = "It’s not too late to train today!";
        $categoryTypeIdForTrainingSession = CategoryType::where('name','Train')->pluck('_id');
        if(!empty($categoryTypeIdForTrainingSession[0])){
            $trainingSessionIds = Session::where('category_type_id',$categoryTypeIdForTrainingSession[0])->pluck('_id')->toArray();
        }else{
            $trainingSessionIds = [];
        }
        
        $users = User::where('user_type','user')->where('fcm_token','!=',NULL)->where('fcm_token','!=',"")->where('country_id','!=',NULL)->where('country_id','!=',"")->get();
        if($users->count() > 0){
            $countries = Country::pluck('timezone','_id')->toArray();
            
            foreach ($users as $user) {
                $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();
                $timezone = $countries[$user->country_id];
               
                $currentDateTime = Carbon::now($timezone);
                $formattedCurrentDate = $currentDateTime->format('Y-m-d');
                $currentHour = $currentDateTime->format('H');
               
                $userSessionProgress = UserSessionProgress::whereIn('session_id',$trainingSessionIds)->where('user_id',$user->_id)->orderBy('created_at','desc')->first();
                $notification = Notification::where('user_id',$user->userid)->where('description',$body)->orderBy('created_at','desc')->first();
               
                if($userSessionProgress){
                    //dd($userSessionProgress->created_at);
                    $createdAtInTimezone1 = $userSessionProgress->created_at->setTimezone($timezone);
                    $formattedDate1 = $createdAtInTimezone1->format('Y-m-d');
                    if($formattedDate1 == $formattedCurrentDate){
                        Log::channel('not-performed-session-notification')->info('User already performed training session today --'.$user->full_name . " - ".$user->userid); 
                    }else{
                        if($notification){
                            $createdAtInTimezone = $notification->created_at->setTimezone($timezone);
                            $formattedDate = $createdAtInTimezone->format('Y-m-d');
                           
                            if($formattedDate == $formattedCurrentDate){
                                Log::channel('not-performed-session-notification')->info('Push notification already sent for today for --'.$user->full_name . " - ".$user->userid); 
                            }else{
                                if((int)$currentHour == 22){
                                    if($userFcmTokens->count() > 0){
                                        foreach ($userFcmTokens as $userFcmToken) {
                                            $messageId = "";
                                            $response = $this->sendNotification($userFcmToken,$user->device_type,$title,$body);
                                            if (isset($response['name'])) {
                                                // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                                $MessageData = explode('/',$response['name']);
                                                $messageId = $MessageData[3] ?? "";
                                            }
                                            if ($messageId != "") {
                                                $notification = new Notification();
                                                $notification->title = $title;
                                                $notification->description = $body;
                                                $notification->user_id = $user->userid;
                                                $notification->is_read = false;
                                                $notification->save();
                                                Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                            }else{
                                                Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                            }
                                        }
                                    }else{
                                        $messageId = "";
                                        $response = $this->sendNotification($user->fcm_token,$user->device_type,$title,$body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                        }
                                    }
                                    
                                }
                            }
                        }else{
                            if((int)$currentHour == 22){
                                $response = $this->sendNotification($user->fcm_token,$user->device_type,$title,$body);
                                if (isset($response['name'])) {
                                    // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                    $MessageData = explode('/',$response['name']);
                                    $messageId = $MessageData[3] ?? "";
                                } else {
                                    // echo 'Error in response: ' . $response;
                                    $messageId = "";
                                }
                                if ($messageId != "") {
                                    $notification = new Notification();
                                    $notification->title = $title;
                                    $notification->description = $body;
                                    $notification->user_id = $user->userid;
                                    $notification->is_read = false;
                                    $notification->save();
                                    Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                }else{
                                    Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                }
                            }
                        }
                    }
                }else{
                    if($notification){
                        $createdAtInTimezone = $notification->created_at->setTimezone($timezone);
                        $formattedDate = $createdAtInTimezone->format('Y-m-d');
                        if($formattedDate == $formattedCurrentDate){
                            Log::channel('not-performed-session-notification')->info('Push notification already sent for today for --'.$user->full_name . " - ".$user->userid); 
                        }else{
                            if((int)$currentHour == 22){
                                $response = $this->sendNotification($user->fcm_token,$user->device_type,$title,$body);
                                if (isset($response['name'])) {
                                    // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                    $MessageData = explode('/',$response['name']);
                                    $messageId = $MessageData[3] ?? "";
                                } else {
                                    // echo 'Error in response: ' . $response;
                                    $messageId = "";
                                }
                                if ($messageId != "") {
                                    $notification = new Notification();
                                    $notification->title = $title;
                                    $notification->description = $body;
                                    $notification->user_id = $user->userid;
                                    $notification->is_read = false;
                                    $notification->save();
                                    Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                }else{
                                    Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                                }
                            }
                        }
                    }else{
                        if((int)$currentHour == 22){
                            $response = $this->sendNotification($user->fcm_token,$user->device_type,$title,$body);
                            if (isset($response['name'])) {
                                // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                $MessageData = explode('/',$response['name']);
                                $messageId = $MessageData[3] ?? "";
                            } else {
                                // echo 'Error in response: ' . $response;
                                $messageId = "";
                            }
                            if ($messageId != "") {
                                $notification = new Notification();
                                $notification->title = $title;
                                $notification->description = $body;
                                $notification->user_id = $user->userid;
                                $notification->is_read = false;
                                $notification->save();
                                Log::channel('not-performed-session-notification')->info('Push notifications sent to user-'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                            }else{
                                Log::channel('not-performed-session-notification')->info('Notification could not be sent to user-'.$user->userid." -- ". $response); // There was an issue with sending the notification
                            }
                        }
                    }
                }
            }
        }else{
            Log::channel('not-performed-session-notification')->info('user has not selected timezone or not have device token registered .');
        }
       
    
       
        
    }
    private function getAccessToken($serviceAccountPath) {
        $client = new Client();
        $client->setAuthConfig($serviceAccountPath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->useApplicationDefaultCredentials();
        $token = $client->fetchAccessTokenWithAssertion();
        return $token['access_token'];
    }
    private function sendNotification($fcmToken,$device_type, $title,$body)
    {
        
        Log::channel('upcoming-session')->info('In Send Notification Code');
        $projectId = env('FCM_PROJECT_ID');
        $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
        $serviceAccountPath = storage_path(env('GOOGLE_SERVICE_ACCOUNT_PATH'));
        $accessToken = $this->getAccessToken($serviceAccountPath);

        $headers = [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ];
        $message = [
            'token' => $fcmToken,
            'notification' => [
                'title' => $title,
                'body' => $body,
            ],
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['message' => $message]));
        $response = curl_exec($ch);
        if ($response === false) {
            throw new Exception('Curl error: ' . curl_error($ch));
        }
        curl_close($ch);
        return json_decode($response, true);
    }
}
