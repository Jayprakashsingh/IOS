<?php

namespace App\Console\Commands;

use App\Models\Country;
use App\Models\LogEntry;
use App\Models\Notification;
use App\Models\Swing;
use App\Models\User;
use App\Models\UserRecallCardUpdate;
use App\Models\UserSessionProgress;
use App\Models\UserShotCheck;
use App\Models\UserTrustHole;
use Carbon\Carbon;
use Exception;
use Google\Client;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class CheckUserLoginStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:user-status-sunday';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'If user did not do anything he will get a notification at 8pm time  to fill up the survey';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try {
            //command logic start
            $title = "How's it Going?";
            $body = "How are you feeling about your Fisio™ training?";
            Log::channel('user-status-sunday')->info('Date -'.Carbon::now());
            $countries = Country::pluck('timezone','_id')->toArray();
            $users = User::where('user_type','user')->where('fcm_token','!=',NULL)->where('fcm_token','!=',"")->where('country_id','!=',NULL)->where('country_id','!=',"")->get();
            foreach ($users as $user) {
                // Check if the user has logged in today and it's before 8 PM in their timezone
                if(!empty($user->country_id) ){
                    $userTimezone = $countries[$user->country_id];
                    $currentDateInUserTimezone = Carbon::now($userTimezone)->format('Y-m-d');
                    $notifications = Notification::where('user_id',$user->userid)->where('title',$title)->get();
                
                    if($notifications->count() > 0){
                    
                        $filteredNotification = $notifications->filter(function ($notification) use ($userTimezone, $currentDateInUserTimezone) {
                            $createdAtInUserTimezoneNotification = Carbon::parse($notification->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                            return $createdAtInUserTimezoneNotification === $currentDateInUserTimezone;
                        });
                        if($filteredNotification->count() > 0){
                            Log::channel('user-status-sunday')->info('user already got this notification --'.$user->full_name. " - ".$user->userid);
                        }else{
                            //dd($user->last_login_at && !$this->isToday($user->last_login_at, $user->timezone));
                            if ($user->last_login_at && !$this->isToday($user->last_login_at, $user->timezone)) {
                                //if (Carbon::now($userTimezone)->isSunday() && Carbon::now($userTimezone)->hour >= 20) {
                                if (Carbon::now($userTimezone)->isSunday() && Carbon::now($userTimezone)->hour >= 20) {
                                    $response = $this->sendNotification($user->fcm_token,$title,$body);
                                    if (isset($response['name'])) {
                                        // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                        $MessageData = explode('/',$response['name']);
                                        $messageId = $MessageData[3] ?? "";
                                    } else {
                                        // echo 'Error in response: ' . $response;
                                        $messageId = "";
                                    }
                                    if ($messageId != "") {
                                        $notification = new Notification();
                                        $notification->title = $title;
                                        $notification->description = $body;
                                        $notification->user_id = $user->userid;
                                        $notification->is_read = false;
                                        $notification->save();
                                        Log::channel('user-status-sunday')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                    }else{
                                        Log::channel('user-status-sunday')->info('Notification could not be sent'); // There was an issue with sending the notification
                                    }
                                    $this->info("User {$user->name} (ID: {$user->id}) has not logged in today before 8 PM on Sunday in their timezone.");
                                }else{
                                    Log::channel('user-status-sunday')->info('Not a sunday');
                                }
                            }else{
                                $actionPerformed = 0;
                                Log::channel('user-status-sunday')->info("User {$user->name} (ID: {$user->id})  logged in today");
                                //check if user has performed any action
                                $usersProgress = UserSessionProgress::where('user_id',$user->_id)->get();
                                if($usersProgress->count() > 0){
                                    $filteredUsersProgress = $usersProgress->filter(function ($progress) use ($userTimezone, $currentDateInUserTimezone) {
                                        // Convert created_at to the user's timezone
                                        $createdAtInUserTimezoneUsersProgress = Carbon::parse($progress->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                        // Check if the created_at date matches the user's current date
                                        return $createdAtInUserTimezoneUsersProgress === $currentDateInUserTimezone;
                                    });
                                    if($filteredUsersProgress->count() > 0){
                                        $actionPerformed = $actionPerformed + 1;
                                    }
                                }
                                if($actionPerformed == 0){    
                                    $trustShots = UserTrustHole::where('user_id',$user->userid)->get();
                                
                                    if($trustShots->count() > 0){
                                        $filteredTrustShots = $trustShots->filter(function ($trustShot) use ($userTimezone, $currentDateInUserTimezone) {
                                            // Convert created_at to the user's timezone
                                            $createdAtInUserTimezoneTrustShot = Carbon::parse($trustShot->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                            // Check if the created_at date matches the user's current date
                                            return $createdAtInUserTimezoneTrustShot === $currentDateInUserTimezone;
                                        });
                                    
                                        if($filteredTrustShots->count() > 0){
                                            $actionPerformed = $actionPerformed + 1;
                                        }
                                    }
                                }
                                if($actionPerformed == 0){
                                    $shotChecks = UserShotCheck::where('user_id',$user->userid)->get();
                                    if($shotChecks->count() > 0 ){
                                        $filteredShotChecks = $shotChecks->filter(function ($shotCheck) use ($userTimezone, $currentDateInUserTimezone) {
                                            $createdAtInUserTimezoneShotCheck = Carbon::parse($shotCheck->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                            return $createdAtInUserTimezoneShotCheck === $currentDateInUserTimezone;
                                        });
                                        if($filteredShotChecks->count() > 0){
                                            $actionPerformed = $actionPerformed + 1;
                                        }
                                    }
                                }
                                if($actionPerformed == 0){
                                    $swings = Swing::where('user_id',$user->_id)->get();
                                    if($swings->count() > 0){
                                        $filteredSwings = $swings->filter(function ($swing) use ($userTimezone, $currentDateInUserTimezone) {
                                            $createdAtInUserTimezoneSwing = Carbon::parse($swing->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                            return $createdAtInUserTimezoneSwing === $currentDateInUserTimezone;
                                        });
                                        if($filteredSwings->count() > 0){
                                            $actionPerformed = $actionPerformed + 1;
                                        }
                                    }
                                }
                                if($actionPerformed == 0){
                                    $recallCards = UserRecallCardUpdate::where('user_id',$user->userid)->get();
                                    if($recallCards->count() > 0){
                                        $filteredRecallCard = $recallCards->filter(function ($recallCard) use ($userTimezone, $currentDateInUserTimezone) {
                                            $createdAtInUserTimezoneRecallCard = Carbon::parse($recallCard->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                            return $createdAtInUserTimezoneRecallCard === $currentDateInUserTimezone;
                                        });
                                        if($filteredRecallCard->count() > 0){
                                            $actionPerformed = $actionPerformed + 1;
                                        }
                                    }
                                }
                                
                                //check action performed or not and send Notification
                                if($actionPerformed == 0){
                                    Log::channel('user-status-sunday')->info("User {$user->name} (ID: {$user->id}) has  logged in today but he has not performed any action today as sunday.");
                                    if (Carbon::now($userTimezone)->isSunday() && Carbon::now($userTimezone)->hour >= 20) {
                                        $response = $this->sendNotification($user->fcm_token,$title,$body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        } else {
                                            // echo 'Error in response: ' . $response;
                                            $messageId = "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('user-status-sunday')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('user-status-sunday')->info('Notification could not be sent'); // There was an issue with sending the notification
                                        }
                                        
                                    }else{
                                        Log::channel('user-status-sunday')->info('Not a sunday');
                                    }
                                }else{
                                    Log::channel('user-status-sunday')->info('user have performed some action --'.$user->full_name. " - ".$user->userid);
                                }
                            }
                        }
                    }else{
                        if ($user->last_login_at && !$this->isToday($user->last_login_at, $user->timezone)) {
                            //if (Carbon::now($userTimezone)->isSunday() && Carbon::now($userTimezone)->hour >= 20) {
                            if (Carbon::now($userTimezone)->isSunday() && Carbon::now($userTimezone)->hour >= 20) {
                                $response = $this->sendNotification($user->fcm_token,$title,$body);
                                if (isset($response['name'])) {
                                    // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                    $MessageData = explode('/',$response['name']);
                                    $messageId = $MessageData[3] ?? "";
                                } else {
                                    // echo 'Error in response: ' . $response;
                                    $messageId = "";
                                }
                                if ($messageId != "") {
                                    $notification = new Notification();
                                    $notification->title = $title;
                                    $notification->description = $body;
                                    $notification->user_id = $user->userid;
                                    $notification->is_read = false;
                                    $notification->save();
                                    Log::channel('user-status-sunday')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                }else{
                                    Log::channel('user-status-sunday')->info('Notification could not be sent'); // There was an issue with sending the notification
                                }
                                $this->info("User {$user->name} (ID: {$user->id}) has not logged in today before 8 PM on Sunday in their timezone.");
                            }else{
                                Log::channel('user-status-sunday')->info('Not a sunday');
                            }
                        }else{
                            $actionPerformed = 0;
                            Log::channel('user-status-sunday')->info("User {$user->name} (ID: {$user->id})  logged in today");
                            //check if user has performed any action
                            $usersProgress = UserSessionProgress::where('user_id',$user->_id)->get();
                            if($usersProgress->count() > 0){
                                $filteredUsersProgress = $usersProgress->filter(function ($progress) use ($userTimezone, $currentDateInUserTimezone) {
                                    // Convert created_at to the user's timezone
                                    $createdAtInUserTimezoneUsersProgress = Carbon::parse($progress->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                    // Check if the created_at date matches the user's current date
                                    return $createdAtInUserTimezoneUsersProgress === $currentDateInUserTimezone;
                                });
                                if($filteredUsersProgress->count() > 0){
                                    $actionPerformed = $actionPerformed + 1;
                                }
                            }
                            if($actionPerformed == 0){    
                                $trustShots = UserTrustHole::where('user_id',$user->userid)->get();
                            
                                if($trustShots->count() > 0){
                                    $filteredTrustShots = $trustShots->filter(function ($trustShot) use ($userTimezone, $currentDateInUserTimezone) {
                                        // Convert created_at to the user's timezone
                                        $createdAtInUserTimezoneTrustShot = Carbon::parse($trustShot->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                        // Check if the created_at date matches the user's current date
                                        return $createdAtInUserTimezoneTrustShot === $currentDateInUserTimezone;
                                    });
                                
                                    if($filteredTrustShots->count() > 0){
                                        $actionPerformed = $actionPerformed + 1;
                                    }
                                }
                            }
                            if($actionPerformed == 0){
                                $shotChecks = UserShotCheck::where('user_id',$user->userid)->get();
                                if($shotChecks->count() > 0 ){
                                    $filteredShotChecks = $shotChecks->filter(function ($shotCheck) use ($userTimezone, $currentDateInUserTimezone) {
                                        $createdAtInUserTimezoneShotCheck = Carbon::parse($shotCheck->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                        return $createdAtInUserTimezoneShotCheck === $currentDateInUserTimezone;
                                    });
                                    if($filteredShotChecks->count() > 0){
                                        $actionPerformed = $actionPerformed + 1;
                                    }
                                }
                            }
                            if($actionPerformed == 0){
                                $swings = Swing::where('user_id',$user->_id)->get();
                                if($swings->count() > 0){
                                    $filteredSwings = $swings->filter(function ($swing) use ($userTimezone, $currentDateInUserTimezone) {
                                        $createdAtInUserTimezoneSwing = Carbon::parse($swing->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                        return $createdAtInUserTimezoneSwing === $currentDateInUserTimezone;
                                    });
                                    if($filteredSwings->count() > 0){
                                        $actionPerformed = $actionPerformed + 1;
                                    }
                                }
                            }
                            if($actionPerformed == 0){
                                $recallCards = UserRecallCardUpdate::where('user_id',$user->userid)->get();
                                if($recallCards->count() > 0){
                                    $filteredRecallCard = $recallCards->filter(function ($recallCard) use ($userTimezone, $currentDateInUserTimezone) {
                                        $createdAtInUserTimezoneRecallCard = Carbon::parse($recallCard->updated_at)->setTimezone($userTimezone)->format('Y-m-d');
                                        return $createdAtInUserTimezoneRecallCard === $currentDateInUserTimezone;
                                    });
                                    if($filteredRecallCard->count() > 0){
                                        $actionPerformed = $actionPerformed + 1;
                                    }
                                }
                            }
                            if($actionPerformed == 0){
                                Log::channel('user-status-sunday')->info("User {$user->name} (ID: {$user->id}) has  logged in today but he has not performed any action today as sunday.");
                                if (Carbon::now($userTimezone)->isSunday() && Carbon::now($userTimezone)->hour >= 20) {
                                    $response = $this->sendNotification($user->fcm_token,$title,$body);
                                    if (isset($response['name'])) {
                                        // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                        $MessageData = explode('/',$response['name']);
                                        $messageId = $MessageData[3] ?? "";
                                    } else {
                                        // echo 'Error in response: ' . $response;
                                        $messageId = "";
                                    }
                                    if ($messageId != "") {
                                        $notification = new Notification();
                                        $notification->title = $title;
                                        $notification->description = $body;
                                        $notification->user_id = $user->userid;
                                        $notification->is_read = false;
                                        $notification->save();
                                        Log::channel('user-status-sunday')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                    }else{
                                        Log::channel('user-status-sunday')->info('Notification could not be sent'); // There was an issue with sending the notification
                                    }
                                }else{
                                    Log::channel('user-status-sunday')->info('Not a sunday');
                                }
                            }else{
                                Log::channel('user-status-sunday')->info('user have performed some action --'.$user->full_name. " - ".$user->userid);
                            }
                        }
                    }
                }else{
                    Log::channel('user-status-sunday')->info('user have not selected there timezone yet --'.$user->full_name. " - ".$user->userid);
                }
            }//command logic end
            $logEntry = new LogEntry();
            $logEntry->cron_name = 'Sunday Login check';
            $logEntry->type = 'info';
            $logEntry->message = 'Command executed successfully.';
            $logEntry->save();
        } catch (Exception $e) {
            // Log the error
            $logEntry = new LogEntry();
            $logEntry->cron_name = 'Sunday Login check';
            $logEntry->type = 'Sunday Login check';
            $logEntry->message =  'Error executing command: ' . $e->getMessage();
            $logEntry->save();
        }
        
    }
    private function isToday($date, $timezone)
    {
        return Carbon::parse($date, $timezone)->isToday();
    }
    private function getAccessToken($serviceAccountPath) {
        $client = new Client();
        $client->setAuthConfig($serviceAccountPath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->useApplicationDefaultCredentials();
        $token = $client->fetchAccessTokenWithAssertion();
        return $token['access_token'];
    }
    private function sendNotification($fcmToken,$title,$body)
    {
        Log::channel('user-status-sunday')->info('In Send Notification Code');
        // $serverKey = env('FCM_SERVER_KEY'); // Replace with your FCM server key
        // $headers = [
        //     'Authorization: key=' . $serverKey,
        //     'Content-Type: application/json',
        // ];
        // $data = [
        //     'to' => $fcmToken,
        //     "priority" =>  "high",
        //     "data" => [
        //         "click_action"  =>  "FLUTTER_NOTIFICATION_CLICK",
        //         "id"            =>  "1",
        //         "status"        =>  "done",
        //         "info"          =>  [
        //             "title"  => $title,
        //             'body' => $body,
        //             // "link"   => $link,
        //             // "image"  => $image
        //         ]
        //     ],
        //     'notification' => [
        //         'title' => $title,
        //         'body' => $body,
        //     ],
        // ];
        // $ch = curl_init();
        // curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        // curl_setopt($ch, CURLOPT_POST, true);
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        // $response = curl_exec($ch);
        
        // if ($response === false) {
        //     echo 'cURL error: ' . curl_error($ch);// Handle the error if cURL request fails
        // }
        // Log::channel('user-status-sunday')->info('Response'.$response);
        // curl_close($ch);
        // return $response;
        $projectId = env('FCM_PROJECT_ID');
        $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
        $serviceAccountPath = storage_path(env('GOOGLE_SERVICE_ACCOUNT_PATH'));
        $accessToken = $this->getAccessToken($serviceAccountPath);

        $headers = [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ];
        $message = [
            'token' => $fcmToken,
            'notification' => [
                'title' => $title,
                'body' => $body,
            ],
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['message' => $message]));
        $response = curl_exec($ch);
        if ($response === false) {
            throw new Exception('Curl error: ' . curl_error($ch));
        }
        curl_close($ch);
        return json_decode($response, true);
    }
}
