<?php

namespace App\Console\Commands;

use App\Models\Country;
use App\Models\LogEntry;
use App\Models\User;
use App\Models\UserBillingHistory;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use DateTime;
use Exception;

class UpdateUserBillingHistoryStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:user-billing-history-status';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Automation process of update status based on expiry date';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try{
            Log::channel('update-billing-history-status')->info('Date -'.Carbon::now());
            $userIds = UserBillingHistory::groupBy('user_id')->pluck('user_id')->toArray();
           
            $users = User::whereIn('_id', $userIds)
            // ->where('_id',"65f2c75abee89f1c3c0935e1")
                        ->where('user_type', 'user')
                        ->whereNotNull('country_id')
                        ->where('country_id', '!=', '')
                        ->get();
            
            if($users->count() > 0){
                $countries = Country::pluck('timezone','_id')->toArray();
                foreach ($users as $user) {
                    Log::channel('update-billing-history-status')->info("User -{$user->userid} - {$user->full_name}");
                    $subscriptions = UserBillingHistory::where('user_id',$user->_id)->where('status','active')->where('payment_status','Paid')->get();
                    if(!empty($subscriptions)){
                        $userTimezone = $countries[$user->country_id] ?? 'UTC';
                        $todayDate = Carbon::now($userTimezone);
                        foreach ($subscriptions as $subscription) {
                            $lastExpDate = $subscription->expiry_date;
                            $expiryDate = Carbon::parse($lastExpDate, $userTimezone);
                            Log::channel('update-billing-history-status')->info("User Billing ID: ==>".$subscription->_id);
                            if ($todayDate > $expiryDate) {
                                Log::channel('update-billing-history-status')->info("Start Time:==>".$todayDate. '>' .$expiryDate);
                                $subscription->status = 'expired';
                                $subscription->save();
                            }else{
                                Log::channel('update-billing-history-status')->info("Start Time:==>".$todayDate. '<' .$expiryDate);
                            }
                            
                        }
                    }
                }
            }
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Update User billing history status";
            $logEntry->type =  'info'; 
            $logEntry->message = 'Command executed successfully.';
            $logEntry->save();
        } catch (Exception $e) {
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Update User billing history status";
            $logEntry->type =  'error';
            $logEntry->message = 'Error executing command: ' . $e->getMessage();
            $logEntry->save();
        }
    }
}
