<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\LogEntry;
use Carbon\Carbon;

class RemoveLogEntrie extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'logs:delete-old';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Delete log entries older than one month';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $oneMonthAgo = Carbon::now()->subMonth();
        
        $deleted = LogEntry::where('created_at', '<', $oneMonthAgo)->delete();
        
        $this->info("Deleted $deleted old log entries.");

    }
}
