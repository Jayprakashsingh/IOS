<?php

namespace App\Console\Commands;

use App\Models\Country;
use App\Models\LogEntry;
use App\Models\Notification;
use App\Models\User;
use App\Models\UserFcmToken;
use App\Models\UserTrainingStreak;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use DateTime;
use Exception;
use Google\Client;

class SendMulligan extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:mulligan';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'If the user misses a day, then his/her streak resets to 0 days, except when that user gets a surprise & delight “mulligan” which is earned after every 7 consecutive days of training';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try {
            // Your command logic here
            Log::channel('send-mulligan')->info('Date -'.Carbon::now());
            $type = "Use Your Mulligan";
            
            $users = User::where('user_type','user')->where('fcm_token','!=',NULL)->where('fcm_token','!=',"")->where('country_id','!=',NULL)->where('country_id','!=',"")->get();
            if($users->count() > 0){
                $countries = Country::pluck('timezone','_id')->toArray();
                $title = $body = "We know life gets busy, so we gave you a mulligan on training yesterday. Train today and keep your streak alive!";
                foreach ($users as $user) {
                    Log::channel('send-mulligan')->info('User -'.$user->userid.' - '.$user->full_name);
                    $timezone = $countries[$user->country_id];
                    $currentDateTime = Carbon::now($timezone);
                    $currentHour = $currentDateTime->format('H');
                    $userFcmTokens = UserFcmToken::where('user_id',$user->_id)->get();
                    if((int)$currentHour >= 7 && (int)$currentHour < 11){
                        $yesterday = Carbon::now($timezone)->format('Y-m-d');
                        Log::channel('send-mulligan')->info('user Yesterday date -'.$yesterday);
                        $userStreak = UserTrainingStreak::where('user_id',$user->userid)->where('mulligan',1)->where('date',$yesterday)->first();
                        Log::channel('send-mulligan')->info('Checking user have mulligan which assigned yesterday');
                        if($userStreak){
                            Log::channel('send-mulligan')->info('Lets send notification if not sent yet');
                            $notification = Notification::where('user_id',$user->userid)->where('type',$type)->orderBy('created_at','desc')->first();
                            if($notification){
                                if(!$this->isToday($notification->created_at, $timezone)){
                                    if($userFcmTokens->count() > 0){
                                        foreach ($userFcmTokens as $userFcmToken) {
                                            $messageId = "";
                                            $response = $this->sendNotification($userFcmToken, $title, $body);
                                            if (isset($response['name'])) {
                                                // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                                $MessageData = explode('/',$response['name']);
                                                $messageId = $MessageData[3] ?? "";
                                            }
                                            if ($messageId != "") {
                                                $notification = new Notification();
                                                $notification->type = $type;
                                                $notification->title = $title;
                                                $notification->description = $body;
                                                $notification->user_id = $user->userid;
                                                $notification->is_read = false;
                                                $notification->save();
                                                Log::channel('send-mulligan')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                            }else{
                                                Log::channel('send-mulligan')->info('Notification could not be sent'); // There was an issue with sending the notification
                                            }
                                        }
                                    }else{
                                        $messageId = "";
                                        $response = $this->sendNotification($user->fcm_token, $title, $body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->type = $type;
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('send-mulligan')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('send-mulligan')->info('Notification could not be sent'); // There was an issue with sending the notification
                                        }
                                    }
                                    
                                }else{
                                    Log::channel('send-mulligan')->info('Notification already been sent');
                                }
                            }else{
                                if($userFcmTokens->count() > 0){
                                    foreach ($userFcmTokens as $userFcmToken) {
                                        $messageId = "";
                                        $response = $this->sendNotification($userFcmToken, $title, $body);
                                        if (isset($response['name'])) {
                                            // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                            $MessageData = explode('/',$response['name']);
                                            $messageId = $MessageData[3] ?? "";
                                        }
                                        if ($messageId != "") {
                                            $notification = new Notification();
                                            $notification->type = $type;
                                            $notification->title = $title;
                                            $notification->description = $body;
                                            $notification->user_id = $user->userid;
                                            $notification->is_read = false;
                                            $notification->save();
                                            Log::channel('send-mulligan')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                        }else{
                                            Log::channel('send-mulligan')->info('Notification could not be sent'); // There was an issue with sending the notification
                                        }
                                    }
                                }else{
                                    $messageId = "";
                                    $response = $this->sendNotification($user->fcm_token, $title, $body);
                                    if (isset($response['name'])) {
                                        // echo 'Message sent successfully. Message ID: ' . $response['name'];
                                        $MessageData = explode('/',$response['name']);
                                        $messageId = $MessageData[3] ?? "";
                                    }
                                    if ($messageId != "") {
                                        $notification = new Notification();
                                        $notification->type = $type;
                                        $notification->title = $title;
                                        $notification->description = $body;
                                        $notification->user_id = $user->userid;
                                        $notification->is_read = false;
                                        $notification->save();
                                        Log::channel('send-mulligan')->info('Push notifications sent to user -'.$user->userid. '. Message ID: ' . $messageId); // Notification was successfully sent
                                    }else{
                                        Log::channel('send-mulligan')->info('Notification could not be sent'); // There was an issue with sending the notification
                                    }
                                }
                                
                            }
                        }else{
                            Log::channel('send-mulligan')->info('No mulligan sent yesterday.');
                        }
                    }else{
                        Log::channel('send-mulligan')->info('not 7 am yet');
                    }
                }
            }
            // else{
            //     Log::channel('send-mulligan')->info('user has not selected timezone or not have device token registered .');
            // }
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Send Mulligan";
            $logEntry->type =  'info';
            $logEntry->message = 'Command executed successfully.';
            $logEntry->save();
        } catch (Exception $e) {
            $logEntry = new LogEntry();
            $logEntry->cron_name = "Send Mulligan";
            $logEntry->type =  'error';
            $logEntry->message = 'Error executing command: ' . $e->getMessage();
            $logEntry->save();
        }
        
    }
    private function getAccessToken($serviceAccountPath) {
        $client = new Client();
        $client->setAuthConfig($serviceAccountPath);
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');
        $client->useApplicationDefaultCredentials();
        $token = $client->fetchAccessTokenWithAssertion();
        return $token['access_token'];
    }
    private function isToday($date, $timezone)
    {
        return Carbon::parse($date, $timezone)->isToday();
    }
    
    private function sendNotification($fcmToken, $title,$body)
    {
        Log::channel('upcoming-session')->info('In Send Notification Code');
        $projectId = env('FCM_PROJECT_ID');
        $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
        $serviceAccountPath = storage_path(env('GOOGLE_SERVICE_ACCOUNT_PATH'));
        $accessToken = $this->getAccessToken($serviceAccountPath);

        $headers = [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ];
        $message = [
            'token' => $fcmToken,
            'notification' => [
                'title' => $title,
                'body' => $body,
            ],
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['message' => $message]));
        $response = curl_exec($ch);
        if ($response === false) {
            throw new Exception('Curl error: ' . curl_error($ch));
        }
        curl_close($ch);
        return json_decode($response, true);
    }
}
