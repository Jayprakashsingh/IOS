<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_trust_holes', function (Blueprint $table) {
            $table->id();
            $table->string('trust_key')->nullable();
            $table->integer('user_id')->nullable();
            $table->integer('trust_hole_no')->nullable();
            $table->string('date')->nullable();
            $table->string('location')->nullable();
            $table->integer('temperature')->nullable();
            $table->integer('wind')->nullable();
            $table->integer('warm_up_time')->nullable();
            $table->enum('hole_type', ['Drive', 'Approach'])->nullable();
            $table->enum('direction', ['Left', 'Straight','Right'])->nullable();
            $table->enum('curve', ['To Left', 'To Curve','To Right'])->nullable();
            $table->enum('contact', ['Fat', 'Solid','Thin'])->nullable();
            $table->enum('face', ['Heel', 'Center','Toe'])->nullable();
            $table->enum('alignment', ['Left', 'Center','Right'])->nullable();
            $table->enum('distance', ['Short', 'Middle','Long'])->nullable();
            $table->integer('trust_key_percent')->nullable();
            $table->integer('pre_shot_percent')->nullable();
            $table->integer('post_shot_percent')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_trust_holes');
    }
};
