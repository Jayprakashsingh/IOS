<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Check if the table exists
        if (Schema::hasTable('user_contact_person')) {
            // Check if the column exists
            if (Schema::hasColumn('user_contact_person', 'plan')) {
                Schema::table('user_contact_person', function (Blueprint $table) {
                    $table->dropColumn('plan');
                });
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('user_contact_person')) {
            if (!Schema::hasColumn('user_contact_person', 'plan')) {
                //add plan column if not exist
                Schema::table('user_contact_person', function (Blueprint $table) {
                    $table->enum('plan', ['Ok', 'Good', 'Great','Awesome']);
                });
            }
            
        }
    }
};
