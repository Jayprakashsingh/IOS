<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_object_type', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('object_type_id')->nullable();
            $table->integer('category_type_id')->nullable();
            $table->string('object_name')->nullable();
            $table->string('headline')->nullable();
            $table->string('subtitle')->nullable();
            $table->string('textarea')->nullable();
            $table->string('equipment')->nullable();
            $table->string('file')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_object_type');
    }
};
