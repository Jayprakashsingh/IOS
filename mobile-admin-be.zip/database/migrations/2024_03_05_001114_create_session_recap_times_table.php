<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('session_recap_times', function (Blueprint $table) {
            $table->id();
            $table->string('user_id')->nullable();
            $table->string('unit_id')->nullable();
            $table->string('session_id')->nullable();
            $table->integer('recap_reps')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('session_recap_times');
    }
};
