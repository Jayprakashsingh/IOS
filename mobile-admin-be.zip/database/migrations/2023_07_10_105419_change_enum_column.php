<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('user_contact_person', function (Blueprint $table) {
            //
        });
        if (Schema::hasTable('user_contact_person')) {
            Schema::table('user_contact_person', function (Blueprint $table) {
                $table->enum('plan', ['Ok', 'Good', 'Great','Awesome'])->change();
            });
        }
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('user_contact_person')) {
            Schema::table('user_contact_person', function (Blueprint $table) {
                $table->enum('plan', ['Good', 'Very Good', 'Best', 'Excellent'])->change();
            });
        }
          
    }
};
