<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            //
        });
        if (Schema::hasTable('users')) {
            // Check if the column exists
            if (Schema::hasColumn('users', 'fcm_token')) {
                Schema::table('users', function (Blueprint $table) {
                    $table->string('fcm_token')->nullable();
                    $table->string('device_type')->nullable();
                });
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('fcm_token');
            $table->dropColumn('device_type');
        });
    }
};
