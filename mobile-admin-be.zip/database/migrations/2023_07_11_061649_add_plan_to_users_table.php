<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Check if the table exists
        if (Schema::hasTable('user_training_plan')) {
            Schema::table('users', function (Blueprint $table) {
                $table->enum('plan', ['Ok', 'Good', 'Great','Awesome']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Check if the table exists
        if (Schema::hasTable('users')) {
            // Check if the column exists
            if (Schema::hasColumn('users', 'plan')) {
                Schema::table('users', function (Blueprint $table) {
                    $table->dropColumn('plan');
                });
            }
        }
    }
};
