<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('user_training_plan')) {
            Schema::table('user_training_plan', function (Blueprint $table) {
                $table->enum('plan', ['Good', 'Very Good', 'Best', 'Excellent'])->default('Good');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('user_training_plan')) {
            Schema::table('user_training_plan', function (Blueprint $table) {
                $table->dropColumn('plan');
            });
        }
    }
};
