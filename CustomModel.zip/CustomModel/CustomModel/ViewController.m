//
//  ViewController.m
//  CustomModel
//
//  Created by BL@CK on 7/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "NSString+Utility.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSString *strPath = [NSString getPathForFileName:@"response" withFileType:@"json"];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:strPath];
    NSError *error;
    NSMutableDictionary *dictJson = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if (error == nil)
    {
        NSLog(@"%@",dictJson);
        NSMutableArray *aryData = [[dictJson valueForKey:@"data"] mutableCopy];
     //   for (NSDictionary *dictTemp in aryData)
     //   {
//            FWStudent *objStudent = [[FWStudent alloc] initWithData:dictTemp];
//            [aryStudentData addObject:objStudent];
            
     //   }
       // NSLog(@"%@",aryStudentData);
    }
    else
    {
        NSLog(@"Error :: %@",error.description);
    }
    
    

    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-TableView Method
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell == nil)
    {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        cell.selectionStyle=UITableViewCellSelectionStyleBlue;
    }
    
    return cell;
}















@end
