//
//  CUStudent.h
//  CustomModel
//
//  Created by BL@CK on 7/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CUStudent : NSObject
@property(nonatomic,strong)NSString *strName;
@end
