//
//  NSString+Utility.h
//  CustomModel
//
//  Created by BL@CK on 7/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Utility)
+(NSString *)getPathForFileName:(NSString *)strFileName withFileType:(NSString *)strFileType;

@end
