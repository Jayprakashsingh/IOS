//
//  CUStudent.m
//  CustomModel
//
//  Created by BL@CK on 7/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "CUStudent.h"

@implementation CUStudent

@end
