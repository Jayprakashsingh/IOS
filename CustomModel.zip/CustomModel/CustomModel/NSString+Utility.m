//
//  NSString+Utility.m
//  CustomModel
//
//  Created by BL@CK on 7/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "NSString+Utility.h"

@implementation NSString (Utility)
+(NSString *)getPathForFileName:(NSString *)strFileName withFileType:(NSString *)strFileType
{
    return  [[NSBundle mainBundle] pathForResource:strFileName ofType:strFileType];
    
}
@end
