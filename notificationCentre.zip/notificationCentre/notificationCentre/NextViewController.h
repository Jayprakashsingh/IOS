//
//  NextViewController.h
//  notificationCentre
//
//  Created by BL@CK on 6/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextViewController : UICollectionViewController
{
}
-(IBAction)umeshData:(id)sender;
@end
