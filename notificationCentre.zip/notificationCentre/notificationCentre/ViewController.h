//
//  ViewController.h
//  notificationCentre
//
//  Created by BL@CK on 6/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
}
-(IBAction)btnGo:(id)sender;
@end
