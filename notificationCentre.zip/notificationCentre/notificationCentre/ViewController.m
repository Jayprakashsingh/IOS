//
//  ViewController.m
//  notificationCentre
//
//  Created by BL@CK on 6/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "AnotherViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(dataArray) name:@"ArrayID" object:nil];
}
-(void)dataArray
{
    NSMutableArray *array=[NSMutableArray new];
    [array addObject:@"JAVA"];
    [array addObject:@"PHP"];
    [array addObject:@"IOS"];
    [array addObject:@"WEBDESIGN"];
    NSLog(@"%@",array);

}
-(IBAction)btnGo:(id)sender
{
    AnotherViewController *obj=[self.storyboard instantiateViewControllerWithIdentifier:@"AnotherViewController"];
    [self.navigationController pushViewController:obj animated:YES];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
