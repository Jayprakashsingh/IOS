/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    container: {
      center: true,
    },
    safelist: [
      "bg-[#F9F9F9]",
      "bg-[#FFFFFF]",
      "text-white",
      "hover:bg-red-700",
      "bg-orangegradient",
      "object-fill",
    ],

    extend: {
      backgroundImage: {
        lightbluegradianet:
          "linear-gradient(120.04deg, rgba(151, 165, 235, 0.63) 28.09%, rgba(223, 228, 255, 0.47) 61.35%)",
        bluegradient:
          "linear-gradient(322.69deg, #285A9F 15.37%, #C0DAFE 120.52%)",
        orangegradient:
          "linear-gradient(318deg, #F58124 -4.22%, #FFC266 120.23%)",
        offwhitegradient:
          "linear-gradient(322.69deg, #285A9F 15.37%, #C0DAFE 120.52%)",
      },
      boxShadow: {
        section: "0px 4px 10px 0px #89898933",
      },
      colors: {
        secondary: {
          light: "#FFFFFF",
          DEFAULT: "#F9F9F9",
          dark: "#EAF0F3",
        },
        primary: {
          light: "",
          DEFAULT: "",
          dark: "",
        },
        primaryFont: {
          light: "#9E9E9E",
          DEFAULT: "#767576",
          dark: "#212121",
        },
        secondaryFont: {
          light: "",
          DEFAULT: "",
          dark: "",
        },
        utils:{
          danger: "#ef4444"
        },
        gradientPairs: {
          blueStart: "#285A9F",
          blueEnd: "#C0DAFE",
          orangeStart: "#F58124",
          orangeEnd: "#FFC266",
        },
      },
    },
  },
};
