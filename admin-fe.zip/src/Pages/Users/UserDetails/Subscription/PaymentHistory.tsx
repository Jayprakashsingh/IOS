import React from 'react'

type Props = {}

const PaymentHistory = (props: Props) => {
    return (
        <div className='border rounded-lg p-4'>
            <h4 className='font-bold'>Purchase History</h4>
            <table className='w-full my-4'>
                <thead className='font-bold '>
                    <tr>
                        <td>Order No.</td>
                        <td>Date</td>
                        <td>Price</td>
                        <td>Status</td>
                    </tr>
                </thead>
                <tbody className='text-[#757575]'>
                    {
                        [1, 2, 3].map((item, index) => (
                            <tr className='border-t '>
                                <td className='py-2'>12877227695</td>
                                <td>26th feb</td>
                                <td>$199</td>
                                <td>completed</td>
                            </tr>
                        ))
                    }

                </tbody>
            </table>
        </div>
    )
}

export default PaymentHistory