import React from 'react'

type Props = {}

const PaymentMethods = (props: Props) => {
    return (
        <div className='border rounded-lg p-4'>
            <h4 className='font-bold'>Purchase method</h4>
            {
                [1, 2, 3].map((item) => (
                    <>
                        <div className='px-4 py-3'>
                            <h4 className='text-base '>Visa</h4>
                            <p className='text-xs text-[#9E9E9E]'>Ending in 5237 XXXX XXXX 123456</p>
                        </div>
                        <hr />
                    </>
                ))
            }
        </div>
    )
}

export default PaymentMethods