import React from 'react';
import classnames from "classnames"

type Props = {
    plan: "active" | "other",
    status: "Active Plan" | "Not Active",
    planName: string,
    validity: string
}

const ProductCard = ({ plan, planName, status, validity }: Props) => {
    return (
        <div className={classnames("rounded-2xl w-full flex flex-col gap-4 border-l-8 px-6 py-4 ", {
            "bg-[#FFF5E5] border-l-[#F58124] text-[#212121]": plan === "active",
            "bg-[#EAF0F3] border-l-[#1F3161] text-[#1F3161]": plan === "other",
        })}>
            <div className='flex flex-col'>
                <span className='text-xs font-medium'>{status}</span>
                <span className='text-md font-medium'>{planName}</span>
            </div>
            <div className={classnames("text-sm", {
                " text-[#F58124]": plan === "active",
                " text-[#1F3161]": plan === "other",
            })}>{validity}</div>
        </div>
    )
}

export default ProductCard