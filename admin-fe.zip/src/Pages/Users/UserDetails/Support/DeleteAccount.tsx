import React from 'react'

type Props = {}

const DeleteAccount = (props: Props) => {
    return (
        <div className='px-[1.88rem] py-[1.25rem] h-full'>
            <h4 className='font-bold'>Delete Account</h4>
            <span className='m-auto flex flex-col h-full items-start gap-4 py-3'>
                <p>To deactivate your account, first delete its resources. If you are the only owner of any teams, either assign another owner or deactivate the team.</p>
                <button className='px-2 py-1 border-[#D84315] rounded border text-[#D84315] font-semibold'>Deactivate User Account </button>
            </span>
        </div>
    )
}

export default DeleteAccount