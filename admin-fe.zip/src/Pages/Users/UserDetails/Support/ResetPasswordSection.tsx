import moment from 'moment'
import InputComponent from '../../../../Components/Inputs/InputComponent'
import { useForm } from 'react-hook-form'
import ButtonComponent from '../../../../Components/Buttons/ButtonComponent'

type Props = {

}

type ContactUsForm = {
    currentpass: string;
    newpass: string;
    confirmpass: string;
}

const ResetPasswordSection = (props: Props) => {

    const { register, watch } = useForm<ContactUsForm>()

    return (
        <div className='py-[1.25rem] px-[1.88rem] flex flex-col gap-[1.25rem] '>
            <span className='block'>
                <h4 className='font-bold'>Reset Password</h4>
                {/* <p className='text-[#757575] text-xs'>{moment().format("DD.MM.YY   HH:MM")}</p> */}
            </span>

            <div className='grid grid-cols-2'>
                <InputComponent inputRef='currentpass' name='currentpass' register={register} value='' label='Cuurent Password' />
            </div>
            <div className='grid grid-cols-2 gap-2 '>
                <InputComponent inputRef='newpass' name='newpass' register={register} value='' label='New Password' />
                <InputComponent inputRef='currentpass' name='currentpass' register={register} value='' label='Confirm Password' />
            </div>
            <ButtonComponent CTA='Save' buttonType='submit' varient='blue' />
        </div>
    )
}

export default ResetPasswordSection