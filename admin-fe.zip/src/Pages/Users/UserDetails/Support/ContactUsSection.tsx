import moment from 'moment'
import React from 'react'
import InputComponent from '../../../../Components/Inputs/InputComponent'
import { useForm } from 'react-hook-form'
import TextAreaComponent from '../../../../Components/Inputs/TextAreaComponent'

type Props = {

}

type ContactUsForm = {
    subject: string;
    email: string;
    body: string;
}

const ContactUsSection = (props: Props) => {

    const { register, watch } = useForm<ContactUsForm>()

    return (
        <div className='py-[1.25rem] px-[1.88rem] flex flex-col gap-[1.25rem] '>
            <span className='block'>
                <h4 className='font-bold'>Contact Us</h4>
                <p className='text-[#757575] text-xs'>{moment().format("DD.MM.YY   HH:MM")}</p>
            </span>
            <InputComponent inputRef='subject' name='subject' register={register} value='' label='Subject' />
            <InputComponent inputRef='email' name='subject' register={register} value='' label='Email' />
            <TextAreaComponent inputRef='body' name='subject' register={register} value='' label='Body' />
        </div>
    )
}

export default ContactUsSection