import React from 'react'
import Accordion from '../../../../Components/AccordianTable/AccordianTable'

type Props = {}

const SupportSection = (props: Props) => {
    return (
        <div className='px-[1.88rem] py-[1.25rem]'>
            <h4 className='font-bold'>Something's wrong?</h4>

        </div>
    )
}

export default SupportSection