import React from 'react'
import { PolarAngleAxis, RadialBar, RadialBarChart } from 'recharts';

type Props = {}

const ProgressChart = (props: Props) => {
    const data = [
        { name: 'L1', value: 25 }
    ];

    const circleSize = 30;
    return (

        <div className='w-fit rounded-full bg-[#FFF5E5] text-[#FFF5E5] font-semibold p-8 m-auto'>
            <div className='w-fit rounded-full bg-[#E6E6E6] p-1 m-auto'>
                <RadialBarChart
                    className='rounded-full w-fit bg-white text-[#FFF5E5] m-auto'
                    width={200}
                    height={200}
                    cx={200 / 2}
                    cy={200 / 2}
                    innerRadius={80}
                    outerRadius={200}
                    barSize={18}
                    data={data}
                    startAngle={90}
                    endAngle={-270}
                >
                    <PolarAngleAxis
                        className='bg-black text-[#FFF5E5]'
                        width={200}
                        height={200}
                        type="number"
                        domain={[0, 100]}
                        angleAxisId={0}
                        tick={false}
                    />

                    <RadialBar
                        className='bg-black text-[#FFF5E5]'

                        // background
                        // clock
                        width={200}
                        height={200}
                        dataKey="value"
                        cornerRadius={circleSize / 2}
                        fill="#FFA45B"
                    />
                    <text
                        x={200 / 2}
                        y={200 / 2}
                        textAnchor="middle"
                        style={{ fill: "#FFA45B", fontSize: "18px" }}
                        color='#FFF5E5'
                        dominantBaseline="middle"
                        className="progress-label text-[#FFF5E5]"
                    >
                        32%
                    </text>
                    <text
                        x={200 / 2}
                        y={200 / 2 + 20}
                        style={{ fill: "#FFA45B", fontSize: "24px", margin: "20px 0" }}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="progress-label "
                    >
                        Unit 1
                    </text>
                </RadialBarChart>
            </div>
        </div>
    )
}

export default ProgressChart