import BoxLayout from '../../../../Containers/Layout/BoxLayout'

type Props = {}

const Profile = (props: Props) => {
    return (
        <BoxLayout HeaderName='User Profile' sectionName='Profile' >
            <div>
                <p className='text-center font-bold text-md'>Yet to Developed</p>
            </div>
        </BoxLayout>
    )

}

export default Profile