import FilterSortPanel from "../../Containers/Layout/FilterSortPanel";
import PaginationComponent from "../../Components/PaginationComponent";
import TableComponent from "../../Components/TableComponent";
import {
  AdminTypeListTableHeader,
  FreeUserTypeListTableHeader,
} from "../../utils/TableColumns";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../Redux/app/hooks";
import {
  DeleteUserAPI,
  UserPostAPI,
  UserListAPI,
  UserListSort,
  handleSort,
  Status,
  FreeUserListAPI,
} from "../../Redux/features/UserManagementSlice";
import ModalComponent from "../../Components/PopUp/ModalComponent";
import ButtonComponent from "../../Components/Buttons/ButtonComponent";
import moment from "moment";
import DeleteIcon from "../../Components/Icons/DeleteIcon";
import EditIcon from "../../Components/Icons/EditIcon";
import Sidedrawer from "../../Components/SideDrawer";
import AddAdminForm from "../../Containers/UserManagement/AddAdminForm";
import InputComponent from "../../Components/Inputs/InputComponent";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import BoxLayout from "../../Containers/Layout/BoxLayout";
import TableSkeleton from "../../Skeleton/TableSkeleton";
import { manageSorting } from "../../utils/helper";
import { useIsMount } from "../../CustomHooks/useIsMount";
import AddFreeUser from "../../routes/freeUser/AddFreeUser";

type Props = {};

type FormValues = {
  email: string;
  name: string;
};

const FreeUserList = (props: Props) => {
  const validationSchema = Yup.object().shape({
    email: Yup.string().required("Email is required").email("Invalid email"),
    name: Yup.string().required("Name is required"),
  });

  const {
    register,
    watch,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: yupResolver(validationSchema),
    defaultValues: { email: "", name: "" },
  });

  const dispatch = useAppDispatch();

  const [adminListValue, setAdminListValue] = useState();
  const [userName, setuserName] = useState("userName");
  const [showUpdateForm, setUpdateForm] = useState(false);
  const [showDeleteForm, setDeleteForm] = useState(false);
  const [showAddForm, setAddFormModal] = useState(false);
  const [perPage, setPerPage] = useState<{ label: string; value: number }>({
    label: "Show 50",
    value: 50,
  });

  const loading = useAppSelector(
    (state) => state.UserManagement.UserPostAPIIdle
  );
  const [id, setid] = useState(0);

  const userList = useAppSelector((state) => state.UserManagement.freeUserList);
  const pageNumber = useAppSelector(
    (state) => state.UserManagement.userList.current_page
  );
  const sortType = useAppSelector((state) => state.UserManagement.sortType);

  useEffect(() => {
    dispatch(
      FreeUserListAPI({
        page: 1,
        userType: "admin",
        sortType: sortType,
        sortValue: sortValue,
        per_page: perPage.value,
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortType]);

  const handleEditClick = (id: number, name: string, email: string) => {
    setUpdateForm(true);
    setValue("email", email);
    setValue("name", name);
    setid(id);
  };

  const handleDeleteClick = (id: number, username: string) => {
    setDeleteForm(true);
    setid(id);
    setuserName(username);
  };

  const ConfirmDelete = () => {
    dispatch(DeleteUserAPI(id)).then((res: any) => {
      if (res.payload.success) {
        setDeleteForm(false);
        dispatch(
          FreeUserListAPI({
            page: pageNumber,
            userType: "admin",
            per_page: perPage.value,
          })
        );
      }
    });
  };

  const ConfirmUpdate = (data: FormValues) => {
    // dispatch(FreeUserListAPI({ data: data, id: id })).then((res: any) => {
    //   if (res.payload?.success) {
    //     setUpdateForm(false);
    //     dispatch(
    //       FreeUserListAPI({
    //         page: pageNumber,
    //         userType: "admin",
    //         per_page: perPage.value,
    //       })
    //     );
    //   }
    // });
  };

  const handleCloseDeleteModel = () => {
    setDeleteForm(false);
  };

  const handleCloseUpdateModel = () => {
    setUpdateForm(false);
  };

  const formValues = watch();

  const sortValue = useAppSelector((state) => state.UserManagement.sortValue);
  const active = useAppSelector(
    (state) => state.UserManagement.userList?.current_page
  );

  const total = useAppSelector(
    (state) => state.UserManagement.userList?.last_page
  );

  const pageChange = (pageNumber: number) => {
    console.log(pageNumber);
    dispatch(
      FreeUserListAPI({
        page: pageNumber,
        userType: "admin",
        searchValue: adminListValue,
        sortType: sortType,
        sortValue: sortValue,
        per_page: perPage.value,
      })
    );
  };

  const listLoading = useAppSelector(
    (state) => state.UserManagement.FreeUserListAPIIdle
  );

  const getSearchValue = (d: any) => {
    setAdminListValue(d);
  };

  const setPerPageValue = (value: { label: string; value: number }) => {
    setPerPage(value);
    dispatch(
      FreeUserListAPI({
        page: 1,
        userType: "admin",
        searchValue: adminListValue,
        sortType: sortType,
        sortValue: sortValue,
        per_page: value.value,
      })
    );
  };
  const isMount = useIsMount();

  useEffect(() => {
    if (!isMount) {
      const delayDebounceFn = setTimeout(() => {
        dispatch(
          FreeUserListAPI({
            page: 1,
            userType: "admin",
            searchValue: adminListValue,
            sortType: sortType,
            sortValue: sortValue,
            per_page: perPage.value,
          })
        );
      }, 1000);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [adminListValue]);

  const getSortValue = () => {
    dispatch(UserListSort());
  };

  useEffect(() => {
    document.title = "FISIO | List Admin";
  }, []);
  return (
    <>
      <BoxLayout HeaderName="Free User" sectionName="FreeUser List">
        <FilterSortPanel
          Function={() => setAddFormModal((prev) => !prev)}
          showAddForm={showAddForm}
          getSearchValue={getSearchValue}
          getSortValue={getSortValue}
          sortType={sortType}
        >
          <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50 z-[99]">
            <Sidedrawer onClose={setAddFormModal}>
              <AddFreeUser setAddFormModal={setAddFormModal} />
            </Sidedrawer>
          </div>
        </FilterSortPanel>
        <TableComponent
          onClick={manageSorting}
          loader={listLoading}
          TableHeaderData={FreeUserTypeListTableHeader}
          sortValue={sortValue}
          sortType={sortType}
          handleSortAction={handleSort}
        >
          {listLoading === Status.SUCCESS && (
            <tbody className="">
              {userList.map((i) => (
                <tr
                  className="border-y py-1 text-xs border-y-[#EAF0F3]"
                  key={i._id}
                >
                  <td className="py-1 text-start font-medium cursor-pointer text-[#212121] ">
                    {i._id}
                  </td>
                  <td className="py-1 text-start font-medium   text-[#212121]">
                    {i.email}
                  </td>
                  <td className="py-1 text-start text-[#767576] capitalize ">
                    Free User
                  </td>

                  <td className="py-1 flex gap-3 text-start">
                    <button
                    // onClick={() =>
                    //   handleEditClick(i.userid, i.full_name, i.email)
                    // }
                    >
                      <EditIcon />
                    </button>
                    <button
                    // onClick={() => handleDeleteClick(i.userid, i.full_name)}
                    >
                      <DeleteIcon />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          )}
          {listLoading === Status.LOADING && <TableSkeleton tableColumns={4} />}
        </TableComponent>
        <PaginationComponent
          paginationFunction={pageChange}
          active={active}
          total={total}
          setPerPageValue={setPerPageValue}
          perPageValue={perPage}
        />
      </BoxLayout>

      <ModalComponent
        confirmAction={ConfirmDelete}
        message={`Are you sure you want to disable ${userName}?`}
        isOpen={showDeleteForm}
        onClose={handleCloseDeleteModel}
      />

      {showUpdateForm && (
        <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50 z-[99]">
          <Sidedrawer onClose={handleCloseUpdateModel}>
            <p className="text-lg p-4">Update User</p>
            <form
              className="p-4 flex  h-full flex-col justify-between gap-4"
              onSubmit={handleSubmit(ConfirmUpdate)}
            >
              <div className="h-full flex flex-col gap-4">
                <InputComponent
                  register={register}
                  inputRef="email"
                  label="email"
                  name="email"
                  errorname={errors.email?.message}
                  value={formValues.email}
                />
                <InputComponent
                  register={register}
                  inputRef="name"
                  label="name"
                  name="name"
                  errorname={errors.name?.message}
                  value={formValues.name}
                />
              </div>
              <div className="flex h-[150px] gap-6">
                <ButtonComponent
                  buttonType="submit"
                  CTA="Update"
                  varient={"blue"}
                  loading={loading}
                />
                <ButtonComponent
                  buttonType="button"
                  CTA="cancel"
                  onClick={handleCloseUpdateModel}
                />
              </div>
            </form>
          </Sidedrawer>
        </div>
      )}
    </>
  );
};

export default FreeUserList;
