import React, { memo } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { useForm, useFieldArray } from "react-hook-form";
import InputComponent from "../../Components/Inputs/InputComponent";
import { DraggableItem } from "./DraggableItem";


interface DraggableListProps {
    defaultValues: any;
    name: string;
    onSubmit: (data: any) => void;
    inputComponent?: React.ComponentType<any>;
    itemLayout?: (item: any, index: number, register: any, remove: (index: number) => void) => JSX.Element;
}

const DraggableList: React.FC<DraggableListProps> = ({
    defaultValues,
    name,
    onSubmit,
    inputComponent = InputComponent,
    itemLayout
}) => {
    const { register, control, handleSubmit, setValue } = useForm({
        defaultValues: defaultValues
    });

    const { fields, append, remove } = useFieldArray({
        control,
        name
    });

    const moveItem = (from: number, to: number) => {
        const updatedFields = [...fields];
        const [movedItem] = updatedFields.splice(from, 1);
        updatedFields.splice(to, 0, movedItem);
        setValue(name, updatedFields);
    };

    const DefaultItemLayout = (item: any, index: number, register: any, remove: (index: number) => void) => (
        <div className="flex" key={item.id}>
            <InputComponent
                inputRef={`${name}.${index}.value`}
                value=""
                name={`${name}.${index}.value`}
                register={register}
            />
            <button
                type="button"
                onClick={() => {
                    // moveItem();
                }}
            >Drag</button>
            <button type="button" onClick={() => remove(index)}>Delete</button>
        </div>
    );

    return (
        <DndProvider backend={HTML5Backend}>
            <form onSubmit={handleSubmit(onSubmit)}>
                {fields.map((item, index) => (
                    <DraggableItem
                        key={item.id}
                        item={item}
                        index={index}
                        moveItem={moveItem}
                        register={register}
                        remove={remove}
                        renderItem={itemLayout || DefaultItemLayout}
                    />
                ))}
                <input type="submit" />

                <button
                    type="button"
                    onClick={() => {
                        append({});
                    }}
                >Append</button>
            </form>
        </DndProvider>
    );
};

export default DraggableList;
