import { useRef, memo } from "react";
import { DndProvider, useDrag, useDrop } from "react-dnd";

const DRAG_TYPE = "ITEM";

let renderCount = 0

export const DraggableItem: React.FC<{
    item: any;
    index: number;
    moveItem: (from: number, to: number) => void;
    register: any;
    remove: (index: number) => void;
    renderItem: (item: any, index: number, register: any, remove: (index: number) => void) => JSX.Element;
}> = memo(({ item, index, moveItem, register, remove, renderItem }) => {
    const ref = useRef<HTMLDivElement>(null);

    const [, drop] = useDrop({
        accept: DRAG_TYPE,
        hover: (draggedItem: { index: number }) => {
            if (draggedItem.index !== index) {
                moveItem(draggedItem.index, index);
                draggedItem.index = index;
            }
        },
    });

    const [{ isDragging }, drag] = useDrag({
        type: DRAG_TYPE,
        item: { index },
        collect: (monitor) => ({
            isDragging: monitor.isDragging(),
        }),
    });

    drag(drop(ref));

    renderCount++

    return (
        <div ref={ref} style={{ opacity: isDragging ? 0.5 : 1 }}>
            {renderCount}
            {renderItem(item, index, register, remove)}
        </div>
    );
});
