import { useEffect, useState } from "react";
import UnitDetails from "../../Containers/Units/UnitsDetail";
import UnitObjects from "../../Containers/Units/UnitObjects";
import BoxLayout from "../../Containers/Layout/BoxLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { useForm } from "react-hook-form";
import { useAppDispatch, useAppSelector } from "../../Redux/app/hooks";
import { useLocation, useNavigate } from "react-router-dom";
import ButtonComponent from "../../Components/Buttons/ButtonComponent";
import { AddUnitAPI } from "../../Redux/features/UnitSlice";
import { sessionListAPI } from "../../Redux/features/SessionSlice";
import { CategoryTypeListAPI } from "../../Redux/features/ObjectSlice";
import { notifyError } from "../../helper";

type Props = {};

export type UnitAddFormValues = {
  category_type_id: string;
  unit_name: string;
  internal_unit_name: string;
  order: number;
};

export type UnitSession = {
  object_id: string;
  permission: 0 | 1 | "";
  time: number;
};

const AddUnitsPage = (props: Props) => {
  const validationSchema = Yup.object().shape({
    unit_name: Yup.string().required("Unit name Necessary"),
    internal_unit_name: Yup.string(),
    category_type_id: Yup.string().required("Category type Necessary"),
  });

  const location = useLocation();

  const {
    register,
    watch,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<UnitAddFormValues>({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      internal_unit_name: location.state?.internal_unit_name,
      unit_name: location.state?.unit_name,
      category_type_id: location.state?.category_type_id,
      order: location.state?.order,
    },
  });

  const formValues = watch();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [UnitObjectList, setUnitObjectList] = useState<Array<UnitSession>>([]);

  useEffect(() => {
    setUnitObjectList(
      location.state?.session?.map((i: any) => {
        return {
          permission: i.permission,
          object_id: i.id,
          time: i.time,
        };
      })
    );
  }, [location.state]);

  const onSubmit = (data: UnitAddFormValues) => {
    let hasNoEmptyString = UnitObjectList.every(
      (item) => item.object_id !== "" && item.permission !== ""
    );
    if (hasNoEmptyString) {
      dispatch(
        AddUnitAPI({
          internal_unit_name: data.internal_unit_name,
          category_type_id: data.category_type_id,
          unit_name: data.unit_name,
          unit_object: UnitObjectList,
          order: data.order,
        })
      ).then(() => {
        navigate("/contentrepository/units");
      });
    }
  };

  useEffect(() => {
    const arrayOfError = Object.values(errors);
    if (Object.keys(errors).length !== 0) {
      arrayOfError.slice(0, 1).map((error: any) => notifyError(error.message));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [errors]);

  useEffect(() => {
    dispatch(sessionListAPI({}));
    dispatch(CategoryTypeListAPI());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    document.title = "FISIO | Add Units";
  }, []);

  const loading = useAppSelector((state) => state.Unit.UnitPostAPIIdle);

  return (
    <BoxLayout HeaderName="Content Repository" sectionName="Add Unit">
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="py-3 p-4">
          <div className="rounded-[10px] w-full  border">
            <div className="py-2 text-base px-4 font-semibold border-b">
              <p className=" py-2">Unit Details</p>
            </div>
            <div className="py-2 text-start">
              <UnitDetails
                control={control}
                register={register}
                errors={errors}
                formValues={formValues}
              />
            </div>
          </div>

          <div className=" py-2 text-start">
            <div className="py-2 text-start">
              <UnitObjects
                UnitObjectList={UnitObjectList}
                setUnitObjectList={setUnitObjectList}
                control={control}
                register={register}
                errors={errors}
                formValues={formValues}
              />
            </div>
          </div>
        </div>
        <div className="flex justify-between p-4">
          <button
            type="button"
            onClick={() => navigate("/contentrepository/units")}
          >
            Back
          </button>
          <div className="w-[100px]">
            <ButtonComponent
              className="w-[100px]"
              CTA="Save"
              buttonType="submit"
              varient="blue"
              loading={loading}
            />
          </div>
        </div>
      </form>
    </BoxLayout>
  );
};

export default AddUnitsPage;
