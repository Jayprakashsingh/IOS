import React, { useEffect, useState } from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Controller, useForm } from "react-hook-form";
import { useAppDispatch, useAppSelector } from "../../../Redux/app/hooks";
import { postWelcomePage } from "../../../Redux/features/OnboardingQuestionsSlice";
import ButtonComponent from "../../../Components/Buttons/ButtonComponent";
import { Status } from "../../../Redux/features/UserManagementSlice";

type Props = {
  data: WelcomeInfo[]
};

const SignInSignUp = ({ data }: Props) => {
  const [mimeType, setMimeType] = useState([
    "image/jpeg",
    "image/png",
    "application/pdf",
  ]);
  const validationSchema = Yup.object().shape({
    objectFile: Yup.mixed().test(
      "fileType",
      "Unsupported File Format",
      (value: any) => value && mimeType.includes(value[0].type)
    ),
  });

  const [loader, setLoader] = useState<Status>(Status.SUCCESS);
  const {
    register,
    setValue,
    watch,
    control,
    formState: { errors },
    handleSubmit,
  } = useForm<any>({
    resolver: yupResolver(validationSchema),
  });
  const formValues = watch();
  // const data = useAppSelector(
  //   (state) => state.OnboardingQuestions.getWeclomePageInfo.data.login
  // );

  const dispatch = useAppDispatch();

  useEffect(() => {
    setValue("objectFile", data[0]?.image);
  }, [data[0]?.image]);

  const handleSignInSignUp = (form: any) => {
    setLoader(Status.LOADING);
    let formData = new FormData();
    formData.append("id", data[0]?._id);
    formData.append("type", data[0]?.type);
    formData.append("text", data[0]?.text);
    formData.append("subtext", data[0]?.subtext);
    formData.append("image", form.objectFile[0]);
    dispatch(postWelcomePage(formData)).then(() => {
      setLoader(Status.SUCCESS);
    });
  };

  return (
    <form
      onSubmit={handleSubmit(handleSignInSignUp)}
      className="border-2 rounded-[10px] m-4 "
    >
      <p className="p-4 font-semibold capitalize ">{data[0]?.type}</p>
      <div className="grid grid-cols-12  border-t-2 p-4 pr-6 items-center">
        <label htmlFor={`file-inputs${data[0]?.type}`} className="cursor-pointer">
          <span className={`flex justify-center gap-2 text-sm items-center `}>
            <img src="/images/plusButton.svg" alt="" />
            Add File
          </span>
        </label>
        {typeof formValues?.objectFile !== "string" ? (
          <p className="w-[250px] whitespace-nowrap text-ellipsis">
            <span className="text-blue-950">File Name : </span>
            {typeof formValues?.objectFile !== "undefined" && formValues?.objectFile[0].name}
          </p>
        ) : (
          <p className="w-[250px] text-red-500 whitespace-nowrap text-ellipsis ">
            <span className="text-blue-950">File Name : </span>
            {formValues?.objectFile.split("/")[3]}
          </p>
        )}
        <Controller
          control={control}
          name="objectFile"
          render={({ field: { onChange, ref } }) => (
            <input
              id={`file-inputs${data[0]?.type}`}
              ref={ref}
              type="file"
              className="hidden"
              onChange={(e) => onChange(e.target.files)} // When the file changes, update it in the RHF store
            />
          )}
        />
        <ButtonComponent
          className="col-span-1  col-start-12"
          CTA="Save"
          varient="blue"
          loading={loader}
        />
      </div>
    </form>
  );
};

export default SignInSignUp;
