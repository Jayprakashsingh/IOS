import React from "react";
import { useAppSelector } from "../../../Redux/app/hooks";
import MarketingPage from "./MarketingPage";

type Props = {};

const MarketingPageContainer = (props: Props) => {
  const Marketing = useAppSelector(
    (state) => state.OnboardingQuestions.getWeclomePageInfo.data.Marketing
  );

  return (
    <div className="m-4 border-2 rounded-[10px]">
      <div className="font-medium py-4 px-4">Marketing Page</div>
      <div className="border-t-2 flex flex-col gap-3 py-4 px-6">
        {Marketing.map((marketing) => (
          <MarketingPage
            key={marketing._id}
            id={marketing._id}
            image={marketing.image}
            subtext={marketing.subtext}
            text={marketing.text}
            type={marketing.type}
          />
        ))}
      </div>
    </div>
  );
};

export default MarketingPageContainer;
