import React, { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import ButtonComponent from "../../../Components/Buttons/ButtonComponent";
import { useAppDispatch } from "../../../Redux/app/hooks";
import { postWelcomePage } from "../../../Redux/features/OnboardingQuestionsSlice";
import TextEditor from "../../../Components/Inputs/TextEditor";
import { Status } from "../../../Redux/features/UserManagementSlice";

type Props = {
  subtext: string;
  text: string;
  type: string;
  image: string | FileList;
  id: string;
};

type MarketingForm = {
  subtext: string,
  text: string,
  type: string,
  objectFile: string | FileList,
}

const MarketingPage = ({ subtext, text, type, image, id }: Props) => {
  const [loader, setLoader] = useState<Status>(Status.SUCCESS);
  const [mimeType] = useState([
    "image/jpeg",
    "image/png",
    "application/pdf",
  ]);
  const validationSchema = Yup.object().shape({
    objectFile: Yup.mixed().test(
      "fileType",
      "Unsupported File Format",
      (value: any) => {
        return typeof value === "object"
          ? mimeType.includes(value[0].type)
          : true;
      }
    ),
  });

  const {
    register,
    watch,
    handleSubmit,
    control,
  } = useForm<any>({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      subtext: subtext,
      text: text,
      type: type,
      objectFile: image,
    },
  });
  const formValues = watch();
  const dispatch = useAppDispatch();
  const handleMarketingPage = (data: MarketingForm) => {
    setLoader(Status.LOADING);
    let formData = new FormData();
    formData.append("text", data.text);
    formData.append("subtext", data.subtext);
    formData.append("type", data.type);
    formData.append("id", id);
    if (typeof data.objectFile !== "string") {
      formData.append("image", data.objectFile[0]);
    }
    dispatch(postWelcomePage(formData)).then((res) => {
      setLoader(Status.SUCCESS);
    });
  };
  return (
    <div>
      <form onSubmit={handleSubmit(handleMarketingPage)}>
        <div className="grid grid-cols-12  items-start justify-center gap-4">
          <TextEditor
            control={control}
            name="text"
            className="col-span-6"
            register={register}
            values={formValues.text}
            inputRef="text"
            label="text"
          />
          <TextEditor
            control={control}
            name="subtext"
            className="col-span-6"
            register={register}
            values={formValues.subtext}
            inputRef="subtext"
            label="subtext"
          />
          <div className="col-span-5 flex justify-start items-center w-full">
            <label htmlFor={`file-input-market${id}`}>
              <span className={`flex justify-center gap-2 text-sm items-center `}>
                <img src="/images/plusButton.svg" alt="" />
                Add File
              </span>
            </label>
            <div className="text-center py-4 flex items-center justify-between gap-4 px-4">
              <div className="flex gap-4 items-center">
                {typeof formValues?.objectFile !== "string" ? (
                  <p className="w-[250px] whitespace-nowrap text-ellipsis ">
                    <span className="text-blue-950">File Name : </span>
                    {formValues.objectFile && formValues?.objectFile[0]?.name}
                  </p>
                ) : (
                  <p className="w-[250px] text-red-500 whitespace-nowrap text-ellipsis ">
                    <span className="text-blue-950">File Name : </span>
                    {formValues?.objectFile?.split("/")[4]}
                  </p>
                )}
              </div>
            </div>
            <Controller
              control={control}
              name="objectFile"
              render={({ field: { onChange, ref } }) => (
                <input
                  id={`file-input-market${id}`}
                  ref={ref}
                  type="file"
                  className="hidden"
                  onChange={(e) => onChange(e.target.files)}
                />
              )}
            />
          </div>
          <ButtonComponent
            CTA="Submit"
            className="col-span-1 col-start-12"
            buttonType="submit"
            varient="blue"
            loading={loader}
          />
        </div>
      </form>
    </div>
  );
};

export default MarketingPage;
