import React, { useEffect } from 'react'
import BoxLayout from '../../Containers/Layout/BoxLayout'
import { useLocation, useNavigate } from 'react-router-dom'
import TextAreaComponent from '../../Components/Inputs/TextAreaComponent'
import { useForm, Controller } from 'react-hook-form'
import VideoPlayer from '../../Components/VideoPlayer/VideoPlayer'
import AddCoachFeedBack from '../../Containers/Coach/AddCoachFeedBack'
import InputComponent from '../../Components/Inputs/InputComponent'
import ButtonComponent from '../../Components/Buttons/ButtonComponent'
import { yupResolver } from '@hookform/resolvers/yup'
import * as Yup from "yup";
import { useAppDispatch, useAppSelector } from '../../Redux/app/hooks'
import { getReview, getSwingCheckByID, submitCoachReview } from '../../Redux/features/CoachReviewSlice'
import { notifyError, notifySuccess } from '../../helper'
import UploadFileComponents from '../../Components/Inputs/UploadFileComponents'

export type CoachReviewForm = {
    title: string,
    comment: string,
    rating: number,
    video: FileList | string,

}

type Props = {

}

const ReviewDetails = (props: Props) => {

    const validationSchema = Yup.object().shape({
        title: Yup.string().required(" Review Title Required"),
        comment: Yup.string().required("Comment Required"),
        rating: Yup.number().required(""),
        // video: Yup.string(),
    })

    const location = useLocation()

    const Review = useAppSelector(state => state.Coach.review)

    const { register, control, setValue, formState: { errors }, handleSubmit, watch } = useForm<any>({
        resolver: yupResolver(validationSchema),
        defaultValues: {
            video: ""
        }
    })

    const formValues = watch()

    useEffect(() => {
        const arrayOfError = Object.values(errors);
        if (Object.keys(errors).length !== 0) {
            arrayOfError.slice(0, 1).map((error: any) => notifyError(error.message));
        }
    }, [errors])



    useEffect(() => {
        setValue("comment", Review?.comment)
        setValue("rating", Review?.rating)
        setValue("title", Review?.title)
        if (Review?.file) {
            setValue("video", Review?.file)
        }
    }, [Review])


    useEffect(() => {
        dispatch(getSwingCheckByID({ id: location.state.data._id }))
    }, [])

    const dispatch = useAppDispatch()
    const navigate = useNavigate()

    const onSubmit = async (data: CoachReviewForm) => {
        console.log(data)
        const formData = new FormData()
        if (data?.video) {
            formData.append("file", data.video[0])
        }
        if (Review?.id) {
            formData.append("id", Review?.id)
        }
        formData.append("swing_id", location.state.data._id)
        formData.append("status", "Reviewed")
        formData.append("title", data.title)
        formData.append("comment", data.comment)
        formData.append("rating", String(data.rating))
    }
    const loading = useAppSelector(state => state.Coach.submitCoachReview)
    console.log(formValues)
    return (
        <BoxLayout HeaderName='Coach' sectionName='Review Status'>
            <div className='grid border-t py-3 items-start gap-2 text-center grid-cols-6'>
                <div>
                    <div className='text-base font-medium'>User Name</div>
                    <div>{location.state?.data.user_name}</div>
                </div>
                <div>
                    <div className='text-base font-medium'>Review ID</div>
                    <div>{location.state?.data.id}</div>
                </div>
                <div>
                    <div className='text-base font-medium'>Title</div>
                    <div>{location.state?.data.title}</div>
                </div>
                <div>
                    <div className='text-base font-medium'>Unit</div>
                    <div>{location.state?.data.current_unit}</div>
                </div>
                <div>
                    <div className='text-base font-medium'>Session</div>
                    <div>{location.state?.data.current_session}</div>
                </div>
                <div>
                    <div className='text-base font-medium'>Status</div>
                    <div className='text-orange-500 bg-[#fff8e1] w-fit m-auto px-2 rounded-3xl'>{location.state.data.status}</div>
                </div>
            </div>
            <div className='grid py-6 mb-16 gap-2 grid-cols-12 px-4'>
                <div className='col-span-6 '>
                    <VideoPlayer url={location.state.data?.file} />
                </div>
                <form onSubmit={handleSubmit(onSubmit)} className='col-span-6 flex h-full flex-col gap-2'>
                    <div className='border rounded-2xl'>
                        <div className='px-3 py-2 font-medium '>Coach Comment</div>
                        <div className='border-t flex flex-col gap-3 px-4 py-3'>
                            <InputComponent inputRef='title' label='title' register={register} name='' value='' />
                            <TextAreaComponent inputRef='comment' rows={3} label='Comment' register={register} name='' value='' />
                            <p>{Review?.file.split("/")[5]}</p>
                            <UploadFileComponents
                                label={
                                    "Upload File"
                                }
                                id="fileupload"
                                control={control}
                                inputRef="video"
                                value={formValues?.video}
                            />
                        </div>
                    </div>
                    <AddCoachFeedBack setSelectedRating={setValue} inputRef='rating' register={register} />
                    <ButtonComponent buttonType='submit' CTA='Save' varient='blue' loading={loading} />
                </form>
            </div>
        </BoxLayout>
    )
}

export default ReviewDetails