import React from 'react';
import { ModalProps } from '../../types/globle.type';

const Modal: React.FC<ModalProps> = ({ onSave, data, setData }) => {

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setData({ ...data, [e.target.name]: e.target.value });
    };

    return (
        <div className='w-full flex z-50 items-center justify-center h-screen bg-black bg-opacity-30 fixed top-0 left-0'>
            <div className='flex z-50 opacity-100 justify-center items-center h-[30vh] w-[30vw] bg-white ' >

                {/* Modal layout */}
                <input name="link" value={data.link} onChange={handleChange} />
                <input name="title" value={data.title} onChange={handleChange} />
                <textarea name="desc" value={data.description} onChange={handleChange} />
                <button type="button" onClick={onSave}>Save</button>
                <button type="button" onClick={() => setData({ link: '', title: '', description: '' })}>Cancel</button>
            </div>
        </div>
    );
};

export default Modal;
