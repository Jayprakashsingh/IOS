import React, { useEffect, useState } from "react";
import ResetPasswordForm from "../../Containers/Auth/ResetPasswordForm";

type Props = {};

const ResetPasswordPage = (props: Props) => {
  const [first, setfirst] = useState("");
  useEffect(() => {
    document.title = "FISIO | Reset Password";
  }, []);

  return (
    <div className="box-border h-screen">
      <div className="grid grid-cols-1 lg:grid-cols-2 w-full h-screen  justify-between">
        <div className="col-span-1">
          <div className="flex justify-start p-6">
            <img src="/images/logo.svg" className="h-[40px]" alt="FISIO Logo" />
          </div>
          <ResetPasswordForm />
        </div>
        {/* Right Column: Background Image (hidden on smaller screens) */}
        <div className="col-span-1 hidden lg:flex">
          <img
            className="object-cover w-full"
            src="/images/background.jpg"
            alt="Background"
          />
        </div>
      </div>
    </div>
  );
};

export default ResetPasswordPage;
