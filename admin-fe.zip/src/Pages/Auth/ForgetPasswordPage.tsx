import { useEffect } from "react";
import ForgetPasswordForm from "../../Containers/Auth/ForgetPasswordForm";

type Props = {};

const ForgetPasswordPage = (props: Props) => {
  useEffect(() => {
    document.title = "FISIO | Forget Password";
  }, []);

  return (
    <div className="box-border h-screen ">
      <div className="grid grid-cols-1 lg:grid-cols-2 w-full h-screen  justify-between">
        <div className="col-span-1">
          <div className="flex justify-start p-6">
            <img src="/images/logo.svg" className="h-[40px]" alt="FISIO Logo" />
          </div>
          <ForgetPasswordForm />
        </div>
        {/* Right Column: Background Image (hidden on smaller screens) */}
        <div className="col-span-1 hidden lg:flex">
          <img
            className="object-cover w-full"
            src="/images/background.jpg"
            alt="Background"
          />
        </div>
      </div>
    </div>
  );
};

export default ForgetPasswordPage;
