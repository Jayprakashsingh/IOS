import React, { useEffect } from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { useAppDispatch, useAppSelector } from "../../Redux/app/hooks";
import ButtonComponent from "../../Components/Buttons/ButtonComponent";
import UploadFileComponents from "../../Components/Inputs/UploadFileComponents";
import {
  getRecallCards,
  postRecallCardsAPI,
} from "../../Redux/features/RecallCardsSlice";
import TextAreaComponent from "../../Components/Inputs/TextAreaComponent";
import MultiSelectComponent from "../../Components/Inputs/MultiSelectComponent";
import { TagListAPI } from "../../Redux/features/TagSlice";
import TextEditor from "../../Components/Inputs/TextEditor";
import CustomPlayer from "../../Components/VideoPlayer/VideoPlayer";
import { toast } from "react-toastify";

type Props = {
  setAddFormModal: React.Dispatch<React.SetStateAction<boolean>>;
  answer_text?: string;
  question_text?: string;
  answer_image?: FileList | string;
  question_image?: FileList | string;
  learn_more_video?: FileList | string;
  id?: string;
  Heading: string;
  setAnswerImage: Function;
  setQuestionImage: Function;
  tags?: string
};

type FormValues = {
  answer_text: string;
  question_text: string;
  answer_image: FileList | string;
  question_image: FileList | string;
  learn_more_video: FileList | string;
  tag: any[]
};

const AddCardForm = ({
  tags = "",
  setAnswerImage,
  setQuestionImage,
  setAddFormModal,
  answer_image = "",
  answer_text = "",
  question_image = "",
  question_text = "",
  learn_more_video = "",
  id = "",
  Heading,
}: Props) => {
  const validationSchema = Yup.object().shape({
    answer_text: Yup.string().required("Answer Text is required"),
    question_text: Yup.string().required("Question Text is required"),
    tag: Yup.array()
  });

  useEffect(() => {
    return () => {
      setAnswerImage("null");
      setQuestionImage("null");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tag = useAppSelector((state) => state.Tag.TagList.data.tags);

  const {
    setValue,
    register,
    watch,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<any>({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      answer_image: answer_image,
      answer_text: answer_text,
      question_image: question_image,
      question_text: question_text,
      learn_more_video: learn_more_video,
      tag: tag
        ?.filter((item) => tags?.includes(item._id))
        ?.map((item) => ({ label: item.name, value: item._id })),

    },
  });

  const dispatch = useAppDispatch();

  const formValues = watch();
  console.log(formValues)
  const handleAddCard = (data: FormValues) => {
    console.log(data)

    let formData = new FormData();
    formData.append("answer_text", data.answer_text);
    formData.append("question_text", data.question_text);
    formData.append("level", "1");
    if (id !== "") {
      formData.append("id", id);
    }
    if (typeof data.answer_image === "object") {
      formData.append("answer_img", data.answer_image[0]);
    } else {
      formData.append("answer_img", "");
    }
    const tags = data.tag.map((tag) => {
      return tag.value;
    });
    formData.append("tag", tags.join(","));
    if (typeof data.question_image === "object") {
      formData.append("question_img", data.question_image[0]);
    } else {
      formData.append("question_img", "");
    }
    if (typeof data?.learn_more_video === "object" && data?.learn_more_video?.length) {
      formData.append("learn_more_video", data?.learn_more_video[0]);
    } else if (data.learn_more_video === "") {
      formData.append("learn_more_video", "");
    }
    dispatch(postRecallCardsAPI(formData)).then((res) => {
      if (res.payload) {
        dispatch(getRecallCards({}));
        setAddFormModal(false);
      } else {
        toast.error("Please Upload Valid File")
      }
      // console.log(res)
    });
  };
  const loading = useAppSelector(
    (state) => state.RecallCards.postRecallCardsAPIIdle
  );

  useEffect(() => {
    dispatch(TagListAPI({}));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  return (
    <div className="p-4 flex flex-col overflow-auto h-full">
      <h2 className="text-xl font-bold mb-4">{Heading}</h2>
      <form onSubmit={handleSubmit(handleAddCard)} className="mb-4 h-full">
        <div className="mt-auto flex flex-col h-full w-full justify-between">
          <div className="flex flex-col gap-3 ">
            <TextEditor
              className=""
              name="question_text"
              control={control}
              inputRef="question_text"
              label="Question Text"
              register={register}
              values={formValues.question_text}
            />
            <TextEditor
              className=""
              name="question_text"
              control={control}
              inputRef="answer_text"
              label="Answer Text"
              register={register}
              values={formValues.question_text}
            />
            <MultiSelectComponent
              // errorname={errors.tag?.message}
              control={control}
              inputRef="tag"
              isMulti
              label="Tags"
              placeHolder="Tags"
              options={tag.map((value) => {
                return {
                  value: value._id,
                  label: value.name,
                };
              })}
            />
            <div className="flex flex-row gap-6">
              <UploadFileComponents
                label={
                  answer_image !== "" && typeof answer_image === "string" && formValues?.answer_image.length !== 0
                    ? answer_image.split("/")[4]
                    : "Upload Answer Image"
                }
                id="answer_image"
                control={control}
                inputRef="answer_image"
                value={formValues.answer_image}
              />
              {answer_image === undefined && "Upload Question Image"}
              <img
                className="w-6"
                onClick={() => setValue("answer_image", "")}
                src="/images/remove.svg"
                alt="remove"
              />
            </div>
            <div className="flex flex-row gap-6">
              <UploadFileComponents
                label={
                  question_image !== "" &&
                    typeof question_image === "string"
                    && formValues?.question_image.length !== 0
                    ? question_image.split("/")[4]
                    : "Upload Question Image"
                }
                id="question_image"
                control={control}
                inputRef="question_image"
                value={formValues.question_image}
              />
              <img
                className="w-6"
                onClick={() => setValue("question_image", "")}
                src="/images/remove.svg"
                alt="remove"
              />
            </div>
            <div className="flex flex-row gap-6">
              <UploadFileComponents
                label={
                  learn_more_video !== "" &&
                    typeof learn_more_video === "string"
                    && formValues?.learn_more_video.length !== 0
                    ? learn_more_video?.split("/")[4]
                    : "Upload Video File"
                }
                id="learn_more_video"
                control={control}
                inputRef="learn_more_video"
                value={formValues?.learn_more_video}
              />
              <img
                className="w-6"
                onClick={() => setValue("learn_more_video", "")}
                src="/images/remove.svg"
                alt="remove"
              />
            </div>
          </div>
          <div className="mb-16">

            {
              formValues?.learn_more_video !== "" && typeof formValues?.learn_more_video === "string" ?
                <CustomPlayer url={formValues?.learn_more_video} /> : <></>
            }
            {
              formValues?.learn_more_video !== "" && typeof formValues?.learn_more_video === "object" && formValues?.learn_more_video.length ?
                <CustomPlayer url={formValues?.learn_more_video.length ? URL.createObjectURL(formValues?.learn_more_video[0]) : ""} /> : <></>
            }
          </div>
          <div className="flex gap-5 rounded-none col-end-3 ">
            <ButtonComponent
              CTA="Cancel"
              buttonType="button"
              varient="outline"
              onClick={() => setAddFormModal(false)}
            />
            <ButtonComponent
              CTA="Save"
              buttonType="submit"
              loading={loading}
              varient="blue"
            />
          </div>
        </div>
      </form>
    </div>
  );
};

export default React.memo(AddCardForm);
