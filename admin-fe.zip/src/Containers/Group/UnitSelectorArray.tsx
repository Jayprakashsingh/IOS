import React, { useEffect } from "react";
import Select from "react-select";
import { DropDownStyles } from "../../helper";
import { formatTime } from "../../utils/helper";

type Props = {
  index: number;
  select: any;
  objectList: any;
  ObjectList: any;
  handleInputChange: any;
  handlePermissionChange: any;
  handleRemoveInput: any;
};

const UnitSelectorArray = React.memo(
  ({
    index,
    select,
    objectList,
    ObjectList,
    handleInputChange,
    handlePermissionChange,
    handleRemoveInput,
  }: Props) => {
    console.log(select, objectList, "select");
    return (
      <div className="grid grid-cols-12 gap-4 items-center" key={index}>
        <p className="col-span-1 m-auto">{index + 1}.</p>
        <div className="col-span-6">
          <div className="flex flex-col w-full">
            <div className="relative">
              <label
                className={`absolute left-4 -top-2 bg-gradient-to-b text-xs font-medium from-[#ffffff] from-[-4.22%] to-[#Fafafa] to-[120.23%] px-2 z-10`}
              >
                Unit Name
              </label>
              <Select
                value={{
                  value: select.object_id,
                  label: objectList?.filter(
                    (value: any) => value.id === select.object_id
                  )[0]?.unit,
                }}
                options={objectList.map((value: any) => {
                  return {
                    label: value.unit,
                    value: value.id,
                  };
                })}
                styles={DropDownStyles}
                placeholder={"Unit Name"}
                onChange={(e: any) => {
                  const time = objectList.filter(
                    (i: any) => i._id === ObjectList[index].object_id
                  )[0]?.object_time;
                  handleInputChange(index, e.value, Number(time));
                }}
              />
            </div>
          </div>
        </div>
        <div className="col-span-3 hidden justify-center m-auto  flex-col gap-1 text-xs">
          <p>Permission</p>
          <div className=" hidden">
            <div className="flex flex-wrap gap-2 items-center">
              <input
                type="radio"
                onChange={(e) => handlePermissionChange(index, e.target.value)}
                name={`val${index}`}
                defaultChecked={Number(select.permission) === 0}
                value={0}
              />
              <label>{"Required"}</label>
              <input
                type="radio"
                name={`val${index}`}
                value={1}
                defaultChecked={Number(select.permission) === 1}
                onChange={(e) => handlePermissionChange(index, e.target.value)}
              />
              <label>{"Optional"}</label>
            </div>
          </div>
        </div>
        <div className="text-xs col-span-1">
          <div>Time</div>
          <div>
            {formatTime(
              Number(
                objectList.filter(
                  (i: any) => i.id === ObjectList[index].object_id
                )[0]?.time
              )
            )}
          </div>
        </div>
        <div className="col-span-2  col-start-12 flex gap-4">
          <span className="text-xs">{}</span>
          <button type="button" onClick={() => handleRemoveInput(index)}>
            <img className="w-6" src="/images/remove.svg" alt="remove" />
          </button>
        </div>
      </div>
    );
  }
);

export default UnitSelectorArray;
