import { UseFormRegister } from "react-hook-form/dist/types"
import RatingComponent from '../../Components/RatingComponent'
import { CoachReviewForm } from '../../Pages/Coach/ReviewDetails'

type Props = {
    register: UseFormRegister<CoachReviewForm>,
    inputRef: string,
    setSelectedRating: Function

}

const AddCoachFeedBack = ({ register, inputRef, setSelectedRating }: Props) => {

    return (
        <div className='col-span-6 '>
            <div className='border rounded-2xl'>
                <div className='px-3 py-2 font-medium '>Coach FeedBack</div>
                <div className='border-t px-4 py-3'>
                    <RatingComponent onChange={setSelectedRating} inputRef={inputRef} />
                </div>
            </div>
        </div>
    )
}

export default AddCoachFeedBack