import React, { useState } from 'react'
import OverviewDetails from '../Session/OverviewDetails'
import { useForm } from 'react-hook-form'

type Props = {}

const AddTrustOverView = (props: Props) => {
    const { control, register, formState: { errors }, watch } = useForm({

    })

    const formValues = watch()

    const [objectList, setObjectList] = useState<any>([{
        "object_id": "64be7ad9b8f8198b810764d5",
        "permission": "1",
        "title": "Muscle: Training",
        "description": "Pinch, Place, Close: Left Hand - Gravity Check: This drill helps you train the correct Pinch, Place, Close technique plus check to ensure your grip is correct every time.",
        "time": 0
    }])
    return (
        <OverviewDetails
            overviewName='Add Trust Overview'
            placeholder={""}
            formValues={formValues}
            ObjectList={objectList}
            control={control}
            errors={errors}
            // formValues={formValues}
            // placeholder={placeholder}
            register={register}
            setObjectList={setObjectList}
        />
    )
}

export default AddTrustOverView