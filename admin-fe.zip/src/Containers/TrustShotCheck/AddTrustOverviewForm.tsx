import React, { useEffect, useState } from "react";
import InputComponent from "../../Components/Inputs/InputComponent";
import TextEditor from "../../Components/Inputs/TextEditor";
import ButtonComponent from "../../Components/Buttons/ButtonComponent";
import { useForm } from "react-hook-form";
import { useAppDispatch, useAppSelector } from "../../Redux/app/hooks";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  getShotCheckOverViewAPI,
  getTrustOverViewAPI,
  postOverViewAPI,
} from "../../Redux/features/TrustShotCheckSlice";
import { Status } from "../../Redux/features/UserManagementSlice";
import { notifySuccess } from "../../helper";
type Props = {};

type OverviewForm = {
  headline: string;
  text: string;
  time: number;
  description: string;
};

const AddTrustOverviewForm = (props: Props) => {
  const overview = useAppSelector(
    (state) => state.TrustShotCheck.trustOverView
  );
  const description = useAppSelector(
    (state) => state.TrustShotCheck.trustOverView?.description
  );
  const text = useAppSelector(
    (state) => state.TrustShotCheck.trustOverView?.text
  );
  const time = useAppSelector(
    (state) => state.TrustShotCheck.trustOverView?.time
  );
  const headline = useAppSelector(
    (state) => state.TrustShotCheck.trustOverView?.headline
  );

  const validationSchema = Yup.object().shape({
    headline: Yup.string().required("headline Need"),
    text: Yup.string().required("text need"),
    // time: Yup,
    description: Yup.string().required("description"),
  });

  const {
    control,
    setValue,
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<any>({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      description: description,
      headline: headline,
      text: text,
      time: time,
    },
  });

  console.log(errors, "errors");

  useEffect(() => {
    if (overview) {
      setValue("description", overview.description);
      setValue("headline", overview.headline);
      setValue("text", overview.text);
      setValue("time", overview.time);
    }
  }, [overview]);

  const [loading, setLoading] = useState<Status>(Status.SUCCESS);

  const onSubmit = (data: any) => {
    setLoading(Status.LOADING);
    dispatch(
      postOverViewAPI({
        type: "trust",
        headline: data.headline,
        description: data.description,
        time: data.time ? data.time : 0,
        text: data.text,
        id: overview?.id,
      })
    ).then((res) => {
      if (res.payload.success) {
        notifySuccess("Text saved successfully");
        setLoading(Status.SUCCESS);
      }
      setLoading(Status.ERROR);
    });
  };

  const dispatch = useAppDispatch();

  useEffect(() => {
    // dispatch(getShotCheckOverViewAPI())
    dispatch(getTrustOverViewAPI());
  }, []);

  // const

  return (
    <div>
      <div className="pb-2 mx-6 mb-3 gap-3 border rounded-2xl  ">
        <div className="col-span-3  py-3 font-semibold border-b">
          <span className="px-6">Trust Overview</span>
        </div>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className=" grid-cols-3 grid gap-3 px-4 py-3"
        >
          {/* {overview && */}
          <>
            <InputComponent
              value=""
              inputRef="headline"
              name="Headline"
              register={register}
              label="Headline"
            />
            <InputComponent
              inputRef="text"
              label="Text"
              name=""
              register={register}
              value=""
              className=""
              errorname=""
              inputClassName=""
            />
            <InputComponent
              inputRef="time"
              name=""
              label="Time (mm:ss)"
              register={register}
              value=""
              className="hidden"
              errorname=""
              inputClassName=""
            />
            <TextEditor
              className="col-span-3"
              control={control}
              inputRef="description"
              label="Description"
              name=""
              register={register}
              values=""
            />
            <ButtonComponent
              CTA="Save"
              buttonType="submit"
              varient="blue"
              className="max-w-[120px]"
              loading={loading}
            />
          </>
          {/* } */}
        </form>
      </div>
      <div></div>
    </div>
  );
};

export default AddTrustOverviewForm;
