import React, { useEffect, useState } from 'react';
import { useAppSelector } from '../Redux/app/hooks';

interface Props {
    onChange?: Function;
    inputRef: string
}

const RatingComponent: React.FC<Props> = ({ onChange, inputRef }) => {
    const Review = useAppSelector((state) => state.Coach.review)
    const [selectedRating, setSelectedRating] = useState<number | null>(Number(Review?.id));

    useEffect(() => {
        setSelectedRating(Number(Review?.rating))
    }, [Review])


    const handleRatingClick = (rating: number) => {
        // Determine next rating based on current rating and clicked star
        let nextRating;
        if (selectedRating === rating) {
            nextRating = rating - 0.5;  // go from full to half
        } else if (selectedRating === rating - 0.5) {
            nextRating = rating;        // go from half to full
        } else {
            nextRating = rating;        // other case, set to full
        }
        setSelectedRating(nextRating);

        if (onChange) {
            onChange(inputRef, nextRating);
        }
    };

    console.log(selectedRating, "s")

    const renderStar = (index: number) => {
        if (selectedRating === null) return <img className='h-8 w-8' src={"/images/star.svg"} />;

        if (index + 1 <= selectedRating) {
            return <img className='h-8 w-8' src={"/images/starfill.svg"} />; // full star
        } else if (index + 0.5 === selectedRating) {
            return <img className='h-8 w-8' src={"/images/halfStar.svg"} />; // half star
        }
        return <img className='h-8 w-8' src={"/images/emptystar.svg"} />; // empty star
    };

    return (
        <div className="rating flex gap-4">
            {[1, 2, 3, 4, 5].map(index => (
                <span
                    key={index}
                    className='cursor-pointer  text-4xl'
                    onClick={() => handleRatingClick(index)} // This will handle star rating logic
                    style={{
                        cursor: 'pointer',
                        fontSize: 36,
                        // color: renderStar(index) !== '☆' ? 'gold' : 'grey',
                        marginRight: 8
                    }}
                >
                    {renderStar(index - 1)}
                </span>
            ))}
        </div>
    );
}

export default RatingComponent;
