type BadgeProps = {
    onClick?: (data?: any) => void
    CTA: string
}
type Props = {
}


export function Badge({ onClick = () => { }, CTA }: BadgeProps) {
    return (
        <span className='bg-black text-white hover:bg-slate-700 cursor-pointer px-3 py-1 text-sm rounded select-none' onClick={() => onClick()}>{CTA}</span>
    )
}