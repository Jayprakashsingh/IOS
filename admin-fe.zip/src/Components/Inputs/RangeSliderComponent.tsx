import React, { useState } from 'react';


type Props = {
    label?: string;
}


const RangeSlider: React.FC<Props> = ({ label = " 4 more sessions to move to the next level!" }) => {
    const [value, setValue] = useState<number>(50);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setValue(Number(e.target.value));
    };

    // Calculate the percentage of the value within the range
    const valuePercentage = (value - 0) * 100 / (1000 - 0);

    return (
        <div className="flex flex-col items-center gap-4 py-2 h-full ">
            <div className='flex justify-between items-center w-full text-sm'>
                <label htmlFor="range">
                    {label}
                </label>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {value}
                </p>
            </div>
            <input
                id='range'
                type="range"
                min="0"
                max="1000"
                value={value}
                onChange={handleChange}
                className="w-full h-4 shadow-2xl  rounded-lg appearance-none cursor-pointer bg-gray-200"
                style={{
                    background: `linear-gradient(to right, #F58124  ${valuePercentage}%,#efefef ${valuePercentage}%)`
                }}
            />

        </div>
    );
};

export default RangeSlider;
