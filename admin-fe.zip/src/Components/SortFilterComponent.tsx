import SortIcon from "./Icons/SortIcon";

type Props = {
  getSortValue: Function;
  sortType: sortValues;
};

const SortFilterComponent = ({ getSortValue, sortType }: Props) => {
  return (
    <button
      onClick={() => {
        getSortValue();
      }}
    >
      <SortIcon ascending={sortType === "ascending"} />
    </button>
  );
};

export default SortFilterComponent;
