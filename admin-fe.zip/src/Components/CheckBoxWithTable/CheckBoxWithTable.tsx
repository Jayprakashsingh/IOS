import React from 'react'

type Props = {}

const CheckBoxWithTable = (props: Props) => {
    return (
        <div>CheckBoxWithTable</div>
    )
}

export default CheckBoxWithTable