type Props = {};

const CoverIcon = (props: Props) => {
  return (
    <svg
      width="19"
      height="19"
      viewBox="0 0 19 19"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3.55556 17H14.4444C15.3036 17 16 16.3036 16 15.4444V4.55556C16 3.69645 15.3036 3 14.4444 3H3.55556C2.69645 3 2 3.69645 2 4.55556V15.4444C2 16.3036 2.69645 17 3.55556 17ZM3.55556 17L12.1111 8.44444L16 12.3333M7.44444 7.27778C7.44444 7.92211 6.92211 8.44444 6.27778 8.44444C5.63345 8.44444 5.11111 7.92211 5.11111 7.27778C5.11111 6.63345 5.63345 6.11111 6.27778 6.11111C6.92211 6.11111 7.44444 6.63345 7.44444 7.27778Z"
        stroke="url(#paint0_linear_439_24455)"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <rect x="12" width="7" height="7" rx="3.5" fill="white" />
      <path
        d="M15.0327 5.5L13 3.03192L13.3271 2.63475L15.0327 4.70567L17.6729 1.5L18 1.89716L15.0327 5.5Z"
        fill="url(#paint1_linear_439_24455)"
      />
      <defs>
        <linearGradient
          id="paint0_linear_439_24455"
          x1="16.2143"
          y1="17.9333"
          x2="-0.384563"
          y2="-0.241625"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#F58124" />
          <stop offset="1" stopColor="#FFC266" />
        </linearGradient>
        <linearGradient
          id="paint1_linear_439_24455"
          x1="18.0765"
          y1="5.76667"
          x2="13.5398"
          y2="-0.442766"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#F58124" />
          <stop offset="1" stopColor="#FFC266" />
        </linearGradient>
      </defs>
    </svg>
  );
};

export default CoverIcon;
