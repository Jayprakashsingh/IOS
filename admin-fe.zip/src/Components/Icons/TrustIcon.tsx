import React from 'react'

type Props = {
    isActive: boolean;
};
const TrustIcon = (props: Props) => {
    return (
        <svg width="14" height="13" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 12.0414C10.0376 12.0414 12.5 11.1796 12.5 10.1164C12.5 9.05326 10.0376 8.19141 7 8.19141C3.96243 8.19141 1.5 9.05326 1.5 10.1164C1.5 11.1796 3.96243 12.0414 7 12.0414Z" stroke="#767576" />
            <path d="M7 9.84297V1.04297M7 1.86797L9.9821 3.35902C10.8407 3.78802 11.2702 4.00307 11.2702 4.34297C11.2702 4.68287 10.8412 4.89737 9.9821 5.32692L7 6.81797" stroke="#767576" stroke-linecap="round" />
        </svg>

    )
}

export default TrustIcon