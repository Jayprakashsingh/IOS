import React from "react";

type Props = {
  isActive: boolean;
};

const UserManagementIcon = ({ isActive }: Props) => {
  return (
    <>
      {isActive ? (
        <svg
          width="20"
          height="20"
          viewBox="0 0 20 20"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M13.6863 7.87321V6.08404C13.6863 3.98987 11.9879 2.29154 9.89378 2.29154C7.79962 2.28237 6.09462 3.97237 6.08545 6.06737V6.08404V7.87321"
            stroke="url(#paint0_linear_567_834)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M13.0695 17.7081H6.70199C4.95699 17.7081 3.54199 16.294 3.54199 14.5481V10.974C3.54199 9.22813 4.95699 7.81396 6.70199 7.81396H13.0695C14.8145 7.81396 16.2295 9.22813 16.2295 10.974V14.5481C16.2295 16.294 14.8145 17.7081 13.0695 17.7081Z"
            stroke="url(#paint1_linear_567_834)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M9.8859 11.8357V13.6865"
            stroke="url(#paint2_linear_567_834)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <defs>
            <linearGradient
              id="paint0_linear_567_834"
              x1="11.7647"
              y1="7.43714"
              x2="7.35665"
              y2="-0.43865"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
            <linearGradient
              id="paint1_linear_567_834"
              x1="13.022"
              y1="16.9352"
              x2="4.96955"
              y2="3.38718"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
            <linearGradient
              id="paint2_linear_567_834"
              x1="10.0919"
              y1="13.5419"
              x2="8.58999"
              y2="12.6547"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
          </defs>
        </svg>
      ) : (
        <svg
          width="15"
          height="18"
          viewBox="0 0 15 18"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M11.6863 6.87321V5.08404C11.6863 2.98987 9.98795 1.29154 7.89378 1.29154C5.79962 1.28237 4.09462 2.97237 4.08545 5.06737V5.08404V6.87321"
            stroke="#9E9E9E"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M11.0695 16.7081H4.70199C2.95699 16.7081 1.54199 15.294 1.54199 13.5481V9.97397C1.54199 8.22813 2.95699 6.81396 4.70199 6.81396H11.0695C12.8145 6.81396 14.2295 8.22813 14.2295 9.97397V13.5481C14.2295 15.294 12.8145 16.7081 11.0695 16.7081Z"
            stroke="#9E9E9E"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M7.8859 10.8354V12.6863"
            stroke="#9E9E9E"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </>
  );
};

export default UserManagementIcon;
