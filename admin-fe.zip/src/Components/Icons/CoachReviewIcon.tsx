import React from "react";

type Props = {
  isActive: boolean;
};

const CoachReviewIcon = ({ isActive }: Props) => {
  return (
    <>
      {isActive ? (
      <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.8572 6.42857L14.8572 10L19.8572 13.5714V6.42857Z" stroke="url(#paint0_linear_3550_1412)" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M13.4286 5H5.57145C4.78248 5 4.14288 5.63959 4.14288 6.42857V13.5714C4.14288 14.3604 4.78248 15 5.57145 15H13.4286C14.2176 15 14.8572 14.3604 14.8572 13.5714V6.42857C14.8572 5.63959 14.2176 5 13.4286 5Z" stroke="url(#paint1_linear_3550_1412)" stroke-linecap="round" stroke-linejoin="round"/>
      <defs>
      <linearGradient id="paint0_linear_3550_1412" x1="15.8845" y1="14.2188" x2="8.60862" y2="-0.782521" gradientUnits="userSpaceOnUse">
      <stop stop-color="#285A9F"/>
      <stop offset="1" stop-color="#C0DAFE"/>
      </linearGradient>
      <linearGradient id="paint1_linear_3550_1412" x1="15.8845" y1="14.2188" x2="8.60862" y2="-0.782521" gradientUnits="userSpaceOnUse">
      <stop stop-color="#285A9F"/>
      <stop offset="1" stop-color="#C0DAFE"/>
      </linearGradient>
      </defs>
      </svg>
      
      ) : (
        <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19.8572 6.42857L14.8572 10L19.8572 13.5714V6.42857Z"  stroke="#9E9E9E" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M13.4286 5H5.57145C4.78248 5 4.14288 5.63959 4.14288 6.42857V13.5714C4.14288 14.3604 4.78248 15 5.57145 15H13.4286C14.2176 15 14.8572 14.3604 14.8572 13.5714V6.42857C14.8572 5.63959 14.2176 5 13.4286 5Z" stroke="url(#paint1_linear_3550_1412)" stroke-linecap="round" stroke-linejoin="round"/>
        <defs>
        <linearGradient id="paint0_linear_3550_1412" x1="15.8845" y1="14.2188" x2="8.60862" y2="-0.782521" gradientUnits="userSpaceOnUse">
        <stop stop-color="#9E9E9E"/>
        <stop offset="1" stop-color="#C0DAFE"/>
        </linearGradient>
        <linearGradient id="paint1_linear_3550_1412" x1="15.8845" y1="14.2188" x2="8.60862" y2="-0.782521" gradientUnits="userSpaceOnUse">
        <stop stop-color="#9E9E9E"/>
        <stop offset="1" stop-color="#C0DAFE"/>
        </linearGradient>
        </defs>
        </svg>
      )}
    </>
  );
};

export default CoachReviewIcon;

