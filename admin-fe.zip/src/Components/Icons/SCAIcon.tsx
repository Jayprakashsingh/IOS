import React from "react";

type Props = {};

const SCAIcon = (props: Props) => {
  return (
    <>
      <svg
        width="10"
        height="14"
        viewBox="0 0 10 14"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M2.83429 8.08003L2.14286 13.2857L5 11.5715L7.85714 13.2857L7.16571 8.07432M9 4.71432C9 6.92345 7.20914 8.71431 5 8.71431C2.79086 8.71431 1 6.92345 1 4.71432C1 2.50518 2.79086 0.714315 5 0.714315C7.20914 0.714315 9 2.50518 9 4.71432Z"
          stroke="#1F3161"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </>
  );
};

export default SCAIcon;
