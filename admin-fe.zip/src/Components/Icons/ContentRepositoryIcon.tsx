type Props = {
  isActive: boolean;
};

const ContentRepositoryIcon = ({ isActive }: Props) => {
  return (
    <>
      {isActive ? (
        <svg
          width="16"
          height="18"
          viewBox="0 0 16 18"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.2814 1.30142H4.73727C3.00394 1.29475 1.58311 2.67642 1.54227 4.40892V13.3364C1.50394 15.0972 2.89977 16.5564 4.66061 16.5956C4.68644 16.5956 4.71144 16.5964 4.73727 16.5956H11.3948C13.1398 16.5247 14.5148 15.0831 14.5023 13.3364V5.69808L10.2814 1.30142Z"
            stroke="url(#paint0_linear_892_14396)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M10.0625 1.29163V3.71579C10.0625 4.89913 11.0192 5.85829 12.2025 5.86163H14.4983"
            stroke="url(#paint1_linear_892_14396)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M9.90674 11.7987H5.40674"
            stroke="url(#paint2_linear_892_14396)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M8.20243 8.67167H5.40576"
            stroke="url(#paint3_linear_892_14396)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <defs>
            <linearGradient
              id="paint0_linear_892_14396"
              x1="11.2257"
              y1="15.4011"
              x2="-2.86551"
              y2="-0.26633"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
            <linearGradient
              id="paint1_linear_892_14396"
              x1="13.3769"
              y1="5.50459"
              x2="9.2636"
              y2="0.266161"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
            <linearGradient
              id="paint2_linear_892_14396"
              x1="8.7691"
              y1="12.1503"
              x2="8.55541"
              y2="10.6363"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
            <linearGradient
              id="paint3_linear_892_14396"
              x1="7.49541"
              y1="9.02323"
              x2="7.16191"
              y2="7.55479"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#285A9F" />
              <stop offset="1" stopColor="#C0DAFE" />
            </linearGradient>
          </defs>
        </svg>
      ) : (
        <svg
          width="16"
          height="18"
          viewBox="0 0 16 18"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.2814 1.30154H4.73727C3.00394 1.29487 1.58311 2.67654 1.54227 4.40904V13.3365C1.50394 15.0974 2.89977 16.5565 4.66061 16.5957C4.68644 16.5957 4.71144 16.5965 4.73727 16.5957H11.3948C13.1398 16.5249 14.5148 15.0832 14.5023 13.3365V5.6982L10.2814 1.30154Z"
            stroke="#ADA4A5"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M10.0625 1.29175V3.71591C10.0625 4.89925 11.0192 5.85841 12.2025 5.86175H14.4983"
            stroke="#ADA4A5"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M9.90674 11.7987H5.40674"
            stroke="#ADA4A5"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M8.20243 8.67179H5.40576"
            stroke="#ADA4A5"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </>
  );
};

export default ContentRepositoryIcon;
