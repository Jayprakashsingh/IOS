type Props = {};

const DashboardIcon = (props: Props) => {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10.8878 3.85833C10.8878 5.43333 9.60446 6.71667 8.00029 6.71667C6.39613 6.71667 5.11279 5.43333 5.11279 3.85833C5.11279 2.28333 6.39613 1 8.00029 1C9.60446 1 10.8878 2.28333 10.8878 3.85833Z" stroke="#1F3161" stroke-width="1.3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M8 8.08789C4.12083 8.08789 1 11.1796 1 15.0004H15C15 11.1796 11.8792 8.08789 8 8.08789Z" stroke="#1F3161" stroke-width="1.3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
    </svg>

  );
};

export default DashboardIcon;
