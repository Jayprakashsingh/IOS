type Props = {};

const ReportIcon = (props: Props) => {
  return (
    <svg
      width="18"
      height="20"
      viewBox="0 0 18 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12.4064 13.8717H5.78809"
        stroke="#9E9E9E"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.4064 10.034H5.78809"
        stroke="#9E9E9E"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8.3135 6.20516H5.78809"
        stroke="#9E9E9E"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.5828 1.52075C12.5828 1.52075 5.54557 1.52442 5.53457 1.52442C3.00457 1.54 1.43799 3.20467 1.43799 5.74384V14.1735C1.43799 16.7255 3.01649 18.3966 5.56849 18.3966C5.56849 18.3966 12.6048 18.3938 12.6167 18.3938C15.1467 18.3783 16.7142 16.7127 16.7142 14.1735V5.74384C16.7142 3.19184 15.1348 1.52075 12.5828 1.52075Z"
        stroke="#9E9E9E"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default ReportIcon;
