import React from 'react'
import PieChartComponent from '../PieChart/PieChartComponent'

type Props = {
    data: Array<{ name: string, value: number }>
}

const TotalProgressCard = ({ data }: Props) => {
    return (
        <div className='w-full flex flex-col justify-center  bg-white rounded-lg '>
            <p className='text-2xl font-medium px-4' >Total Processes</p>
            <PieChartComponent data={data} />
            {/* <label htmlFor=""></label> */}
        </div>
    )
}

export default TotalProgressCard