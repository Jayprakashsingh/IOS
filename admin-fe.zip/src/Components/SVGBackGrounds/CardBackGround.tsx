import React from 'react'

type Props = {
    stopColor: string
    stopOpacity: string,
    stopColorOffset: string,
    stopOpacityOffset: string
    stopColorWave: string
    stopOpacityWave: string,
    stopColorOffsetWave: string,
    stopOpacityOffsetWave: string
}

const CardBackGround = ({ stopColor, stopOpacity, stopColorOffset, stopOpacityOffset, stopColorOffsetWave, stopColorWave, stopOpacityOffsetWave, stopOpacityWave }: Props) => {
    return (
        <svg viewBox="0 0 382 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <mask id="mask0_986_14519" style={{ maskType: "alpha" }} maskUnits="userSpaceOnUse" x="0" y="0" width="382" height="200">
                <rect x="0.5" width="381.5" height="200" rx="12" fill="white" />
            </mask>
            <g mask="url(#mask0_986_14519)">
                <rect opacity="0.4" x="293.965" y="-437.332" width="309.602" height="562.667" rx="100" fill="url(#paint0_linear_986_14519)" />
                <rect x="337.98" y="-58.6641" width="309.602" height="562.667" rx="100" fill="url(#paint1_linear_986_14519)" />
            </g>
            <defs>
                {/* <linearGradient id="paint0_linear_986_14519" x1="311.573" y1="-61.332" x2="459.147" y2="-14.3722" gradientUnits="userSpaceOnUse">
                    <stop stop-color={stopColor} stop-opacity={stopOpacity} />
                    <stop offset="1" stop-color={stopColorOffset} stop-opacity={stopOpacityOffset} />
                </linearGradient>
                <linearGradient id="paint1_linear_986_14519" x1="411.346" y1="29.336" x2="282.898" y2="150.497" gradientUnits="userSpaceOnUse">
                    <stop stop-color={stopColorWave} stop-opacity={stopOpacityWave} />
                    <stop offset="1" stop-color={stopColorOffsetWave} stop-opacity={stopOpacityOffsetWave} />
                </linearGradient> */}
                <linearGradient id="paint0_linear_986_14519" x1="311.573" y1="-61.332" x2="459.147" y2="-14.3722" gradientUnits="userSpaceOnUse">
                    <stop stop-color={stopColor} stop-opacity={stopOpacity} />
                    <stop offset="1" stop-color={stopColorOffset} stop-opacity={stopOpacityOffset} />
                </linearGradient>
                <linearGradient id="paint1_linear_986_14519" x1="411.346" y1="29.336" x2="282.898" y2="150.497" gradientUnits="userSpaceOnUse">
                    <stop stop-color={stopColorWave} stop-opacity={stopOpacityWave} />
                    <stop offset="1" stop-color={stopOpacityOffsetWave} stop-opacity={stopOpacityOffsetWave} />
                </linearGradient>
                {/* <linearGradient id="paint0_linear_986_14534" x1="311.069" y1="-61.332" x2="458.643" y2="-14.3722" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#58BBCF" />
                    <stop offset="1" stop-color="#58BBCF" stop-opacity="0.47" />
                </linearGradient>
                <linearGradient id="paint1_linear_986_14534" x1="410.846" y1="29.336" x2="282.398" y2="150.497" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#4797A4" stop-opacity="0.7" />
                    <stop offset="1" stop-color="#4797A4" stop-opacity="0.37" />
                </linearGradient> */}
            </defs>
        </svg>

    )
}

export default CardBackGround

{/* <svg width="382" height="200" viewBox="0 0 382 200" fill="none" xmlns="http://www.w3.org/2000/svg">
<mask id="mask0_986_14534" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="382" height="200">
<rect width="381.5" height="200" rx="12" fill="white"/>
</mask>
<g mask="url(#mask0_986_14534)">
<rect opacity="0.4" x="293.461" y="-437.332" width="309.602" height="562.667" rx="100" fill="url(#paint0_linear_986_14534)"/>
<rect x="337.48" y="-58.6641" width="309.602" height="562.667" rx="100" fill="url(#paint1_linear_986_14534)"/>
</g>
<defs>
<linearGradient id="paint0_linear_986_14534" x1="311.069" y1="-61.332" x2="458.643" y2="-14.3722" gradientUnits="userSpaceOnUse">
<stop stop-color="#58BBCF"/>
<stop offset="1" stop-color="#58BBCF" stop-opacity="0.47"/>
</linearGradient>
<linearGradient id="paint1_linear_986_14534" x1="410.846" y1="29.336" x2="282.398" y2="150.497" gradientUnits="userSpaceOnUse">
<stop stop-color="#4797A4" stop-opacity="0.7"/>
<stop offset="1" stop-color="#4797A4" stop-opacity="0.37"/>
</linearGradient>
</defs>
</svg> */}
