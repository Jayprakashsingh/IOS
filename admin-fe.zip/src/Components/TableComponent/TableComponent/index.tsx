import {
    useReactTable,
    getCoreRowModel,
    getPaginationRowModel,
    ColumnDef,
    flexRender,
    ColumnResizeMode,
    ColumnOrderState,
    Column,
    Header,
    Table,
    VisibilityState,
    PaginationState,
    OnChangeFn,
    getSortedRowModel,
} from '@tanstack/react-table'
import React, { FC, useEffect, useState } from 'react'
import { useDrag, useDrop } from 'react-dnd'
import { changePagination } from '../../../Redux/features/UserManagementSlice'
import { useAppDispatch } from '../../../Redux/app/hooks'


type Props<T extends object> = {
    tableData: Array<T>
    columnDef: ColumnDef<T>[]
    getTableData: (data: PaginationState) => void
    paginationg: PaginationState
}

type DraggableColumnHeaderProps<T extends object> = {
    header: Header<T, unknown>
    table: Table<T>
    columnResizeMode: ColumnResizeMode
}

const DraggableColumnHeader = <T extends object>({ header, table, columnResizeMode }: DraggableColumnHeaderProps<T>) => {
    const { getState, setColumnOrder } = table
    const { columnOrder } = getState()
    const { column } = header

    const [, dropRef] = useDrop({
        accept: 'column',
        drop: (draggedColumn: Column<T>) => {
            const newColumnOrder = reorderColumn(
                draggedColumn.id,
                column.id,
                columnOrder
            )
            setColumnOrder(newColumnOrder)
        },
    })

    const [{ isDragging }, dragRef, previewRef] = useDrag({
        collect: monitor => ({
            isDragging: monitor.isDragging(),
        }),
        item: () => column,
        type: 'column',
    })

    return (
        <th
            {...{
                key: header.id,
                colSpan: header.colSpan,
                style: {
                    width: header.getSize(),
                },
            }}
            ref={dropRef}
            colSpan={header.colSpan}
            style={{ opacity: isDragging ? 0.5 : 1 }}
            className='relative font-bold text-center h-6 '
        >
            <div ref={previewRef}>
                {header.isPlaceholder
                    ? null
                    : flexRender(header.column.columnDef.header, header.getContext())}
                <div {...{
                    className: header.column.getCanSort()
                        ? 'cursor-pointer select-none'
                        : '',
                    onClick: header.column.getToggleSortingHandler(),
                }}>

                    {{
                        asc: ' 🔼',
                        desc: ' 🔽',
                    }[header.column.getIsSorted() as string] ?? <>null</>}
                </div>
                <button ref={dragRef}>🟰</button>
                <div   {...{
                    onMouseDown: header.getResizeHandler(),
                    onTouchStart: header.getResizeHandler(),
                    className: `resizer ${header.column.getIsResizing() ? 'isResizing' : ''
                        }`,
                    style: {
                        transform:
                            columnResizeMode === 'onEnd' &&
                                header.column.getIsResizing()
                                ? `translateX(${table.getState().columnSizingInfo.deltaOffset
                                }px)`
                                : '',
                    },
                }} />
            </div>
        </th>
    )
}

const reorderColumn = (
    draggedColumnId: string,
    targetColumnId: string,
    columnOrder: string[]
): ColumnOrderState => {
    columnOrder.splice(
        columnOrder.indexOf(targetColumnId),
        0,
        columnOrder.splice(columnOrder.indexOf(draggedColumnId), 1)[0] as string
    )
    return [...columnOrder]
}


const TableComponent = <T extends object>({ tableData, columnDef, getTableData, paginationg }: Props<T>) => {
    const [{ pageIndex, pageSize }, setPagination] =
        React.useState<PaginationState>({
            pageIndex: 0,
            pageSize: 10,
        })
    const [columnResizeMode, setColumnResizeMode] =
        React.useState<ColumnResizeMode>('onChange')
    const [tableWidthMode, setTableWidthMode] =
        React.useState<"fixwidth" | "fullwidth">('fixwidth')

    const data = React.useMemo<Array<T>>(() => [...tableData], [tableData])
    const columns = React.useMemo<typeof columnDef>(() => [
        ...columnDef,
    ], [columnDef])
    const [columnOrder, setColumnOrder] = React.useState<ColumnOrderState>(
        columns.map(column => column.id as string) //must start out with populated columnOrder so we can splice
    )

    const fetchDataOptions = {
        pageIndex,
        pageSize,
    }

    const pagination = React.useMemo(
        () => ({
            pageIndex,
            pageSize,
        }),
        [pageIndex, pageSize]
    )
    const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({})
    const table = useReactTable({
        data,
        columns,
        columnResizeMode,
        pageCount: 10,
        state: {
            columnOrder,
            columnVisibility,
            pagination
        },
        manualPagination: true,
        onPaginationChange: setPagination,
        onColumnVisibilityChange: setColumnVisibility,
        getSortedRowModel: getSortedRowModel(),
        onColumnOrderChange: setColumnOrder,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
    })

    useEffect(() => {
        getTableData(fetchDataOptions)
    }, [pagination])




    return (
        <div className="p-2">
            <select
                value={tableWidthMode}
                onChange={e => setTableWidthMode(e.target.value as "fullwidth" || "fixwidth")}
                className="border p-2 border-black rounded"
            >
                <option value="fixwidth">Resize: "Fix width"</option>
                <option value="fullwidth">Resize: "Full Width"</option>
            </select>
            <select
                value={columnResizeMode}
                onChange={e => setColumnResizeMode(e.target.value as ColumnResizeMode)}
                className="border p-2 border-black rounded"
            >
                <option value="onEnd">Resize: "onEnd"</option>
                <option value="onChange">Resize: "onChange"</option>
            </select>

            <div className="overflow-x-auto">
                {table.getAllLeafColumns().map(column => {
                    return (
                        <div key={column.id} className="px-1">
                            <label>
                                <input
                                    {...{
                                        type: 'checkbox',
                                        checked: column.getIsVisible(),
                                        onChange: column.getToggleVisibilityHandler(),
                                    }}
                                />{' '}
                                {column.id}
                            </label>
                        </div>
                    )
                })}

                <table
                    className='table-auto border-0 w-full'
                    {...{
                        style: tableWidthMode !== "fixwidth" ? {
                            width: table.getCenterTotalSize()
                        } : {},
                    }}
                >
                    <thead>
                        {table.getHeaderGroups().map(headerGroup => (
                            <tr className=' border-y border-y-[#EAF0F3]' key={headerGroup.id}>
                                {headerGroup.headers.map(header => (
                                    <DraggableColumnHeader<T>
                                        key={header.id}
                                        header={header}
                                        table={table}
                                        columnResizeMode={columnResizeMode}
                                    />
                                ))}
                            </tr>
                        ))}
                    </thead>
                    <tbody>
                        {table.getRowModel().rows.map(row => (
                            <tr className=' border-y border-y-[#EAF0F3]' key={row.id}>
                                {row.getVisibleCells().map(cell => (
                                    <td
                                        {...{
                                            key: cell.id,
                                            style: {
                                                width: cell.column.getSize(),
                                            },
                                        }}
                                    >
                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="flex items-center gap-2">
                    <button
                        className="border rounded p-1"
                        onClick={() => table.setPageIndex(0)}
                        disabled={!table.getCanPreviousPage()}
                    >
                        {'<<'}
                    </button>
                    <button
                        className="border rounded p-1"
                        onClick={() => table.previousPage()}
                        disabled={!table.getCanPreviousPage()}
                    >
                        {'<'}
                    </button>
                    <button
                        className="border rounded p-1"
                        onClick={() => table.nextPage()}
                        disabled={!table.getCanNextPage()}
                    >
                        {'>'}
                    </button>
                    <button
                        className="border rounded p-1"
                        onClick={() => table.setPageIndex(table.getPageCount() - 1)}
                        disabled={!table.getCanNextPage()}
                    >
                        {'>>'}
                    </button>
                    <span className="flex items-center gap-1">
                        <div>Page</div>
                        <strong>
                            {table.getState().pagination.pageIndex + 1} of{' '}
                            {table.getPageCount()}
                        </strong>
                    </span>
                    <span className="flex items-center gap-1">
                        | Go to page:
                        <input
                            type="number"
                            defaultValue={table.getState().pagination.pageIndex + 1}
                            onChange={e => {
                                const page = e.target.value ? Number(e.target.value) - 1 : 0
                                table.setPageIndex(page)
                            }}
                            className="border p-1 rounded w-16"
                        />
                    </span>
                    <select
                        value={table.getState().pagination.pageSize}
                        onChange={e => {
                            table.setPageSize(Number(e.target.value))
                        }}
                    >
                        {[10, 20, 30, 40, 50].map(pageSize => (
                            <option key={pageSize} value={pageSize}>
                                Show {pageSize}
                            </option>
                        ))}
                    </select>

                </div>
            </div>

            {/* <pre>{JSON.stringify(table.getState().columnOrder, null, 2)}</pre>
            <pre>
                {JSON.stringify(
                    {
                        columnSizing: table.getState().columnSizing,
                        columnSizingInfo: table.getState().columnSizingInfo,
                    },
                    null,
                    2
                )}
            </pre> */}
        </div >
    )
    // ...render your table
}

export default TableComponent