// if you are sending cotent as DOM then make sure you have to use the class attribute instead of className
// example <div class='flex justify-between'>Hello <button class='border-0 outline-0 p-2 bg-red-400'>Know more</button></div>
// this allow you to make style uisng class attributes.


import React, { useState } from "react";
import CenterPopUpComponent from "../PopUp/CenterPopUpComponent";
import { Control, UseFieldArrayReturn, UseFormRegister } from "react-hook-form";
import FundamentalForm from "../../Pages/Guide/FundamentalForm";
import { AddFundamentalForm } from "../../Pages/Guide/AddFundamentalPage";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import classNames from "classnames";
interface Data {
    title: string;
    content: string;
}

type Props = {
    data: any[];
    register: UseFormRegister<AddFundamentalForm>
    control: Control<AddFundamentalForm, any>
    fieldArray: UseFieldArrayReturn<AddFundamentalForm, "micromoves", "id">
    formValues: AddFundamentalForm
    setValue: any
};

const AccordianComp = ({
    data,
    control,
    fieldArray,
    register,
    setValue,
    formValues,
}: Props) => {
    // State to track the open accordion item
    const [openItem, setOpenItem] = useState<number | null>(null);
    // Function to toggle accordion item
    const toggleItem = (index: number) => {
        console.log(index)
        if (openItem === index) {
            // Close the item if it's already open
            setOpenItem(null);
        } else {
            // Open the item
            setOpenItem(index);
        }
    };
    // Sync the order of items with React Hook Form
    const childrenRef = React.useRef<any>(null);

    const reorder = (result: any) => {
        console.log(result);
        const { source, destination, type } = result;
        if (!destination) {
            return;
        }
        const sourceIndex = source.index;
        const destIndex = destination.index;

        if (type === "parentContainer2") {
            fieldArray.move(sourceIndex, destIndex);
        } else if (type === "childContainer" && source.droppableId) {
            const reorderChild = childrenRef.current[source.droppableId];
            if (reorderChild) {
                reorderChild(sourceIndex, destIndex);
            }
        }
    };

    return (<div className="flex flex-col gap-[10px] ">
        <DragDropContext onDragEnd={reorder}>
            <Droppable droppableId="parent2w" type="parentContainer2">
                {(provided) => (
                    <ul ref={provided.innerRef} {...provided.droppableProps}>

                        {data.map((item, index) => (
                            <Draggable key={item.id} draggableId={item.id} index={index}>
                                {(provided) => (
                                    <li
                                        key={item.id}
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                    >

                                        {/* <AccordianItem
                                            provided={provided}
                                            setValue={setValue}
                                            register={register}
                                            control={control}
                                            key={item.name}
                                            item={item}
                                            index={index}
                                            openItem={openItem}
                                            toggleItem={toggleItem}
                                            fieldArray={fieldArray}
                                            formValues={formValues}
                                        /> */}
                                    </li>
                                )}
                            </Draggable>
                        ))
                        }
                    </ul>
                )}
            </Droppable>
        </DragDropContext>
    </div>
    );
};

export default AccordianComp;


type AccordionItemProps = {
    formValues: AddFundamentalForm,
    provided: any,
    setValue: any,
    register: UseFormRegister<AddFundamentalForm>, item: any, toggleItem: any, openItem: any, index: any, control: Control<AddFundamentalForm>, fieldArray: UseFieldArrayReturn<AddFundamentalForm, "micromoves", "id">
}


export const AccordianItem = ({ item, toggleItem, provided, setValue, openItem, index, control, fieldArray, register, formValues }: AccordionItemProps) => {
    const [isModalOpen, setIsModalOpen] = useState(false)

    const handleEdit = () => {
        setIsModalOpen(true)
    }
    return (
        <>
            <CenterPopUpComponent isOpen={isModalOpen} message='Edit Micro Moves' onClose={() => setIsModalOpen(false)}>

                {/* <FundamentalForm
                    fieldArray={fieldArray}
                    index={index}
                    control={control}
                    register={register}
                    closeForm={() => setIsModalOpen(false)}
                    cancelForm={() => setIsModalOpen(false)}
                /> */}

            </CenterPopUpComponent>
            <div className={`flex flex-col gap-[8px]`} >
                <div
                    className={classNames(`p-2 border flex-col w-full text-left  flex justify-between`, {
                        "bg-[#eaf0f399]": openItem === index
                    })}

                >
                    <div className="flex h-full items-center justify-between">

                        <div onClick={() => toggleItem(index)} className={`flex justify-center mx-4 gap-2 items-center`}>
                            <img
                                className="h-4"
                                src={openItem === index ? "/images/minus.svg" : "/images/plusButton.svg"}
                                alt=""
                            />
                        </div>

                        <div>{index + 1}.</div>
                        <div className="flex flex-col w-[300px]" >
                            <span className="text-[#BDBDBD] text-[0.825rem]">Headline</span>
                            <span>{formValues.micromoves[index]?.title ? formValues.micromoves[index]?.title : " "}</span>
                        </div>
                        <div className="flex flex-col w-[300px]" >
                            <span className="text-[#BDBDBD] text-[0.825rem]">Description</span>
                            <span className="w-[300px] block text-ellipsis overflow-hidden whitespace-nowrap"> {formValues.micromoves[index]?.description}</span>

                        </div>
                        <div className="flex flex-col" >
                            <span className="text-[#BDBDBD] text-[0.825rem]">Step Number</span>
                            <span> {formValues.micromoves[index].steps ? formValues.micromoves[index]?.steps?.length : 0}</span>
                        </div>
                        <div className="flex gap-4 mx-8">

                            <div
                                className="flex my-auto flex-col items-center justify-center h-full py-[10px] bg-[] px-[8px] border bg-[#EAF0F3] rounded-md  gap-1"
                                {...provided.dragHandleProps}
                            >
                                <span className="block  w-6 h-[2px] bg-[#285A9F]"></span>
                                <span className="block  w-6 h-[2px] bg-[#285A9F]"></span>
                                <span className="block  w-6 h-[2px] bg-[#285A9F]"></span>
                            </div>
                            <button
                                className='text-[#9E9E9E] font-medium text-sm flex justify-center items-center gap-2' type="button"
                                onClick={() => handleEdit()}>
                                <img
                                    className='h-6'
                                    src="/images/editicon.svg"
                                    alt=""
                                />

                            </button>
                            <button
                                className='text-[#9E9E9E] font-medium text-sm flex justify-center items-center gap-2' type="button"
                                onClick={() => { fieldArray.remove(index) }}>
                                <img
                                    className='w-6'
                                    src="/images/remove.svg"
                                    alt=""
                                />
                            </button>
                        </div>
                    </div>

                    {openItem === index && (
                        <div
                            className={` py-2     w-full rounded-md overflow-y-auto`}
                        // dangerouslySetInnerHTML={createMarkup(item.content)}
                        >
                            <ul className="mx-[10rem]">
                                <p>
                                    Steps List :
                                </p>
                                {
                                    formValues.micromoves[index]?.steps?.map((i, index) => (
                                        <li className="flex mx-10 my-3 w-fit gap-[3.12rem]">
                                            <span>{index + 1}</span>
                                            <span className="w-[300px]">{i.detail}</span>
                                            <span>{i.vimeo_link}</span>
                                        </li>
                                    ))
                                }

                            </ul>
                        </div>
                    )}
                </div>
            </div >
        </>
    )
}
