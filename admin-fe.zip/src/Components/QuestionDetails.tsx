import { QuestionFormValues } from "../Pages/OnBoardingQuestion/AddOnBoardingQuestionPage";
import InputComponent from "./Inputs/InputComponent";
import SelectComponent from "./Inputs/SelectComponent";
import {
  Control,
  FieldErrors,
  UseFormRegister,
} from "react-hook-form/dist/types";

type Props = {
  register: UseFormRegister<QuestionFormValues>;
  errors: FieldErrors<QuestionFormValues>;
  formValues: QuestionFormValues;
  control: Control<QuestionFormValues>;
};

const QuestionDetails = ({ register, errors, formValues, control }: Props) => {
  const options = [
    { label: "Radio", value: "radio" },
    { label: "Multi Choice", value: "multiple_choice" },
    { label: "Open Text Box", value: "opentext_box" },
  ];

  return (
    <div className="py-3 p-4 border-b">
      <form>
        <div className="grid grid-cols-2 gap-4 items-center">
          <SelectComponent<QuestionFormValues>
            control={control}
            inputRef="question_type"
            options={options}
            label="Question Type"
          />
          <InputComponent
            register={register}
            inputRef="question"
            errorname={errors.question?.message}
            label="Question"
            name="question"
            value={formValues.question}
          />
        </div>
      </form>
    </div>
  );
};

export default QuestionDetails;
