export type FormData = {
  items: Array<{
    link: string;
    title: string;
    description: string;
  }>;
};

export type ModalData = {
  link: string;
  title: string;
  description: string;
};

export type ModalProps = {
  onSave: () => void;
  data: ModalData;
  setData: React.Dispatch<React.SetStateAction<ModalData>>;
};
