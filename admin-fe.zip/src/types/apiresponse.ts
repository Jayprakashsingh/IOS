import { getRatings } from "../Redux/features/UserDashboardSlice";

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}
export interface notificationresponse {
  success: boolean;
  message: string;
}

export type Rating = {
  type: string;
  date: string;
  rating: string;
  text: string;
};
export interface Feedback {
  _id: string;
  id?: string;
  type: "Coach Reviews:" | "Swing Videos:";
  swing_id: string;
  swing_video: string;
  swing_video_duration: string; // If this is always empty, you might consider removing it or using a more appropriate type
  title: string;
  unit: number;
  session: string;
  status: string;
  comment: string;
  coach_name: string;
  date: string;
  video_link: string;
  down_the_line: string;
  face_on: string;
  shot_checks: ShotCheck[];
}

export interface ShotCheck {
  _id: string;
  shot_no: number;
  date: string;
  location: string;
  distance: string;
  user_id: 24;
  direction: string;
  curve: string;
  contact: string;
  face: string;
  updated_at: string;
  created_at: string;
}

export interface DashBoardData {}

export interface SwingReview {
  type: string;
  title: string;
  date: string;
  video_link: string;
}

interface TrainingIntention {
  day: string;
  time: string;
  location: string;
}

interface Reps {
  recall_cards: number;
  move_drills: number;
  swing_drills: number;
  trust_shots: number;
}

export interface FriendSupport {
  id: string;
  name: string;
  phone: string;
}
export interface QuestionAnswer {
  question: string;
  answer: string;
}
interface ratings {
  weekly_rating: Rating[];
  session_rating: Rating[]; // Since there's no data provided for sessionRating, it's set to any[].
  scc_rating: Rating[];
}
export interface User {
  status: boolean;
  _id: string;
  country_flag: string;
  is_free: boolean;
  full_name: string;
  email: string;
  user_type: string;
  registered_at: string;
  first_name: string;
  last_name: string;
  gender: string;
  birthday: string;
  height: string;
  weight: string;
  address: string;
  country: string;
  postal_code: string;
  time_zone: string;
  last_login_at: string;
  userid: number;
  is_confirm: number;
  group_id: string;
  device_type: string;
  fcm_token: string;
  updated_at: string;
  created_at: string;
  country_id: string;
  last_updated_training_streak: string;
  mulligan: number;
  training_streak: number;
  last_recall_card_level_updated_date: string;
  user_recall_card_level: number;
  max_training_streak: number;
  plan: string;
  profile_picture: string;
  timezone_name: string;
  country_name: string;
  timezone_field: string;
  aboutFisio: boolean;
  aboutYou: boolean;
  acknowledgement: boolean;
  active_plan_name: string;
  appCarousel: boolean;
  convertFreeSuccess: boolean;
  convertToFreeTrail: boolean;
  dailyReminder: boolean;
  dailyReminderSelection: boolean;
  hour: string;
  initialFreeTrail: boolean;
  letsStart: boolean;
  min: string;
  planOverView: boolean;
  selectTimezone: boolean;
  set_daily_reminder: boolean;
  set_daily_reminder_time: string;
  skip_reminder: boolean;
  time: string;
  timezone: string;
  group_name?: string;
  first_object?: string;
}

export type StreakCalander = {
  _id: string;
  user_id: number;
  date: string;
  current_streak: number;
  mulligan: number;
  updated_at: string;
  created_at: string;
};

export interface dashboardDataInterface {
  user: User;
  training_intention: TrainingIntention[];
  reps: Reps;
  rate: string;
  plan: string;
  rating: ratings;
  friend_support: FriendSupport[];
  training_streak: number;
  show_blue: number;
  max_training_streak: number;
  question_answer: QuestionAnswer[];
  activity: Activity;
  streak_calender: StreakCalander[];
  feedback: FeedbackData;
}

export interface ActivityItem {
  category_type: "Trust" | "Train" | "Apply";
  trust_key_percent: number;
  pre_shot_percent: number;
  post_shot_percent: number;
  date: string;
  name: string;
  session_object: string;
  unit_name: string;
}

export interface Activity {
  train: ActivityItem[];
  apply: ActivityItem[];
  trust: ActivityItem[];
}

interface Swing {
  type: "Swing Videos:";
  title: string;
  date: string;
  video_link: string;
}

interface ShotCheckDetail {
  _id: string;
  shot_no: number;
  date: string;
  location: string;
  distance: string;
  user_id: number;
  direction: string | null;
  curve: string | null;
  contact: string | null;
  face: string | null;
  updated_at: string;
  created_at: string;
}

export interface ShotCheckData {
  date: string;
  shot_check_count?: number;
  shot_checks: ShotCheckDetail[];
}

interface CoachReview {
  id: string;
  type: "Coach Reviews:";
  swing_id: string;
  swing_video: string;
  swing_video_duration: string;
  title: string;
  unit: number;
  session: string;
  status: string;
  comment: string;
  coach_name: string;
  file: string;
  date: string;
}

export interface PaymentMethod {
  name: string;
  id: string;
  brand: string;
  last4: string;
  exp_month: number;
  exp_year: number;
  is_default: boolean;
}

export interface FeedbackData {
  shot_check_count: number;
  swing_count: number;
  coach_review_count: number;
  swings: Swing[];
  shot_checks: ShotCheckData[];
  coach_reviews: CoachReview[];
}

export interface guideList {
  id: string;
  title: string;
  description: string;
  updated_at: Date;
  created_at: Date;
  fundamentals: Array<{
    updated_at: string;
    id: string;
    name: string | null;
    secondary_vimeo_link: string;
    description: string | null;
    main_image: string;
    secondary_image: string;
    micro_moves: Array<{
      title: string;
      description: string;
      steps: Array<{
        details: string;
        vimeo_link: string;
      }>;
    }>;
  }>;
}

// Guide Drill

export interface listGuideAPIResponse {}
export interface listGuideAPIRequest {}

export interface postGuideAPIResponse {}
export interface postGuideAPIRequest {
  title: string;
  description: string;
  id?: string;
}

export interface getRatingsResponse {
  ratings: Rating[];
  total_page: number;
  total_ratings: number;
  current_page: string;
}

export interface getCoachResponse {
  data: Feedback[];
  total_page: number;
  total_records: number;
  current_page: string;
}
export interface getNotificationListResponse {
  notifications: Array<{
    created_at: string;
    description: string;
    is_read: true;
    title: string;
    updated_at: string;
    user_id: number;
    _id: string;
  }>;
  total_page: number;
  total_notifications: number;
  current_page: string;
}

export type userProgress = {
  category_type: "Train" | "Apply";
  unit_name: string;
  session_name: string;
  date: string;
};
export interface getUserProgressTracking {
  user: User;
  first_object: string;
  user_progress_train: Array<userProgress>;
  user_progress_apply: Array<userProgress>;
  user_question_answer: Array<{
    question: string;
    answer: string;
  }>;
}

export interface getUserDetailsResponse {
  data: dashboardDataInterface;
  message: string;
  success: boolean;
}

export interface getPlansResponse {
  _id: string;
  name: "Basic" | " Premium" | "Ultra";
  amount: 99 | 199 | 299;
  validity: 3;
  validity_type: "month";
  product_id: string;
  payment_link: string;
}
