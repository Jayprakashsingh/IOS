// Generic Payload Types

declare interface Pagination {
  first_page_url?: string;
  last_page_url?: string;
  from: number;
  last_page: number;
  links: Array<{
    url: string | null;
    label: string;
    active: boolean;
  }>;
  next_page_url?: string | null;
  path?: string | null;
  per_page: number;
  prev_page_url?: string | null;
  to: number;
  total: number;
  current_page: number;
}

// type Status = "loading" | "success" | "error";

// declare enum Status {
//   IDLE = "idle",
//   LOADING = "loading",
//   SUCCESS = "success",
//   ERROR = "error",
// }

// declare enum Status {
//   IDLE = "idle",
//   LOADING = "loading",
//   SUCCESS = "success",
//   ERROR = "error",
// }

declare interface PayloadType {
  success?: boolean;
  message?: string;
}

// API CALLS
// USERAUTH MODULE
// Login API Type
declare interface LoginAdminResponse extends PayloadType {
  user: {
    _id: string;
    full_name: string;
    email: string;
    user_type: "admin" | "user" | "coach";
    registered_at?: string;
    userid: number;
    is_confirm: 0 | 1;
    updated_at: string;
    created_at: string;
  };
  token: string;
  type: string;
}
declare interface LoginAPIRequest {
  email: string;
  password: string;
  user_type: "admin" | "user" | "coach";
}
// ForgetPasswordAPIRequest
declare interface ForgetPasswordAPIRequest {
  email: string;
}
//  AdminList API Interface
declare type UserType = {
  _id: string;
  is_confirm: number;
  user_type: string;
  full_name: string;
  email: string;
  registered_at: string;
  first_name: string;
  last_name: string;
  gender: string;
  birthday: string;
  height: string;
  weight: string;
  address: string;
  country: string;
  postal_code: string;
  time_zone: string;
  last_login_at: string;
  training_streak: number;
  mulligan: number;
  affiliate_deeplink: string;
  last_updated_training_streak: string;
  weekly_rating_switch: boolean;
  userid: number;
  group_id: string;
  updated_at: string;
  created_at: string;
  device_type: string;
  provider: string;
  providerId: string;
  fcm_token: string | null;
  convertFreeSuccess: boolean;
  letsStart: boolean;
  dailyReminder: boolean;
  hour: number;
  min: number;
  skip_reminder: boolean;
  time: string;
  dailyReminderSelection: boolean;
  country_id: string;
  timezone: string;
  selectTimezone: boolean;
  max_training_streak: number;
  status: boolean;
  unit_name: number;
  session_name: number;
  group_name: string;
  customized_plan_name: string;
  registered_date: string;
  login_date: string;
  allow_notification_permission: boolean;
  days_subscribed: number;
  total_rep_reviews: number;
  totalRepCount: number;
  user_progress_train: number;
  user_progress_apply: number;
  user_progress_trust: number;
  weekly_rating: string;
  tag_id: string;
  tag_name: string;
  subscribed_plan: string;
  applied_promo_code: string;
  renewal_date: string;
  billed_amount: string;
};

declare interface FreeUser {
  _id: string;
  email: string;
  admin_id: string;
  updated_at: string;
  created_at: string;
}

declare interface UserTypeList extends Pagination {
  data: UserType[];
}
declare interface AllUserListType extends Pagination {
  data: AllUserListType[];
}
declare interface billingHistory {
  _id: string;
  user_id: string;
  transaction_no: string;
  tras_id: string;
  status: string;
  payment_status: string;
  expiry_date: string;
  payment_method: string;
  plan_id: string;
  amount: number;
  updated_at: string;
  created_at: string;
  plan: string;
}
declare interface UserTypePayload {
  per_page?: number;
  page: number;
  userType: "admin" | "user" | "coach";
  searchValue?: string;
  sortValue?: string;
  sortType?: sortValues;
  filter_dashboard?:
    | "premium_plan_count"
    | "pro_plan_count"
    | "basic_plan_count"
    | "fourtosevenDayLoginCount"
    | "withinthreeDayLoginCount"
    | "morethansevenDayLoginCount"
    | "weekly_rating_count"
    | "session_rating_count"
    | "scc_rating_count"
    | "free_plan_count"
    | "";
}
declare interface FreeUserListPayload {
  per_page?: number;
  page: number;
  userType: "admin" | "user" | "coach";
  searchValue?: string;
  sortValue?: string;
  sortType?: sortValues;
  filter_dashboard?:
    | "premium_plan_count"
    | "pro_plan_count"
    | "basic_plan_count"
    | "fourtosevenDayLoginCount"
    | "withinthreeDayLoginCount"
    | "morethansevenDayLoginCount"
    | "weekly_rating_count"
    | "session_rating_count"
    | "scc_rating_count"
    | "free_plan_count"
    | "";
}
declare interface AllUserTypePayload {
  per_page?: number;
  page: number;
  userType: "admin" | "user" | "coach";
  searchValue?: string;
  sortValue?: string;
  sortType?: sortValues;
  filter_dashboard?:
    | "premium_plan_count"
    | "pro_plan_count"
    | "basic_plan_count"
    | "fourtosevenDayLoginCount"
    | "withinthreeDayLoginCount"
    | "morethansevenDayLoginCount"
    | "weekly_rating_count"
    | "session_rating_count"
    | "scc_rating_count"
    | "free_plan_count"
    | "";
}
declare interface UserTypeListResponse extends PayloadType {
  data: UserTypeList;
}
declare interface FreeUserListResponse extends PayloadType {
  data: FreeUser[];
}
declare interface AllUserTypeListResponse extends PayloadType {
  data: AllUserListType;
}
declare interface UserInfo {
  _id: string;
  full_name: string;
  email: string;
  user_type: string;
  registered_at: string;
  first_name: string;
  last_name: string;
  gender: string;
  birthday: string;
  height: string;
  weight: string;
  address: string;
  country: string;
  postal_code: string;
  time_zone: string;
  userid: string;
  is_confirm: string;
  updated_at: string;
  created_at: string;
  profile_picture: string;
  group_id: number;
}

declare interface trainingIntention {
  day: string;
  time: string;
  location: string;
}

declare interface Reps {
  recall_cards: number;
  move_drills: number;
  swing_drills: number;
  trust_shots: number;
}

declare type sortValues = "ascending" | "descending" | null;

declare interface UserDetailsAPIResponse extends Payload {
  data: {
    user: UserInfo;
    training_intention: trainingIntention[];
    reps: Reps;
    rate: string;
  };
}

declare interface UserDashboardAPIResponse extends Payload {
  data: {
    login_at: {
      withinthreeDayLoginCount: number;
      fourtosevenDayLoginCount: number;
      morethansevenDayLoginCount: number;
    };
    rating: {
      weekly_rating_count: number;
      session_rating_count: number;
      scc_rating_count: number;
    };
    subscription: {
      free_plan_count: number;
      basic_plan_count: number;
      premium_plan_count: number;
      pro_plan_count: number;
    };
    new_flow: boolean;
    free_app: boolean;
  };
}

//Update/Create User Interface

declare type UserCreatePostAPIRequest = {
  data: {
    first_name: string;
    last_name: string;
    email: string;
    password?: string;
    user_type?: string;
    group_id?: string;
    status?: boolean;
  };
  id?: number | string;
};

declare type UserUpdatePostAPIRequest = {
  data: {
    name: string;
    email: string;
  };
  id?: number;
};

declare interface UserPostAPIResponse extends PayloadType {
  data: UserType;
}
// Delete user Interface
declare interface DeleteUserAPIResponse extends PayloadType {}
//Question Type

declare type Question = {
  answers: string[];
  created_at: string;
  question_type: "radio" | "multiple_choice";

  text: string;
  updated_at: string;
  _id: string;
};
//Question List API Interface
declare interface QuestionListAPIResponse extends PayloadType {
  data: Question[];
}
//Add Questions API Request Type
declare interface AddQuestionAPIRequest {
  text: string;
  answers: string[];
  question_type: string;
  can_skip?: boolean;
  subtitle?: string;
  text_ip_1?: string;
  text_ip_10?: string;
}
//Add Questions API Response Interface
declare interface AddQuestionAPIResponse extends PayloadType {
  data: Question;
}
// Update Question API Request Interface
declare interface UpdateQuestionAPIRequest extends AddQuestionAPIRequest {
  question_id: string;
}
//Delete Question API Interface
declare interface DeleteQuestionAPIResponse extends PayloadType {}

// Tag Module
declare type Tag = {
  _id: string;
  name: string;
  user_id: string;
  updated_at: string;
  created_at: string;
  user_name: string;
  type: string;
};

declare interface TagListAPIResponse extends PayloadType {
  data: {
    tags: Tag[];
    total_tags: number;
    total_page: number;
  };
}

declare interface getTagsAPIResponse {
  data: TagListAPIResponse;
  page: number;
}

// declare interface TagListAPIResponse extends PayloadType {
//   data: Tag[];
// }
interface DeleteTagListAPIResponse extends PayloadType {}

interface AddTagAPIRequest {
  id?: string;
  name: string;
  type: string;
}
interface AssignTagAPIRequest {
  user_id: string;
  tag_id: string;
}
//Object Module
declare type ObjectType = {
  _id: string;
  name:
    | "Quote"
    | "Audio"
    | "Video"
    | "Image"
    | "Text"
    | "Self Report"
    | "Self Check Check";
};
declare type CategoryType = {
  _id: string;
  name: "Train" | "Apply" | "Trust";
};
declare type SessionType = {
  _id: string;
  name: "Session" | "Recap Session";
};

declare type ObjectItem = {
  _id: string;
  object_type_id: string;
  category_type_id: string;
  object_name: string;
  session_allocated: boolean;
  headline: string;
  subtitle: string;
  textarea: string;
  equipment: string;
  file: string;
  updated_at: string;
  created_at: string;
  object_type_name: string;
  thumbnail: string;
  category_type_name: string;
  object_time: string;
  reps: string;
  video_id: string;
  tag?: string;
  tag_name: string;
  is_drill?: boolean;
  link_items: Array<{ title: string; link: string; description }>;
};

declare interface ObjectTypeListAPIResponse extends PayloadType {
  data: ObjectType[];
}

declare interface CategoryTypeListAPIResponse extends PayloadType {
  data: CategoryType[];
}

declare interface ObjectListAPI {
  data: {
    objects: ObjectItem[];
    total_count: number;
    total_page: number;
  };
}
declare interface ObjectListAPIResponse extends PayloadType {
  page: number;
  data: ObjectListAPI;
}

declare interface AddObjectAPIRequest {}

declare interface AddObjectAPIResponse extends PayloadType {}

declare interface DeleteObjectAPIResponse extends PayloadType {}
// Sessions API requests

declare interface SessionItem {
  internal_session_name: string;
  session_type_id: string;
  category_type_id: string;
  id: string;
  time: string;
  order: string | null;
  session: string;
  //headline: string;
  description: string;
  text: string;
  object_list: Array<{
    object_id: string;
    permission: "1" | "0";
  }>;
  overview: {
    equipments: "Golf Club";
    headline: "Square Face Grip: Muscle Training";
    is_equipments_needed: true;
    list_items: Array<{
      title: string;
      description: string;
      time: number;
    }>;
    move_drills_count: 0;
    recall_cards_count: 1;
    text: "In this session, we’ll review how to execute a Square Face Grip and then learn a Movement Drill to train getting the left hand on the club correctly. We’ll show the Movement Drill instructions first, then you can do the drill in the next video.";
    time: 0;
  };
  recall_cards: Array<{ recall_card_id: string }>;
  session_type: "Session" | "Recap Session";
  category_type: "Trust" | "Train" | "Apply";
  last_update: "2023-06-12T19:41:08.892000Z";
}

declare interface SessionItemList {
  data: Array<Session>;
  total_page: number;
  total_session: number;
}

declare interface SessionAPIResponse extends PayloadType {
  data: SessionItemList;
  page: number;
}

declare interface SessionTypeAPIResponse extends PayloadType {
  data: SessionType[];
}

declare interface SessionDeleteAPIResponse extends PayloadType {}

declare interface SessionPostAPIRequest {
  id?: string;
  session_type_id: string;
  order?: number;
  // headline?: string;
  text: string;
  category_type_id: string;
  session_name: string;
  internal_session_name?: string;
  description?: string;
  overview?: {
    text: string;
    headline: string;
    time: number;
    is_equipments_needed: boolean;
    equipments: string;
    recall_cards_count: number;
    move_drills_count: number;
    list_items: Array<{
      title: string;
      time: number;
      description: string;
    }>;
  };
  recall_cards?: Array<{ recall_card_id: string }>;
  session_object: Array<{
    object_id: string;
    permission: 1 | 0 | "";
    time: number;
  }>;
}

declare interface SessionPostAPIResponse extends PayloadType {
  data: {
    id?: string;
    session_type_id: string;
    category_type_id: string;
    session_name: string;
    session_object: Array<{
      object_id: string;
      permission: 1 | 0;
      time: string;
    }>;
    updated_at: string;
    created_at: string;
  };
}

// Unit APIS

declare interface UnitItem {
  order: number;
  id: string;
  unit: string;
  time: number;
  internal_unit_name: string;
  category_type: string;
  category_type_id: string;
  last_update: string;
  session: Array<{
    id: string;
    session_name: string;
    session_type: string;
  }>;
}

// {
//   "id": "64996de6d245e97bfc0e04b2",
//   "unit": "Unit 1",
//   "time": 0,
//   "session": [
//       {
//           "id": "64996da83d3e1752c60e1fa2",
//           "session_name": "Seesion 1 Train",
//           "session_type": "Session"
//       }
//   ],
//   "category_type": "Train",
//   "last_update": "2023-06-26T10:52:22.021000Z"
// },

declare interface UnitAPIListResponse {
  data: {
    units: UnitItem[];
    total_unit: number;
    total_page: number;
  };
  page: number;
}

declare interface UnitDeleteAPIResponse extends PayloadType {}
declare interface UnitPostAPIResponse extends PayloadType {
  data: {
    category_type_id: string;
    unit_name: string;
    unit_object: Array<{
      object_id: string;
      permission: 1 | 0;
    }>;
  };
  updated_at: string;
  created_at: string;
  _id: string;
}

declare interface UnitAPIRequest {
  category_type_id: string;
  order: number;
  id?: string;
  unit_name: string;
  internal_unit_name: string;
  unit_object: Array<{
    object_id: string;
    permission: 1 | 0 | "";
  }>;
}

interface WelcomeInfo {
  _id: string;
  image: string;
  type: string;
  text: string;
  subtext: string;
}

interface GetWeclomePageInfo extends PayloadType {
  data: {
    welcome: WelcomeInfo[];
    Marketing: WelcomeInfo[];
    login: WelcomeInfo[];
    Register: WelcomeInfo[];
  };
}

interface RecallCard {
  _id: string;
  title: string;
  question_text: string;
  answer_text: string;
  level: string;
  question_img?: FileList | string;
  answer_img?: FileList | string;
  updated_at: string;
  created_at: string;
  tag: string;
  tagName: string;
  learn_more_video: string;
  show: boolean;
  order: number;
}

type PostRecallCardsRequest = {
  id?: string;
  question_text: string;
  answer_text: string;
  level: string;
  question_img?: FileList;
  answer_img?: FileList;
};

interface PostRecallCardsResponse extends PayloadType {
  data: RecallCard;
}

interface GetRecallCards extends PayloadType {
  data: {
    total_page: number;
    total_recall_cards: number;
    recall_cards: Array<RecallCard>;
  };
  page: number;
}

type TrophiesData = {
  id: string;
  type: string;
  name: string;
  description: string;
  image_front: string;
  image_back: string;
  retrieved: boolean;
  retrieved_on: string;
};

interface GetTrophiesListAPIResponse extends PayloadType {
  data: Array<TrophiesData>;
}

interface PostTrophiesResponse extends PayloadType {
  data: {
    name: string;
    description: string;
    received_date: string;
    trophie_type: string;
    trophie_front: string;
    trophie_back: string;
    updated_at: string;
    created_at: string;
    _id: string;
  };
}

interface PostTrophiesRequestPayload {
  id?: string;
  name: string;
  description: string;
  trophie_type: string;
  trophie_front: string;
  trophie_back: string;
  received_date: string;
}

interface Group {
  _id: string;
  group_name: string;
  plan_name: string;
  group_object: Array<{
    object_id: string;
    time: number;
  }>;
  tag: string;
  tag_name?: string;
  order: number;
  updated_at: string;
  created_at: string;
}

declare interface GroupListResponse extends PayloadType {
  data: Array<Group>;
}

declare interface GroupObject {
  object_id: string;
  time: string;
}

interface GroupListRequest {
  id?: string;
  group_name: string;
  plan_name: string;
  tag: string;
  group_object: GroupObject[];
  // tags: string;
}

interface TrustShotCheckOverView {
  id: string;
  text: string;
  headline: string;
  type: "Trust" | "Shot Check";
  time: number;
  description: string;
}

interface TrustShotCheckResponse extends PayloadType {
  data: Array<TrustShotCheckOverView>;
}
interface Quote {
  _id: string;
  title: string;
  quote: string;
  quote_by: string;
  shown: boolean;
  updated_at: string;
  created_at: string;
}

interface QuoteAPIResponse extends PayloadType {
  data: Array<Quote>;
}

interface getReviewResponse extends PayloadType {
  data: Array<SwingReview>;
}

interface getDashboardResponse extends PayloadType {
  data: coachDashBoard;
}

interface coachDashBoard {
  total_swing: number;
  pending_swing: number;
  in_progress_swing: number;
  reviewed_swing: number;
  avg_response_time: number;
}

interface SwingReview {
  id: string;
  swing_id: string;
  title: string;
  status: string;
  comment: string;
  rating: number;
  user_id: string;
  user_name: string;
  coach_id: string;
  coach_name: string;
  file: string;
  created_at: string;
  last_update: string;
}

interface TrustKeys {
  _id: string;
  trust_key: string;
  date: string;
  created_by: string;
  updated_at: string;
  created_at: string;
}

interface TrustKeys extends PayloadType {
  data: TrustKeys[];
}

interface SwingVideo {
  _id: string;
  type: string;
  rep_video: string;
  user_id: string;
  face_on: string;
  down_the_line: string;
  status: "Pending" | "Completed" | "In Progress";
  title: string;
  face_on_duration: string;
  down_the_line_duration: string;
  face_on_filesize: string;
  down_the_line_filesize: string;
  direction: string;
  curve: string;
  contact: string;
  face: string;
  description: string;
  submit_to_coach: boolean;
  updated_at: string;
  created_at: string;
  coach_name: string;
  coach_review_id: string;
  remaining_hours: number;
  user_name: string;
}

interface Report {
  created_at: string;
  description: string;
  file: string;
  folder_id: number;
  is_pinned: boolean;
  thumbnail: string;
  title: string;
  type: string;
  updated_at: string;
  user_id: number;
  user_name: string;
  _id: string;
}

interface reportAPIRequest {
  page: number;
  searchValue?: string;
  sortType?: sortValues;
  sortValue?: string;
}

interface reportAPI {
  data: {};
}

interface reportAPIResponse extends PayloadType {
  active: number;
  data: {
    data: {
      report_count: number;
      total_page: number;
      reports: {
        data: Report[];
      };
    };
  };
}

interface TabItem {
  label: string;
  content: React.ReactNode;
}

interface TabsProps {
  items: TabItem[];
}

interface UserProgress {
  user_progress_train: any[];
  user_progress_apply: any[];
  user_question_answer: UserQuestionAnswer[];
  first_object: string;
}

interface UserQuestionAnswer {
  question: string;
  answer: string;
}

interface AllUserListType {
  _id: string;
  full_name: string;
  email: string;
  user_type: string;
  registered_at: string;
  first_name: string;
  last_name?: string;
  gender?: string;
  birthday?: string;
  height?: string;
  weight?: string;
  address?: string;
  country?: string;
  postal_code?: string;
  time_zone?: string;
  userid: number;
  is_confirm: number;
  device_type: string;
  fcm_token: string;
  updated_at: string;
  created_at: string;
  last_login_at: string;
  hour?: number;
  min?: number;
  skip_reminder?: boolean;
  time?: string;
  aboutFisio?: boolean;
  appCarousel?: boolean;
  dailyReminder?: boolean;
  initialFreeTrail?: boolean;
  letsStart?: boolean;
  planOverView?: boolean;
  aboutYou?: boolean;
  acknowledgement?: boolean;
  convertFreeSuccess?: boolean;
  convertToFreeTrail?: boolean;
  dailyReminderSelection?: boolean;
  selectTimezone?: boolean;
  group_id: string;
  group_name: string;
  country_id?: string;
  last_updated_training_streak?: string;
  mulligan?: number;
  training_streak?: number;
  last_recall_card_level_updated_date?: string;
  user_recall_card_level?: number;
  max_training_streak?: number;
  profile_picture?: string;
  timezone?: string;
  stripe_customer_id?: string;
  active_subscription_id?: string;
  payment_method?: string;
  plan?: string;
}
interface UserProgressUserList {
  unit_name: string;
  session_name: string;
}

declare interface User {
  user: UserInfo;
  user_progress_train: UserProgressUserList[];
  user_progress_apply: UserProgressUserList[];
  user_question_answer: UserQuestionAnswer[];
  first_object: string;
}

declare interface AllUserListApiResponse {
  success: boolean;
  message: string;
  data: {
    users: Array<{ user: UserType[] }>;
  };
}
