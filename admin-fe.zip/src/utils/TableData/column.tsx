import {
  ColumnDef,
  ColumnHelper,
  createColumnHelper,
  createTable,
} from "@tanstack/react-table";
import moment from "moment";

const userTableHelper = createColumnHelper<UserType>();
export const defaultColumns: ColumnDef<UserType>[] = [
  {
    header: "Name",
    accessorKey: "full_name",
  },
  {
    header: "User Type",
    accessorKey: "user_type",
  },
  {
    header: "Email",
    accessorKey: "email",
  },
  {
    header: "Email2",
    accessorKey: "created_at",
    cell: (res) => {
      return <span>Hello</span>;
    },
  },
  {
    header: "Registration Date",
    accessorKey: "registered_at",
  },
  {
    header: "Last Logon",
    accessorKey: "updated_at",
    cell: (res) => <>Hello</>,
  },
];


export const userListColumn: ColumnDef<UserType>[] = [
  {
    header: "User Name",
    id: "User Name",
    accessorKey: "full_name",
    size: 30,

  },
  {
    header: "User Type",
    id: "User Type",
    accessorKey: "user_type",
  },
  {
    header: "Email",
    id: "Email",
    accessorKey: "email",
  },
  {
    header: "RegistrationDate",
    id: "RegistrationDate",
    accessorKey: "created_at",
    cell: (res) => {
      return <span>{moment(res.row.original.registered_at).format("DD-MM-YYYY")}</span>;
    },
  },
  {
    header: "Last Log on",
    id: "Last Log",
    accessorKey: "registered_at",
    cell: (res) => {
      return <span>{moment(res.row.original.created_at).format("DD-MM-YYYY")}</span>;
    },
  },
  {
    header: "Cohort",
    id: "Co",
    accessorKey: "group_name",
    cell: (res) => <>{res.row.original.group_name === "" ? "Default" : res.row.original.group_name}</>,
  },
  {
    header: "Days Subscribed",
    id: "Days Subscribed",
    accessorKey: "updated_at",
    cell: (res) => <>42</>,
  },
  {
    header: "Current Activity Status",
    id: "Current Activity Status",
    accessorKey: "updated_at",
    cell: (res) => <>Hello</>,
  },
  {
    header: "Email Sends",
    id: "Email Sends",
    accessorKey: "updated_at",
    cell: (res) => <>Hello</>,
  },
  {
    header: "Action",
    id: "Action",
    accessorKey: "updated_at",
    cell: (res) => {
      return (
        <>
          <div className="py-1 m-auto w-fit text-start items-center flex gap-4">
            <button onClick={() => { }} >
              <img className='h-8' src={"/images/actionbutton.svg"} />
            </button>
          </div>
        </>
      )
    },
  },
];
