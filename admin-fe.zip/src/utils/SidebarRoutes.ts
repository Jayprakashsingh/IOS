import ContentRepositoryIcon from "../Components/Icons/ContentRepositoryIcon";
import OnBoardingQuestionsIcon from "../Components/Icons/OnBoardingQuestionsIcon";
import ReportIcon from "../Components/Icons/ReportIcon";
import TagsIcon from "../Components/Icons/TagsIcon";
import UserManagementIcon from "../Components/Icons/UserManagementIcon";
import CoachReviewIcon from "../Components/Icons/CoachReviewIcon";
import AffiliateIcon from "../Components/Icons/AffiliateIcon";
import TrustIcon from "../Components/Icons/TrustIcon";
import { sidebarImages } from "../assets/sidebarasset";

type Props = {
  isActive: boolean;
};
export interface ISidebarRoutes {
  id: string;
  path: string;
  label: string;
  icon: ({ isActive }: Props) => JSX.Element;
  children: {
    id: string;
    path: string;
    label: string;
    icon: string;
  }[];
}

export const SideBarRoutes: ISidebarRoutes[] = [
  {
    id: "1",
    path: "/",
    label: "Content Repository",
    icon: ContentRepositoryIcon,
    children: [
      {
        id: "1",
        path: "/contentrepository/objects",
        label: "Objects",
        icon: "/",
      },
      {
        id: "2",
        path: "/contentrepository/session",
        label: "Sessions",
        icon: "/Session List",
      },
      {
        id: "3",
        path: "/contentrepository/units",
        label: "Units",
        icon: "/Unit List",
      },
      {
        id: "4",
        path: "/contentrepository/recallcard",
        label: "Recall Cards",
        icon: "/Unit List",
      },
      {
        id: "5",
        path: "/contentrepository/trophies",
        label: "Trophies",
        icon: "/Unit List",
      },
      {
        id: "5",
        path: "/contentrepository/group",
        label: "Program",
        icon: "/Unit List",
      },
      {
        id: "6",
        path: "/contentrepository/fundamentals",
        label: "Guide",
        icon: "/Fundamentals List",
      },
    ],
  },
  {
    id: "2",
    path: "/",
    label: "FTUE",
    icon: OnBoardingQuestionsIcon,
    children: [
      {
        id: "1",
        path: "/onboardingquestionsrepository",
        label: "Questions",
        icon: "/",
      },
      {
        id: "2",
        path: "/managewelcomescreen",
        label: "Welcome Pages",
        icon: "/",
      },
      {
        id: "2",
        path: "/aboutfisio",
        label: "About Fisio",
        icon: "/",
      },
    ],
  },
  {
    id: "3",
    path: "/",
    label: "Coach Review",
    icon: CoachReviewIcon,
    children: [
      {
        id: "1",
        path: "/coachreview/tickets",
        label: "Tickets",
        icon: "/",
      },
      {
        id: "2",
        path: "/coachreview/coaches",
        label: "Coaches",
        icon: "/",
      },
    ],
  },
  {
    id: "4",
    path: "",
    label: "Tags",
    icon: TagsIcon,
    children: [
      {
        id: "1",
        path: "/TagsRepository/Tags",
        label: "Tag",
        icon: "/",
      },
    ],
  },
  {
    id: "5",
    path: "/",
    label: "Admin Management",
    icon: UserManagementIcon,
    children: [
      {
        id: "1",
        path: "/usermanagement/adminlist",
        label: "Admin List",
        icon: "/",
      },
    ],
  },
  {
    id: "6",
    path: "/",
    label: "Affiliate",
    icon: AffiliateIcon,
    children: [
      {
        id: "1",
        path: "/affiliate",
        label: "Affiliate Marketing",
        icon: "/",
      },
    ],
  },
  {
    id: "7",
    path: "/",
    label: "Trust",
    icon: TrustIcon,
    children: [
      {
        id: "1",
        path: "/trust",
        label: "Trust",
        icon: "/",
      },
    ],
  },
  {
    id: "8",
    path: "/",
    label: "Report",
    icon: ReportIcon,
    children: [
      {
        id: "1",
        path: "/report",
        label: "Report",
        icon: "/",
      },
    ],
  },
];

export const CoachSideBarRoutes = [
  {
    id: "1",
    path: "/",
    label: "Coach Review",
    icon: CoachReviewIcon,
    activeIcon: sidebarImages.CoachReviewActive,
    children: [],
  },
];

export const UserManagementRoutes = [
  {
    id: "profile",
    label: "Profile",
    route: "/usermanagement/userlist/:id/profile",
  },
  {
    id: "rating",
    label: "Rating",
    route: "/usermanagement/userlist/:id/rating",
  },
  {
    id: "Subscription",
    label: "Subscription",
    route: "/usermanagement/userlist/:id/subscription",
  },
  {
    id: "feedback",
    label: "Feedback",
    route: "/usermanagement/userlist/:id/feedback",
  },
  {
    id: "activity",
    label: "Activity",
    route: "/usermanagement/userlist/:id/activity",
  },
];
