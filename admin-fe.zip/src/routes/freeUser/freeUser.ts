// Import necessary modules for lazy loading and authentication
import { lazy } from "react"; // For lazy loading components
import AdminRoutes from "../../auth/AdminRoutes"; // Admin authentication wrapper

// Lazy load the FreeUserList component
import FreeUserList from "../../Pages/freeUser/FreeuserList";

/**
 * Free User Routes
 * Defines the route for managing free users in the application.
 *
 * Features:
 * 1. Includes a route for viewing the list of free users.
 * 2. Uses lazy-loaded components to optimize initial load performance.
 * 3. Breadcrumbs are included for navigation clarity.
 */
export const freeUserRoutes = [
  {
    id: "freeUser", // Unique route identifier
    name: "Free User", // Display name for the route
    module: "Free User", // Associated module name
    path: "/freeUser", // URL path for the Free User List page
    component: FreeUserList, // Lazy-loaded component
    auth: AdminRoutes, // Admin authentication wrapper
    breadCrumbRoutes: [
      {
        name: "Free User", // Breadcrumb name
        path: "#", // Path for breadcrumb (stub)
      },
    ],
  },
];
