# Project DGT - Admin Panel Documentation

**Author:** Shyam Patel (Tuvoc Technologies)  
**Technology Stack & Libs:** React.js (Frontend), Redux Toolkit (State Management), Tailwind CSS (Styling), React-Select, Tanstack-table(v8), axios, React-Toastify, React-Beautiful-DND, React-cookie, React-player, react-Quill, Recharts, react-hook-forms

## Introduction

The Project DGT Admin Panel is a web-based, fully client-side rendered (CSR) application designed to manage users, coaches, sessions, and various other components of the DGT platform. By leveraging React.js, Redux Toolkit, and Tailwind CSS, this admin panel provides a scalable, performant, and maintainable solution for administrators and support teams.

This documentation aims to provide clear guidance on the architecture, code design principles, and each functional module. It is intended for developers, QA engineers, and administrators who wish to understand or contribute to the codebase.

## Installation Process

- **Node Version**: "16.2.0"
- **Add ENV:** add needed info in `.env` file.
- **Commands**:
  1. `npm i`;
  2. `npm run start`;

## Key Features

- **Modular Architecture:** The project is divided into well-defined modules, each responsible for distinct functionalities.
- **State Management with Redux Toolkit:** Ensures predictable state mutations and a clear data flow.
- **Tailwind CSS for Styling:** Delivers a responsive, utility-first approach to styling that improves development speed and maintainability.
- **Scalability:** A monolithic architecture with careful code structuring to prevent unnecessary complexity.
- **Security:** Incorporates secure authentication and authorization flows.

## Table of Contents

1.  [Architecture and Code Design](#architecture-and-code-design)
2.  [Login & Authentication](#login--authentication)
3.  [User Dashboard](#user-dashboard)
4.  [Coach Dashboard](#coach-dashboard)
5.  [Object Management](#object-management)
6.  [Session Management](#session-management)
7.  [Unit Management](#unit-management)
8.  [Recall Card Management](#recall-card-management)
9.  [Program Management](#program-management)
10. [Guide Management](#guide-management)
11. [FTUE (First-Time User Experience)](#ftue-first-time-user-experience)
12. [Trust & Security](#trust--security)
13. [Tag Management](#tag-management)
14. [Admin Management](#admin-management)
15. [SCA (Strong Customer Authentication)](#sca-strong-customer-authentication)
16. [FAQ and Policies](#faq-and-policies)

---

### Architecture and Code Design

**Philosophy:**  
Simplicity drives our architectural choices. We strive to minimize the use of unnecessary libraries and complexity. The codebase is structured as a monolith, but logically segmented by modules to maintain clarity and ease of navigation.

**Key Highlights:**

- **Monolithic SPA (Single-Page Application):**  
  The admin panel is entirely client-side rendered (CSR), which allows seamless navigation and quick load times once the application is running in the browser.
- **React.js:**  
  We use React components and Hooks extensively. Code is organized into `components`, `pages`, and `hooks` directories for better maintainability.
- **Redux & Redux Toolkit:**  
  State management is handled via Redux Toolkit, which streamlines store setup, reducers, and actions. This approach helps maintain a predictable state flow and simplifies debugging.
- **Tailwind CSS:**  
  For styling, we rely on Tailwind CSS. It provides utility classes that speed up development time, maintain design consistency, and eliminate the need for complex CSS frameworks.
- **RESTful API Integration:**  
  Communication with the backend services (e.g., to fetch data or perform updates) occurs through RESTful APIs. Each module’s Redux slice includes async thunks for data fetching and mutation.
- **Workflow:**  
  While not covered in-depth here, but still you can understand how global state, API are managed here in quite managable and independent manner in below chart
  the Entry point of code is `App.tsx` file

- **Routes Overview**
  Here is the comprehensive module wise list of all Routes in Admin Panel

| **File**                    | **Path**                                              | **Module Name**       |
| --------------------------- | ----------------------------------------------------- | --------------------- |
| **authRoutes.ts**           | `/`                                                   | Auth                  |
|                             | `/forgetpassword`                                     | Auth                  |
|                             | `/forgetpassword/:hashedID/:email`                    | Auth                  |
| **appControlRoutes.ts**     | `/appcontrol`                                         | AppControl            |
| **affiliateRoutes.ts**      | `/affiliate`                                          | Affiliate             |
|                             | `/affiliate/details`                                  | Affiliate Details     |
| **reportRoutes.ts**         | `/report`                                             | Report                |
|                             | `/reportdetails`                                      | Report                |
| **discountCodesRoutes.ts**  | `/discountcodes`                                      | Discount Codes        |
| **faqRoutes.ts**            | `/faq`                                                | FAQs                  |
| **freeUserRoutes.ts**       | `/freeUser`                                           | Free User             |
| **scaRoutes.ts**            | `/sca`                                                | SCA                   |
| **userDashboardRoutes.ts**  | `/usermanagement/userlist/:id/rating`                 | User Management       |
|                             | `/usermanagement/userlist/:id/profile`                | User Management       |
|                             | `/usermanagement/userlist/:id/activity`               | User Management       |
|                             | `/usermanagement/userlist/:id/support`                | User Management       |
|                             | `/usermanagement/userlist/:id/feedback`               | User Management       |
|                             | `/usermanagement/userlist/:id/subscription`           | User Management       |
|                             | `/usermanagement/userlist/:id/notification`           | User Management       |
| **coachRoutes.ts**          | `/coachreview/tickets`                                | Tickets               |
|                             | `/coachreview/tickets/:ticketid`                      | Tickets               |
|                             | `/coachreview/coaches`                                | Coaches               |
|                             | `/coachreview/list`                                   | Coach Review          |
|                             | `/coachreview/list/details`                           | Review Details        |
| **programRoutes.ts**        | `/contentrepository/group`                            | Program               |
|                             | `/contentrepository/addgroup`                         | Content Repository    |
|                             | `/contentrepository/editgroup`                        | Content Repository    |
| **guideRoutes.ts**          | `/contentrepository/fundamentals`                     | Content Repository    |
|                             | `/contentrepository/addfundamentals`                  | Content Repository    |
|                             | `/contentrepository/editfundamentals`                 | Content Repository    |
| **onBoardingRoutes.ts**     | `/onboardingquestionsrepository`                      | On-Boarding Questions |
|                             | `/onboardingquestionsrepository/editonboardquestions` | On-Boarding Questions |
|                             | `/onboardingquestionsrepository/addonboardquestions`  | On-Boarding Questions |
|                             | `/managewelcomescreen`                                | On-Boarding Questions |
|                             | `/aboutfisio`                                         | On-Boarding Questions |
| **tagRoutes.ts**            | `/TagsRepository/Tags`                                | Tags                  |
| **objectRoutes.ts**         | `/contentrepository/objects`                          | Content Repository    |
|                             | `/contentrepository/addobjects`                       | Content Repository    |
|                             | `/contentrepository/editobjects`                      | Content Repository    |
| **sessionRoutes.ts**        | `/contentrepository/session`                          | Content Repository    |
|                             | `/contentrepository/addsession`                       | Content Repository    |
|                             | `/contentrepository/editsession`                      | Content Repository    |
| **unitRoutes.ts**           | `/contentrepository/units`                            | Content Repository    |
|                             | `/contentrepository/AddUnits`                         | Content Repository    |
|                             | `/contentrepository/editunit`                         | Content Repository    |
| **recallCardRoutes.ts**     | `/contentrepository/recallcard`                       | Content Repository    |
|                             | `/contentrepository/addrecallcard`                    | Content Repository    |
|                             | `/contentrepository/editrecallcard`                   | Content Repository    |
| **usermanagementRoutes.ts** | `/usermanagement/adminlist`                           | User Management       |
|                             | `/usermanagement/userlist`                            | User Dashboard        |
|                             | `/usermanagement/userlist/:userId`                    | User Management       |

- **Folder Structure:**  
  Folder structure is key to manage clean code in modular way, in this project you can navigate through below folder tree

```
├── public/
│   ├── favicon.png
│   ├── images/
│   │   └── ... (All SVGs, PNGs, JPEGs for UI icons, branding, and graphics)
│   ├── index.html
│   └── manifest.json
│   └── robots.txt
|
├── src/
│   ├── api/
│   │   ├── api.ts (API config and axios inteceptors)
│   │   └── constants.ts
│   ├── auth/
│   │   ├── AdminRoutes.tsx (Admin Role Based Routes)
│   │   ├── CoachRoutes.tsx
│   │   ├── OpenRoutes.tsx
│   │   └── PublicRoutes.tsx
│   ├── Components/
│   │   ├── (Reusable UI Components: Buttons, Inputs, Tables, Charts, Modals, etc.)
│   │   └── ...
│   ├── Containers/
│   │   ├── Auth/ (Form containers for login, reset password, etc.)
│   │   ├── Coach/ (Containers related to coach dashboard & feedback)
│   │   ├── Objects/ (Containers for managing objects and their details)
│   │   ├── Sessions/ (Containers for session listing, editing, adding sessions)
│   │   ├── Units/ (Containers for managing units and their details)
│   │   ├── UserManagement/ (Containers for admin/user management forms and listings)
│   │   └── ... (Other feature-specific containers)
│   ├── CustomHooks/
│   │   └── (Custom React Hooks for specific functionalities)
│   ├── helper/
│   │   └── index.ts (Helper/util functions)
│   ├── Pages/
│   │   ├── Auth/ (LoginPage, ForgetPasswordPage, ResetPasswordPage)
│   │   ├── Coach/ (CoachDashboard, CoachListPage)
│   │   ├── Objects/ (ObjectListPage, AddObjectsPage, EditObjectPage)
│   │   ├── Sessions/ (SessionListPage, AddSessionPage, EditSessionPage)
│   │   ├── Units/ (UnitsListPage, AddUnitsPage, EditUnitPage)
│   │   ├── Users/ (AdminListPage, UserListPage, User details pages)
│   │   ├── Faq/, TagPage.tsx, Trust/, etc. (Other feature pages)
│   │   └── ... (Various pages corresponding to each module)
│   ├── Redux/
│   │   ├── app/
│   │   │   ├── hooks.ts (Typed hooks for Redux)
│   │   │   └── store.ts (Redux store configuration)
│   │   └── features/
│   │       ├── (Individual slices for each feature: UserAuthSlice, TagSlice, SessionSlice, etc.)
│   │       └── ...
│   ├── routes/
│   │   ├── (Route configuration files for different modules: authRoutes, coachRoutes, objectRoutes, etc.)
│   │   └── index.ts (Master route configuration entry point)
│   ├── types/
│   │   ├── apirequest.d.ts
│   │   ├── apiresponse.ts
│   │   ├── globle.type.ts
│   │   └── type.d.ts (Type definitions and interfaces)
│   ├── utils/
│   │   ├── helper.tsx (Utility functions and helpers)
│   │   ├── SidebarRoutes.ts (Sidebar navigation configuration)
│   │   ├── TableColumns.ts (Table column configuration)
│   │   └── ... (Additional utility modules)
│   ├── App.tsx (Main application component)
│   ├── index.tsx (React application entry point)
│   ├── index.css (Global stylesheet)
│   └── reportWebVitals.ts (Performance measurement file)
|
├── qa-dgt.pem (Certificate or key file for QA environment)
├── README.md (Project documentation)
├── tailwind.config.js (Tailwind CSS configuration)
└── tsconfig.json (TypeScript configuration)
```

---

### Login & Authentication

**Overview:**  
The login module handles user authentication. Using JWT or session tokens, administrators must authenticate themselves before accessing restricted areas of the admin panel.

**Key Points:**

- **Secure Authentication:** Users log in with valid credentials, triggering an API call to authenticate and retrieve tokens.
- **Protected Routes:** React Router guards restricted pages. Users without valid tokens are redirected to the login screen.
- **Token Storage:** Auth tokens are stored securely (e.g., in HTTP-only cookies or secure storage) to prevent XSS attacks.

---

### User Dashboard

**Overview:**  
Provides an at-a-glance overview of all registered users and their details. Administrators can view profiles, activity logs, and manage user states (active, suspended, etc.).

**Key Points:**

- **Search & Filtering:** Quickly find users by name, email, or ID.
- **Bulk Actions:** Enable admins to update multiple user records simultaneously.
- **User Detail Views:** Includes editable fields for profile updates and status changes.

---

### Coach Dashboard

**Overview:**  
Similar to the User Dashboard, but focused on coaches. Administrators can manage coaches, their sessions, qualifications, and performance metrics.

**Key Points:**

- **Coach Verification:** Confirm coach credentials and approve or deny profiles.
- **Schedules & Sessions:** View upcoming sessions, assign coaches to sessions, and track performance metrics.

---

### Object Management

**Overview:**  
Manages various "objects" within the DGT platform (this could be content items, data entities, or other relevant items).

**Key Points:**

- **CRUD Operations:** Add, edit, delete, and list all objects.
- **Categorization & Tagging:** Organize objects into categories for easier retrieval.
- **Versioning & History:** Track changes over time, revert to previous versions if necessary.

---

### Session Management

**Overview:**  
Handles the scheduling, updating, and oversight of sessions (e.g., training sessions, meetings, or events).

**Key Points:**

- **Session Creation & Editing:** Define session details like date, time, participants, and assigned coaches.
- **Status Tracking:** Monitor session completion, cancellations, or rescheduling.
- **Notifications & Reminders:** Integrate with notification systems to remind participants about upcoming sessions.

---

### Unit Management

**Overview:**  
Units represent modular content segments within the platform. Administrators can manage these units for courses, tutorials, or lessons.

**Key Points:**

- **Unit Hierarchy:** Organize units into modules or chapters.
- **Content Linking:** Associate units with lessons, sessions, or guides.
- **Progress Tracking:** Integrate with reporting tools to track user progress through units.

---

### Recall Card Management

**Overview:**  
Recall cards (if applicable to the platform) serve as memory aids or flashcards for users.

**Key Points:**

- **Card Creation:** Add new cards with prompts and answers.
- **Card Sets:** Organize cards into sets and categories.
- **User Access:** Assign card sets to users or groups for study and review.

---

### Program Management

**Overview:**  
Programs are broader constructs, potentially encompassing sessions, units, and various learning materials.

**Key Points:**

- **Program Structure:** Link multiple units, sessions, and guides into cohesive programs.
- **Enrollment & Tracking:** Manage which users or coaches are enrolled in which programs.
- **Progress & Completion:** Track user progress through each program component.

---

### Guide Management

**Overview:**  
Guides provide instructional or reference content.

**Key Points:**

- **Guide Creation & Updates:** Add rich text or multimedia content.
- **Search & Indexing:** Ensure easy retrieval through search functionality.

---

### FTUE (First-Time User Experience)

**Overview:**  
Configures and maintains the onboarding flow for new users, ensuring they receive the right guidance and resources upon their first login.

**Key Points:**

- **Onboarding Steps:** Define Questions for new users.
- **Feedback Collection:** Gather user feedback to improve the FTUE over time.

---

### Trust & Security

**Overview:**  
Focuses on ensuring that the platform meets security, compliance, and trust standards.

**Key Points:**

- **Access Controls:** Define and manage role-based permissions.
- **Audit Logging:** Keep a record of admin actions for transparency.
- **Compliance & Regulatory Checks:** Maintain compliance with industry standards (e.g., GDPR, HIPAA).

---

### Tag Management

**Overview:**  
Tags help categorize content, sessions, or users for easier filtering and retrieval.

**Key Points:**

- **Tag Creation & Assignment:** Easily create new tags and assign them to various entities.
- **Bulk Tagging:** Apply tags to multiple items at once.
- **Search & Filter:** Enhance search capabilities using tags.

---

### Admin Management

**Overview:**  
Manage administrators and their permissions within the platform.

**Key Points:**

- **Admin Roles & Privileges:** Assign and manage varying levels of admin access.
- **Activity Monitoring:** Track admin actions for accountability.

---

### FAQ and Policies

**Overview:**  
Central repository for frequently asked questions, user guidelines, and policy documents.

**Key Points:**

- **Content Management:** Admins can update FAQ entries and policy documents.
- **Searchable Knowledge Base:** Easily find relevant policies or FAQs.
- **Versioning of Policies:** Track changes over time, provide revision history.

---

## Additional Notes

- **Performance Monitoring:**  
  Consider integrating a performance monitoring tool (e.g., Lighthouse, New Relic) to ensure the admin panel remains performant as it scales.
- **Error Handling & Logging:**  
  Implement robust error handling within components and API calls. Use browser console warnings or integrated logging tools to diagnose issues efficiently.
- **Localization & Internationalization:**  
  If the project requires multi-language support, consider integrating a localization library (e.g., react-intl or i18next).

## Conclusion

This documentation outlines the conceptual architecture, code design principles, and the various modules that make up the DGT Admin Panel. By following these guidelines and best practices, developers can maintain a clean, secure, and scalable codebase, enabling continuous improvement and smooth operations for all DGT stakeholders.

---

_For further questions or clarifications, please contact the development team at Tuvoc Technologies._
