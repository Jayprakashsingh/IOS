//
//  ViewController.m
//  ComplacateBlock
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
   
    [self callblock];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)clickStart:(id)sender
{
    NSLog(@"Start");
}

#pragma marks-Block Method
-(void)changeView:(present)dataview
{
    dataview(objView1,@"hi");
    NSLog(@"call");
}
-(void)callblock
{
    [self changeView:^(UIView *objView, NSString *str) {
        [UIView animateWithDuration:2 animations:^{
             objView1=[[UIView alloc] initWithFrame:CGRectMake(20, 150, 200, 100)];
            objView1.backgroundColor=[UIColor blueColor];
            [self.view addSubview:objView1];
            str1=@"Start Web Service";
           
            
        } completion:^(BOOL finished) {
            UILabel *lbl=[[UILabel alloc] initWithFrame:CGRectMake(10, 10, 180, 30)];
            lbl.backgroundColor=[UIColor redColor];
            [lbl setText:str1];
            [objView1 addSubview:lbl];
        }];

        
        
    }];

}









@end
