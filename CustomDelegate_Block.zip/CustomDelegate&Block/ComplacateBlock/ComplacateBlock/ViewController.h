//
//  ViewController.h
//  ComplacateBlock
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^present)(UIView *objView,NSString *str);

@interface ViewController : UIViewController
{
    IBOutlet UIButton *startButton;
    UIView *objView1;
    NSString *str1;
}
-(IBAction)clickStart:(id)sender;
@end
