//
//  CustomCell.h
//  CustomBlock
//
//  Created by BL@CK on 7/2/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^myBlock)(NSString *strName,BOOL error);

@interface CustomCell : UITableViewCell
-(void)myCellMethod:(myBlock)block;
@property(nonatomic,strong)myBlock touchCell;



-(IBAction)btnClick:(id)sender;
@property(nonatomic,strong)IBOutlet UIButton *btnCell;
@property(nonatomic,strong)IBOutlet UILabel *lbl;

@end




