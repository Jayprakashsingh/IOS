//
//  CustomCell.m
//  CustomBlock
//
//  Created by BL@CK on 7/2/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "CustomCell.h"


@implementation CustomCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
#pragma mark-MyBlock Method

-(void)myCellMethod:(myBlock)block
{
    self.touchCell=block;

   
}
-(IBAction)btnClick:(id)sender
{
    if (self.touchCell !=nil) {
        self.touchCell(@"touch Here",true);
    }
}


@end
