//
//  ViewController.m
//  CustomBlock
//
//  Created by BL@CK on 7/2/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "CustomCell.h"
#import "LoginViewController.h"
@interface ViewController ()
{
    CustomCell *cell;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)MyClassMethod:(myBlock)customBlock
{
    customBlock(@"MyClassMethod Call",true);
}

#pragma marks-t6ableview Method
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    cell=(CustomCell *)[objTable dequeueReusableCellWithIdentifier:@"cell"];
    
    
    if (cell == nil) {

        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
        cell = (CustomCell*) nib.firstObject;

    }
    
    [cell myCellMethod:^(NSString *strName,BOOL error){
        NSLog(@"%d",(int)indexPath.row);
        cell.backgroundColor=[UIColor brownColor];
        if (error==true) {
            NSLog(@"error");
        }
     
        NSLog(@"%@",strName);
     
    }];
    return cell;
}

#pragma marks-FirstDelegate Method

-(void)chngeBackgroundColor
{
   [self.view setBackgroundColor:[UIColor redColor]];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"LoginVC"]) {
        NSLog(@"%@",segue.sourceViewController);
        LoginViewController *obj=(LoginViewController*) [segue destinationViewController];
        obj.objLogin=self;
    }


}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
