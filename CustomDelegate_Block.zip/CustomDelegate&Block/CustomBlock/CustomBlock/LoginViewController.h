//
//  LoginViewController.h
//  CustomBlock
//
//  Created by BL@CK on 7/2/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol firstDelegate <NSObject>

@required
-(void)chngeBackgroundColor;

@optional
-(void)addText;

@end

@interface LoginViewController : UIViewController

@property(nonatomic,strong)id<firstDelegate>objLogin;
-(IBAction)btnLogin:(id)sender;
@end




