//
//  ViewController.h
//  MyDelegate
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^makeBlock)(NSString *str);
@interface ViewController : UIViewController

@end
