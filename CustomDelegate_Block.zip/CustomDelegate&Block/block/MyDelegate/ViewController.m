//
//  ViewController.m
//  MyDelegate
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self CountDatacallFromHere];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-MyBlock Method
-(void)CountData:(makeBlock)blocksender
{
    blocksender(@"stringPassed");
    NSLog(@"stringPassed");

}
-(void)CountDatacallFromHere
{
    [self CountData:^(NSString *str) {
        str=@"Call String or not";
        NSLog(@"%@",str);
    }];

}





@end
