//
//  SecondViewController.h
//  CreateFirstDelegate
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol friendsWayDelegate <NSObject>

@required
-(void)changeBackground;
@optional
-(void)changeFont;
@end


@interface SecondViewController : UIViewController
-(IBAction)callMethodFromfirst:(id)sender;
@property(nonatomic,strong)id<friendsWayDelegate>objFriendWayDelegate;
@end
