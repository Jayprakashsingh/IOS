//
//  ViewController.m
//  CreateFirstDelegate
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-FriendsWay Delegate method
-(void)changeBackground
{
    self.view.backgroundColor=[UIColor blueColor]; ;

}
-(void)changeFont
{
    UILabel *lbl=[[UILabel alloc] initWithFrame:CGRectMake(50, 200, 150, 30)];
    [lbl setText:@"Label Arrived"];
    [self.view addSubview:lbl];
}

#pragma marks-Passed value using storyBoard object
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"SecondVC"]) {
      
        SecondViewController *objSecondView=(SecondViewController *)[segue destinationViewController];
        objSecondView.objFriendWayDelegate=self;
    }

}

@end
