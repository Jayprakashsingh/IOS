//
//  CustomCell.h
//  DelegateInTableView
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^BlockForCell)(NSArray *arr,NSString *str);

@interface CustomCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UIButton *btnClick;
-(void)methodForBlock:(BlockForCell)block;
@property(nonatomic,strong)BlockForCell objBlock;
-(IBAction)btnClickMethod:(id)sender;

@end
