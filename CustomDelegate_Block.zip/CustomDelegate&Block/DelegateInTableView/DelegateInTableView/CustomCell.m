//
//  CustomCell.m
//  DelegateInTableView
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(IBAction)btnClickMethod:(id)sender
{
   
    NSArray *array=[[NSArray alloc] initWithObjects:@"Dhaval",@"Rajan", nil];
    
    if (self.objBlock !=nil) {
        self.objBlock(array,@"send array");
    }

}
-(void)methodForBlock:(BlockForCell)block
{
    self.objBlock=block;

}
@end
