//
//  ViewController.m
//  DelegateInTableView
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "CustomCell.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-Tableview Data Source Method
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *nib=[[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
    CustomCell *cell=(CustomCell *)nib.firstObject;
    [cell methodForBlock:^(NSArray *arr, NSString *str) {
        cell.backgroundColor=[UIColor yellowColor];
        NSLog(@"Array is%@ \n String is%@",arr,str);
    }];
    return cell;
}




@end
