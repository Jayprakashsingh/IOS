//
//  LoginPage.h
//  TabBarusingXIB
//
//  Created by BL@CK on 6/6/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginPage : UIViewController
@property(strong,nonatomic)UITabBarController *objTabBarController;

@end
