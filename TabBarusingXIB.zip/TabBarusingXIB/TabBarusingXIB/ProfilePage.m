//
//  ProfilePage.m
//  TabBarusingXIB
//
//  Created by BL@CK on 6/6/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ProfilePage.h"
#import "AppDelegate.h"
@interface ProfilePage ()

@end

@implementation ProfilePage

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
}
-(IBAction)btnClick:(id)sender
{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    [appDelegate.nameRecord addObject:@"Rohan"];
    [appDelegate.nameRecord addObject:@"Parikshit"];
    NSLog(@"Array of Name:--->%@",appDelegate.nameRecord);
    

    int y=130;
    for (int i=0; i<appDelegate.nameRecord.count; i++)
    {
        name=[[UILabel alloc] initWithFrame:CGRectMake(130, y, 100, 50)];
        name.text=[appDelegate.nameRecord objectAtIndex:i];
        y=y+60;
        [self.view addSubview:name];
    }

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
