//
//  LoginPage.m
//  TabBarusingXIB
//
//  Created by BL@CK on 6/6/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "LoginPage.h"
#import "ProfilePage.h"
#import "AppDelegate.h"

@interface LoginPage ()

@end

@implementation LoginPage
@synthesize objTabBarController;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
     AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    [appDelegate.nameRecord addObject:@"Rajat"];
    
    LoginPage *objLogin=[[LoginPage alloc] init];
    ProfilePage *objProfile=[[ProfilePage alloc] init];
    
    objTabBarController = [[UITabBarController alloc] init];
    objProfile.tabBarItem =
    [[UITabBarItem alloc] initWithTitle:@"ProfilePage" image:nil tag:1];
    
    objLogin.tabBarItem=
    [[UITabBarItem alloc] initWithTitle:@"LoginPage" image:nil tag:2];
    
    UINavigationController *objNavigation = [[UINavigationController alloc] initWithRootViewController:objLogin];
    
    
   // UIImage *loginImage = [UIImage imageNamed:@"on.jpeg"];
   // UIImage *profileImage = [UIImage imageNamed:@"image.jpg"];
    
    NSArray *aryView = [[NSArray alloc] initWithObjects:objNavigation,objProfile, nil];
    
    
    
    [objTabBarController setViewControllers:aryView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
