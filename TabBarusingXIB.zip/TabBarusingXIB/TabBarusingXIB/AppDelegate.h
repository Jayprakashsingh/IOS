//
//  AppDelegate.h
//  TabBarusingXIB
//
//  Created by BL@CK on 6/6/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(nonatomic,strong)UITabBarController *tabBarController;
@property(nonatomic,strong)NSMutableArray *nameRecord;






@end
