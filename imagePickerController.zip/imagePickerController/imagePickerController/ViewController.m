//
//  ViewController.m
//  imagePickerController
//
//  Created by BL@CK on 6/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSArray *images=[[NSArray alloc] initWithObjects:[UIImage imageNamed:@"n1.jpeg"],[UIImage imageNamed:@"n2.jpeg"],[UIImage imageNamed:@"n3.jpeg"],[UIImage imageNamed:@"n4.jpeg"], nil];
    [natureImage setAnimationImages:images];
    natureImage.animationDuration=4.0;
    [natureImage startAnimating];
	// Do any additional setup after loading the view, typically from a nib.
}
-(IBAction)btnShow:(id)sender
{
    UIImagePickerController *objPicker=[[UIImagePickerController alloc] init];
    objPicker.delegate=self;
    objPicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    [self.navigationController presentViewController:objPicker animated:YES completion:nil];

}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSLog(@"%@",info);
    [natureImage2 setImage:[info valueForKey:UIImagePickerControllerOriginalImage]];
    natureImage2.contentMode=UIViewContentModeScaleAspectFill;
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"Cancel");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
