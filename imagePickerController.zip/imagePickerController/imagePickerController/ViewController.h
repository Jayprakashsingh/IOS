//
//  ViewController.h
//  imagePickerController
//
//  Created by BL@CK on 6/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    IBOutlet UIImageView *natureImage;
    IBOutlet UIImageView *natureImage2;
    
}
-(IBAction)btnShow:(id)sender;
@end
