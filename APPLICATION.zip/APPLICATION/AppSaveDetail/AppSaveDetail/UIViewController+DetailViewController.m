//
//  UIViewController+DetailViewController.m
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "UIViewController+DetailViewController.h"

@implementation UIViewController (DetailViewController)

@end
