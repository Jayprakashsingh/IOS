//
//  DetailViewController.m
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "DetailViewController.h"
#import "ViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize arrayOld,selectedRow;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    arrayTotalData=[NSMutableArray new];
    arrayTotalData=[[[NSUserDefaults standardUserDefaults] valueForKey:@"data"] mutableCopy];
    if (selectedRow !=nil) {
        self.txtName.text=[[arrayOld objectAtIndex:selectedRow]valueForKey:@"Name"];
        self.txtAge.text=[[arrayOld objectAtIndex:selectedRow]valueForKey:@"Age"];
        self.txtEducation.text=[[arrayOld objectAtIndex:selectedRow]valueForKey:@"Education"];
        
        
        NSMutableDictionary *copyData=[NSMutableDictionary new];
        copyData=[[arrayTotalData objectAtIndex:selectedRow] mutableCopy];
        // NSLog(@"%@",copyData);
        NSString *a=self.txtName.text;
        NSString *b=self.txtEducation.text;
        NSString *c=self.txtAge.text;
        [copyData setObject:a forKey:@"Name"];
        [copyData setObject:b forKey:@"Education"];
        [copyData setObject:c forKey:@"Age"];
        NSDictionary *dic=[NSDictionary new];
        dic = copyData;
        [arrayTotalData replaceObjectAtIndex:selectedRow withObject:dic];
        NSLog(@"%@",arrayTotalData);

        
    }
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-UIButton Action
-(void)btnCancel:(id)sender
{

    ViewController *objView=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self.navigationController pushViewController:objView animated:YES];
}
-(void)btnSave:(id)sender
{
   
    

    
    
    
    
    NSMutableDictionary *dicSave=[NSMutableDictionary new];
    [dicSave setObject:self.txtName.text forKey:@"Name"];
    [dicSave setObject:self.txtEducation.text forKey:@"Education"];
    [dicSave setObject:self.txtAge.text forKey:@"Age"];
    
    [arrayTotalData addObject:dicSave];
    [[NSUserDefaults standardUserDefaults]setObject:arrayTotalData forKey:@"data"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    ViewController *objView=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self.navigationController pushViewController:objView animated:YES];
}

@end
