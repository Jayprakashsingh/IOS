//
//  ViewController.m
//  CollectionController
//
//  Created by agilemac-151 on 6/8/16.
//  Copyright (c) 2016 agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
        recipePhotos = [NSArray arrayWithObjects:@"images1.jpg", @"images8.jpg", @"images9.jpg", @"images7.jpg", @"index4.jpg", @"index.jpg", @"index6.jpg", @"index3.jpg", @"index5.jpg", @"index2.jpg", nil];
    
    // Do any additional setup after loading the view, typically from a nib.
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return recipePhotos.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"Cell";
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    recipeImageView.image = [UIImage imageNamed:[recipePhotos objectAtIndex:indexPath.row]];
    
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
