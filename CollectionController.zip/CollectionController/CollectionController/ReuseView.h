//
//  ReuseView.h
//  CollectionController
//
//  Created by BL@CK on 6/9/16.
//  Copyright (c) 2016 agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReuseView : UICollectionReusableView

@end
