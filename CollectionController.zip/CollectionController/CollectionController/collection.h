//
//  collection.h
//  CollectionController
//
//  Created by BL@CK on 6/8/16.
//  Copyright (c) 2016 agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface collection : UICollectionViewController<UICollectionViewDelegate,UICollectionViewDataSource>
{
    NSArray *recipePhotos;
 
}
@property (strong, nonatomic) IBOutlet UILabel *headerLabel;


@end
