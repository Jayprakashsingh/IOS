//
//  ViewController.m
//  LocalNotificationCentre
//
//  Created by BL@CK on 7/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    UILocalNotification *localNotification2=[[UILocalNotification alloc]init];
    localNotification2.fireDate=[NSDate dateWithTimeIntervalSinceNow:8];
    localNotification2.alertBody=@"Message";
    localNotification2.alertAction=@"Chirag";
    localNotification2.alertLaunchImage=@"profile.jpg";
    localNotification2.soundName=UILocalNotificationDefaultSoundName;
    localNotification2.applicationIconBadgeNumber=1;
    localNotification2.timeZone=[NSTimeZone defaultTimeZone];
    [[UIApplication sharedApplication]scheduleLocalNotification:localNotification2];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-Button Method
-(void)btnShowNotification:(id)sender
{
    UILocalNotification *localNotification=[[UILocalNotification alloc]init];
    localNotification.fireDate=[NSDate dateWithTimeIntervalSinceNow:5];
    localNotification.alertBody=@"Message Arrived";
    localNotification.alertAction=@"Chirag";
    localNotification.alertLaunchImage=@"profile.jpg";
    localNotification.soundName=UILocalNotificationDefaultSoundName;
    localNotification.applicationIconBadgeNumber +=1;
    localNotification.timeZone=[NSTimeZone defaultTimeZone];
    [[UIApplication sharedApplication]scheduleLocalNotification:localNotification];
   
    
    NSLog(@"Before %@",[[UIApplication sharedApplication] scheduledLocalNotifications]);
    [self deleteNotification];
    NSLog(@"After %@",[[UIApplication sharedApplication] scheduledLocalNotifications]);
    
}
-(void)deleteNotification
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications) {
        
        if ([localNotification.alertBody isEqualToString:@"Message"]) {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ; // delete the notification from the system
            
        }
        
    }}
@end
