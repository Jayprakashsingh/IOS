//
//  ViewController.h
//  LocalNotificationCentre
//
//  Created by BL@CK on 7/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{

}
-(IBAction)btnShowNotification:(id)sender;
@end
