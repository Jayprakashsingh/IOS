//
//  LocalNotificationCentreTests.m
//  LocalNotificationCentreTests
//
//  Created by BL@CK on 7/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface LocalNotificationCentreTests : XCTestCase

@end

@implementation LocalNotificationCentreTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
