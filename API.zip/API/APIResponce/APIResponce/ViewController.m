//
//  ViewController.m
//  APIResponce
//
//  Created by BL@CK on 6/29/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    NSMutableDictionary *dic;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSURLRequest *urlRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://api.Foursquare.com/v2/venues/search?ll=37.33,-122.03&categoryId=4bf58dd8d48988d1e0931735"]];
    [NSURLConnection sendAsynchronousRequest:urlRequest queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data,
                                               NSError *error)
     {
         NSError *err;
         
         if ([data length]>10 && error==nil) {
             NSString *str=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
             NSLog(@"Given String%@\n\n",str);
             
             dic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
             NSLog(@"In Dictionary%@",dic);
             
             
             NSDictionary *dic1=[NSDictionary new];
            dic1=[[dic valueForKey:@"results"] valueForKey:@"nat"];
            NSLog(@"%@",dic1);
         
             
         }
         else if ([data length]==0 && error==nil)
         {
             NSLog(@"Data is not get ");
         }
         else if(error !=nil)
         {
             NSLog(@"Error %@",error);
         }
     }];
    
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
