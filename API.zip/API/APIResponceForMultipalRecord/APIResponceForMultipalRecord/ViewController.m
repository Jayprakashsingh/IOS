//
//  ViewController.m
//  APIResponceForMultipalRecord
//
//  Created by BL@CK on 6/29/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableDictionary *dict1,*dict2,*dict3,*dict4,*dict5,*dict6,*dict7;
    UITextField *txt;
    UIButton *btnOK;

}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    txt=[[UITextField alloc]initWithFrame:CGRectMake(50, 50, 100, 30)];
    txt.backgroundColor=[UIColor whiteColor];
    txt.borderStyle=UITextBorderStyleRoundedRect;
    txt.placeholder=@"Enter any between 1 to 7";
    [self.view addSubview:txt];
    
    btnOK=[[UIButton alloc] initWithFrame:CGRectMake(180, 50, 80, 30)];
    btnOK.backgroundColor=[UIColor blueColor];
    [btnOK setTitle:@"CLICK" forState:UIControlStateNormal];
    [btnOK addTarget:self action:@selector(btnTouched:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnOK];
    

    

  
    
  

  //  NSMutableArray *totalRecord=[[NSMutableArray alloc] initWithObjects:dict1,dict2,dict3,dict4,dict5,dict6,dict7, nil];
  //  NSLog(@"Array%@",totalRecord);
    
}
-(IBAction)btnTouched:(id)sender
{
    if ([txt.text isEqualToString:@"1"]) {
      
#pragma marks-For Forgot password
        
        NSURLRequest *urlRequest1=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=forgotpassword&email=CHIRAG0957@GMAIL.COM" ]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest1 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                NSString *str=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",str);
                
                dict1=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for Forgot Password %@",dict1);
                NSString *newStr=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",newStr);
                NSLog(@"%@",dict1);
                
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
            }
            else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
            
        }];
        

        
    }
    else if ([txt.text isEqualToString:@"2"]){
    
    #pragma marks-For Login
        
        NSURLRequest *urlRequest2=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=login&email=keyur.sosa@agileinfoways.com&password=123456&user_deviceid=123568494&device_platform=0"]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest2 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                
              //  NSString *str2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",str2);
                
                dict2=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for login %@",dict2);
              //  NSString *newStr2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",newStr2);
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
                
            }else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
        }];

        
        
    }
    else if ([txt.text isEqualToString:@"3"]){
#pragma marks-For Create Profile
        
        
        NSURLRequest *urlRequest3=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=register&email=rCHIRAG0957@GMAIL.COM&password=r5020&mobile_number=+97250718281&screen_name=&country=thailanduk&address=&nhw_id=&membership_number=&user_deviceid=904555525cc4c1e4dc65ce0&lat=23.0380&long=62.5560&registration_date=2016-07-01&device_platform=8&name=rajni"]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest3 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                
                NSString *str2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                //  NSLog(@"%@",str2);
                
                dict3=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for Create Profile %@",dict3);
                NSString *newStr2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",newStr2);
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
                
            }else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
        }];
        
        
        
        
        
    }
    else if ([txt.text isEqualToString:@"4"]){
       
#pragma marks-For Edit Profile
        
        
        NSURLRequest *urlRequest4=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=updateuser&user_id=957&email=CHIRAG0957@GMAIL.COM.com&password=5020&name=testprofile&mobile_number=9725071828&screen_name=CHIRAG&country=thailand&address=&nhw_id=&membership_number=&user_deviceid=904525cc4c1e4dc65ce0&lat=23.0300&long=72.5560&device_platform=8"]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest4 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                
                NSString *str2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                //  NSLog(@"%@",str2);
                
                dict4=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for login %@",dict4);
                NSString *newStr2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",newStr2);
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
                
            }else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
        }];
        
    }
    else if ([txt.text isEqualToString:@"5"]){
       
#pragma marks-For Create Group
        
        NSURLRequest *urlRequest5=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=create_group&admin_id=56&privacy=public&group_name=FRIENDSWAY&description=testING&invite_frend=2,3,4,5"]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest5 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                
                NSString *str2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",str2);
                
                dict5=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for Create Group %@",dict5);
                NSString *newStr2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                //  NSLog(@"%@",newStr2);
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
                
            }else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
        }];

        
    }
    else if ([txt.text isEqualToString:@"6"]){
        
#pragma marks-For Search Group
        
        NSURLRequest *urlRequest6=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=login&email=keyur.sosa@agileinfoways.com&password=123456&user_deviceid=123568494&device_platform=0"]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest6 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                
                NSString *str2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                //NSLog(@"%@",str2);
                
                dict6=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for Search Group %@",dict6);
                NSString *newStr2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                //NSLog(@"%@",newStr2);
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
                
            }else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
        }];
        

        
        
    }
    else if ([txt.text isEqualToString:@"7"]){
       
#pragma marks-For Group Details
        
        NSURLRequest *urlRequest7=[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://180.211.99.165/rs/unitehood/API/frmapi.php?api=group_detail&group_id=1"]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest7 queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            NSError *err;
            
            if ([data length]>10 && connectionError==nil) {
                
                NSString *str2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                //  NSLog(@"%@",str2);
                
                dict7=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"Dictionary for Group Details %@",dict7);
                NSString *newStr2=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"%@",newStr2);
                
            } else if([data length]==0 && connectionError==nil){
                NSLog(@"Data is not fount");
                
            }else if (connectionError!=nil){
                NSLog(@"Error =%@",connectionError);
            }
        }];
        
    }
    else
    {
    
        NSLog(@"Enter Value between 1 to 7");
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
