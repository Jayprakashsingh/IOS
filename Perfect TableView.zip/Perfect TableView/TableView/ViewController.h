//
//  ViewController.h
//  TableView
//
//  Created by agilemac-74 on 07/07/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

#define CellTypeKey @"strCellType"
#define SegmentArrayKey  @"segmentArray"
#define TextFieldTextKey @"textFieldText"

typedef enum ScreenType
{
    ScreenTypeNormal,
    ScreenTypeFacebook,
    
}ScreenType;

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *aryScreenData;
    IBOutlet UITableView *tblSignIn;
    NSString *strCellType;
    //1==SimpeTextFieldCell,2==SegmentCell,3=PickerViewCell
    ScreenType cellTypeEnum;
    
}

@end

