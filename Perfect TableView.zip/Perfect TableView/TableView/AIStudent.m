//
//  AIStudent.m
//  TableView
//
//  Created by agilemac-74 on 07/07/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import "AIStudent.h"

@implementation AIStudent
-(id)initWithData:(NSMutableDictionary *)dictStudent;
{
    self.studentId = [dictStudent valueForKey:@"id"];
  
    self.strImageUrl = [dictStudent valueForKey:@"image"];
    if ([dictStudent valueForKey:@"title"])
    {
          self.name = [dictStudent valueForKey:@"title"];
    }
    else
    {
        self.name = @"";
    }
    return  self;
}

@end
