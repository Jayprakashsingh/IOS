//
//  ViewController.m
//  TableView
//
//  Created by agilemac-74 on 07/07/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "TextfieldCell.h"
#import "AIStudent.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    aryScreenData = [[self createScreenArray] mutableCopy];
    NSLog(@"%@",aryScreenData);
//    cellTypeEnum = ScreenTypeFacebook;
//    if (cellTypeEnum == ScreenTypeFacebook )
//    {
//        
//    }
//    else
//    {
//        
//    }
    
    [self createStudentArray];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Array-Dictionary
-(void)createStudentArray
{
    NSMutableArray *aryStudents = [NSMutableArray new];
    NSMutableDictionary *dictTemp= [NSMutableDictionary new];
    [dictTemp setObject:@"1" forKey:@"id"];
    [dictTemp setObject:@"abc" forKey:@"name"];
    
    
    AIStudent *objStudent = [[AIStudent alloc] initWithData:dictTemp];
    [aryStudents addObject:objStudent];
    
    
    dictTemp= [NSMutableDictionary new];
    [dictTemp setObject:@"3" forKey:@"id"];
    [dictTemp setObject:@"xyZ" forKey:@"name"];
    objStudent = [[AIStudent alloc] initWithData:dictTemp];
    [aryStudents addObject:objStudent];
    
    
    
    dictTemp= [NSMutableDictionary new];
    [dictTemp setObject:@"2" forKey:@"id"];
    [dictTemp setObject:@"abc" forKey:@"name"];
    objStudent = [[AIStudent alloc] initWithData:dictTemp];
    [aryStudents addObject:objStudent];
    
    
    NSLog(@"%@",aryStudents);
    
    AIStudent *getStudent = [aryStudents objectAtIndex:2];
    NSLog(@"%@",getStudent.strImageUrl);
    
    
}
-(NSMutableArray *)createScreenArray
{
    NSMutableArray *aryTemp = [NSMutableArray new];
    
    NSMutableDictionary *dictTemp = [NSMutableDictionary new];
    [dictTemp setObject:@"" forKey:TextFieldTextKey];
    [dictTemp setObject:@"1" forKey:@"strCellType"];
    [aryTemp addObject:dictTemp];
    dictTemp = [NSMutableDictionary new];
    [dictTemp setObject:@"" forKey:TextFieldTextKey];
    [dictTemp setObject:@"1" forKey:@"strCellType"];
    [aryTemp addObject:dictTemp];
    
    dictTemp = [NSMutableDictionary new];
    [dictTemp setObject:@"" forKey:TextFieldTextKey];
    [dictTemp setObject:@"1" forKey:@"strCellType"];
    [aryTemp addObject:dictTemp];
    
    dictTemp = [NSMutableDictionary new];
    [dictTemp setObject:@"" forKey:TextFieldTextKey];
    NSArray *arySegment = [[NSArray alloc] initWithObjects:@"Students",@"Teachers", nil];
    [dictTemp setObject:arySegment forKey:SegmentArrayKey];
    [dictTemp setObject:@"2" forKey:CellTypeKey];
    [aryTemp addObject:dictTemp];
    

    
    return aryTemp;
}
#pragma mark - TableView Delegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return aryScreenData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSMutableDictionary *dictRecord = [aryScreenData objectAtIndex:indexPath.row];
    
    NSString *strCellTypeKey = [dictRecord valueForKey:@"strCellType"];
    if ( [strCellTypeKey isEqualToString:@"1"])
    {
        NSArray *aryNibs = [[NSBundle mainBundle] loadNibNamed:@"TextfieldCell" owner:self options:nil];
        TextfieldCell *cell = (TextfieldCell*)[aryNibs firstObject];
        
        
        cell.txtField.text = [NSString stringWithFormat:@"%@",[dictRecord valueForKey:@"textFieldText"]];
        return cell;
    }
    else if( [strCellTypeKey isEqualToString:@"2"])
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell == nil)
        {
            cell  = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
            
        }
        NSLog(@"%@",[dictRecord valueForKey:SegmentArrayKey]);
        
        cell.backgroundColor  = [UIColor redColor];
        return cell;
    }
    else if( [strCellTypeKey isEqualToString:@"3"])
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell == nil)
        {
            cell  = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
            
        }
        cell.backgroundColor  = [UIColor purpleColor];
        return cell;
    }
    else
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell == nil)
        {
            cell  = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
            
        }
        cell.backgroundColor  = [UIColor yellowColor];
        return cell;
    }
   

}


@end
