//
//  TextfieldCell.h
//  TableView
//
//  Created by agilemac-74 on 07/07/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextfieldCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UITextField *txtField;

@end
