//
//  TextfieldCell.m
//  TableView
//
//  Created by agilemac-74 on 07/07/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import "TextfieldCell.h"

@implementation TextfieldCell

@end
