//
//  AIStudent.h
//  TableView
//
//  Created by agilemac-74 on 07/07/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AIStudent : NSObject
@property(nonatomic,strong)NSString *studentId;
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *strImageUrl;

-(id)initWithData:(NSMutableDictionary *)dictStudent;



@end
