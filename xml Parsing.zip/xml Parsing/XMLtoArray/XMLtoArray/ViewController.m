//
//  ViewController.m
//  XMLtoArray
//
//  Created by BL@CK on 6/17/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "CustomCell.h"
@interface ViewController ()

@end

@implementation ViewController
{
    UITextField *txt1;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    txt1=[[UITextField alloc]initWithFrame:CGRectMake(10,50,100,40)];
    txt1.placeholder=@"number";
    txt1.delegate=self;
    txt1.tag=1;
    
	// Do any additional setup after loading the view, typically from a nib.
    [self starParsing];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-NSXMLParser Method
-(void)starParsing
{

    NSString *filePath=[[NSBundle mainBundle] pathForResource:@"simple" ofType:@"xml"];
    objParser=[[NSXMLParser alloc]initWithContentsOfURL:[NSURL fileURLWithPath:filePath]];
    [objParser setDelegate:self];
    //NSLog(@"%d",[objParser parse]);
    [objParser parse];
    
    
    if (!totalData)
    {
        totalData=[NSMutableArray new];
        
    }

   //objParser=[[NSXMLParser alloc]initWithContentsOfURL:[NSURL URLWithString:@"/Users/agilemac-83/Desktop/Chirag-Pro/XMLtoArray"]];
}
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    NSLog(@"parserDidStartDocument");
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
   NSLog(@"didStartElement");
    strTemp=elementName;
    if ([strTemp isEqualToString:FOOD])
    {
        if (!dictFood)
        {
        dictFood =[[NSMutableDictionary alloc] init];
        }
        return;

    }

}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([string rangeOfString:@"\n"].location == NSNotFound) {
        if ([strTemp isEqualToString:ITEM_PRICE]) {
            [dictFood setObject:string forKey:ITEM_PRICE];
        }else if ([strTemp isEqualToString:ITEM_NAME]){
            [dictFood setObject:string forKey:ITEM_NAME];
        }else if ([strTemp isEqualToString:ITEM_DESCRIPTION]){
            [dictFood setObject:string forKey:ITEM_DESCRIPTION];
        }else if ([strTemp isEqualToString:ITEM_CALORIES]){
            [dictFood setObject:string forKey:ITEM_CALORIES];
        }
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
    NSLog(@"didEndElement");
    
    if ([elementName isEqualToString:ITEM_NAME])
    {
        strTemp=elementName;
    }
    else if ([elementName isEqualToString:ITEM_PRICE])
    {
        strTemp=elementName;
    }
    else if ([elementName isEqualToString:ITEM_CALORIES])
    {
        strTemp=elementName;
    }
    else if ([elementName isEqualToString:ITEM_DESCRIPTION])
    {
        strTemp=elementName;
    }
    
    if ([elementName isEqualToString:FOOD])
    {
        if (!totalData)
        {
            totalData=[NSMutableArray new];
        }
        [totalData addObject:[dictFood copy]];
        [dictFood removeAllObjects];
    }


}



- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"parserDidEndDocument");

    NSLog(@"%@",totalData);
    [table reloadData];

}

#pragma mark-UITableView method


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return totalData.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    NSDictionary *currentItemDetails = [totalData objectAtIndex:indexPath.row];
    
    cell.lblName.text = [currentItemDetails objectForKey:ITEM_NAME];
    cell.lblPrice.text = [currentItemDetails objectForKey:ITEM_PRICE];
    cell.lblDescription.text = [currentItemDetails objectForKey:ITEM_DESCRIPTION];
    cell.lblCalories.text = [NSString stringWithFormat:@"Calories :: %@",  [currentItemDetails objectForKey:ITEM_CALORIES]];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
}




@end
