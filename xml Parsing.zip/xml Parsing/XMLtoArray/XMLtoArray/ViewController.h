//
//  ViewController.h
//  XMLtoArray
//
//  Created by BL@CK on 6/17/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#define ITEM_NAME @"name"
#define FOOD @"food"
#define ITEM_PRICE @"price"
#define ITEM_DESCRIPTION @"description"
#define ITEM_CALORIES @"calories"



@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    NSMutableDictionary *dictFood;
    NSString *strTemp;
    NSMutableArray *totalData;
    NSXMLParser *objParser;
    IBOutlet UITableView *table;
}
@end
