//
//  ViewController.m
//  CalCProject
//
//  Created by agile on 5/3/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn1:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@1",txtView.text];
}

- (IBAction)btn2:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@2",txtView.text];
}

- (IBAction)btn3:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@3",txtView.text];
}

- (IBAction)btn4:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@4",txtView.text];
}

- (IBAction)btn5:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@5",txtView.text];
}

- (IBAction)btn6:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@6",txtView.text];
}

- (IBAction)btn7:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@7",txtView.text];
}

- (IBAction)btn8:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@8",txtView.text];
}

- (IBAction)btn9:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@9",txtView.text];
}

- (IBAction)btn0:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@0",txtView.text];
}

- (IBAction)btnPlus:(id)sender
{
    operation = Plus;
    storage = txtView.text;
    txtView.text =@"";
}

- (IBAction)btnMinus:(id)sender
{
    operation = Minus;
    storage = txtView.text;
    txtView.text =@"";
    
}

- (IBAction)btnMultiply:(id)sender
{
    operation = Multiply;
    storage = txtView.text;
    txtView.text =@"";
}

- (IBAction)btndevide:(id)sender
{
    operation = Divide;
    storage = txtView.text;
    txtView.text =  @"";
}

- (IBAction)txtClear:(id)sender
{
    txtView.text =@"";
}

- (IBAction)btnDot:(id)sender
{
    txtView.text=[NSString stringWithFormat:@"%@",txtView.text];
}


- (IBAction)btnEqual:(id)sender
{
    NSString *Value = txtView.text;
    switch(operation)
    {
        case Plus:
            txtView.text= [NSString stringWithFormat:@"%qi",[Value longLongValue]+[storage longLongValue]];
            break;
        case Minus:
            txtView.text= [NSString stringWithFormat:@"%qi",[storage longLongValue]-[Value longLongValue]];
            break;
        case Multiply:
            txtView.text= [NSString stringWithFormat:@"%qi",[storage longLongValue]*[Value longLongValue]];
            break;
        case Divide:
            txtView.text= [NSString stringWithFormat:@"%qi",[Value longLongValue]/[storage longLongValue]];
            break;
   }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

@end
