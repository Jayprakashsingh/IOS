//
//  ViewController.h
//  CalCProject
//
//  Created by agile on 5/3/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{Plus,Minus,Multiply,Divide} CalcOperation;
@interface ViewController : UIViewController<UITextFieldDelegate>
{
    
     IBOutlet UITextField *txtView;
     IBOutlet UIButton *btnAC;
     NSString *storage;
   // NSString *Value;
    CalcOperation operation;
}
- (IBAction)btn1:(id)sender;
- (IBAction)btn2:(id)sender;
- (IBAction)btn3:(id)sender;
- (IBAction)btn4:(id)sender;
- (IBAction)btn5:(id)sender;
- (IBAction)btn6:(id)sender;
- (IBAction)btn7:(id)sender;
- (IBAction)btn8:(id)sender;
- (IBAction)btn9:(id)sender;
- (IBAction)btn0:(id)sender;
- (IBAction)btnEqual:(id)sender;
- (IBAction)btnPlus:(id)sender;
- (IBAction)btnMinus:(id)sender;
- (IBAction)btnMultiply:(id)sender;
- (IBAction)btndevide:(id)sender;
- (IBAction)txtClear:(id)sender;
- (IBAction)btnDot:(id)sender;


@end
