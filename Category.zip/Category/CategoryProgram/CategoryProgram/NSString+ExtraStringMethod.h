//
//  NSString+ExtraStringMethod.h
//  CategoryProgram
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ExtraStringMethod)
-(NSMutableDictionary *)showdicRecord:(NSString *)string;

@end
