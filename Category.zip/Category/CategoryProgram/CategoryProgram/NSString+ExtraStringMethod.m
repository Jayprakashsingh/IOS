//
//  NSString+ExtraStringMethod.m
//  CategoryProgram
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "NSString+ExtraStringMethod.h"

@implementation NSString (ExtraStringMethod)

-(NSMutableDictionary *)showdicRecord:(NSString *)string
{
    NSArray *arr=[string componentsSeparatedByString:@","];
    int sum=0;
    for (int i=0; i<arr.count; i++) {
        sum = sum + [[arr objectAtIndex:i] integerValue];
    }

    NSMutableDictionary *dic=[NSMutableDictionary new];
    [dic setObject:[NSNumber numberWithInt:sum] forKey:@"Addition"];
    
    return dic;

}




@end
