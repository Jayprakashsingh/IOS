//
//  ViewController.m
//  CategoryProgram
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "NSMutableArray+ExtraMethod.h"
#import "NSString+ExtraStringMethod.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //[self checkCategory];
    [self testNSStringMethod];
}
-(void)checkCategory
{
    NSMutableArray *ar=[NSMutableArray new];
  
    [ar addObject:@"FirstName=Chirag"];
    [NSMutableArray addDataInArray:ar ];
      NSLog(@"data %@",[NSMutableArray addDataInArray:ar]);
}
-(void)testNSStringMethod
{
    NSString *str=@"";
    NSLog(@"%@",[str showdicRecord:@"1,2,3,4,5,6,7"]);

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
