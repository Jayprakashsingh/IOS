//
//  NSMutableArray+ExtraMethod.m
//  CategoryProgram
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "NSMutableArray+ExtraMethod.h"

@implementation NSMutableArray (ExtraMethod)
+(NSMutableArray *)addDataInArray:(NSMutableArray *)aryObject
{
    NSMutableArray *arrData=[aryObject mutableCopy];
    [arrData addObject:@"ID=1"];
    [arrData addObject:@"Department=computer"];
    //NSLog(@"%@",arrData);
    return arrData;
}
@end
