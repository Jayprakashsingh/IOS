//
//  NSMutableArray+ExtraMethod.h
//  CategoryProgram
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (ExtraMethod)
+(NSMutableArray *)addDataInArray:(NSMutableArray *)aryObject;

@end
