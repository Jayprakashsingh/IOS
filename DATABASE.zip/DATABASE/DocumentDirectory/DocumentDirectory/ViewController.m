//
//  ViewController.m
//  DocumentDirectory
//
//  Created by BL@CK on 7/12/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-UIButton Method
-(void)btnCreateFolderInDocumentDirectory:(id)sender
{
    NSArray *filePath=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
   // NSLog(@"Path Of File %@",filePath.firstObject);

    NSString *DocumentDirectoryPath=[filePath firstObject];
    DocumentDirectoryPath=[DocumentDirectoryPath stringByAppendingString:@"/AppFolder2"];
    NSLog(@"SubFolder Path %@",DocumentDirectoryPath);
    
   
    
}
-(void)btnAddFileInDocumentDirectory:(id)sender
{
    NSArray *filePath=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    // NSLog(@"Path Of File %@",filePath.firstObject);
    
    NSString *DocumentDirectoryPath=[filePath firstObject];
    NSFileManager *objFileManager=[NSFileManager defaultManager];
    NSError *error;
    [objFileManager createDirectoryAtPath:DocumentDirectoryPath withIntermediateDirectories:NO attributes:nil error:&error];
    
    if (![objFileManager fileExistsAtPath:DocumentDirectoryPath])
    {
        NSData *imageData = UIImageJPEGRepresentation([UIImage imageNamed:@"11.jpeg"], 1.0);
        
        [imageData writeToFile:DocumentDirectoryPath atomically:YES];
    }
    
    DocumentDirectoryPath=[DocumentDirectoryPath stringByAppendingString:@"/11.jpeg"];
    NSLog(@"image Path %@",DocumentDirectoryPath);
}




@end
