//
//  AppDelegate.h
//  DATABASE OPERATION
//
//  Created by BL@CK on 7/11/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SKDatabase.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) SKDatabase *objDadaBase;

@end
