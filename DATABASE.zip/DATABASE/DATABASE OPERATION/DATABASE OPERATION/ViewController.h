//
//  ViewController.h
//  DATABASE OPERATION
//
//  Created by BL@CK on 7/11/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SKDatabase.h"

@interface ViewController : UIViewController
-(IBAction)performSQL:(NSString *)sql;
@property (strong, nonatomic) SKDatabase *objDadaBase;

@end
