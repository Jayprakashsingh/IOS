//
//  ViewController.m
//  DATABASE OPERATION
//
//  Created by BL@CK on 7/11/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)performSQL:(NSString *)sql
{
   self.objDadaBase=[[SKDatabase alloc] initWithFile:@"RegisterData.sqlite"];
     NSLog(@"%@",[self.objDadaBase lookupAllForSQL:@"DELETE FROM RegisterData [WHERE FirstName=Chirag]"]);
    NSMutableArray *array=[NSMutableArray new];
    [array addObject:[self.objDadaBase lookupAllForSQL:@"select * from RegisterData"]];
    //[array addObject:[self.objDadaBase lookupAllForSQL:@"select FirstName from RegisterData"]];
   // [array addObject:[self.objDadaBase lookupAllForSQL:@"UPDATE RegisterData SET Id = 3,FirstName = Raj,[WHERE FirstName=Chirag]"]];
    
   // [array addObject:[self.objDadaBase lookupAllForSQL:@"DELETE FROM RegisterData [WHERE FirstName=Chirag]"]];
    NSLog(@"%@",array);

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
