//
//  ViewController.m
//  MapLocationFirst
//
//  Created by BL@CK on 6/24/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self getLocation];
}
#pragma marks-Location Delegate
-(void)getLocation
{
    locationManager=[[CLLocationManager alloc] init];
    if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusNotDetermined) {
        
       UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Error" message:@"Check Location Setting" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [self.view addSubview:alert];
    }
    else if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusRestricted) {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Get Location" message:@"User permission is must" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [self.view addSubview:alert];

    }
    else if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied) {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Get Location" message:@"Please check your setting" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [self.view addSubview:alert];

    }
    else if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusAuthorized) {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Get Location" message:@"We use your Data" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [self.view addSubview:alert];
    }
    locationManager.delegate=self;
    locationManager.desiredAccuracy=kCLLocationAccuracyBest;
    locationManager.distanceFilter=100;
    [locationManager startUpdatingLocation];
   /*desiredAccuracy type
    (kCLLocationAccuracyBest;
    kCLLocationAccuracyNearestTenMeters;
    kCLLocationAccuracyHundredMeters;
    kCLLocationAccuracyKilometer;
    kCLLocationAccuracyThreeKilometers;)
*/
    MKPointAnnotation *annimation=[[MKPointAnnotation alloc] init];
    annimation.coordinate=CLLocationCoordinate2DMake(23.0542, 72.5523);
    annimation.title=@"Hi";
    annimation.subtitle=@"Bye";
    [mapView addAnnotation:annimation];
    
    MKCoordinateSpan span = MKCoordinateSpanMake(10.0f,5.0001f);
    CLLocationCoordinate2D coordinate = {23.0542, 72.5523};
    MKCoordinateRegion region = {coordinate, span};
    MKCoordinateRegion newRegion =[mapView regionThatFits:region];
    [mapView setRegion:newRegion animated:YES];

}
#pragma mark - CLLocationManagerDelegate




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
