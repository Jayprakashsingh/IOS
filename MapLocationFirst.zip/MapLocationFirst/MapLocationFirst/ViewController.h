//
//  ViewController.h
//  MapLocationFirst
//
//  Created by BL@CK on 6/24/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<CLLocationManagerDelegate,MKMapViewDelegate,UIAlertViewDelegate>
{
    CLLocationManager *locationManager;
    IBOutlet MKMapView *mapView;

}
@end
