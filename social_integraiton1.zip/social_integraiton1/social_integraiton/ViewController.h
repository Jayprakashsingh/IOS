//
//  ViewController.h
//  social_integraiton
//
//  Created by agilemac-74 on 29/06/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import "secondViewController.h"

@interface ViewController : UIViewController
{
    IBOutlet UITextField *txtfield;
    IBOutlet UIDatePicker *datepicker;
}

@end

