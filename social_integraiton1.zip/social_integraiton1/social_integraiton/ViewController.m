//
//  ViewController.m
//  social_integraiton
//
//  Created by agilemac-74 on 29/06/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    secondViewController *secObj = [[secondViewController alloc] init];
    
    
    secObj.string =@"";
    NSString *string = secObj.string;
    
    [secObj setString:@""];
    NSString *str = [secObj string];
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}


-(IBAction)setButtonAction:(id)sender
{
    NSDate *date = [datepicker date];
    
    
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    
    notification.fireDate = date;
    
    notification.alertTitle = @"test";
    notification.alertBody = txtfield.text;
    
    
    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
    
    
    
    
}


-(IBAction)shareToFacebook:(id)sender
{
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        
        SLComposeViewController *fbComposeViewcontroller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        
        [fbComposeViewcontroller setInitialText:@"test"];
        [fbComposeViewcontroller addImage:[UIImage imageNamed:@""]];
        [fbComposeViewcontroller addURL:[NSURL URLWithString:@""]];
        
        [self presentViewController:fbComposeViewcontroller animated:YES completion:nil];

    }
    
    
}

-(IBAction)shareToTwitter:(id)sender
{
    SLComposeViewController *twitterComposeviewcontroller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    
    [twitterComposeviewcontroller setInitialText:@""];
    [twitterComposeviewcontroller addURL:[NSURL URLWithString:@""]];
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
