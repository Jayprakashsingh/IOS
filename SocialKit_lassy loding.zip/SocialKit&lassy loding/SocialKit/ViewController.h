//
//  ViewController.h
//  SocialKit
//
//  Created by agilemac-74 on 05/08/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import "UIImageView+WebCache.h"

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

{
    IBOutlet UIImageView *imageProfile;
    
    NSMutableArray *aryData;
    IBOutlet UITableView *objTableView;
    UIActivityIndicatorView *loader;
    UIRefreshControl *objRefresh;
}
@end

