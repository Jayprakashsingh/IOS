//
//  ViewController.m
//  SocialKit
//
//  Created by agilemac-74 on 05/08/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    aryData = [[NSMutableArray alloc] init];
    [self createArray:0];
    objTableView.delegate = self;
    objTableView.dataSource = self;
    
    
    objRefresh = [[UIRefreshControl alloc] init];
    [objRefresh addTarget:self action:@selector(refreshContent) forControlEvents:UIControlEventValueChanged];
    objRefresh.attributedTitle = [[NSAttributedString alloc] initWithString:@"Pull to refresh"];
    [objTableView addSubview:objRefresh];
    
    
    
//    [imageProfile sd_setImageWithURL:[NSURL URLWithString:@"http://media2.intoday.in/indiatoday/images/stories/rustom-story+fb_062816115528.jpg"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL)
//     {
//        [imageProfile setImage:image];
//    }];
    [imageProfile sd_setImageWithURL:[NSURL URLWithString:@"https://media2.intoday.in/indiatoday/images/stories/rustom-story+fb_062816115528.jpg"] placeholderImage:[UIImage imageNamed:@"download"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (error == nil)
        {
            [imageProfile setImage:image];
        }
    }];
}
-(void)refreshContent
{
    [objRefresh endRefreshing];
    [aryData removeAllObjects];
    [objTableView reloadData];
    
}
-(void)createArray:(int )count
{
    count = (int)aryData.count;
    
    for ( int i=count; i<count+20; i++)
    {
        [aryData addObject:[NSString stringWithFormat:@"data :: %d ",i]];
        
    }
    [loader stopAnimating];
    [objTableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - TableView Methods
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  aryData.count+1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    
    if (indexPath.row == aryData.count)
    {
        loader = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        [loader startAnimating];
        loader.center = cell.contentView.center;
        [cell.contentView addSubview:loader];
        [self performSelector:@selector(createArray:) withObject:nil afterDelay:5.0];
        
    }
    else
    {
        cell.textLabel.text = [aryData objectAtIndex:indexPath.row];
    }
    
    return  cell;
}
#pragma  mark - Button 
-(IBAction)OpenFacebook:(UIButton *)sender

{
    
    SLComposeViewController *objSocial  = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    [objSocial setInitialText:@"testing"];
    
    [objSocial addImage:[UIImage imageNamed:@"download"]];
    
    [self presentViewController:objSocial animated:YES completion:nil];
    [objSocial setCompletionHandler:^(SLComposeViewControllerResult result){
        NSLog(@"%d",result);
    }];
    
    
    
    
}
@end
