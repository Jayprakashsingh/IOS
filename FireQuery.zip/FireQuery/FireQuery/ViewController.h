//
//  ViewController.h
//  FireQuery
//
//  Created by BL@CK on 8/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabase.h"
@interface ViewController : UIViewController


@property(nonatomic,strong)FMDatabase *objFMDB;

@end
