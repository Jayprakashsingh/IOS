//
//  ViewController.m
//  FireQuery
//
//  Created by BL@CK on 8/8/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import <sqlite3.h>

@interface ViewController ()
{
    NSString *fullPath;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
//    filepath=[[NSBundle mainBundle]pathForResource:@"DataBaseFireDB" ofType:@"sqlite"];
//    NSLog(@"%@",filepath);
    [self checkDataBaseFile];
    [self applyQuery];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)checkDataBaseFile
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    fullPath = [NSHomeDirectory() stringByAppendingPathComponent:@"/Documents/DataBaseFireDB.sqlite"];
    NSLog(@"fullPath :: %@",fullPath);
    
    if (![fileManager fileExistsAtPath:fullPath])
    {
        NSString* strBundlePath =[[NSBundle mainBundle]pathForResource:@"DataBaseFireDB" ofType:@"sqlite"];
        NSError *error;
        [fileManager copyItemAtPath:strBundlePath toPath:fullPath error:&error];
    }
}
-(void)applyQuery
{
    // Insert Query
    
    self.objFMDB=[[FMDatabase alloc] initWithPath:fullPath];
    [self.objFMDB open];
    [self.objFMDB executeUpdate:@"Insert into EmployeeData (name,salary) values ('Bharat','55000')"];
    
    //select Query
    FMResultSet *set = [self.objFMDB executeQuery:@"select * from EmployeeData"];
      NSLog(@"%@",set);
    
    //one by one get data from database
    while ([set next])
    {
        NSLog(@"%@",set.columnNameToIndexMap);
        NSLog(@"%@",set.resultDictionary);
    }
    
    //Delete Query
    
  //  [self.objFMDB executeQuery:@"delete from EmployeeData where name=parikshit"];

    [self.objFMDB close];

}

@end
