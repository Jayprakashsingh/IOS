//
//  ViewController.m
//  NsDate
//
//  Created by BL@CK on 7/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
   // [self getDate];
   // [self setDate];
    [self setDateIn];
}
-(void)getDate
{
    NSDate *date=[NSDate date];
    NSLog(@"Today is %@",date);
}
-(void)setDate
{
    NSDate *date=[NSDate date];
    NSDateFormatter *dateFormater=[[NSDateFormatter alloc] init];
    [dateFormater setDateStyle:NSDateFormatterFullStyle];

    [dateFormater setDateFormat:@"dd MMM yyyy HH:mm:ss a"];
    NSString *strDate=[dateFormater stringFromDate:date];
    NSLog(@"According stringFromDate formate%@",strDate);
    
    NSDate *myDate=[dateFormater dateFromString:strDate];
    NSLog(@"mydate dateFromString is%@",myDate);
    // NSDate *dateConvert = [dateFormater dateFromString:strDate];
  
    
    
    NSCalendar *calander = [NSCalendar currentCalendar];
    NSDateComponents *dateComponent = [calander components: NSYearCalendarUnit|
                                       NSMonthCalendarUnit|
                                       NSDayCalendarUnit
                                                  fromDate:date];
    [dateComponent setDay:10];
    [dateComponent setMonth:01];
    
    NSLog(@"%@",[calander dateFromComponents:dateComponent]);
}
-(void)setDateIn
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *component = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:[NSDate new]];
    [component setDay:25];
    [component setHour:07];
    [component setMinute:00];
    [component setSecond:59];
    
    NSDate *newDate = [calendar dateFromComponents:component];
    
    NSDateFormatter *dateFormater = [[NSDateFormatter alloc] init];
    [dateFormater setDateFormat:@"yyyy-MM-dd HH:mm:ss z"];
    NSLog(@"String %@",[dateFormater stringFromDate:newDate]);
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
