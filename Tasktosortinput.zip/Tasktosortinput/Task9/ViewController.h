//
//  ViewController.h
//  Task9
//
//  Created by BL@CK on 4/22/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSMutableArray *arrayDemo;
}
@end
