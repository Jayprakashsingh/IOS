//
//  ViewController.m
//  Task9
//
//  Created by BL@CK on 4/22/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
   NSMutableArray *arraydemo;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self checkArray];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)checkArray
{
   arrayDemo = [[NSMutableArray alloc]initWithObjects:@"Test",[NSNumber numberWithInt:10],[NSNumber numberWithInt:20],@"Practice",@"button",[NSNumber numberWithInt:5],[NSNumber numberWithInt:2],[NSNumber numberWithInt:3], nil];
    NSMutableArray *str = [[NSMutableArray alloc]init];
    NSMutableArray *strText = [[NSMutableArray alloc]init];
    NSMutableArray *finalarray = [[NSMutableArray alloc]init];
    NSMutableArray *finalText = [[NSMutableArray alloc]init];

    for(NSNumber  *arrtext in arrayDemo)
    {
        if ([arrtext isKindOfClass:[NSString class]])
                    {
                      //  NSLog(@"%@",arrtext);
                        [strText addObject:arrtext];
                        finalText = strText.copy;
                    }
    }
    
    for(NSNumber  *arr in arrayDemo)
    {
        if ([arr isKindOfClass:[NSNumber class]])
        {
            [str addObject:arr];
            finalarray = str.copy;
            // NSLog(@"%@",finalarray);
        }
    }
    //ascending Number
    NSSortDescriptor *sortnumber = [[NSSortDescriptor alloc] initWithKey:@"self" ascending:YES];
   NSMutableArray *asc = [NSMutableArray arrayWithObject:sortnumber];
   NSMutableArray *noOrder = (NSMutableArray*)[finalarray sortedArrayUsingDescriptors:asc];
   NSMutableArray *inOrder = [[NSMutableArray alloc]initWithArray:noOrder];
   // NSLog(@"Data with asc%@",inOrder);
    
    
    //descending number
    NSSortDescriptor *revsordno = [[NSSortDescriptor alloc]initWithKey:@"self" ascending:NO];
    NSMutableArray *dsc = [NSMutableArray arrayWithObject:revsordno];
    NSMutableArray *preOrder = (NSMutableArray *)[finalarray sortedArrayUsingDescriptors:dsc];
    NSMutableArray *pre = [[NSMutableArray alloc]initWithArray:preOrder];
   
   // NSLog(@"%@",finalText);
  //  NSLog(@"Data with dsc%@",preOrder);
    NSMutableArray *dic1 = [[NSMutableArray alloc]initWithObjects:finalText,inOrder, nil];
    NSMutableArray *dic2 = [[NSMutableArray alloc]initWithObjects:finalText,pre, nil];
    

    NSLog(@"Data1%@",dic1);
    NSLog(@"Data2%@",dic2);

}
-(void)checkNumber
{
    

    
//    NSArray *sortedArray = [str sortedArrayUsingComparator:
//                            ^NSComparisonResult(id obj1, id obj2){
//                                //descending order
//                                return [obj2 compare:obj1];
//                                //ascending order
//                                // return [obj1 compare:obj2];
//                            }];
//    NSLog(@"%@", sortedArray);
//    
    
    
//
//        NSArray *sortedArray = [no sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
//            if ([[obj1 valueForKey:@"sId"] integerValue] > [[obj2 valueForKey:@"sId"] integerValue]) {
//                return (NSComparisonResult)NSOrderedDescending;
//            }
//            if ([[obj1 valueForKey:@"sId"] integerValue] < [[obj2 valueForKey:@"sId"] integerValue]) {
//                return (NSComparisonResult)NSOrderedAscending;
//            }
//            return (NSComparisonResult)NSOrderedSame;
//        }];
//        NSLog(@"Sorted Service Array is ::%@",sortedArray);
//        NSSortDescriptor* sortOrder = [NSSortDescriptor sortDescriptorWithKey: @"self" ascending: NO];
//        return [demo sortedArrayUsingDescriptors: [NSArray arrayWithObject: sortOrder]];
//    
//    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];
//    NSArray *sortedArray = [str sortedArrayUsingDescriptors:@[sortDescriptor]];
//    //[demo sortUsingDescriptors:sortDescriptors];
//    NSLog(@"%@",sortedArray);
    
}

//[[NSMutableData data] isKindOfClass:[NSData class]]; // YES
//[[NSMutableData data] isMemberOfClass:[NSData class]]; // NO

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
