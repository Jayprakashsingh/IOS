//
//  UIColor+category.h
//  COLLABMIX
//
//  Created by Rajni on 20/10/16.
//  Copyright (c) 2016 Rajni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (category)

+(UIColor*)changecolor;
@end
