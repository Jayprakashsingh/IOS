//
//  SignInWithViewController.h
//  COLLABMIX
//
//  Created by Rajni on 19/10/16.
//  Copyright (c) 2016 Rajni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignInWithViewController : UIViewController<UIScrollViewDelegate>


{
    
    
    IBOutlet UIButton *btnCheckBox;
    
    IBOutlet UIButton *SignInbtn;
    IBOutlet UIButton *btnFaceBook;
    IBOutlet UIButton *btnInstagram;
     IBOutlet UIButton *HomeBtn;
}

typedef enum ScrollDirection {
    ScrollDirectionNone,
    ScrollDirectionRight,
    ScrollDirectionLeft,
    ScrollDirectionUp,
    ScrollDirectionDown,
    ScrollDirectionCrazy,
} ScrollDirection;


- (IBAction)CheckBox:(UIButton *)sender;
- (IBAction)btnFaceBook:(UIButton *)sender;
- (IBAction)btnInstagram:(UIButton *)sender;
- (IBAction)btnSignIn:(UIButton *)sender;
- (IBAction)btnForgotPassWord:(UIButton *)sender;
- (IBAction)btnCreateAccount:(UIButton *)sender;
- (IBAction)btnHomeScreen:(UIButton *)sender;
@property(strong,nonatomic)IBOutlet UIScrollView *objScrollView;
@property(strong,nonatomic)    IBOutlet UIView *ContentView;
@property (nonatomic) CGFloat lastContentOffset;

@end
