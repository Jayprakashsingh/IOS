//
//  AppDelegate.h
//  COLLABMIX
//
//  Created by Rajni on 18/10/16.
//  Copyright (c) 2016 Rajni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

