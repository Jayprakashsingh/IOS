//
//  UIColor+category.m
//  COLLABMIX
//
//  Created by Rajni on 20/10/16.
//  Copyright (c) 2016 Rajni. All rights reserved.
//

#import "UIColor+category.h"

@implementation UIColor (category)

+(UIColor *)changecolor
{

    return [UIColor yellowColor];
}

@end
