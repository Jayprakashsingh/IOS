//
//  ViewController.m
//  COLLABMIX
//
//  Created by Rajni on 18/10/16.
//  Copyright (c) 2016 Rajni. All rights reserved.
//

#import "ViewController.h"
#import "SignInWithViewController.h"
#import "UIColor+category.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    ObjImageView.image= [UIImage imageNamed:@"spash.jpg"];
    _signInBtn.backgroundColor =[UIColor changecolor];
    _CreateRegisterbtn.backgroundColor=[UIColor changecolor];
   
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)SignIn:(UIButton *)sender
{
  
    SignInWithViewController *SignInWithViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SignInWithViewController"];
    [[self navigationController] pushViewController:SignInWithViewController animated:YES];
}

- (IBAction)CreateRegister:(UIButton *)sender {
}
@end
