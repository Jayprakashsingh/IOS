//
//  SignInWithViewController.m
//  COLLABMIX
//
//  Created by Rajni on 19/10/16.
//  Copyright (c) 2016 Rajni. All rights reserved.
//

#import "SignInWithViewController.h"
#import "UIColor+category.h"
@interface SignInWithViewController ()


@property BOOL checkboxSelected;

@end

@implementation SignInWithViewController
@synthesize objScrollView,ContentView;


- (void)viewDidLoad {
    [super viewDidLoad];
    [objScrollView setContentSize:CGSizeMake(500, 1000)];
    [objScrollView setScrollEnabled:TRUE];
    [objScrollView setShowsVerticalScrollIndicator:NO];
    [objScrollView setShowsHorizontalScrollIndicator:YES];
    [self.objScrollView setContentOffset:CGPointMake(self.objScrollView.contentOffset.x, 0) animated:YES];
    
    UIImage *objfacebookimg=[UIImage imageNamed:@"facebook.png"];
    [btnFaceBook setImage:objfacebookimg forState:UIControlStateNormal];
    UIImage *objistagramimg=[UIImage imageNamed:@"instagram.png"];
    [btnInstagram setImage:objistagramimg forState:UIControlStateNormal];
    
    SignInbtn.backgroundColor=[UIColor changecolor];
    HomeBtn.backgroundColor=[UIColor changecolor];
    
    // Do any additional setup after loading the view.
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    ScrollDirection scrollDirection;
    if (self.lastContentOffset > scrollView.contentOffset.x)
        scrollDirection = ScrollDirectionUp;
    else if (self.lastContentOffset < scrollView.contentOffset.x)
        scrollDirection = ScrollDirectionDown;
    
    self.lastContentOffset = scrollView.contentOffset.x;
    
    // do whatever you need to with scrollDirection here.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)CheckBox:(UIButton *)sender
{
    _checkboxSelected = !_checkboxSelected;
    UIButton* check = (UIButton*) sender;
    if (_checkboxSelected == NO)
        [check setImage:[UIImage imageNamed:@"checkbox1.png"] forState:UIControlStateNormal];
    else
        [check setImage:[UIImage imageNamed:@"checkright.png"] forState:UIControlStateNormal];

}

- (IBAction)btnFaceBook:(UIButton *)sender
{
    
}

- (IBAction)btnInstagram:(UIButton *)sender {
}

- (IBAction)btnSignIn:(UIButton *)sender {
}

- (IBAction)btnForgotPassWord:(UIButton *)sender {
}

- (IBAction)btnCreateAccount:(UIButton *)sender {
}

- (IBAction)btnHomeScreen:(UIButton *)sender {
}
@end
