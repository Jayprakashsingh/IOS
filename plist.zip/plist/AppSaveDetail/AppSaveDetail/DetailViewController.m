//
//  DetailViewController.m
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "DetailViewController.h"
#import "ViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize arrayOld,selectedRow;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    

   // arrayOld=[[[NSUserDefaults standardUserDefaults] valueForKey:@"data"] mutableCopy];
    if (selectedRow !=nil) {
        self.txtName.text=[[arrayOld objectAtIndex:selectedRow]valueForKey:@"Name"];
        self.txtAge.text=[[arrayOld objectAtIndex:selectedRow]valueForKey:@"Age"];
        self.txtEducation.text=[[arrayOld objectAtIndex:selectedRow]valueForKey:@"Education"];
        
        
        NSMutableDictionary *copyData=[NSMutableDictionary new];
        copyData=[[arrayOld objectAtIndex:selectedRow] mutableCopy];
        // NSLog(@"%@",copyData);
        NSString *a=self.txtName.text;
        NSString *b=self.txtEducation.text;
        NSString *c=self.txtAge.text;
        [copyData setObject:a forKey:@"Name"];
        [copyData setObject:b forKey:@"Education"];
        [copyData setObject:c forKey:@"Age"];
        NSDictionary *dic=[NSDictionary new];
        dic = copyData;
        [arrayOld replaceObjectAtIndex:selectedRow withObject:dic];
        NSLog(@"%@",arrayOld);
          }
    
    
}
-(void)writeDataInPlist
{

    NSString *filePath=[[NSBundle mainBundle] pathForResource:@"Detail" ofType:@"plist"];
    NSMutableArray *receiveData=[NSMutableArray arrayWithContentsOfFile:filePath];
    [receiveData addObject:arrayOld];
    [receiveData writeToFile:filePath atomically:YES];
    NSLog(@"New Array%@",receiveData);
}
- (CGRect)textRectForBounds:(CGRect)bounds {
    
    return CGRectInset(bounds, 8,4);
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-UIButton Action
-(void)btnCancel:(id)sender
{

    ViewController *objView=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self.navigationController pushViewController:objView animated:YES];
}

-(void)btnSave:(id)sender
{
    NSMutableDictionary *dicSave=[NSMutableDictionary new];
    [dicSave setObject:self.txtName.text forKey:@"Name"];
    [dicSave setObject:self.txtEducation.text forKey:@"Education"];
    [dicSave setObject:self.txtAge.text forKey:@"Age"];
    
    [arrayOld addObject:dicSave];
    [[NSUserDefaults standardUserDefaults]setObject:arrayOld forKey:@"data"];
    [[NSUserDefaults standardUserDefaults]synchronize];
   

    ViewController *objView=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self writeDataInPlist];
    [self.navigationController pushViewController:objView animated:YES];
}

@end
