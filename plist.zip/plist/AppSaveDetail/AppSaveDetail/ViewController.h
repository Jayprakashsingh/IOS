//
//  ViewController.h
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{

    IBOutlet UITableView *objTableView;
    IBOutlet UIButton *btnAdd;
    NSMutableArray *array,*updatearray;

}
-(IBAction)btnAddMehod:(id)sender;


@end
