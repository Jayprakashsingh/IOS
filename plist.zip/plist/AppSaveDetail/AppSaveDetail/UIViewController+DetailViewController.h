//
//  UIViewController+DetailViewController.h
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (DetailViewController)

@end
