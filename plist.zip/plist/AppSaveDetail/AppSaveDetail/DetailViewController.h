//
//  DetailViewController.h
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
{

}
@property(nonatomic,strong)IBOutlet UITextField *txtName;
@property(nonatomic,strong)IBOutlet UITextField *txtEducation;
@property(nonatomic,strong)IBOutlet UITextField *txtAge;
@property(nonatomic,strong)NSMutableArray *arrayOld;
@property(nonatomic)int selectedRow;
-(IBAction)btnSave:(id)sender;
-(IBAction)btnCancel:(id)sender;
@end
