//
//  ViewController.m
//  AppSaveDetail
//
//  Created by BL@CK on 7/7/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [[self navigationController] setNavigationBarHidden:YES animated:YES];

    array=[NSMutableArray new];
    array=[[[NSUserDefaults standardUserDefaults]valueForKey:@"data"]mutableCopy];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma marks-UITableView Data Source Method
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return array.count;

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

     UITableViewCell *cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"data"];
    NSString *a=[[array objectAtIndex:indexPath.row] valueForKey:@"Name"];
    NSString *b=[[array objectAtIndex:indexPath.row] valueForKey:@"Age"];
    NSString *c=[[array objectAtIndex:indexPath.row] valueForKey:@"Education"];
    [cell.textLabel setText:[NSString stringWithFormat:@"%@ %@",a,b]];
    [cell.detailTextLabel setText:c];
    if (array != nil) {
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%d",indexPath.row);
    DetailViewController *objDetail=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    objDetail.arrayOld=array;
    objDetail.selectedRow=indexPath.row;
    [self.navigationController pushViewController:objDetail animated:YES];

}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [array removeObjectAtIndex:indexPath.row];
    updatearray=[array mutableCopy];
    editingStyle=UITableViewCellEditingStyleInsert;
    [objTableView reloadData];

}
#pragma marks -UIButton Action
-(IBAction)btnAddMehod:(id)sender
{
    DetailViewController *objDetail=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    objDetail.arrayOld=updatearray;
    [self.navigationController pushViewController:objDetail animated:YES];


}








@end
