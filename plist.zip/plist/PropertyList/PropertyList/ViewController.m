//
//  ViewController.m
//  PropertyList
//
//  Created by BL@CK on 7/4/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "NSString+removeNumber.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self checkRemoveNumber];
    [self readFromRegistrationData];
    [self writeInRegistrationData];
    
}
-(void)checkRemoveNumber
{
    NSString *stringWithNums = @"ABC 123";
    NSLog(@" First stringWithNums %@",stringWithNums);
    stringWithNums = [stringWithNums removeNumbersFromString:stringWithNums];
    NSLog(@"trimmed stringWithNums%@",stringWithNums);

}
-(void)readFromRegistrationData
{
    NSString *filePath=[[NSBundle mainBundle] pathForResource:@"RegistrationData" ofType:@"plist"];
    NSArray *receiveData=[NSArray arrayWithContentsOfFile:filePath];
    NSLog(@"First Array %@ \n\n\n\n",receiveData);

}
-(void)writeInRegistrationData
{
    NSMutableDictionary *dicEducation=[NSMutableDictionary new];
    [dicEducation setObject:@"SSC" forKey:@"10TH"];
    [dicEducation setObject:@"HSC" forKey:@"12TH"];
    [dicEducation setObject:@"BE IN IT" forKey:@"Graduation"];
    
    NSString *filePath=[[NSBundle mainBundle] pathForResource:@"RegistrationData" ofType:@"plist"];
    NSMutableArray *receiveData=[NSMutableArray arrayWithContentsOfFile:filePath];
    [receiveData addObject:dicEducation];
    [receiveData writeToFile:filePath atomically:YES];
    NSLog(@"New Array%@",receiveData);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
