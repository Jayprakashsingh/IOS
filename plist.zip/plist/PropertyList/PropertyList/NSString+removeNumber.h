//
//  NSString+removeNumber.h
//  PropertyList
//
//  Created by BL@CK on 7/5/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (removeNumber)
- (NSString *)removeNumbersFromString:(NSString *)string;
@end
