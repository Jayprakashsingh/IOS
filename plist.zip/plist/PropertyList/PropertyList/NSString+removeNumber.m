//
//  NSString+removeNumber.m
//  PropertyList
//
//  Created by BL@CK on 7/5/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "NSString+removeNumber.h"

@implementation NSString (removeNumber)
- (NSString *)removeNumbersFromString:(NSString *)string
{
    NSString *trimmedString = nil;
    NSCharacterSet *numbersSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    trimmedString = [string stringByTrimmingCharactersInSet:numbersSet];
    return trimmedString;
}
@end
