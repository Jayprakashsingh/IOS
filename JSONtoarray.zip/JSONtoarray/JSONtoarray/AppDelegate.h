//
//  AppDelegate.h
//  JSONtoarray
//
//  Created by BL@CK on 6/20/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
