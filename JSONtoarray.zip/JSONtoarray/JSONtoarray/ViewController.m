//
//  ViewController.m
//  JSONtoarray
//
//  Created by BL@CK on 6/20/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSString *filePath=[[NSBundle mainBundle] pathForResource:@"response" ofType:@"json"];
    NSData *objDdata=[[NSData alloc] initWithContentsOfFile:filePath];
    NSError *error;

    NSMutableDictionary *recordDic=[NSJSONSerialization JSONObjectWithData:objDdata options:NSJSONReadingMutableContainers error:&error];
    NSMutableArray *array=[[recordDic valueForKey:@"data"] mutableCopy];
    NSLog(@"%@",array);
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
