//
//  ViewController.h
//  Demo
//
//  Created by agilemac-74 on 22/06/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
{
    NSMutableArray *aryTableData,*aryAllData;
    IBOutlet UITableView *tblData;
    IBOutlet UISearchBar *searchBar;
    
}


@end

