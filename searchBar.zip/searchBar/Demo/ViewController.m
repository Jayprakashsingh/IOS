//
//  ViewController.m
//  Demo
//
//  Created by agilemac-74 on 22/06/16.
//  Copyright © 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    aryAllData = [NSMutableArray new];
    [aryAllData addObject:@"A"];
    [aryAllData addObject:@"Urvish"];
    [aryAllData addObject:@"Ajay"];
    [aryAllData addObject:@"Mitesh"];
    [aryAllData addObject:@"Rakesh"];
    
    
    [aryAllData addObject:@"Rakesh"];
    [aryAllData addObject:@"Rakesh"];
    [aryAllData addObject:@"Rakesh"];
    [aryAllData addObject:@"Rakesh"];
    [aryAllData addObject:@"Rakesh"];
    
    aryTableData = [aryAllData mutableCopy];
 
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TableView Datasource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return aryTableData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tblData dequeueReusableCellWithIdentifier:@"cell"];
    if ( cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        
    }
    
    cell.textLabel.text = [aryTableData objectAtIndex:indexPath.row];
    return  cell;
    
}


#pragma mark - SearchBar Delegate
//-(BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
//{
//    
//    return  false;
//}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSLog(@"%@",searchText);
    searchText = [searchText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (searchText.length > 0)
    {
        NSPredicate *predict = [NSPredicate predicateWithFormat:@"self contains[cd] %@",searchText];
        NSArray *arySearchData = [aryAllData filteredArrayUsingPredicate:predict];
        aryTableData = [arySearchData mutableCopy];
        [tblData reloadData];
    }
    else
    {
        aryTableData = [aryAllData mutableCopy];
        [tblData reloadData];
    }
}

@end

