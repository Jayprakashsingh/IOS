//
//  NewRegisterViewController.m
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "NewRegisterViewController.h"
#import "CellFormTableViewCell.h"
#import "TeacherHomeViewController.h"
@interface NewRegisterViewController ()
{
    NSMutableArray *enterRecord;
    NSMutableDictionary *enterData;
}

@end

@implementation NewRegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    enterRecord =[[NSMutableArray alloc]init];
    enterData =[[NSMutableDictionary alloc]init];
    str = @"";
    // Do any additional setup after loading the view from its nib.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 11;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;              // Default is 1 if not implemented
{

    return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
     UITableViewCell *cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:@"data"];
    UITextField *txtData  = [[UITextField alloc]initWithFrame:CGRectMake(150, 10, 170, 30)];
    txtData.backgroundColor=[UIColor greenColor];
    txtData.borderStyle=UITextBorderStyleRoundedRect;
    txtData.placeholder=@"Enter Data";
    txtData.tag=indexPath.row;
    txtData.delegate=self;
    
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(10, 10, 120, 30)];
    lbl.backgroundColor=[UIColor yellowColor];
    
    
    UIButton *btn4=[[UIButton alloc]initWithFrame:CGRectMake(150, 100, 20, 20)];
    UIButton *btn5=[[UIButton alloc]initWithFrame:CGRectMake(200, 100, 20, 20)];
    btn4.backgroundColor=[UIColor redColor];
    btn5.backgroundColor=[UIColor redColor];
    
    [btn4 addTarget:self action:@selector(studentClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btn5 addTarget:self action:@selector(teacherClicked:) forControlEvents:UIControlEventTouchUpInside];
    
   // btn4.tag = indexPath.row;
   // [cell.contentView addSubview:btn4];
    
    if (indexPath.section==0 && indexPath.row == 0)
    {
        [lbl setText:@"First Name"];
        txtData.text=str;
        txtData.text = [enterData valueForKey:@"firstName"];
    }
    else if (indexPath.section==0 && indexPath.row==1)
    {
        [lbl setText:@"Last Name"];
        txtData.text = [enterData valueForKey:@"lastName"];
    }
    else if (indexPath.section==0 && indexPath.row==2)
    {
        [lbl setText:@"Email-Id"];
        txtData.text = [enterData valueForKey:@"emailId"];
    }
    else if (indexPath.section==0 && indexPath.row==3)
    {
        [lbl setText:@"Password"];
        txtData.text = [enterData valueForKey:@"password"];
    }
    else if (indexPath.section==0 && indexPath.row==4)
    {
        [lbl setText:@"Confirm PWD"];
        txtData.text = [enterData valueForKey:@"conPassword"];
    }
    else if (indexPath.section==0 && indexPath.row==5)
    {
        [lbl setText:@"Department"];
        txtData.text = [enterData valueForKey:@"department"];
    }
    else if (indexPath.section==0 && indexPath.row==6)
    {
        [lbl setText:@"Age"];
        txtData.text = [enterData valueForKey:@"age"];
    }
    else if (indexPath.section==0 && indexPath.row==7)
    {
        [lbl setText:@"Stu-About"];
        txtData.text = [enterData valueForKey:@"studentAbout"];
    }
    else if (indexPath.section==0 &&  indexPath.row==8)
    {
        [lbl setText:@"Stu-Education"];
        txtData.text = [enterData valueForKey:@"stuEducation"];
    }
    else if (indexPath.section==0 && indexPath.row==9)
    {
        [lbl setText:@"Tea-Education"];
        txtData.text = [enterData valueForKey:@"teaEducation"];
    }
    else if (indexPath.section==0 &&  indexPath.row==10)
    {
        [lbl setText:@"Tea-Desiganation"];
        txtData.text = [enterData valueForKey:@"teaDesiganation"];
    }
    [cell.contentView addSubview:lbl];
    [cell.contentView addSubview:txtData];
    if (indexPath.section==1 && indexPath.row==0)
    {
        [lbl setText:@"Select User"];
        [cell.contentView addSubview:btn4];
        [cell.contentView addSubview:btn5];

    }
   
    //NSLog(@"Add TextField %@",txtData);
   
    return cell;
    
    
}
-(IBAction)btnSubmit:(id)sender
{
    [enterRecord addObject:enterData];
    NSLog(@"%@",enterRecord);
  
    [[NSUserDefaults standardUserDefaults]setObject:enterRecord forKey:@"TotalData"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
   // NSLog(@"Data Dictionary : %@",[[NSUserDefaults standardUserDefaults]valueForKey:@"TotalData"]);
    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //strFirstName =textField.text;
    
    if (textField.tag == 0)
    {
        [enterData setValue:textField.text forKey:@"firstName"];
    }
    else if (textField.tag == 1)
    {
        [enterData setValue:textField.text forKey:@"lastName"];
    }
    else if (textField.tag == 2)
    {
        [enterData setValue:textField.text forKey:@"emailId"];
    }
    else if (textField.tag == 3)
    {
        [enterData setValue:textField.text forKey:@"password"];
    }
    else if (textField.tag == 4)
    {
        [enterData setValue:textField.text forKey:@"conPassword"];
    }
    else if (textField.tag == 5)
    {
        [enterData setValue:textField.text forKey:@"department"];
    }
    else if (textField.tag == 6)
    {
        [enterData setValue:textField.text forKey:@"age"];
    }
    else if (textField.tag == 7)
    {
        [enterData setValue:textField.text forKey:@"studentAbout"];
    }
    else if (textField.tag == 8)
    {
        [enterData setValue:textField.text forKey:@"stuEducation"];
    }
    else if (textField.tag == 9)
    {
        [enterData setValue:textField.text forKey:@"teaEducation"];
    }
    else if (textField.tag == 10)
    {
        [enterData setValue:textField.text forKey:@"teaDesiganation"];
    }
    return YES;
    
    
    NSLog(@"%@",enterData);
}
#pragma mark  - UITextfield
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    return YES;
    //return [textField resignFirstResponder];
    
}
//-(void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    if (textField.tag >= 1)
//    {
//        
//        [tableReg scrollRectToVisible:CGRectMake(textField.frame.origin.x,textField.frame.origin.y + 180,textField.frame.size.width,textField.frame.size.height) animated:YES];
//    }
//}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
