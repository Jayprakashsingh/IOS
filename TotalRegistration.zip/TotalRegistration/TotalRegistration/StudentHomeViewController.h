//
//  StudentHomeViewController.h
//  TotalRegistration
//
//  Created by BL@CK on 5/19/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StudentHomeViewController : UIViewController
{
    IBOutlet  UILabel *firstname;
    IBOutlet  UILabel *lastname;

}
@end
