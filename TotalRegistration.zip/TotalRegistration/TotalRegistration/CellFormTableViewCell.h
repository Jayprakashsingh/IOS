//
//  CellFormTableViewCell.h
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellFormTableViewCell : UITableViewCell
{
    IBOutlet UIView *viewStudent;
    IBOutlet UIView *viewTeacher;
    
}
- (IBAction)studentShow:(id)sender;
- (IBAction)teacherShow:(id)sender;

@property(nonatomic,strong)IBOutlet UITextField *fName;
@property(nonatomic,strong)IBOutlet UITextField *lName;
@property(nonatomic,strong)IBOutlet UITextField *emailId;
@property(nonatomic,strong)IBOutlet UITextField *password;
@property(nonatomic,strong)IBOutlet UITextField *department;
@property(nonatomic,strong)IBOutlet UITextField *conPassword;

@property(nonatomic,strong)IBOutlet UITextField *age;
@property(nonatomic,strong)IBOutlet UITextField *studentAbout;
@property(nonatomic,strong)IBOutlet UITextField *stuEducation;
@property(nonatomic,strong)IBOutlet UITextField *teaEducation;;
@property(nonatomic,strong)IBOutlet UITextField *teaDesiganation;
@end
