//
//  TeacherHomeViewController.h
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeacherHomeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UITableView *tableTeacher;
    NSMutableArray *stuName;
}
@end
