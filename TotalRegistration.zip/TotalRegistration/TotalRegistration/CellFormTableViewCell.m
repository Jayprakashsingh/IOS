//
//  CellFormTableViewCell.m
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "CellFormTableViewCell.h"
#import "NewRegisterViewController.h"
@implementation CellFormTableViewCell
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
  
    // Configure the view for the selected state
   
}

- (IBAction)studentShow:(id)sender
{
//    UITextField *objText=[[UITextField alloc] init];
//    [objText setFrame:CGRectMake(150, 450, 130, 30)];
//    objText.backgroundColor=[UIColor redColor];
//    [self.contentView addSubview:objText];
//    
   //[objText removeFromSuperview];
   // viewStudent=[[UIView alloc] init];
     [viewTeacher removeFromSuperview];
    [self.contentView addSubview:viewStudent];
    
    
}

- (IBAction)teacherShow:(id)sender
{
    [viewStudent removeFromSuperview];
   // viewTeacher=[[UIView alloc] init];
    [self.contentView addSubview:viewTeacher];
    

}


@end
