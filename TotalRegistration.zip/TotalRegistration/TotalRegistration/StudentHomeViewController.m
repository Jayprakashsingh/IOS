//
//  StudentHomeViewController.m
//  TotalRegistration
//
//  Created by BL@CK on 5/19/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "StudentHomeViewController.h"
#import "NewRegisterViewController.h"

@interface StudentHomeViewController ()
{
    NSMutableArray *sample;
    NSString *n1,*n2;
}
@end

@implementation StudentHomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self addNavigationBarButton];

        if (![[NSUserDefaults standardUserDefaults]objectForKey:@"TotalData"])
    {
        sample = [[NSMutableArray alloc]init];
    }
    else
    {
        sample =  [[[NSUserDefaults standardUserDefaults]objectForKey:@"TotalData"] mutableCopy];
        
       // NSLog(@"FULL RECORD%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"enterRecord"]);
        n1=[[sample valueForKey:@"firstName"] objectAtIndex:0];
        n2=[[sample valueForKey:@"lastName"] objectAtIndex:0];
        firstname.text=n1;
        lastname.text=n2;
        
    }
    
    // Do any additional setup after loading the view from its nib.
}
-(void)addNavigationBarButton{
    UIBarButtonItem *myedit = [[UIBarButtonItem alloc] initWithTitle:
                @"EDIT" style:UIBarButtonItemStyleBordered target:
                                 self action:@selector(editButton:)];
    UIBarButtonItem *mylog = [[UIBarButtonItem alloc] initWithTitle:
                @"LOGOUT" style:UIBarButtonItemStyleBordered target:
                                 self action:@selector(logoutButton:)];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    [self.navigationItem setRightBarButtonItem:myedit];
    self.navigationItem.hidesBackButton = YES;
    [self.navigationItem setLeftBarButtonItem:mylog];
}
-(IBAction)editButton:(id)sender
{
    

}
-(IBAction)logoutButton:(id)sender
{
    
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
