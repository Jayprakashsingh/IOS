//
//  NewRegisterViewController.h
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewRegisterViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
{

    IBOutlet UITableView *tableReg;
    NSString *str;
}
- (IBAction)btnSubmit:(id)sender;



@end
