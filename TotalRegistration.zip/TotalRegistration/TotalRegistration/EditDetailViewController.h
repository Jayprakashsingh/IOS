//
//  EditDetailViewController.h
//  TotalRegistration
//
//  Created by BL@CK on 5/21/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditDetailViewController : UIViewController

@end
