//
//  ViewController.m
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"
#import "NewRegisterViewController.h"
#import "StudentHomeViewController.h"
#import "TeacherHomeViewController.h"
@interface ViewController ()
{
    NSMutableArray *sample;
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [objScroll setContentSize:CGSizeMake(320,600)];
    imageLogo = [[UIImageView alloc] initWithFrame:CGRectMake(80, 50,     200, 80)];
    [imageLogo setImage:[UIImage imageNamed:@"6.jpeg"]];
    [objScroll addSubview:imageLogo];


	// Do any additional setup after loading the view, typically from a nib.
}
-(void)viewWillAppear:(BOOL)animated
{
    if (![[NSUserDefaults standardUserDefaults]objectForKey:@"TotalData"])
    {
        sample = [[NSMutableArray alloc]init];
    }
    else
    {
        sample =  [[[NSUserDefaults standardUserDefaults]objectForKey:@"TotalData"] mutableCopy];
        
        NSLog(@"FULL RECORD%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"enterRecord"]);
        s1=[[sample valueForKey:@"emailId"]objectAtIndex:0];
        s2=[[sample valueForKey:@"password"]objectAtIndex:0];
        
        NSLog(@"%@ %@",s1,s2);
    
    }
  
    
            

}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag >= 1)
    {
        
        [objScroll scrollRectToVisible:CGRectMake(textField.frame.origin.x,textField.frame.origin.y + 180,textField.frame.size.width,textField.frame.size.height) animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnNewReg:(id)sender
{
    
    
    NewRegisterViewController *objReg=[[NewRegisterViewController alloc] initWithNibName:@"NewRegisterViewController" bundle:nil];
    [self.navigationController pushViewController:objReg animated:YES];

}
- (IBAction)btnSignIn:(id)sender
{
   
    if ([emailId.text isEqualToString:s1]&&[password.text isEqualToString:s2])
    {
        
//        StudentHomeViewController *objStu=[[StudentHomeViewController alloc] initWithNibName:@"StudentHomeViewController" bundle:nil];
//        [self.navigationController pushViewController:objStu animated:YES];
        TeacherHomeViewController *objTea=[[TeacherHomeViewController alloc]initWithNibName:@"TeacherHomeViewController" bundle:nil];
        [self.navigationController pushViewController:objTea animated:YES];
        

    }
    else
    {
        NSLog(@"YOUR EMAIL-ID AND PASSWORD IS NOT CORRECT");
        
    }

    
   }
@end
