//
//  TeacherHomeViewController.m
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "TeacherHomeViewController.h"
#import "ViewController.h"

@interface TeacherHomeViewController ()
{
    NSMutableArray *sample;
    NSString *n1,*n2;
}
@end

@implementation TeacherHomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    if (![[NSUserDefaults standardUserDefaults]objectForKey:@"TotalData"])
    {
        sample = [[NSMutableArray alloc]init];
    }
    else
    {
        sample =  [[[NSUserDefaults standardUserDefaults]objectForKey:@"TotalData"] mutableCopy];
        
        // NSLog(@"FULL RECORD%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"enterRecord"]);
        n1=[[sample valueForKey:@"firstName"] objectAtIndex:0];
        n2=[[sample valueForKey:@"lastName"] objectAtIndex:0];
        stuName=[NSMutableArray new];
        [stuName addObject:n1];
        [stuName addObject:n2];

        
    }
     [self addNavigationBarButton];
    // Do any additional setup after loading the view from its nib.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [stuName count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"data"];
    cell.textLabel.text=[stuName objectAtIndex:indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}
-(void)addNavigationBarButton{
    UIBarButtonItem *myNavBtn = [[UIBarButtonItem alloc] initWithTitle:
                @"LOGOUT" style:UIBarButtonItemStyleBordered target:
                    self action:@selector(logoutButton:)];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    self.navigationItem.title = n1;
    
    [self.navigationItem setRightBarButtonItem:myNavBtn];
    self.navigationItem.hidesBackButton = YES;
    
}
-(IBAction)logoutButton:(id)sender
{

[self.navigationController popToRootViewControllerAnimated:YES];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
