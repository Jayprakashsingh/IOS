//
//  ViewController.h
//  TotalRegistration
//
//  Created by BL@CK on 5/18/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
    IBOutlet UIScrollView *objScroll;
    IBOutlet UIImageView *imageLogo;

    IBOutlet UITextField *emailId;

    IBOutlet UITextField *password;
    NSString *s1,*s2;
}
- (IBAction)btnSignIn:(id)sender;
- (IBAction)btnNewReg:(id)sender;




@end
