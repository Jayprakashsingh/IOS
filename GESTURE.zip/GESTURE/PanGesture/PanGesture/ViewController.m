//
//  ViewController.m
//  PanGesture
//
//  Created by BL@CK on 7/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    
    UIPanGestureRecognizer *panRecognizer=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];
    [myView addGestureRecognizer:panRecognizer];
    
   // UIPanGestureRecognizer *panRecognizerimage=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handleimagePan:)];
    //[myView addGestureRecognizer:panRecognizerimage];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)handleimagePan:(UIPanGestureRecognizer *)imagerecognizer
{
    CGPoint touchLocation = [imagerecognizer locationInView:self.view];
    
    imagepan.center = touchLocation;
    
}
-(void)handlePan:(UIPanGestureRecognizer *)recognizer
{
    CGPoint touchLocation = [recognizer locationInView:self.view];
    
    myView.center = touchLocation;

    
    CGPoint velocity=[recognizer velocityInView:myView];
    lblHorizontal.text=[NSString stringWithFormat:@"Horizontal Velocity: %.2f points/sec",velocity.x];
    lblVertical.text=[NSString stringWithFormat:@"Vertical Velocity: %.2f points/sec", velocity.y];

}
@end
