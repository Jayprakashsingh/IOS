//
//  ViewController.h
//  PanGesture
//
//  Created by BL@CK on 7/27/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIView *myView,*smallView;
    IBOutlet UILabel *lblHorizontal,*lblVertical;
    IBOutlet UIImageView *imagepan;
    CGFloat firstX,firstY,endX,endY,changeX,changeY;
}
@end
