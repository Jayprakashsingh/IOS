//
//  ViewController.h
//  RotateGesture
//
//  Created by BL@CK on 7/26/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIImageView *imageRotation,*imageSwipe;
}
@end
