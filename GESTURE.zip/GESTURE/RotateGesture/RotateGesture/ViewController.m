//
//  ViewController.m
//  RotateGesture
//
//  Created by BL@CK on 7/26/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    UIRotationGestureRecognizer *rotationGesture=[[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotationGesturehandle:)];
    [self.view addGestureRecognizer:rotationGesture];
    
    UISwipeGestureRecognizer *swipeGesture=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGesture:)];
    //swipeGesture.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:swipeGesture];
    
}
-(void)rotationGesturehandle:(UIRotationGestureRecognizer *)rotationRecognizer
{
    imageRotation.transform=CGAffineTransformRotate(imageRotation.transform, rotationRecognizer.rotation);
    rotationRecognizer.rotation=0;
    
}
-(void)swipeGesture:(UISwipeGestureRecognizer *)swipeRecognizer
{
    [UIView animateWithDuration:5 animations:^{
        if (swipeRecognizer.direction == UISwipeGestureRecognizerDirectionLeft) {
            imageSwipe.backgroundColor=[UIColor redColor];
            imageSwipe.backgroundColor=[UIColor greenColor];
        }
        else if (swipeRecognizer.direction == UISwipeGestureRecognizerDirectionRight)
        {
            imageSwipe.backgroundColor=[UIColor yellowColor];
            imageSwipe.backgroundColor=[UIColor purpleColor];
        }
        else if (swipeRecognizer.direction == UISwipeGestureRecognizerDirectionDown)
        {
            imageSwipe.backgroundColor=[UIColor orangeColor];
            imageSwipe.backgroundColor=[UIColor whiteColor];
        }
 
    }];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
