//
//  ViewController.m
//  TapGesture
//
//  Created by BL@CK on 7/26/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    UITapGestureRecognizer *tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(TapGestureClicked:)];
    tapGesture.numberOfTapsRequired=2;
    tapGesture.numberOfTouchesRequired=1;
    [self.view addGestureRecognizer:tapGesture];
    
    UIPinchGestureRecognizer *pinchGesture=[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(PinchGestureClicked:)];
    [imagePinch addGestureRecognizer:pinchGesture];
    
    
    
    
}
-(void)TapGestureClicked:(UITapGestureRecognizer *)sender
{
   // [imageTap setFrame:CGRectMake(imageTap.frame.origin.x, imageTap.frame.origin.y, imageTap.frame.size.width+100, imageTap.frame.size.height+50)];
    imageTap.backgroundColor=[UIColor yellowColor];
}
-(IBAction)PinchGestureClicked:(UIPinchGestureRecognizer *)pinchRecognizer
{
    pinchRecognizer.view.transform=CGAffineTransformScale(pinchRecognizer.view.transform, pinchRecognizer.scale, pinchRecognizer.scale);
    pinchRecognizer.scale=1;
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
