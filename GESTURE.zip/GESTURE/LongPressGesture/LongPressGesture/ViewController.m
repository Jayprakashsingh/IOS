//
//  ViewController.m
//  LongPressGesture
//
//  Created by BL@CK on 7/28/16.
//  Copyright (c) 2016 Agile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    UILongPressGestureRecognizer *longPress=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressHandler:)];
    longPress.minimumPressDuration=1.0f;
    [myView addGestureRecognizer:longPress];
    
}
-(void)longPressHandler:(UILongPressGestureRecognizer *)recognizer
{
   
            [[[UIAlertView alloc] initWithTitle:@"YOU PRESS" message:@"view is press long" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
    

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
